#include "common.h"
#include "radio.h"
#include "CMT2310A_def.h"
#include "CMT2310A_reg.h"
#include "cmt2310a_params.h"

CMT2310A_CFG	g_radio;					//

unsigned char g_reg_read_buf[128];

	

/******************************
**Name:  vRadioInit
**Func:  Radio config spi & reset
**Input: None
*Output: None
********************************/
void vRadioInit(void)
{
	vRadioSoftReset();

	vRadioConfigPageReg(0, g_cmt2310a_page0, CMT2310A_PAGE0_SIZE);		//config page 0
	vRadioConfigPageReg(1, g_cmt2310a_page1, CMT2310A_PAGE1_SIZE);   	//config page 1

	vRadioSetNirq(CMT2310A_nIRQ_TCXO);	//for TCXO need cofig as nIRQ pin at first 	
	vRadioTcxoDrvSel(0);				//drive power 
	
	vRadioPowerUpBoot();				
	delay(10);
	
	bRadioGoStandby();
	delay(2);
	bRadioApiCommand(0x02);				//
	delay(10);
	bRadioApiCommand(0x01);				//IR Calibration, need some times

	vRadioCapLoad(2);					//Xo Cap 

	//GPIOn default setting
	vRadioSetGpio0(CMT2310A_GPIO0_INT3);
	vRadioSetGpio1(CMT2310A_GPIO1_INT2);	
	vRadioSetGpio2(CMT2310A_GPIO2_DCLK);
	vRadioSetGpio3(CMT2310A_GPIO3_DOUT);		
	vRadioSetGpio4(CMT2310A_GPIO4_INT1);							
	vRadioSetGpio5(CMT2310A_GPIO5_nRST);
	
	
	//INT1 = RX_FIFO_WBYTE,   INT2 = PKT_DONE
	vRadioSetInt1Sel(INT_SRC_RX_FIFO_WBYTE);
	vRadioSetInt2Sel(INT_SRC_PKT_DONE);
	vRadioSetInt1Polar(FALSE);
	vRadioSetInt2Polar(FALSE);
	vRadioSetInt3Polar(FALSE);
	
	//interrupt source enable config
	g_radio.int_src_en._BITS.PKT_DONE_EN   		= 1;
	g_radio.int_src_en._BITS.CRC_PASS_EN   		= 1;
	g_radio.int_src_en._BITS.ADDR_PASS_EN  		= 0;
	g_radio.int_src_en._BITS.SYNC_PASS_EN  		= 1;
	g_radio.int_src_en._BITS.PREAM_PASS_EN 		= 1;
	g_radio.int_src_en._BITS.TX_DONE_EN    		= 1;
	g_radio.int_src_en._BITS.RX_TOUT_EN    		= 1;			
	g_radio.int_src_en._BITS.LD_STOP_EN    		= 0;
	g_radio.int_src_en._BITS.LBD_STOP_EN   		= 0;
	g_radio.int_src_en._BITS.LBD_STAT_EN   		= 0;
	g_radio.int_src_en._BITS.PKT_ERR_EN    		= 0;
	g_radio.int_src_en._BITS.RSSI_COLL_EN  		= 0;
	g_radio.int_src_en._BITS.OP_CMD_FAILED_EN 	= 0;
	g_radio.int_src_en._BITS.RSSI_PJD_EN   		= 0;
	g_radio.int_src_en._BITS.SEQ_MATCH_EN  		= 0;
	g_radio.int_src_en._BITS.NACK_RECV_EN       = 0;
	g_radio.int_src_en._BITS.TX_RESEND_DONE_EN  = 0;
	g_radio.int_src_en._BITS.ACK_RECV_FAILED_EN = 0;
	g_radio.int_src_en._BITS.TX_DC_DONE_EN      = 0;
	g_radio.int_src_en._BITS.CSMA_DONE_EN       = 0;
	g_radio.int_src_en._BITS.CCA_STAT_EN        = 0;
	g_radio.int_src_en._BITS.API_DONE_EN        = 0;
	g_radio.int_src_en._BITS.TX_FIFO_TH_EN		= 1;
	g_radio.int_src_en._BITS.TX_FIFO_NMTY_EN	= 1;
	g_radio.int_src_en._BITS.TX_FIFO_FULL_EN	= 1;
	g_radio.int_src_en._BITS.RX_FIFO_OVF_EN		= 1;
	g_radio.int_src_en._BITS.RX_FIFO_TH_EN		= 1;
	g_radio.int_src_en._BITS.RX_FIFO_NMTY_EN	= 1;
	g_radio.int_src_en._BITS.RX_FIFO_FULL_EN 	= 1;
	vRadioInterruptSoucreCfg(&g_radio.int_src_en);
		
	//packet preamble config
	g_radio.preamble_cfg.PREAM_LENG_UNIT = 0;					//8-bits mode	
	g_radio.preamble_cfg.PREAM_VALUE     = 0xAA;				//
	g_radio.preamble_cfg.RX_PREAM_SIZE   = 2;					//
	g_radio.preamble_cfg.TX_PREAM_SIZE   = 16;	
	vRadioCfgPreamble(&g_radio.preamble_cfg);
	
	//packet syncword config
	g_radio.sync_cfg.SYN_CFG_u._BITS.SYNC_MAN_EN   = 0;			//disable syncword manchester coding
	g_radio.sync_cfg.SYN_CFG_u._BITS.SYNC_SIZE     = 2;			//enable 3 bytes for syncword 
	g_radio.sync_cfg.SYN_CFG_u._BITS.SYNC_TOL      = 0;
	g_radio.sync_cfg.SYN_CFG_u._BITS.SYNC_MODE_SEL = 0;			//compatible 802.15.4
	g_radio.sync_cfg.SYNC_VALUE[0] = 0xAA;
	g_radio.sync_cfg.SYNC_VALUE[1] = 0x2D;
	g_radio.sync_cfg.SYNC_VALUE[2] = 0xD4;
	g_radio.sync_cfg.SYNC_VALUE_SEL= 0;							//select SYN_VAL
	vRadioCfgSyncWord(&g_radio.sync_cfg);

	//packet node address config
	g_radio.addr_cfg.ADDR_CFG_u._BITS.ADDR_DET_MODE = 0;		//disable Node Address
	vRadioCfgNodeAddr(&g_radio.addr_cfg);				
	
	//packet crc config
	g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_EN         = 1;			//enable crc
	g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_BIT_ORDER  = 0;
	g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_REFIN      = 0;
	g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_RANGE      = 0;
	g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_BIT_INV    = 0;
	g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_BYTE_SWAP  = 0;
	g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_REFOUT     = 0;			//whole payload
	g_radio.crc_cfg.CRC_CFG_u._BITS.CRCERR_CLR_FIFO_EN  = 0;	//note: need ative FIFO_AUTO_CLR_RX_EN = 1 or call vRadioFifoAutoClearGoRx(1)
	g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_SIZE       = 1;			//crc-16 mode
	g_radio.crc_cfg.CRC_POLY_u.u32_POLY = 0x10210000;
	g_radio.crc_cfg.CRC_SEED_u.u32_SEED = 0x00000000;
	vRadioCfgCrc(&g_radio.crc_cfg);
	
	//packet coding format
	g_radio.coding_format_cfg.CODING_FORMAT_CFG_u._BITS.MANCH_EN          = 0;	
	g_radio.coding_format_cfg.CODING_FORMAT_CFG_u._BITS.MANCH_TYPE        = 0;
	g_radio.coding_format_cfg.CODING_FORMAT_CFG_u._BITS.WHITEN_EN         = 0;
	g_radio.coding_format_cfg.CODING_FORMAT_CFG_u._BITS.WHITEN_TYPE       = 0;
	g_radio.coding_format_cfg.CODING_FORMAT_CFG_u._BITS.WHITEN_SEED_TYP   = 0;
	g_radio.coding_format_cfg.CODING_FORMAT_CFG_u._BITS.FEC_EN            = 0;
	g_radio.coding_format_cfg.CODING_FORMAT_CFG_u._BITS.FEC_RSC_NRNSC_SEL = 0;
	g_radio.coding_format_cfg.CODING_FORMAT_CFG_u._BITS.FEC_TICC          = 0;
	g_radio.coding_format_cfg.WHITEN_SEED  = 0x01FF;		
	g_radio.coding_format_cfg.FEC_PAD_CODE = 0;
	vRadioCfgCodeFormat(&g_radio.coding_format_cfg);
	
	//packet frame format
	g_radio.frame_cfg.DATA_MODE = 2;								//0=direct mode, 	2=packet mode
	g_radio.frame_cfg.FRAME_CFG1_u._BITS.PKT_TYPE 	       = 0;		//fixd-length packet mode
	g_radio.frame_cfg.FRAME_CFG1_u._BITS.PAYLOAD_BIT_ORDER = 0;		//msb first
	g_radio.frame_cfg.FRAME_CFG1_u._BITS.ADDR_LEN_CONF     = 0;		
	g_radio.frame_cfg.FRAME_CFG1_u._BITS.PAGGYBACKING_EN   = 0;
	g_radio.frame_cfg.FRAME_CFG1_u._BITS.LENGTH_SIZE 	   = 0;
	g_radio.frame_cfg.FRAME_CFG1_u._BITS.INTERLEAVE_EN     = 0;		//note: when FEC enable, INTERLEAVE_EN should be set 1	

	g_radio.frame_cfg.FRAME_CFG2_u._BITS.TX_PREFIX_TYPE    = TX_PREFIX_SEL_PREAMBLE;		//transmit preamble
	g_radio.frame_cfg.FRAME_CFG2_u._BITS.SEQNUM_EN  	   = 0;
	g_radio.frame_cfg.FRAME_CFG2_u._BITS.SEQNUM_AUTO_INC   = 0;
	g_radio.frame_cfg.FRAME_CFG2_u._BITS.SEQNUM_SIZE	   = 0;
	g_radio.frame_cfg.FRAME_CFG2_u._BITS.SEQNUM_MACH_EN    = 0;
	g_radio.frame_cfg.FRAME_CFG2_u._BITS.FCS2_EN    	   = 0;
	
	g_radio.frame_cfg.TX_PKT_NUM     = 0;
	g_radio.frame_cfg.TX_PKT_GAP     = 0;
	g_radio.frame_cfg.FCS2_TX_IN     = 0;
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioCfgFrameFormat(&g_radio.frame_cfg);

	//Run Mode Config
	g_radio.word_mode_cfg.WORK_MODE_CFG1_u._BITS.TX_DC_EN          = 0;	
	g_radio.word_mode_cfg.WORK_MODE_CFG1_u._BITS.TX_ACK_EN         = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG1_u._BITS.TX_DC_PERSIST_EN  = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG1_u._BITS.TX_AUTO_HOP_EN    = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG1_u._BITS.TX_EXIT_STATE     = EXIT_TO_READY;

	g_radio.word_mode_cfg.WORK_MODE_CFG2_u._BITS.RX_DC_EN          = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG2_u._BITS.RX_AUTO_HOP_EN    = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG2_u._BITS.RX_ACK_EN         = 0;			
	g_radio.word_mode_cfg.WORK_MODE_CFG2_u._BITS.RX_TIMER_EN       = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG2_u._BITS.RX_EXIT_STATE     = EXIT_TO_READY;
	g_radio.word_mode_cfg.WORK_MODE_CFG2_u._BITS.CSMA_EN           = 0;
	
	g_radio.word_mode_cfg.WORK_MODE_CFG3_u._BITS.PKT_DONE_EXIT_EN  = 0;			
	g_radio.word_mode_cfg.WORK_MODE_CFG3_u._BITS.RX_HOP_SLP_MODE   = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG3_u._BITS.SLP_MODE          = 0;
	
	g_radio.word_mode_cfg.WORK_MODE_CFG4_u._BITS.LFCLK_OUT_EN      = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG4_u._BITS.LFCLK_SEL         = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG4_u._BITS.SLEEP_TIMER_EN    = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG4_u._BITS.TIMER_RAND_MODE   = 0;
	
	g_radio.word_mode_cfg.WORK_MODE_CFG5_u._BITS.CSMA_CCA_MODE     = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG5_u._BITS.CSMA_CCA_WIN_SEL  = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG5_u._BITS.CSMA_CCA_INT_SEL  = 0;
	g_radio.word_mode_cfg.WORK_MODE_CFG5_u._BITS.CSMA_PERSIST_EN   = 0;
	
	g_radio.word_mode_cfg.FREQ_CHANL_NANU  = 0;
	g_radio.word_mode_cfg.FREQ_DONE_TIMES  = 0;
	g_radio.word_mode_cfg.FREQ_SPACE       = 0;
	g_radio.word_mode_cfg.FREQ_TIMES       = 0;
	g_radio.word_mode_cfg.SLEEP_TIMER_M    = 0;
	g_radio.word_mode_cfg.SLEEP_TIMER_R    = 0;
	g_radio.word_mode_cfg.RX_TIMER_T1_M    = 0;					//M*2^(R+1)*5us=M*2^R*10us,   
	g_radio.word_mode_cfg.RX_TIMER_T1_R    = 0;					//R=7, unit=0.64ms
	g_radio.word_mode_cfg.RX_TIMER_T2_M    = 0;
	g_radio.word_mode_cfg.RX_TIMER_T2_R    = 0;
	g_radio.word_mode_cfg.RX_TIMER_CSMA_M  = 0;
	g_radio.word_mode_cfg.RX_TIMER_CSMA_R  = 0;
	g_radio.word_mode_cfg.TX_DC_TIMES      = 0;
	g_radio.word_mode_cfg.TX_RS_TIMES      = 0;					
	g_radio.word_mode_cfg.CSMA_TIMES       = 0;
	g_radio.word_mode_cfg.SLEEP_TIMER_CSMA_M = 0;
	g_radio.word_mode_cfg.SLEEP_TIMER_CSMA_R = 0;
	vRadioCfgWorkMode(&g_radio.word_mode_cfg);

	//FIFO Init
	vRadioFifoMerge(FALSE);
	vRadioSetFifoTH(30);
	vRadioClearRxFifo();										//reset & clear fifo
	vRadioClearTxFifo();	

	vRadioFifoAutoClearGoRx(TRUE);								//when crc error, need to auto clear fifo, should enable

	vRadioRssiUpdateSel(CMT2310A_RSSI_UPDATE_ALWAYS);
	
	vRadioSetAntSwitch(FALSE, FALSE);							//
	
	vRadioDcdcCfg(FALSE);										//dc-dc off
}

void vRadioClearInterrupt(void)
{
	vRadioInterruptSoucreFlag(&g_radio.int_src_flag);

	g_radio.int_src_clear._BITS.SLEEP_TMO_CLR = g_radio.int_src_flag._BITS.SLEEP_TMO_FLG;
	g_radio.int_src_clear._BITS.RX_TMO_CLR    = g_radio.int_src_flag._BITS.RX_TMO_FLG;
	g_radio.int_src_clear._BITS.TX_DONE_CLR   = g_radio.int_src_flag._BITS.TX_DONE_FLG;

	g_radio.int_src_clear._BITS.PKT_DONE_CLR  = g_radio.int_src_flag._BITS.PKT_DONE_FLG;
	g_radio.int_src_clear._BITS.CRC_PASS_CLR  = g_radio.int_src_flag._BITS.CRC_PASS_FLG;
	g_radio.int_src_clear._BITS.ADDR_PASS_CLR = g_radio.int_src_flag._BITS.ADDR_PASS_FLG;
	g_radio.int_src_clear._BITS.SYNC_PASS_CLR = g_radio.int_src_flag._BITS.SYNC_PASS_FLG|g_radio.int_src_flag._BITS.SYNC1_PASS_FLG;
	g_radio.int_src_clear._BITS.PREAM_PASS_CLR= g_radio.int_src_flag._BITS.PREAM_PASS_FLG;

	g_radio.int_src_clear._BITS.LBD_STAT_CLR      = g_radio.int_src_flag._BITS.LBD_STATUS_FLG;
	g_radio.int_src_clear._BITS.PKT_ERR_CLR       = g_radio.int_src_flag._BITS.PKT_ERR_FLG;
	g_radio.int_src_clear._BITS.RSSI_COLL_CLR     = g_radio.int_src_flag._BITS.RSSI_COLL_FLG;
	g_radio.int_src_clear._BITS.OP_CMD_FAILED_CLR = g_radio.int_src_flag._BITS.OP_CMD_FAILED_FLG;	
	g_radio.int_src_clear._BITS.ANT_LOCK_CLR      = g_radio.int_src_flag._BITS.ANT_LOCK_FLG;
	
	g_radio.int_src_clear._BITS.SEQ_MATCH_CLR       = g_radio.int_src_flag._BITS.SEQ_MATCH_FLG;
	g_radio.int_src_clear._BITS.NACK_RECV_CLR       = g_radio.int_src_flag._BITS.NACK_RECV_FLG;	
	g_radio.int_src_clear._BITS.TX_RESEND_DONE_CLR  = g_radio.int_src_flag._BITS.TX_RESEND_DONE_FLG ;
	g_radio.int_src_clear._BITS.ACK_RECV_FAILED_CLR = g_radio.int_src_flag._BITS.ACK_RECV_FAILED_FLG;
	g_radio.int_src_clear._BITS.TX_DC_DONE_CLR      = g_radio.int_src_flag._BITS.TX_DC_DONE_FLG;
	g_radio.int_src_clear._BITS.CSMA_DONE_CLR       = g_radio.int_src_flag._BITS.CSMA_DONE_FLG;
	g_radio.int_src_clear._BITS.CCA_STATUS_CLR      = g_radio.int_src_flag._BITS.CCA_STATUS_FLG;
	g_radio.int_src_clear._BITS.API_DONE_CLR        = g_radio.int_src_flag._BITS.API_DONE_FLG;

 	vRadioInterruptSoucreClear(&g_radio.int_src_clear);
}	

void vRadioReadAllStatus(void)
{
	bRadioGetState();									
	vRadioFifoGetStatus(&g_radio.fifo_status_flag);		
	vRadioInterruptSoucreFlag(&g_radio.int_src_flag);	
	
	bRadioReadReg(CMT2310A_CTL_REG_04);					
	bRadioReadReg(CMT2310A_CTL_REG_05);							
	bRadioReadReg(CMT2310A_CTL_REG_06);							
			
	bRadioReadReg(CMT2310A_CTL_REG_16);					
	bRadioReadReg(CMT2310A_CTL_REG_17);					
}	

void vRadioCmpReg(byte const wr_ptr[], byte rd_ptr[], byte cmp_ptr[], byte length)
{
	byte i;
	
	for(i=0; i<length; i++)
		{
		if(wr_ptr[i]!=rd_ptr[i])
			cmp_ptr[i] = 0xFF;
		else
			cmp_ptr[i] = 0x00;
		}
}	

void vRadioGoTxInit(void)
{


}

void vRadioGoRxInit(void)
{


}
