#ifndef __RADIO_H__
	#define 	__RADIO_H__

	#include "radio_phy.h"
	#include "radio_mac.h"
	#include "CMT2310A_def.h"
	#include "CMT2310A_reg.h"	

#ifdef __cplusplus
extern "C" {
#endif
	
	void vRadioInit(void);
	void vRadioClearInterrupt(void);
	void vRadioReadAllStatus(void);
	void vRadioCmpReg(byte const wr_ptr[], byte rd_ptr[], byte cmp_ptr[], byte length);
	void vRadioGoTxInit(void);
	void vRadioGoRxInit(void);
	
#ifdef __cplusplus
}
#endif	
#endif	
