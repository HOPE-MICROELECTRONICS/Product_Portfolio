#include "radio_spi.h"	
#include <SPI.h>


#define		SPI_DUMMY_VALUE		0x00

/******************************
**Name: vSpiMasterInit
**Func: SPI Master
**Input: None
*Output: None
********************************/
void vSpiMasterInit(void)
{
	//SPI_CLOCK_DIV2/4/8/16/32/64/128	default :Fcpu/4
	SPI.setClockDivider(SPI_CLOCK_DIV16);	//1Mhz spi rate
	SPI.begin();
	SOFT_SPI_nSS_DIRSET();
}	


unsigned char bSpiWriteByte(unsigned char spi_adr, unsigned char spi_dat) 
{
	unsigned char tmp;
	ClrnSS();
	SPI.transfer(spi_adr&0x7F);
	tmp = SPI.transfer(spi_dat);
	SetnSS();
	return tmp;
}	

unsigned char bSpiReadByte(unsigned char spi_adr)
{
	unsigned char tmp;
	ClrnSS();
	SPI.transfer(spi_adr|0x80);
	tmp = SPI.transfer(SPI_DUMMY_VALUE);
	SetnSS();
	return(tmp);
}

void vSpiBurstWrite(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length)
{
	unsigned char i;
	ClrnSS();
	SPI.transfer(spi_adr&0x7F);
	for(i=0; i<spi_length; i++)
		SPI.transfer(*(spi_dat+i));
	SetnSS();
}	

void vSpiBurstRead(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length)
{
	unsigned char i;
	if(spi_length!=0)
	{
		ClrnSS();
		SPI.transfer(spi_adr|0x80);
		for(i=0; i<spi_length; i++)
			spi_dat[i] = SPI.transfer(SPI_DUMMY_VALUE);
		SetnSS();
	}	
}	
