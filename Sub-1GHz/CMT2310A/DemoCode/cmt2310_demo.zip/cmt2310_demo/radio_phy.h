

#ifndef __RADIO_PHY_H

	#define 	__RADIO_PHY_H
	
	#include "radio_hal.h"	
	#include "CMT2310A_def.h"
	#include "CMT2310A_reg.h"
	
#ifdef __cplusplus
extern "C" {
#endif	
	void 	 	 vRadioSetInt1Sel(unsigned char int1_sel);
	void 		 vRadioSetInt2Sel(unsigned char int2_sel);
	void 		 vRadioSetInt1Polar(unsigned char int1_polar);
	void 		 vRadioSetInt2Polar(unsigned char int2_polar);
	void 		 vRadioSetInt3Polar(unsigned char int3_polar);

	
	void 		 vRadioRssiUpdateSel(unsigned char sel);
	unsigned char bRadioGetRssi(void);
	void 		 vRadioRssiConfig(RSSI_CFG rssi_cfg);
	void 		 vRadioRssiCalOffset(unsigned char cal_offset);
	
	unsigned char bRadioGetLbdValue(void);
	void 		 vRadioSetLbdTH(unsigned char lbd_th);	
	unsigned char bRadioGetTemperature(void);
	unsigned char 	 bRadioApiCommand(unsigned char api_cmd);
	void          vRadioCdrModeCfg(enum CDR_MODE cdr_mode);
	void 		 vRadioTxRampCfg(unsigned char tx_ramp_en, unsigned short tx_ramp_step);
	void 		 vRadioTxGaussianCfg(unsigned char tx_gaus_en, unsigned char tx_gaus_bt);
	void 		 vRadioAfcCfg(unsigned char afc_en);
	
	unsigned char bRadioGetState(void);
	unsigned char bRadioGoSleep(void);
	unsigned char bRadioGoStandby(void);
	unsigned char bRadioGoTx(void);
	unsigned char bRadioGoRx(void);
	unsigned char bRadioGoTxFS(void);
	unsigned char bRadioGoRxFS(void);
	
	
	void 		 vRadioSetFifoTH(unsigned short int fifo_th);
	void 		 vRadioFifoRetent(unsigned char cfg_en);
	void 		 vRadioFifoAutoClearGoRx(unsigned char cfg_en);
	void 		 vRadioFifoAutoRestoreWhenTxDone(unsigned char cfg_en);
	void 		 vRadioFifoMerge(unsigned char cfg_en);
	void 		 vRadioFifoTRxUsageSel(unsigned char cfg_tx);
	void 		 vRadioFifoGetStatus(FIFO_STATUS_FLG *fifo_status);
	void 		 vRadioClearTxFifo(void);
	void 		 vRadioClearRxFifo(void);
	void 		 vRadioManualResetTxFifoPointer(void);
	
	void 		 vRadioInterruptSoucreCfg(INT_SRC_CFG *int_src_ctrl);
	void 		 vRadioInterruptSoucreFlag(INT_SRC_FLG *int_src_flag);
	void 		 vRadioInterruptSoucreClear(INT_SRC_CLR *int_src_clr);


	void 		 vRadioConfigPageReg(byte page_sel, unsigned char const reg_ptr[], unsigned char reg_len);
	void 		 vRadioReadPageReg(byte page_sel, unsigned char reg_ptr[], unsigned char reg_len);
	unsigned char 	 bRadioIsExist(void);
	uint32_t 	 lRadioChipVersion(void);
#ifdef __cplusplus
}
#endif
#endif	
