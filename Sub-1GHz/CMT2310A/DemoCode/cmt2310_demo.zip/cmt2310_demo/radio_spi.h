#ifndef __RADIO_SPI_H
#define __RADIO_SPI_H

#include <arduino.h>

//Dirver hardware I/O define
#define MISO			12	
#define MOSI			11
#define SCK			    13	
#define nCS			    10

#define SOFT_SPI_nSS_DIRSET()      pinMode(nCS,OUTPUT)
#define SetnSS()				   digitalWrite(nCS,HIGH)
#define ClrnSS()				   digitalWrite(nCS,LOW)
	
#define SOFT_SPI_MISO_DIRSET()     pinMode(MISO,INPUT)
#define SOFT_SPI_MISO_PULLUP_SET() digitalWrite(MISO,HIGH)
#define SOFT_SPI_MISO_READ()       digitalRead(MISO)

#define SOFT_SPI_MOSI_DIRSET()     pinMode(MOSI,OUTPUT)
#define SOFT_SPI_MOSI_HI()         digitalWrite(MOSI,HIGH)
#define SOFT_SPI_MOSI_LO()         digitalWrite(MOSI,LOW)

#define SOFT_SPI_SCK_DIRSET()      pinMode(SCK,OUTPUT)
#define SOFT_SPI_SCK_HI()          digitalWrite(SCK,HIGH)
#define SOFT_SPI_SCK_LO()          digitalWrite(SCK,LOW)

#ifdef __cplusplus
extern "C" {
#endif
void vSpiMasterInit(void);
unsigned char bSpiWriteByte(unsigned char spi_adr, unsigned char spi_dat);
unsigned char bSpiReadByte(unsigned char spi_adr);
void vSpiBurstWrite(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length);
void vSpiBurstRead(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length);
#ifdef __cplusplus
}
#endif
	
#endif	
