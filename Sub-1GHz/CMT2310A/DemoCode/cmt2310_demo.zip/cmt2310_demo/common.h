#ifndef __COMMON__H__
#define __COMMON__H__

#define FALSE   0
#define TRUE    1
#define UHF_LEN		20

#endif
