

#ifndef __RADIO_HAL_H

	#define 	__RADIO_HAL_H
	
	
	#include "radio_spi.h"	
	#include "CMT2310A_def.h"
	#include "CMT2310A_reg.h"
#ifdef __cplusplus
extern "C" {
#endif	
	void 		 vRadioGpioInit(void);
	
	unsigned char bRadioReadReg(unsigned char addr);
	unsigned char bRadioWriteReg(unsigned char addr, unsigned char reg_dat);
	unsigned char bRadioSetReg(unsigned char addr, unsigned char set_bits, unsigned char mask_bits);

	void 		 vRadioLoadRegs(unsigned char sta_adr, unsigned char *ptr_buf, unsigned char length);
	void 		 vRadioStoreRegs(unsigned char sta_adr, unsigned char *ptr_buf, unsigned char length);

	void 		 vRadioBurstReadRegs(unsigned char *ptr_buf, unsigned char length);
	void 		 vRadioBurstWriteRegs(unsigned char *ptr_buf, unsigned char length);

	void 		 vRadioReadFifo(unsigned char *ptr_fifo, unsigned char length);
	void 		 vRadioWriteFifo(unsigned char *ptr_fifo, unsigned char length);
	void 		 vRadioReadTxFifo(unsigned char *ptr_fifo, unsigned char length);
	
	
	void 		 vRadioSpiModeSel(unsigned char spi_mod);	
	void 		 vRadioSetTxDin(unsigned char cfg_din, unsigned char pin_sel);
	void 		 vRadioSetDigClkOut(unsigned char cfg_out);
	void 		 vRadioSetLfxoPad(unsigned char cfg_lfxo);
	void 		 vRadioSetGpio0(unsigned char gpio0_sel);
	void 		 vRadioSetGpio1(unsigned char gpio1_sel);
	void 		 vRadioSetGpio2(unsigned char gpio2_sel);
	void 		 vRadioSetGpio3(unsigned char gpio3_sel);
	void 		 vRadioSetGpio4(unsigned char gpio4_sel);
	void 		 vRadioSetGpio5(unsigned char gpio5_sel);
	void 		 vRadioSetNirq(unsigned char nirq_sel);
	void 		 vRadioTcxoDrvSel(unsigned char drv_sel);

	void 		 vRadioRegPageSel(unsigned char page_sel);
	void 		 vRadioPowerUpBoot(void);
	void 		 vRadioSoftReset(void);
	void 		 vRadioSetPaOutputMode(unsigned char cfg_en);
	void 		 vRadioSetTxDataInverse(unsigned char cfg_en);
  	void 		 vRadioSetAntSwitch(unsigned char cfg_en, unsigned char cfg_polar);
  	
	void 		 vRadioDcdcCfg(unsigned char on_off);
	void 		 vRadioCapLoad(unsigned char cap_value);
	void 		 vRadioLfoscCfg(unsigned char on_off);
	void 		 vRadioXoWaitCfg(unsigned char div_sel); 
	#ifdef __cplusplus
}
#endif
#endif	
