#ifndef __RADIO_MAC_H

	#define 	__RADIO_MAC_H
	
	#include "radio_hal.h"	
	#include "CMT2310A_def.h"
	#include "CMT2310A_reg.h"
	
	#ifdef __cplusplus
extern "C" {
#endif
	unsigned char  bRadioGetCurrentChannl(void);

	void 		  vRadioSetTxSeqNumberInitValue(FRAME_CFG *frm_cfg);
	unsigned short wRadioGetTxSeqNumberCurrent(FRAME_CFG *frm_cfg);
 	void 		  vRadioSetTxFCS2(FRAME_CFG *frm_cfg);
	unsigned char  bRadioGetRxFCS2(FRAME_CFG *frm_cfg);
	void 		  vRadioSetPayloadLength(FRAME_CFG *frm_cfg);
	unsigned short vRadioGetPayloadLength(FRAME_CFG *frm_cfg);


	void 		  vRadioCfgPreamble(PREAMBLE_CFG *prm_ptr);
	void 		  vRadioCfgSyncWord(SYNC_CFG *sync_ptr);
	void 		  vRadioCfgNodeAddr(ADDR_CFG *node_addr_ptr);
	void 		  vRadioCfgCrc(CRC_CFG *crc_ptr);
	void			  vRadioCfgCodeFormat(CODING_FORMAT_CFG *code_format_ptr);
	void 		  vRadioCfgFrameFormat(FRAME_CFG *frame_format_ptr);
	void  		  vRadioCfgWiSunFormat(WI_SUN_CFG *wi_sun_ptr);
	void 		  vRadioCdrTracingModeCfg(CDR_TRACING_CFG *cdr_ptr);
		
	void 		  vRadioCfgWorkMode(WORK_MODE_CFG *run_mode_ptr);
	void 		  vRadioReadRunModeCfg(void);
	unsigned char  bRadioGetTxDutyCycleDoneTimes(WORK_MODE_CFG *run_mode_ptr);
	unsigned char  bRadioGetTxResendDoneTimes(WORK_MODE_CFG *run_mode_ptr);
	unsigned char  bRadioGetCMSADoneTimes(WORK_MODE_CFG *run_mode_ptr);
	
	
	extern void 		  vRadioSendWithAck(unsigned char w_ack, FRAME_CFG *frame_format_ptr);
	extern void 		  vRadioEnableTxAck(unsigned char en_flg, WORK_MODE_CFG *run_mode_ptr);
	extern void 		  vRadioEnableRxAck(unsigned char en_flg, WORK_MODE_CFG *run_mode_ptr);
	extern unsigned char  bRadioGetFreqChanl(void);
	extern unsigned char  bRadioGetHopDoneTimes(void);
	extern void 		  vRadioCsmaEnable(unsigned char on_off, WORK_MODE_CFG *run_mode_ptr);
	extern void 		  vRadioSetRssiAbsThValue(signed char rssi);
	extern void 		  vRadioSetPjdDetWin(unsigned char pjd_win);
	
#ifdef __cplusplus
}
#endif

#endif	
