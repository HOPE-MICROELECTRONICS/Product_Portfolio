#include <arduino.h>
#include "radio_spi.h"
#include "radio_phy.h"
#include "common.h"
#include "radio.h"


#define LED_PIN			    3
#define KEY_PIN				2
#define RF_GPIO4			8 

#define OutputLED()		    pinMode(LED_PIN,OUTPUT)
#define SetLED()		    digitalWrite(LED_PIN,1)
#define ClrLED()		    digitalWrite(LED_PIN,0)

#define RF_GPIO4_IN()		pinMode(RF_GPIO4, INPUT_PULLUP)
#define RF_GPIO4_H()		digitalRead(RF_GPIO4)
#define RF_GPIO4_L()		(digitalRead(RF_GPIO4)==0)

#define KEY_SET_IN()	  pinMode(KEY_PIN,INPUT_PULLUP)
#define KEY_READ()		  digitalRead(KEY_PIN)


extern  CMT2310A_CFG	g_radio;	
//radio
byte    radio_rx_buf[UHF_LEN];
byte 	radio_tx_buf[UHF_LEN];
word 	g_rx_count;
word 	g_tx_count;

const unsigned char g_title_string[] = {"2310A   SimpleCode"};


#define		WORK_MODE		1		// 3 = transmit zero
									// 2 = receive mode for sensisity test
									// 1 = transmit packet test
									// 0 = receive packet test								


void vGetRandomTxBuf(void)										
{
 byte i;
 uint32_t trng_tmp=0x12345678;
	
 
 for(i=0; i<UHF_LEN; i+=4)
	{	
	radio_tx_buf[i]   = (byte)trng_tmp;
	radio_tx_buf[i+1] = (byte)(trng_tmp>>8);
	radio_tx_buf[i+2] = (byte)(trng_tmp>>16);	
	radio_tx_buf[i+3] = (byte)(trng_tmp>>24);	
	}

}	

void setup(void)
{

	Serial.begin(115200);
	Serial.println("App starting...");

	OutputLED();
	RF_GPIO4_IN();

	vSpiMasterInit();

	while(bRadioIsExist()==FALSE)	
	{
	Serial.println("not found CMT2310A");
	delay(100);
	}

	g_rx_count  = 0;
	g_tx_count  = 0;


}

void loop(void)
{
	byte i;
	byte systimer;

 #if (WORK_MODE==3)							//test base tx prefix	
	Serial.println("Transmit Tx-Zero");	
	vRadioInit();
	g_radio.word_mode_cfg.WORK_MODE_CFG1_u._BITS.TX_EXIT_STATE = EXIT_TO_TX;	//exit Tx mode for transmit prefix 
	vRadioCfgWorkMode(&g_radio.word_mode_cfg);	
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_TX_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_TX_FIFO_NMTY);
	vGetRandomTxBuf();
	vRadioWriteFifo(radio_tx_buf, UHF_LEN);
	bRadioGoTx();
	while(RF_GPIO4_L());
	vRadioClearInterrupt(); 
	while(1);
 #endif	

 #if (WORK_MODE==2)		   					//test base rx mode
	Serial.println("Receiving      ");
	vRadioInit();
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_WBYTE);
	bRadioGoRx();
	while(1)
		{
		if(RF_GPIO4_H())
			{
			SetLED();	
			vRadioClearRxFifo();	
			vRadioClearInterrupt(); 
			bRadioGoRx();
			ClrLED();
			}
		}
 #endif

 #if (WORK_MODE==1)							//test transmit packet mode
 		vRadioInit();
		//vLcdPrintString(4, "Transmit Packet:  ");
		while (1)
		{
			//SET_LED1();
			vRadioSetInt1Sel(CMT2310A_INT_TX_DONE);
			vRadioSetInt2Sel(CMT2310A_INT_TX_FIFO_NMTY);	
			g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
			vRadioSetPayloadLength(&g_radio.frame_cfg);
			vGetRandomTxBuf();
			vRadioWriteFifo(radio_tx_buf, UHF_LEN);
			vRadioReadTxFifo(radio_rx_buf, UHF_LEN);		
			vRadioManualResetTxFifoPointer();				//because readout tx fifo, so that need to reset tx_fifo_ptr
			for(i=0; i<UHF_LEN; i++)
				{
				if(radio_tx_buf[i]!=radio_rx_buf[i])
					break;
				}
			if(i<UHF_LEN)
				SetLED();
			bRadioGoTx();

			systimer = 250;
			while(systimer--){
				delay(4);
				if(RF_GPIO4_H())
				{
					bRadioGoStandby();
					vRadioClearTxFifo();
					vRadioClearInterrupt();
					g_tx_count++;
					Serial.println(g_tx_count);
					break;
				}
			}
			if(systimer == 0)bRadioGoStandby();
			delay(500);	
			ClrLED();
		}


 #endif


 #if (WORK_MODE==0)							//test receive packet mode
	Serial.println("Receive Packet:   ");
	vRadioInit();
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_WBYTE);
	bRadioGoRx();	
	while(1){
		if(RF_GPIO4_H())
		{
			SetLED();
			if(g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_EN==1)
				{
				vRadioInterruptSoucreFlag(&g_radio.int_src_flag);
				if(g_radio.int_src_flag._BITS.CRC_PASS_FLG==1)
					{
					g_rx_count++;
					}
				}
			else
			g_rx_count++;
			vRadioReadFifo(radio_rx_buf, UHF_LEN);
			vRadioClearRxFifo();	
			vRadioClearInterrupt(); 
			bRadioGoRx();	
			Serial.println(g_rx_count);	
			ClrLED();
		}
	}
 #endif
}


/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
