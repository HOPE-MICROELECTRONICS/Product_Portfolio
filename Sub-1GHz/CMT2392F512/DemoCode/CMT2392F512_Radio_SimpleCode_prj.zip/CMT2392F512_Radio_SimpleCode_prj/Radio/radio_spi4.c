#include "radio_spi4.h"

//#define		SPI_SPEED_SEL		1		//0->7

#define		SPI_DUMMY_VALUE		0xFF

/**
 * \brief   delay100ms
 *          delay approximately 1ms.
 * \param   [in]  u32Cnt
 * \retval  void
 */
void delay100ms(unsigned int u32Cnt)
{
    unsigned int u32end;
    
    SysTick->LOAD = 0xFFFFFF;
    SysTick->VAL  = 0;
    SysTick->CTRL = SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_CLKSOURCE_Msk;
    
    while(u32Cnt-- > 0)
    {
        SysTick->VAL  = 0;
        u32end = 0x1000000 - SystemCoreClock/10;
        while(SysTick->VAL > u32end)
        {
            ;
        }
    }
    
    SysTick->CTRL = (SysTick->CTRL & (~SysTick_CTRL_ENABLE_Msk));
}

/**
 * \brief   delay10ms
 *          delay approximately 1ms.
 * \param   [in]  u32Cnt
 * \retval  void
 */
void delay10ms(unsigned int u32Cnt)
{
    unsigned int u32end;
    
    SysTick->LOAD = 0xFFFFFF;
    SysTick->VAL  = 0;
    SysTick->CTRL = SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_CLKSOURCE_Msk;
    
    while(u32Cnt-- > 0)
    {
        SysTick->VAL  = 0;
        u32end = 0x1000000 - SystemCoreClock/100;
        while(SysTick->VAL > u32end)
        {
            ;
        }
    }
    
    SysTick->CTRL = (SysTick->CTRL & (~SysTick_CTRL_ENABLE_Msk));
}

/**
 * \brief   delay1ms
 *          delay approximately 1ms.
 * \param   [in]  u32Cnt
 * \retval  void
 */
void delay1ms(unsigned int u32Cnt)
{
    unsigned int u32end;
    
    SysTick->LOAD = 0xFFFFFF;
    SysTick->VAL  = 0;
    SysTick->CTRL = SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_CLKSOURCE_Msk;
    
    while(u32Cnt-- > 0)
    {
        SysTick->VAL  = 0;
        u32end = 0x1000000 - SystemCoreClock/1000;
        while(SysTick->VAL > u32end)
        {
            ;
        }
    }
    
    SysTick->CTRL = (SysTick->CTRL & (~SysTick_CTRL_ENABLE_Msk));
}

/**
 * \brief   delay100us
 *          delay approximately 100us.
 * \param   [in]  u32Cnt
 * \retval  void
 */
void delay100us(unsigned int u32Cnt)
{
    unsigned int u32end;
    
    SysTick->LOAD = 0xFFFFFF;
    SysTick->VAL  = 0;
    SysTick->CTRL = SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_CLKSOURCE_Msk;
    
    while(u32Cnt-- > 0)
    {
        SysTick->VAL = 0;

        u32end = 0x1000000 - SystemCoreClock/10000;
        while(SysTick->VAL > u32end)
        {
            ;
        }
    }
    
    SysTick->CTRL = (SysTick->CTRL & (~SysTick_CTRL_ENABLE_Msk));
}

/**
 * \brief   delay10us
 *          delay approximately 10us.
 * \param   [in]  u32Cnt
 * \retval  void
 */
void delay10us(unsigned int u32Cnt)
{
    unsigned int u32end;
    
    SysTick->LOAD = 0xFFFFFF;
    SysTick->VAL  = 0;
    SysTick->CTRL = SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_CLKSOURCE_Msk;
    
    while(u32Cnt-- > 0)
    {
        SysTick->VAL = 0;

        u32end = 0x1000000 - SystemCoreClock/100000;
        while(SysTick->VAL > u32end)
        {
            ;
        }
    }
    
    SysTick->CTRL = (SysTick->CTRL & (~SysTick_CTRL_ENABLE_Msk));
}

/**********************************************************
**Name: 	vSpiInit
**Func: 	Init Spi-3 Config
**Note: 	
**********************************************************/
void vSpiMasterInit(void)
{
	unsigned int tmp;
	SPI_InitType  SPI_InitStructure;	
    GPIO_InitType GPIO_InitStructure;
	
	RCC_EnableAPB2PeriphClk((RCC_APB2_PERIPH_GPIOA|RCC_APB2_PERIPH_GPIOC|RCC_APB2_PERIPH_AFIO), ENABLE);	//enable gpioB & gpioC periph clk
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_SPI1, ENABLE);													//enable SPI1 periph clk

	SystemCoreClockUpdate();	//get SystemCoreClock
	
    /* Configure pins: SCK and MOSI ---------------------------------*/
    GPIO_InitStructure.Pin        = RF_SCK |RF_SDI;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitPeripheral(GPIOA, &GPIO_InitStructure);

	/* Configure pins: MISO -----------------------------------------*/
	GPIO_InitStructure.Pin        = RF_SDO;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;
	GPIO_InitPeripheral(GPIOA, &GPIO_InitStructure);

	/* Configure pins: CS -------------------------------------------*/
	GPIO_InitStructure.Pin        = RF_CSB;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_InitPeripheral(GPIOA, &GPIO_InitStructure);
	
    /* Configure pins: GPIO2 & GPIO3  -------------------------------*/
    GPIO_InitStructure.Pin        = RF_GPIO2 | RF_GPIO3;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPD;
    GPIO_InitPeripheral(GPIOC, &GPIO_InitStructure);

	SET_RF_CSB();

    SPI_Enable(SPI1, DISABLE);
	
    SPI_InitStructure.DataDirection = SPI_DIR_DOUBLELINE_FULLDUPLEX;
    SPI_InitStructure.SpiMode       = SPI_MODE_MASTER;
    SPI_InitStructure.DataLen       = SPI_DATA_SIZE_8BITS;
    SPI_InitStructure.CLKPOL        = SPI_CLKPOL_LOW;
    SPI_InitStructure.CLKPHA        = SPI_CLKPHA_FIRST_EDGE;
    SPI_InitStructure.NSS           = SPI_NSS_SOFT;

//	switch(SPI_SPEED_SEL)    													//   @8MHz   @24MHz   @32MHz   @48MHz    @56MHz    @72MHz    @96MHz/2   @128MHz/2   @144MHz/2
//     	{																		//
//    	case 0: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_2;   break;	//    4M       12M      16M      24M	   28M       36M       24M        32M         36M
//    	case 1: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_4;   break;	//	  2M        6M       8M      12M       14M       18M       12M        16M         18M
//    	case 2: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_8;   break;	//    1M        3M       4M       6M        7M        9M        6M         8M          9M 
//    	case 3: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_16;  break;	//   500k      1.5M      2M       3M       3.5M      4.5M       3M         4M         4.5M
//    	case 4: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_32;  break;	//	 250k	   750k      1M      1.5M     1.75M      2.2M      1.5M        2M         2.2M
//    	case 5: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_64;  break;	//   125k      375k     500k     750k      875k      1.1M      750k        1M         1.1M
//    	case 6: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_128; break;	//   62.5k     187k     250k     375k      437k      562k      375k		  500k        562k
//    	case 7: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_256; break;	//	 31.25k     93k     125k     187k      218k      281k      187k       250k        281k
//    	}
	
	if(SystemCoreClock>=48000000)
		SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_8;			// 9MHz@144/8MHz@128/6MHz@96, 9MHz@72/7MHz@56/6MHz@48
	else if(SystemCoreClock>=24000000)
		SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_4;			// 8MHz@48/6MHz@24
	else
		SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_2;   			// 4MHz@8	
    SPI_InitStructure.FirstBit      = SPI_FB_MSB;
    SPI_InitStructure.CRCPoly       = 7;
    SPI_Init(SPI1, &SPI_InitStructure);	

    SPI_Enable(SPI1, ENABLE);
}

/**********************************************************
**Name:	 	bSpiWriteByte
**Func: 	SPI Write One word
**Input: 	Write word
**Output:	none
**********************************************************/
unsigned char bSpiWriteByte(unsigned char spi_adr, unsigned char spi_dat)
{
	unsigned char dout;
	
	CLR_RF_CSB();

	SPI1->DAT = (spi_adr&0x7F);   
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT;
	SPI1->DAT = spi_dat;	
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT;	

	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_BUSY_FLAG) == SET);		// Wait for SPI1 not busy
	SET_RF_CSB();	
	return(dout);	
}

/**********************************************************
**Name:	 	bSpiReadByte
**Func: 	SPI Read One byte
**Input: 	readout addresss
**Output:	readout byte
**********************************************************/
unsigned char bSpiReadByte(unsigned char spi_adr)
{
	unsigned char dout;
	
	CLR_RF_CSB();

	SPI1->DAT = (spi_adr|0x80);   
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT;
	SPI1->DAT = SPI_DUMMY_VALUE;	
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT;	

	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_BUSY_FLAG) == SET);		// Wait for SPI1 not busy
	SET_RF_CSB();	
	return(dout);	
}

/**********************************************************
**Name:	 	vSpiBurstWrite
**Func: 	burst wirte N byte
**Input: 	array length & head pointer
**Output:	none
**********************************************************/
void vSpiBurstWrite(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length)
{
 	unsigned char i;
	unsigned char dout;	
 	
 	spi_adr &= 0x7F;

	CLR_RF_CSB();
	SPI1->DAT = spi_adr;   
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT; 	
 	if(spi_length!=0x00)
	 	{
 		for(i=0; i<spi_length; i++)
			{
			SPI1->DAT = spi_dat[i];	
			while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
			dout = (unsigned char)SPI1->DAT;				
			}
 		}
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_BUSY_FLAG) == SET);		// Wait for SPI1 not busy
	SET_RF_CSB();	 		
 	return;
}

/**********************************************************
**Name:	 	vSpiBurstRead
**Func: 	burst wirte N byte
**Input: 	array length  & head pointer
**Output:	none
**********************************************************/
void vSpiBurstRead(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length)
{
	unsigned char i;
	
	spi_adr |= 0x80;
	
	CLR_RF_CSB();
	SPI1->DAT = spi_adr;   
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	i = (unsigned char)SPI1->DAT; 	
 	if(spi_length!=0)
 		{
 		for(i=0; i<spi_length; i++)
 			{
			SPI1->DAT = SPI_DUMMY_VALUE;	
			while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
			spi_dat[i] = (unsigned char)SPI1->DAT;	 				
			}
 		}	

	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_BUSY_FLAG) == SET);		// Wait for SPI1 not busy
	SET_RF_CSB();	 		
 	return;
}

