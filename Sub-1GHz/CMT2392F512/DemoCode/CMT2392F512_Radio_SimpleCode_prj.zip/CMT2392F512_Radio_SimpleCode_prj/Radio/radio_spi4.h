
#ifndef		__RADIO_SPI4_H__
	
	#define __RADIO_SPI4_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif

	#include "n32g45x.h"
	#include "n32g45x_conf.h"
	#include "n32g45x_gpio.h"

	/** logical datatype (only values are TRUE and FALSE) */
	typedef uint8_t      boolean_t;

	#ifndef TRUE
	  /** Value is true (boolean_t type) */
	  #define TRUE        ((boolean_t) 1u)
	#endif
	
	#ifndef FALSE
	  /** Value is false (boolean_t type) */
	  #define FALSE       ((boolean_t) 0u)
	#endif  

	typedef unsigned char 	byte;
	typedef	unsigned char 	BYTE;
	
	typedef unsigned short int	word;
	typedef	unsigned short int 	WORD;
	
	typedef unsigned int	lword;
	typedef	unsigned int	LWORD;

	//***************************************************************************
	//GPIO                                                                       
	//mod[1:0]:  2'b, 00(resv in),   01(10M out),    10(2M out),              11(50M out)
	//cfg[3:2]:  2'b, 00(push-pull), 01(open-drain), 10(push-pull for auxrl), 11(open-drain for auxrl), when mod set as 2'b 01/10/11
	//           2'b, 00(analog),    01(floating),   10(pull-up/down),        11(resv),    when mod set as 2'b 00
	//sr:	 1'b, 0(quick toggle), 1(low speed)
	//pod:   1'b, 0(output-high),  1(output-low) for output
	//       1'b, 0(pull-down),    1(pull-up)    for input
	//pbsc:  1'b, 0(none),         1(set or clear)
	//ds:    1'b, 0(high-drv), 	   1(low-drv)
	//***************************************************************************

	//----------------PORTA-------------------------CFG/MOD----sr----pod----ds        
 	#define		RF_CSB			GPIO_PIN_4      //  0011       0      0     0		//2310 CSB
	#define		RF_SCK			GPIO_PIN_5      //  1011       0      0     0		//2310 SCK
	#define		RF_SDO			GPIO_PIN_6      //  1100       0      0     0		//2310 SDO
	#define		RF_SDI			GPIO_PIN_7      //  1011       0      0     0		//2310 SDI

	//----------------PORTC-------------------------CFG/MOD----sr----pod----ds  
	#define		RF_GPIO2		GPIO_PIN_4		//	1000       0      0     0
	#define		RF_GPIO3		GPIO_PIN_5		//	1000       0      0     0

	//----------------PORTD-------------------------CFG/MOD----sr----pod----ds  
 	#define		RF_GPIO5		GPIO_PIN_1      //  1000       0      0     0  
	#define		RF_GPIO4		GPIO_PIN_2      //  1000/0011  0      0     0  
	
	
	#define		SET_RF_CSB()		(GPIOA->PBSC |= RF_CSB)
	#define		CLR_RF_CSB()		(GPIOA->PBC  |= RF_CSB)

	#define		RF_GPIO2_H()		((GPIOC->PID&RF_GPIO2)==RF_GPIO2)
	#define		RF_GPIO2_L()		((GPIOC->PID&RF_GPIO2)==0)

	#define		RF_GPIO3_H()		((GPIOC->PID&RF_GPIO3)==RF_GPIO3)
	#define		RF_GPIO3_L()		((GPIOC->PID&RF_GPIO3)==0)

	#define		RF_GPIO4_H()		((GPIOD->PID&RF_GPIO4)==RF_GPIO4)
	#define		RF_GPIO4_L()		((GPIOD->PID&RF_GPIO4)==0)

	#define		RF_GPIO5_H()		((GPIOD->PID&RF_GPIO5)==RF_GPIO5)
	#define		RF_GPIO5_L()		((GPIOD->PID&RF_GPIO5)==0)

	#define 	RF_GPIO4_Output()	(GPIOD->PL_CFG &= 0xFFFFF0FF; GPIOD->PL_CFG |= 0x00000300;)
	#define		RF_GPIO4_Input()  	(GPIOD->PL_CFG &= 0xFFFFF0FF; GPIOD->PL_CFG |= 0x00000800;)

	#define 	RF_TX_DATA_Output()	(GPIOD->PL_CFG &= 0xFFFFF0FF; GPIOD->PL_CFG |= 0x00000300;)
	#define		RF_TX_DATA_Input()  (GPIOD->PL_CFG &= 0xFFFFF0FF; GPIOD->PL_CFG |= 0x00000800;)

	#define		RF_TX_DAT_H()		(GPIOD->PBSC |= RF_GPIO4)  
	#define		RF_TX_DAT_L()		(GPIOD->PBC  |= RF_GPIO4)


	// API
	extern void delay100ms(unsigned int u32Cnt);
	extern void delay10ms(unsigned int u32Cnt);
	extern void delay1ms(unsigned int u32Cnt);
	extern void delay100us(unsigned int u32Cnt);	
	extern void delay10us(unsigned int u32Cnt);	
	
	extern void vSpiMasterInit(void);
	extern unsigned char bSpiWriteByte(unsigned char spi_adr, unsigned char spi_dat);
	extern unsigned char bSpiReadByte(unsigned char spi_adr);
	extern void vSpiBurstWrite(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length);
	extern void vSpiBurstRead(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length);

	
	#ifdef	__cplusplus
		}
	#endif

#endif 		
