#include "hal.h"

RCC_ClocksType 	RCC_ClockFreq;
ErrorStatus 	HSEStartUpStatus;
ErrorStatus 	HSIStartUpStatus;

void vSysClockInit(void)
{

	//clock setting
	switch(CLOCK_MODE)
		{
		case 0: SetSysClockToHSI(); break;
		case 1: SetSysClockToHSE(); break;
		case 2: SetSysClockToPLL(24000000,  SYSCLK_PLLSRC_HSI); break;
		case 3: SetSysClockToPLL(36000000,  SYSCLK_PLLSRC_HSI); break;
		case 4: SetSysClockToPLL(48000000,  SYSCLK_PLLSRC_HSI); break;	
		case 5: SetSysClockToPLL(56000000,  SYSCLK_PLLSRC_HSI); break;
		case 6: SetSysClockToPLL(72000000,  SYSCLK_PLLSRC_HSI); break;
		case 7: SetSysClockToPLL(96000000,  SYSCLK_PLLSRC_HSI); break;
		case 8: SetSysClockToPLL(128000000, SYSCLK_PLLSRC_HSI); break;	
		case 9: SetSysClockToPLL(24000000,  SYSCLK_PLLSRC_HSE); break;
		case 10:SetSysClockToPLL(36000000,  SYSCLK_PLLSRC_HSE); break;
		case 11:SetSysClockToPLL(48000000,  SYSCLK_PLLSRC_HSE); break;
		case 12:SetSysClockToPLL(56000000,  SYSCLK_PLLSRC_HSE); break;			
		case 13:SetSysClockToPLL(72000000,  SYSCLK_PLLSRC_HSE); break;	
		case 14:SetSysClockToPLL(96000000,  SYSCLK_PLLSRC_HSE); break;
		case 15:SetSysClockToPLL(128000000, SYSCLK_PLLSRC_HSE); break;			
		case 16:SetSysClockToPLL(144000000, SYSCLK_PLLSRC_HSE); break;	
		default:SetSysClockToHSI(); break;
		}
	SystemCoreClockUpdate();	
}

void vGpioInit(void)
{
	uint32_t tmp;

	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOD, ENABLE);	
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOF, ENABLE);
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOG, ENABLE);	
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO,  ENABLE);	
	
	
	//## ds
	GPIOA->DS_CFG   = GPIOA_DS_VAL;
	GPIOB->DS_CFG   = GPIOB_DS_VAL;
	GPIOC->DS_CFG   = GPIOC_DS_VAL;
	GPIOD->DS_CFG   = GPIOD_DS_VAL;
	GPIOF->DS_CFG   = GPIOF_DS_VAL;
	GPIOG->DS_CFG   = GPIOG_DS_VAL;
	
	//## output value
	GPIOA->POD  = GPIOA_POD_VAL;
	GPIOB->POD  = GPIOB_POD_VAL;
	GPIOC->POD  = GPIOC_POD_VAL;
	GPIOD->POD  = GPIOD_POD_VAL;
	GPIOF->POD  = GPIOF_POD_VAL;
	GPIOG->POD  = GPIOG_POD_VAL;

	//## sr 	
	GPIOA->SR_CFG  = GPIOA_SR_VAL;
	GPIOB->SR_CFG  = GPIOB_SR_VAL;
	GPIOC->SR_CFG  = GPIOC_SR_VAL;
	GPIOD->SR_CFG  = GPIOD_SR_VAL;
	GPIOF->SR_CFG  = GPIOF_SR_VAL;
	GPIOG->SR_CFG  = GPIOG_SR_VAL;

	//## cfg & mode		
	GPIOA->PL_CFG  = GPIOA_CFG_PMODE_L_VAL;
	GPIOA->PH_CFG &= GPIOA_CFG_PMODE_H_MASK;
	GPIOA->PH_CFG |= GPIOA_CFG_PMODE_H_VAL;

	GPIOB->PL_CFG  = GPIOB_CFG_PMODE_L_VAL;
	GPIOB->PH_CFG  = GPIOB_CFG_PMODE_H_VAL;

	GPIOC->PL_CFG  = GPIOC_CFG_PMODE_L_VAL;
	GPIOC->PH_CFG  = GPIOC_CFG_PMODE_H_VAL;

	GPIOD->PL_CFG  = GPIOD_CFG_PMODE_L_VAL;
	GPIOD->PH_CFG  = GPIOD_CFG_PMODE_H_VAL;

	GPIOF->PL_CFG  = GPIOF_CFG_PMODE_L_VAL;
	GPIOF->PH_CFG  = GPIOF_CFG_PMODE_H_VAL;

	GPIOG->PL_CFG  = GPIOG_CFG_PMODE_L_VAL;
	GPIOG->PH_CFG  = GPIOG_CFG_PMODE_H_VAL;
}

/**
 * @brief  Configures key port.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void KeyInputExtiInit(FunctionalState cmd)
{
    EXTI_InitType EXTI_InitStructure;
    NVIC_InitType NVIC_InitStructure;

    /*Configure key EXTI Line to key input Pin*/		
    GPIO_ConfigEXTILine(GPIOB_PORT_SOURCE, GPIO_PIN_SOURCE0);		//KEY1---PB0
    /*Configure key EXTI line*/
    EXTI_InitStructure.EXTI_Line    = EXTI_LINE0;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; 
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_InitPeripheral(&EXTI_InitStructure);

    /*Set key input interrupt priority*/
    NVIC_InitStructure.NVIC_IRQChannel                   = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x05;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 0x0F;
    if(cmd != DISABLE)	
    	NVIC_InitStructure.NVIC_IRQChannelCmd            = ENABLE;
    else
    	NVIC_InitStructure.NVIC_IRQChannelCmd            = DISABLE;
    NVIC_Init(&NVIC_InitStructure);
    
   
    /*Configure key EXTI Line to key input Pin*/		
	GPIO_ConfigEXTILine(GPIOD_PORT_SOURCE, GPIO_PIN_SOURCE9);		//KEY2---PD9
	/*Configure key EXTI line*/
    EXTI_InitStructure.EXTI_Line = EXTI_LINE9;   
	EXTI_InitPeripheral(&EXTI_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel                   = EXTI9_5_IRQn; 
    if(cmd != DISABLE)	
    	NVIC_InitStructure.NVIC_IRQChannelCmd            = ENABLE;
    else
    	NVIC_InitStructure.NVIC_IRQChannelCmd            = DISABLE;
    NVIC_Init(&NVIC_InitStructure);    
}

/**
 * @brief  Configures tim4 clocks.
 */
void vTimer4Configuration(void)
{
	TIM_TimeBaseInitType TIM_TimeBaseStructure;
    NVIC_InitType NVIC_InitStructure;
  
	uint16_t PrescalerValue = 0;	

    /* TIM4 clock enable */
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM4, ENABLE);
	if(SystemCoreClock>72000000)
		PrescalerValue = (uint16_t) (SystemCoreClock / 2000000);	//target 1MHz Clock  		
	else
		PrescalerValue = (uint16_t) (SystemCoreClock / 1000000);	//target 1MHz Clock  		
    
    /* Time base configuration */
    TIM_TimeBaseStructure.Period    = 10000;					//target 10ms
    TIM_TimeBaseStructure.Prescaler = 0;
    TIM_TimeBaseStructure.ClkDiv    = 0;
    TIM_TimeBaseStructure.CntMode   = TIM_CNT_MODE_UP;
    TIM_InitTimeBase(TIM4, &TIM_TimeBaseStructure);

    TIM_ConfigPrescaler(TIM4, PrescalerValue, TIM_PSC_RELOAD_MODE_IMMEDIATE);	// Prescaler configuration
    TIM_ConfigInt(TIM4, TIM_INT_UPDATE, ENABLE);				// TIM4 enable update irq
    TIM_Enable(TIM4, ENABLE);									// TIM4 enable counter 
 
    /* Enable the TIM14 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel                   = TIM4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);    
}


/*
void vSetSysClock_LSI(void)
{
    RCC_DeInit();
    RCC_EnableLsi(ENABLE);
    while(RCC_GetFlagStatus(RCC_LSCTRL_FLAG_LSIRD) == RESET);

    RCC_ConfigHclk(RCC_SYSCLK_DIV1);					// HCLK = SYSCLK
    RCC_ConfigPclk2(RCC_HCLK_DIV1);						// PCLK2 = HCLK
    RCC_ConfigPclk1(RCC_HCLK_DIV1);						// PCLK1 = HCLK
	FLASH_SetLatency(FLASH_LATENCY_0);
    
	RCC_ConfigSysclk(RCC_SYSCLK_SRC_LSI);
    while(RCC_GetSysclkSrc() != RCC_CFG_SCLKSTS_LSI);
}


void vSetSysClock_LSE(void)
{
    RCC_DeInit();
    RCC_ConfigLse(RCC_LSE_ENABLE);
    while(RCC_GetFlagStatus(RCC_LSCTRL_FLAG_LSERD) == RESET);
    
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);					// HCLK = SYSCLK
    RCC_ConfigPclk2(RCC_HCLK_DIV1);						// PCLK2 = HCLK 
    RCC_ConfigPclk1(RCC_HCLK_DIV1);						// PCLK1 = HCLK 

    FLASH_SetLatency(FLASH_LATENCY_0);
    RCC_ConfigSysclk(RCC_SYSCLK_SRC_LSE);
    while (RCC_GetSysclkSrc() != RCC_CFG_SCLKSTS_LSE);
}
*/


void SetSysClockToHSI(void)
{
    RCC_DeInit();

    RCC_EnableHsi(ENABLE);

    /* Enable Prefetch Buffer */
    FLASH_PrefetchBufSet(FLASH_PrefetchBuf_EN);

    /* Flash 0 wait state */
    FLASH_SetLatency(FLASH_LATENCY_0);

    /* HCLK = SYSCLK */
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);

    /* PCLK2 = HCLK */
    RCC_ConfigPclk2(RCC_HCLK_DIV1);

    /* PCLK1 = HCLK */
    RCC_ConfigPclk1(RCC_HCLK_DIV1);

    /* Select HSE as system clock source */
    RCC_ConfigSysclk(RCC_SYSCLK_SRC_HSI);

    /* Wait till PLL is used as system clock source */
    while (RCC_GetSysclkSrc() != 0x00)
    {
    }
}

/**
 * @brief  Selects HSE as System clock source and configure HCLK, PCLK2
 *         and PCLK1 prescalers.
 */
void SetSysClockToHSE(void)
{
    /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration
     * -----------------------------*/
    /* RCC system reset(for debug purpose) */
    RCC_DeInit();

    /* Enable HSE */
    RCC_ConfigHse(RCC_HSE_ENABLE);

    /* Wait till HSE is ready */
    HSEStartUpStatus = RCC_WaitHseStable();

    if (HSEStartUpStatus == SUCCESS)
    {
        /* Enable Prefetch Buffer */
        FLASH_PrefetchBufSet(FLASH_PrefetchBuf_EN);

        if (HSE_Value <= 32000000)
        {
            /* Flash 0 wait state */
            FLASH_SetLatency(FLASH_LATENCY_0);
        }
        else
        {
            /* Flash 1 wait state */
            FLASH_SetLatency(FLASH_LATENCY_1);
        }

        /* HCLK = SYSCLK */
        RCC_ConfigHclk(RCC_SYSCLK_DIV1);

        /* PCLK2 = HCLK */
        RCC_ConfigPclk2(RCC_HCLK_DIV1);

        /* PCLK1 = HCLK */
        RCC_ConfigPclk1(RCC_HCLK_DIV1);

        /* Select HSE as system clock source */
        RCC_ConfigSysclk(RCC_SYSCLK_SRC_HSE);

        /* Wait till HSE is used as system clock source */
        while (RCC_GetSysclkSrc() != 0x04)
        {
        }
    }
    else
    {
        /* If HSE fails to start-up, the application will have wrong clock
           configuration. User can add here some code to deal with this error */

        /* Go to infinite loop */
        while (1)
        {
        }
    }
}

void SetSysClockToPLL(uint32_t freq, uint8_t src)
{
    uint32_t pllsrc = (src == SYSCLK_PLLSRC_HSI ? RCC_PLL_SRC_HSI_DIV2 : RCC_PLL_SRC_HSE_DIV2);
    uint32_t pllmul;
    uint32_t latency;
    uint32_t pclk1div, pclk2div;

    if (HSE_VALUE != 8000000)
    {
        /* HSE_VALUE == 8000000 is needed in this project! */
        while (1)
            ;
    }

    /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration
     * -----------------------------*/
    /* RCC system reset(for debug purpose) */
    RCC_DeInit();

    if (src == SYSCLK_PLLSRC_HSE)
    {
        /* Enable HSE */
        RCC_ConfigHse(RCC_HSE_ENABLE);

        /* Wait till HSE is ready */
        HSEStartUpStatus = RCC_WaitHseStable();

        if (HSEStartUpStatus != SUCCESS)
        {
            /* If HSE fails to start-up, the application will have wrong clock
               configuration. User can add here some code to deal with this
               error */

            /* Go to infinite loop */
            while (1)
                ;
        }
    }

    switch (freq)
    {
    case 24000000:
        latency  = FLASH_LATENCY_0;
        pllmul   = RCC_PLL_MUL_6;
        pclk1div = RCC_HCLK_DIV1;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 36000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_9;
        pclk1div = RCC_HCLK_DIV1;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 48000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_12;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 56000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_14;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 72000000:
        latency  = FLASH_LATENCY_2;
        pllmul   = RCC_PLL_MUL_18;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 96000000:
        latency  = FLASH_LATENCY_2;
        pllmul   = RCC_PLL_MUL_24;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    case 128000000:
        latency  = FLASH_LATENCY_3;
        pllmul   = RCC_PLL_MUL_32;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    case 144000000:
        /* must use HSE as PLL source */
        latency  = FLASH_LATENCY_4;
        pllsrc   = RCC_PLL_SRC_HSE_DIV1;
        pllmul   = RCC_PLL_MUL_18;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    default:
        while (1)
            ;
    }

    FLASH_SetLatency(latency);

    /* HCLK = SYSCLK */
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);

    /* PCLK2 = HCLK */
    RCC_ConfigPclk2(pclk2div);

    /* PCLK1 = HCLK */
    RCC_ConfigPclk1(pclk1div);

    RCC_ConfigPll(pllsrc, pllmul);

    /* Enable PLL */
    RCC_EnablePll(ENABLE);

    /* Wait till PLL is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_PLLRD) == RESET)
        ;

    /* Select PLL as system clock source */
    RCC_ConfigSysclk(RCC_SYSCLK_SRC_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while (RCC_GetSysclkSrc() != 0x08)
        ;
}


