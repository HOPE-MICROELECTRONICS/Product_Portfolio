
#ifndef		__RADIO_H__
	
	#define __RADIO_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif
	
	#include "n32g45x.h"
	#include "n32g45x_conf.h"
	#include "n32g45x_gpio.h"

	#include "radio_phy.h"
	#include "radio_mac.h"
	#include "radio_ant_div.h"
	#include "CMT2310A_def.h"
	#include "CMT2310A_reg.h"	
	#include "cmt2392f512_eb.h"
	

	extern const unsigned char g_cmt2310a_page0[CMT2310A_PAGE0_SIZE];
	extern const unsigned char g_cmt2310a_page1[CMT2310A_PAGE1_SIZE];	
	extern const unsigned char g_cmt2310a_page2[CMT2310A_PAGE2_SIZE];	

	
	extern CMT2310A_CFG	g_radio;
	extern uint32_t 	g_chip_id;

	extern void vRadioInit(void);
	extern void vRadioClearInterrupt(void);
	extern void vRadioReadAllStatus(void);
	extern void vRadioCmpReg(unsigned char const wr_ptr[], unsigned char rd_ptr[], unsigned char cmp_ptr[], unsigned char length);
	extern void vRadioSwitchToOOK(void);
	extern void vRadioCWTransmitInit(void);
	
	extern void vRadioTxDataOutput(void);
	extern void vRadioTxDataInput(void);

	#ifdef	__cplusplus
		}
	#endif

#endif 		

