/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/

/**
 * @file main.c
 * @author Nations
 * @version v1.0.1
 *
 * @copyright Copyright (c) 2019, Nations Technologies Inc. All rights reserved.
 */
#include "main.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>


/**
 * @brief  Main program.
 */

word 		g_systimer;
word 		g_keytimer;	
byte		g_key_value;
boolean_t	g_key_press_F;

byte   	 	radio_rx_buf[UHF_LEN];
byte 		radio_tx_buf[UHF_LEN];
word 		g_rx_count;
word 		g_tx_count;

#define		WORK_MODE		2		// 3 = transmit CW
									// 2 = receive mode for sensisity test
									// 1 = transmit packet test
									// 0 = receive packet test		

int main(void)
{   
	byte rev;
	byte i;
	GPIO_InitType GPIO_InitStructure;
	
	vSysClockInit();
	vGpioInit();
	vTimer4Configuration();

	SET_LED1();
	SET_LED2();
	SET_LED3();
	
	vSpiMasterInit();
	g_chip_id = 0x00000000;
	while(1)	
		{
		vRadioSoftReset();
		vRadioPowerUpBoot();				
		delay1ms(10);
		g_chip_id = lRadioChipVersion();	
		if(0x00231000==(g_chip_id&0x00FFF000))
			break;
		CLR_LED1();
		CLR_LED2();
		CLR_LED3();		
		delay1ms(100);
		SET_LED1();
		SET_LED2();
		SET_LED3();		
		delay1ms(100);
		}
	SET_LED1();
	SET_LED2();
	SET_LED3();	
	if(0x00231000==(g_chip_id&0x00FFFF00))		//it is 2310 only
		{
		rev = (byte)g_chip_id;					//dealwith Xtal	
		if(rev!=0xC0)
			{
			for(i=5; i!=0; i--)
				{
				CLR_LED1();
				delay1ms(100);
				SET_LED1();
				delay1ms(100);				
				}
			}
		}	
		
	
 #if (WORK_MODE==3)										//test cw tx	
	vRadioInit();
	vRadioClearInterrupt(); 
	vRadioCWTransmitInit();
	while(1);
 #endif	


 #if (WORK_MODE==2)		   								//test base rx mode
	vRadioInit();
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_WBYTE);
	bRadioGoRx();
	SET_LED1();
	SET_LED2();
	while(1)
		{
		if(RF_GPIO4_H())
			{
			CLR_LED2();	
			vRadioClearRxFifo();	
			vRadioClearInterrupt(); 
			bRadioGoRx();
			}
		}
 #endif

 #if (WORK_MODE==1)										//test transmit packet mode
	vRadioInit();
	while(1)
		{
		CLR_LED1();	
		vRadioSetInt1Sel(CMT2310A_INT_TX_DONE);
		vRadioSetInt2Sel(CMT2310A_INT_TX_FIFO_NMTY);	
		g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
		vRadioSetPayloadLength(&g_radio.frame_cfg);
		vGetTxBuf();
		vRadioWriteFifo(radio_tx_buf, UHF_LEN);
		bRadioGoTx();
		for(g_systimer=0; g_systimer<LIMIT_TIMER_TX_CNT; )
			{
			if(RF_GPIO4_H())
				{
				bRadioGoStandby();
				vRadioClearTxFifo();
				vRadioClearInterrupt();
				g_tx_count++;
				break;
				}
			}
		if(g_systimer>=LIMIT_TIMER_TX_CNT)
			bRadioGoStandby();
		SET_LED1();	
		for(g_systimer=0; g_systimer<25; )
			{
			if(bKeyscan())
				g_tx_count = 0;
			}
		}
 #endif


 #if (WORK_MODE==0)										//test receive packet mode
	vRadioInit();

	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_WBYTE);
	
	bRadioGoRx();	
	while(1)
		{
		if(RF_GPIO4_H())
			{
			if(g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_EN==1)
				{
				vRadioInterruptSoucreFlag(&g_radio.int_src_flag);
				if(g_radio.int_src_flag._BITS.CRC_PASS_FLG==1)
					{
					CLR_LED2();
					g_rx_count++;
					}
				}
			else
				g_rx_count++;
			vRadioReadFifo(radio_rx_buf, UHF_LEN);
			vRadioClearRxFifo();	
			vRadioClearInterrupt(); 
			delay1ms(50);
			bRadioGoRx();	
			SET_LED2();
			}
		if(bKeyscan())
			{
			g_rx_count = 0;
			}
		}

 #endif
		
}

void vBeep(void)
{
	SET_BUZZ();
	for(g_systimer=0; g_systimer<10; )
		delay1ms(1);
	CLR_BUZZ();
}

void vGetTxBuf(void)										//��ȡ�����
{
	word i;

	for(i=0; i<UHF_LEN; i++)
		radio_tx_buf[i] = (byte)i;

}	

//*************************************************************************************************
//keyborad interface
//*************************************************************************************************
byte bReadKey(void)
{
	byte key = 0;
	
	if(KEY1_L())
		key |= 0x01;
	if(KEY2_L())
		key |= 0x02;
	if(KEY3_L())
		key |= 0x04;
	if(KEY4_L())
		key |= 0x08;
	
	return(key);
}

byte bKeyscan(void)								//return: 1-short press, 2-2s-press, 3-press & hold,  0-none
{
	byte key = 0;
	
	key = bReadKey();
	 
	if(key!=0)
		{
		if(g_key_press_F==0)					//1st trigger
			{
			g_keytimer = 0;
			do
				{
				if(bReadKey()==0)
					break;
				delay1ms(5);
				}while(g_keytimer<5);
			if(g_keytimer>=5)
				{
				g_key_press_F = 1;
				g_key_value = bReadKey();
				return(1);						//trigger active
				}	
			else
				{
				g_key_press_F = 0;	
				return(0);
				}
			}
		else									//hold
			{
			if(key==g_key_value)				//keep on
				{
				if(g_keytimer>=200)
					{
					g_keytimer = 200;	
					return(3);					//hold for 2s
					}
				else
					return(2);				
				}
			else								//press change
				{	
				g_keytimer = 0;							
				g_key_value = key;
				return(1);	
				}
			}
		}
	else										//none
		{
		g_key_press_F = 0;
		return(0);	
		}
}
