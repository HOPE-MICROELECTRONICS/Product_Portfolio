


#ifndef		__HAL_H__
	
	#define __HAL_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif
	
	#include "n32g45x.h"
	#include "n32g45x_conf.h"
	#include "n32g45x_gpio.h"
	#include "n32g45x_tim.h"

	#define		CLOCK_MODE			15		//0 =HSI,  8MHz, 
											//1 =HSE,  8MHz, 
											//2 =PLL(base on HSI), 24MHz	
											//3 =PLL(base on HSI), 36MHz
											//4 =PLL(base on HSI), 48MHz
											//5 =PLL(base on HSI), 56MHz
											//6 =PLL(base on HSI), 72MHz
											//7 =PLL(base on HSI), 96MHz
											//8 =PLL(base on HSI), 128MHz
											//9 =PLL(base on HSE), 24MHz 
											//10=PLL(base on HSE), 36MHz 
											//11=PLL(base on HSE), 48MHz	
											//12=PLL(base on HSE), 56MHz		
											//13=PLL(base on HSE), 72MHz	
											//14=PLL(base on HSE), 96MHz	
											//15=PLL(base on HSE), 128MHz	
											//16=PLL(base on HSE), 144MHz	

	enum
		{
		SYSCLK_PLLSRC_HSI,
		SYSCLK_PLLSRC_HSE,
		};

	
	//***************************************************************************
	//GPIO                                                                       
	//mod[1:0]:  2'b, 00(resv in),   01(10M out),    10(2M out),              11(50M out)
	//cfg[3:2]:  2'b, 00(push-pull), 01(open-drain), 10(push-pull for auxrl), 11(open-drain for auxrl), when mod set as 2'b 01/10/11
	//           2'b, 00(analog),    01(floating),   10(pull-up/down),        11(resv), when mod set as 2'b 00
	//sr:	 1'b, 0(quick toggle), 1(low speed)
	//pod:   1'b, 0(output-high),  1(output-low) for output
	//       1'b, 0(pull-down),    1(pull-up)    for input
	//pbsc:  1'b, 0(none),         1(set or clear)
	//ds:    1'b, 0(high-drv), 	   1(low-drv)
	//***************************************************************************

	//----------------PORTA-------------------------CFG/MOD----sr----pod----ds      
	//#define	PA0				GPIO_PIN_0	    //  1000	   0      0     1    	//resv
	#define		KEY3			GPIO_PIN_1      //  1000       0      0     1		//
	//#define	PA2				GPIO_PIN_2      //  1000       0      0     1 		//UART TxD
 	//#define	PA3				GPIO_PIN_3      //  1000       0      0     1		//UART RxD
 	//#define	RF_CSB			GPIO_PIN_4      //  1000       0      0     1		//2310 CSB
	//#define	RF_SCK			GPIO_PIN_5      //  1000       0      0     0		//2310 SCK
	//#define	RF_SDO			GPIO_PIN_6      //  1000       0      0     1		//2310 SDO
	//#define	RF_SDI			GPIO_PIN_7      //  1000       0      0     1		//2310 SDI
	//#define	PA8				GPIO_PIN_8      //  1000       0      0     1     	//resv/MCO	
	#define		UART_RxD		GPIO_PIN_9      //  1000       0      0     1     	**
	#define		UART_TxD		GPIO_PIN_10     //  1000       0      0     1     	**
	//#define	USB_DM			GPIO_PIN_11     //  1000       0      0     1
	//#define	USB_DP			GPIO_PIN_12     //  1000       0      0     1
	//#define	SWD_SWDIO		GPIO_PIN_13     //  1000       0      0     0     	**
	//#define	SWD_SWCLK		GPIO_PIN_14     //  1000       0      0     0     	**
	//#define	PA15			GPIO_PIN_15     //  1000       0      0     1   	//resv
	
	//----------------PORTB-------------------------CFG/MOD----sr----pod----ds      
	#define		KEY1			GPIO_PIN_0      //  1000       0      0     1  
	#define		BUZZ			GPIO_PIN_1      //  0001       0      0     0  
	//#define	PB2				GPIO_PIN_2      //  1000       0      0     1  
	//#define	PB3				GPIO_PIN_3      //  1000       0      0     1  
	//#define	PB4				GPIO_PIN_4      //  1000       0      0     1  
	//#define					GPIO_PIN_5      //  0001       0      0     0  
	//#define					GPIO_PIN_6      //  0001       0      0     0  
	//#define					GPIO_PIN_7      //  0001       0      0     0  
	//#define					GPIO_PIN_8      //  0001       0      0     0  
	//#define					GPIO_PIN_9      //  0001       0      0     0  
	//#define					GPIO_PIN_10     //  0001       0      0     0  
	//#define					GPIO_PIN_11     //  0001       0      0     0  
	//#define					GPIO_PIN_12     //  0001       0      0     0 
	//#define	PB13			GPIO_PIN_13     //  1000       0      0     1      
	//#define	PB14			GPIO_PIN_14     //  1000       0      0     1        
	//#define					GPIO_PIN_15     //  0001       0      0     0     	
	
	//----------------PORTC-------------------------CFG/MOD----sr----pod----ds  
	//#define					GPIO_PIN_0		//	0001       0      0     0
	//#define					GPIO_PIN_1		//	0001       0      0     0
	//#define					GPIO_PIN_2		//	0001       0      0     0
	//#define					GPIO_PIN_3		//	0001       0      0     0
	//#define	RF_GPIO2		GPIO_PIN_4		//	1000       0      0     0
	//#define	RF_GPIO3		GPIO_PIN_5		//	1000       0      0     0
	//#define					GPIO_PIN_6     	//	0001       0      0     0
	//#define					GPIO_PIN_7     	//	0001       0      0     0	
	//#define					GPIO_PIN_8     	//	0001       0      0     0
	//#define					GPIO_PIN_9     	//	0001       0      0     0	
	//#define					GPIO_PIN_10     //	0001       0      0     0
	//#define					GPIO_PIN_11    	//	0001       0      0     0	
	#define		KEY4			GPIO_PIN_12    	//	1000       0      0     1
	//#define	PC13			GPIO_PIN_13		//	1000       0      0     1	
	//#define	LSE_XI			GPIO_PIN_14     //	0001       0      0     0
	//#define	LSE_XO			GPIO_PIN_15     //	0001       0      0     0
	
	//----------------PORTD-------------------------CFG/MOD----sr----pod----ds   
 	//#define	PD0				GPIO_PIN_0		//  1000       0      0     1  
	//#define	RF_GPIO5		GPIO_PIN_1      //  1000       0      0     0  
	//#define	RF_GPIO4		GPIO_PIN_2      //  1000       0      0     0  
	//#define					GPIO_PIN_3      //  0001       0      0     0  
	//#define					GPIO_PIN_4     	//  0001       0      0     0   
	//#define					GPIO_PIN_5     	//  0001       0      0     0   
	//#define					GPIO_PIN_6     	//  0001       0      0     0    	
	//#define					GPIO_PIN_7      //  0001       0      0     0    
	//#define					GPIO_PIN_8      //  0001       0      0     0  
	#define		KEY2			GPIO_PIN_9      //  1000       0      0     1  
	//#define					GPIO_PIN_10     //  0001       0      0     0  
	//#define					GPIO_PIN_11     //  0001       0      0     0  
	//#define					GPIO_PIN_12     //  0001       0      0     0  
	//#define					GPIO_PIN_13     //  0001       0      0     0  
	//#define					GPIO_PIN_14     //  0001       0      0     0  
	//#define					GPIO_PIN_15     //  0001       0      0     0  
	
	//----------------PORTF-------------------------CFG/MOD----sr----pod----ds   
 	//#define	Flash_CS		GPIO_PIN_0		//  1000       0      0     1 
	//#define	Flash_SCK		GPIO_PIN_1      //  1000       0      0     1 
	//#define	Flash_SI		GPIO_PIN_2      //  1000       0      0     1 
	//#define	Flash_SO		GPIO_PIN_3      //  1000       0      0     1 
	//#define	Flash_WP		GPIO_PIN_4     	//  1000       0      0     1 	
	//#define	Flash_HD		GPIO_PIN_5     	//  1000       0      0     1  
	//#define					GPIO_PIN_6     	//  0001       0      0     0 
	//#define					GPIO_PIN_7      //  0001       0      0     0 
	//#define					GPIO_PIN_8      //  0001       0      0     0 
	//#define					GPIO_PIN_9      //  0001       0      0     0 
	//#define					GPIO_PIN_10     //  0001       0      0     0 
	//#define					GPIO_PIN_11     //  0001       0      0     0 
	//#define					GPIO_PIN_12     //  0001       0      0     0 
	//#define					GPIO_PIN_13     //  0001       0      0     0 
	//#define					GPIO_PIN_14     //  0001       0      0     0 
	//#define					GPIO_PIN_15     //  0001       0      0     0 
	
	//----------------PORTG-------------------------CFG/MOD----sr----pod----ds   
 	#define		LED1			GPIO_PIN_0		//  0001       0      0     0 
	#define		LED2			GPIO_PIN_1      //  0001       0      0     0 
	#define		LED3			GPIO_PIN_2      //  0001       0      0     0 
	//#define					GPIO_PIN_3      //  0001       0      0     0 
	//#define					GPIO_PIN_4     	//  0001       0      0     0 	
	//#define					GPIO_PIN_5     	//  0001       0      0     0  
	//#define					GPIO_PIN_6     	//  0001       0      0     0 
	//#define					GPIO_PIN_7      //  0001       0      0     0 
	//#define					GPIO_PIN_8      //  0001       0      0     0 
	//#define					GPIO_PIN_9      //  0001       0      0     0 
	//#define					GPIO_PIN_10     //  0001       0      0     0 
	//#define					GPIO_PIN_11     //  0001       0      0     0 
	//#define					GPIO_PIN_12     //  0001       0      0     0 
	//#define					GPIO_PIN_13     //  0001       0      0     0 
	//#define					GPIO_PIN_14     //  0001       0      0     0 
	//#define					GPIO_PIN_15     //  0001       0      0     0 

	#define		GPIOA_CFG_PMODE_L_VAL		0x88888888		
	//#define		GPIOA_CFG_PMODE_H_VAL		0x88888888		//for uart
	#define		GPIOA_CFG_PMODE_H_VAL		0x88888118		//for led
	
	#define		GPIOB_CFG_PMODE_L_VAL		0x11188818
	#define		GPIOB_CFG_PMODE_H_VAL		0x18811111
	
	#define		GPIOC_CFG_PMODE_L_VAL		0x11881111
	#define		GPIOC_CFG_PMODE_H_VAL		0x11881111	

	#define		GPIOD_CFG_PMODE_L_VAL		0x11111888	
	#define		GPIOD_CFG_PMODE_H_VAL		0x11111181

	#define		GPIOF_CFG_PMODE_L_VAL		0x11888888	
	#define		GPIOF_CFG_PMODE_H_VAL		0x11111111

	#define		GPIOG_CFG_PMODE_L_VAL		0x11111111	
	#define		GPIOG_CFG_PMODE_H_VAL		0x11111111

	#define		GPIOA_CFG_PMODE_H_MASK		0x0FF00000		//for swd
	
	#define		GPIOA_SR_VAL				0x00000000
	#define		GPIOB_SR_VAL				0x00000000
	#define		GPIOC_SR_VAL				0x00000000
	#define		GPIOD_SR_VAL				0x00000000
	#define		GPIOF_SR_VAL				0x00000000
	#define		GPIOG_SR_VAL				0x00000000
                                    		
	#define		GPIOA_POD_VAL				0x00009FDF
	#define		GPIOB_POD_VAL				0x0000601D
	#define		GPIOC_POD_VAL				0x00003000
	#define		GPIOD_POD_VAL				0x00000201
	#define		GPIOF_POD_VAL				0x0000003F
	#define		GPIOG_POD_VAL				0x00000000
                                    		
	#define		GPIOA_DS_VAL				0x00000000
	#define		GPIOB_DS_VAL				0x00000000
	#define		GPIOC_DS_VAL				0x00000000
	#define		GPIOD_DS_VAL				0x00000000
	#define		GPIOF_DS_VAL				0x00000000
	#define		GPIOG_DS_VAL				0x00000000

	//output	
	#define		SET_LED1()		(GPIOG->PBSC=LED1)
	#define		CLR_LED1()		(GPIOG->PBC =LED1)
	
	#define		SET_LED2()		(GPIOG->PBSC=LED2)
	#define		CLR_LED2()		(GPIOG->PBC =LED2)
	
	#define		SET_LED3()		(GPIOG->PBSC=LED3)
	#define		CLR_LED3()		(GPIOG->PBC =LED3)
	
	#define		SET_BUZZ()		(GPIOB->PBSC=BUZZ)
	#define		CLR_BUZZ()		(GPIOB->PBC =BUZZ)
	
	#define		SET_TX_LED()	(GPIOA->PBSC=GPIO_PIN_10)
	#define		CLR_TX_LED()	(GPIOA->PBC =GPIO_PIN_10)		

	#define		SET_RX_LED()	(GPIOA->PBSC=GPIO_PIN_9)
	#define		CLR_RX_LED()	(GPIOA->PBC =GPIO_PIN_9)		
	
	//input
	#define		KEY1_H()		((GPIOB->PID&KEY1)==KEY1)
	#define		KEY1_L()		((GPIOB->PID&KEY1)==0)
	
	#define		KEY2_H()		((GPIOD->PID&KEY2)==KEY2)
	#define		KEY2_L()		((GPIOD->PID&KEY2)==0)	

	#define		KEY3_H()		((GPIOA->PID&KEY3)==KEY3)
	#define		KEY3_L()		((GPIOA->PID&KEY3)==0)	

	#define		KEY4_H()		((GPIOC->PID&KEY4)==KEY4)
	#define		KEY4_L()		((GPIOC->PID&KEY4)==0)	

	
	// vars
	extern RCC_ClocksType 	RCC_ClockFreq;
	extern ErrorStatus 	HSEStartUpStatus;
	extern ErrorStatus 	HSIStartUpStatus;
	
	
	// apis
	extern void vSysClockInit(void);
	extern void vGpioInit(void);
	extern void vKeyInputExtiInit(FunctionalState cmd);
	extern void vTimer4Configuration(void);

	

	extern void SetSysClockToHSI(void);
	extern void SetSysClockToHSE(void);
	extern void SetSysClockToPLL(uint32_t freq, uint8_t src);
	//extern void vSetSysClock_LSI(void);
	//extern void vSetSysClock_LSE(void);	
	

	#ifdef	__cplusplus
		}
	#endif

#endif 
	
