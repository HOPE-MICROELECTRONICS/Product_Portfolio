.\objects\startup_n32g45x.o: common\device\startup\startup_n32g45x.s
