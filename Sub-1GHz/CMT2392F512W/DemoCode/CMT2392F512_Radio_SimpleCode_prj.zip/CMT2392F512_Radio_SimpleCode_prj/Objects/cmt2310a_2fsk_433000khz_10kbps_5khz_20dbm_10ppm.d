.\objects\cmt2310a_2fsk_433000khz_10kbps_5khz_20dbm_10ppm.o: RadioExport\CMT2310A_2fsk_433000kHz_10kbps_5kHz_20dBm_10ppm.c
.\objects\cmt2310a_2fsk_433000khz_10kbps_5khz_20dbm_10ppm.o: .\Radio\CMT2310A_reg.h
.\objects\cmt2310a_2fsk_433000khz_10kbps_5khz_20dbm_10ppm.o: .\Radio\CMT2310A_def.h
