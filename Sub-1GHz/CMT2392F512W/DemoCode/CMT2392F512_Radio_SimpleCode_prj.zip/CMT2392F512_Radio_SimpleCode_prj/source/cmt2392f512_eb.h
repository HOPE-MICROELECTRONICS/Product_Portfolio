
#ifndef		__CMT2392F512_EB_H__
	
	#define __CMT2392F512_EB_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif

	#include "n32g45x.h"
	#include "n32g45x_conf.h"
	#include "n32g45x_gpio.h"
	#include "hal.h"
	#include "radio.h"

	#include <stdio.h>




	#define		UHF_LEN				10
	
	#define		LIMIT_TIMER_TX_CNT	100

	//***************************************************************************
	// vars
	//***************************************************************************
	extern word 		g_systimer;
	extern word 		g_keytimer;	
	extern byte			g_key_value;
	extern boolean_t	g_key_press_F;


	extern byte   	 	radio_rx_buf[UHF_LEN];
	extern byte 		radio_tx_buf[UHF_LEN];
	extern word 		g_rx_count;
	extern word 		g_tx_count;


	//***************************************************************************
	// functions
	//***************************************************************************
	//main.c
	extern void vNvicConfiguration(void);
	extern void vBeep(void);
	extern void vGetTxBuf(void);
	extern void vMcuInit(void);
	extern byte bReadKey(void);
	extern byte bKeyscan(void);
	


	#ifdef	__cplusplus
		}
	#endif

#endif 






