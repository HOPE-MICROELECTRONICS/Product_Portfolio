//******************************************************************************
// THE FOLLOWING FIRMWARE IS PROVIDED: 
//  (1) "AS IS" WITH NO WARRANTY; 
//  (2) TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
// CONSEQUENTLY, HopeRF SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
// CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
// OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
// CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
// 
// Copyright (C) HopeRF
// website: www.HopeRF.com
//          www.HopeRF.cn
//******************************************************************************

//******************************************************************************
//   CMT2189B DEMO
//******************************************************************************
//Schematic:        --------------
//               1-|AVDD      XTAL|-14
//               2-|GND        GND|-13
//               3-|PAP    PC4/DAT|-12-LED
//               4-|PAN       DVDD|-11
//               5-|PC2/CLK    GND|-10
//         KEY3--6-|PA5        PA1|-9--KEY1
//         KEY4--7-|PA2        PA0|-8--KEY2
//                  --------------
//
//Function: 
//1. Press KEY1��2��3��4��and send packet
//2. When Battery Voltage is low than TH Value, the tx power will be to -10dBm
//******************************************************************************

#include "CMT.h"     
#include "CMT60F02X.h"

typedef  unsigned char byte;
typedef  unsigned int  word;

											// 	   mode	 dat  Pullup   IOC
#define		KEY1    	RA0					//		1     1     1       1
#define 	KEY2 	    RA1					//		1     1     1       1
#define		KEY4		RA2					//		1     1     1       1 
//#define	Unused		RA3					//		0     0     0       0
//#define	Unused		RA4					//		0     0     0       0
#define		KEY3		RA5					//		1     1     1       1
//#define 	Unused		RA6					//		0	  0	    0       0
//#define	Unused		RA7					//      0     0     0       0

											//     moode  dat   
//#define	Unused		RC0					//      0     0             
//#define	Unused		RC1					//      0     0
#define 	RF_Clk		RC2 				//      1     1
//#define 	Unused 		RC3					//      0	  0
#define 	RF_Dat		RC4					//      1     0
//#define 	Unused		RC5					//      0     0
//#define 	Unused 		RC6					//      0     0 
//#define 	Unused		RC7					//      0     0


#define		PORTA_DEF	0b00100111
#define		PORTC_DEF	0b00000100
                                             
#define		TRISA_DEF	0b00100111  
#define		TRISC_DEF	0b00010100			//Sleep for let USB Programmer to burn CMT2119A
#define		TRISC_CTRL	0b00000000			//Control mode for mcu configure the CMT2119A
#define		TRISC_READ	0b00010000			//Control mode for mcu read from twi
                                             
#define		WPUA_DEF	0b00100111
#define		IOCA_DEF	0b00100111

//******************
//Constant Define
//******************
#define		INTCON_DEF          0b00000000  //Disable GIE, TMR0IE etc.

#define		OPTION_DEF          0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV1_DEF     0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV2_DEF		0b00000001	//PORTA pull-ups are enable;Timer0 1:4
#define		OPTION_DIV3_DEF		0b00000010	//PORTA pull-ups are enable;Timer0 1:8
#define		OPTION_DIV4_DEF		0b00000011	//PORTA pull-ups are enable;Timer0 1:16
#define		OPTION_DIV5_DEF		0b00000100	//PORTA pull-ups are enable;Timer0 1:32
#define		OPTION_DIV6_DEF		0b00000101	//PORTA pull-ups are enable;Timer0 1:64
#define		OPTION_DIV7_DEF		0b00000110	//PORTA pull-ups are enable;Timer0 1:128
#define		OPTION_DIV8_DEF		0b00000111	//PORTA pull-ups are enable;Timer0 1:256

#define		OSCCON_16M_DEF      0b01110101  //16MHz INTERNAL OSC
#define		OSCCON_8M_DEF       0b01100101  //8MHz INTERNAL OSC
#define		OSCCON_4M_DEF       0b01010101  //4MHz INTERNAL OSC
#define		OSCCON_2M_DEF       0b01000101  //2MHz INTERNAL OSC
#define		OSCCON_1M_DEF       0b00110101  //1MHz INTERNAL OSC
#define		OSCCON_0M5_DEF      0b00100101  //500KHz INTERNAL OSC
#define		OSCCON_250K_DEF     0b00010101  //250KHz INTERNAL OSC
#define		OSCCON_32K_DEF      0b00010101  //32KHz INTERNAL OSC
#define		CMCON0_DEF			0b00000111	//all for digtal IO

#define		WDTCON_DIV5_DEF		0b00000000
#define		WDTCON_DIV6_DEF		0b00000010
#define		WDTCON_DIV7_DEF		0b00000100
#define		WDTCON_DIV8_DEF		0b00000110
#define		WDTCON_DIV9_DEF		0b00001000
#define		WDTCON_DIV10_DEF	0b00001010
#define		WDTCON_DIV11_DEF	0b00001100
#define		WDTCON_DIV12_DEF	0b00001110
#define		WDTCON_DIV13_DEF	0b00010000
#define		WDTCON_DIV14_DEF	0b00010010
#define		WDTCON_DIV15_DEF	0b00010100
#define		WDTCON_DIV16_DEF	0b00010110

#define		TOUTPS_DIV1_DEF		0b00000000		//TOUTPS 1:1
#define		TOUTPS_DIV2_DEF		0b00001000		//TOUTPS 1:2
#define		TOUTPS_DIV3_DEF		0b00010000		//TOUTPS 1:3
#define		TOUTPS_DIV4_DEF		0b00011000		//TOUTPS 1:4
#define		TOUTPS_DIV5_DEF		0b00100000		//TOUTPS 1:5
#define		TOUTPS_DIV6_DEF		0b00101000		//TOUTPS 1:6
#define		TOUTPS_DIV7_DEF		0b00110000		//TOUTPS 1:7
#define		TOUTPS_DIV8_DEF		0b00111000		//TOUTPS 1:8
#define		TOUTPS_DIV9_DEF		0b01000000		//TOUTPS 1:9
#define		TOUTPS_DIV10_DEF	0b01001000		//TOUTPS 1:10
#define		TOUTPS_DIV11_DEF	0b01010000		//TOUTPS 1:11
#define		TOUTPS_DIV12_DEF	0b01011000		//TOUTPS 1:12
#define		TOUTPS_DIV13_DEF	0b01100000		//TOUTPS 1:13
#define		TOUTPS_DIV14_DEF	0b01101000		//TOUTPS 1:14
#define		TOUTPS_DIV15_DEF	0b01110000		//TOUTPS 1:15
#define		TOUTPS_DIV16_DEF	0b01111000		//TOUTPS 1:16

#define		T2CKPS_DIV0_DEF		0b00000000		//T2CKPS 1:1
#define		T2CKPS_DIV2_DEF		0b00000001		//T2CKPS 1:4
#define		T2CKPS_DIV4_DEF		0b00000010		//T2CKPS 1:16

//******************
//Radio LBD
//******************

#define 	CHK_1V8			0x00	//VDD<2.0V
#define 	CHK_2V0			0x01	//2.0V-2.2V
#define 	CHK_2V2			0x02	//2.2V-2.4V
#define 	CHK_2V4			0x03	//2.4V-2.6V
#define 	CHK_2V6 		0x04	//2.6V-2.8V
#define 	CHK_2V8			0x05	//2.8V-3.0V
#define 	CHK_3V0			0x06	//3.0V-3.2V
#define 	CHK_3V2			0x07	//3.2V-3.4V
#define 	CHK_3V4			0x08	//VDD>3.4V

//******************
//Global Variable
//******************
volatile  bit	KeyPre_F;
volatile  bit 	LowVolt_F;

byte KeyTimer;
byte SysTimer;
byte KeyCode;

byte TxBuf[3];


const byte IdTable[3] @0x08 = {'\1', '\2', '\3'};

const word CfgTable[21] = {
	                      	0x007F,					//Mode                = Advanced                             
							0x5400,					//Part Number         = CMT2119A                             
							0x0000,					//Frequency           = 433.92 MHz                           
							0x0000,					//Modulation          = OOK                                  
							0x0000,					//Symbol Rate         = 0.5-30.0 ksps                        
							0xF000,					//Tx Power            = +13 dBm                              
							0x0000,					//Deviation           = NA                                   
							0xC1C5,					//PA Ramping Time     = 0 us                                 
							0x4200,					//Xtal Cload          = 15.00 pF                             
							0x0000,					//Data Representation = NA                                   
							0x2401,					//Tx Start by         = DATA Pin Rising Edge                 
							0x01B0,					//Tx Stop by          = DATA Pin Holding Low For 20 ms       
							0x8000,					//Increase XO Current = No                                   
							0x0007,					//FILE CRC            = B120                                 
							0xFFFF,					//
							0x0020,					//
							0x5FD9,					//
							0x22D6,					//
							0x0E13,					//
							0x0019,					//
							0x2000
	                      };

void TwiRst(void);
void TwiOff(void);
void TwiInit(void);
void TwiTddDelay(void);
byte TwiReadByte(void);
void TwiWriteByte(byte WrPara);
byte TwiReadCmd(byte adr);
void TwiWriteCmd(byte adr, byte WrPara);
word TwiReadReg(byte adr);
void TwiWriteReg(byte adr, word WrPara);
void RadioEnableRegMode(void);
void RadioActiveReg(void);
void RadioLdoAndOscOff(void);
void RadioLdoAndOscOn(void);
void RadioSoftRst(void);
void RadioGoTx(void);


void Timer0Irq(void)
{
 if(T0IF)	
 	{
 	T0IF = 0;
 	SysTimer++;
 	KeyTimer++;
 	}
}

byte ReadKey(void)
{
 return((PORTA^0x27)&0x27);
}

void AssemblePacket(void)
{
 byte tmp;
 
 TxBuf[0] = IdTable[0];
 TxBuf[1] = IdTable[1];
 TxBuf[2] = IdTable[2];
 TxBuf[2] <<= 4;
 TxBuf[2] &= 0xF0;
 
 tmp = KeyCode&0x07;
 if(KeyCode&0x20)
 	tmp |= 0x08;
 TxBuf[2] |= tmp;
}

void KeyScan(void)
{
 byte tmp;
 
 Timer0Irq();
 tmp = ReadKey();
 
 if(!KeyPre_F)
 	{
 	if(tmp!=0)
 		{
 		for(KeyTimer=0; KeyTimer<4; )
 			{
 			CLRWDT();	
 			Timer0Irq();
 			if(tmp!=ReadKey())
 				break;
 			}
 		if(KeyTimer>=4)
 			{
 			KeyCode  = tmp;
 			KeyPre_F = 1;
 			AssemblePacket();
 			RadioGoTx();
 			return;
 			}
		}
	KeyPre_F = 0;
 	KeyCode  = 0;
 	}	
 else
 	{
 	if(tmp!=KeyCode)
 		{
 		KeyCode  = tmp;
 		KeyPre_F = 1;
 		AssemblePacket();
 		return;
 		}
 	else if(tmp==0)
 		{
 		KeyTimer = 0;
 		for(KeyTimer=0; KeyTimer<2; )
 			{
 			CLRWDT();
 			Timer0Irq();
 			if(0!=ReadKey())
 				break;
 			}
 		if(KeyTimer>=2)
 			{
 			KeyPre_F = 0;
 			KeyCode  = 0;
 			RadioSoftRst();
 			}
 		else
 			{
 			KeyCode  = tmp;
 			KeyPre_F = 1;
 			AssemblePacket();
 			RadioGoTx();
 			}
 		}
 	else
 		return;
 	}
 	
}

void UnitDelay(void)
{
 byte i;
 for(i=135; i!=0; i--)
 	{
	CLRWDT();  		
	Timer0Irq();
	}
}

void SendPacket(void)
{
 byte i, z;
 
 TRISC = TRISC_CTRL;
 
 RF_Dat  = 1;
 UnitDelay();
 
 RF_Dat  = 0;
 for(i=31; i!=0; i--)
 	UnitDelay();
 
 for(i=0; i<3; i++)
 	{
 	for(z=0x80; z!=0; z>>=1)	
 		{
 		RF_Dat = 1;
 		UnitDelay();
 		
 		if(TxBuf[i]&z)
 			RF_Dat = 1;
 		else
 			RF_Dat = 0;
 		UnitDelay();
 		UnitDelay();
 	
 		RF_Dat = 0;
		UnitDelay();
		}
 	}
}

void Initial(void)
{
 OSCCON = OSCCON_8M_DEF;		

 PORTA  = PORTA_DEF;    		//Port initial
 TRISA  = TRISA_DEF;    
 WPUA   = WPUA_DEF;    	
 IOCA	= IOCA_DEF;

 PORTC  = PORTC_DEF;
 TRISC  = TRISC_DEF;

 OPTION = OPTION_DIV6_DEF;  	//
 INTCON = INTCON_DEF;          	//Disable interrutp
 
 CMCON0 = CMCON0_DEF;
 
 WDTCON = WDTCON_DIV16_DEF;
}



void main(void)
{
 byte i;
 Initial();
 
 for(SysTimer=0; SysTimer<4; ) 
 	Timer0Irq();
 
 while(1)
 	{
	KeyScan();
	if(KeyPre_F)
		SendPacket();
	else
		{
		KeyCode = 0;
		RF_Dat  = 0;
		PAIF	= 0;
		PEIE    = 1;
		PAIE    = 1;
		PORTA   = PORTA;
		
		SLEEP();
		
		for(i=100; i!=0; i--)
			CLRWDT();
		
		PEIE    = 0;
		PAIE    = 0;
		PAIF    = 0;
		}
 	}
}


//************************************************
//Radio HAL
//************************************************
//************************************************
//RadioGoTx
//************************************************
void RadioGoTx(void)
{
 byte i;
 word tmp;
 
 TwiRst();						//Step1
 RadioSoftRst();				//Step2
 for(i=5; i!=0; i--)			//		wait for 2ms	
 	UnitDelay();				
 
 RadioLdoAndOscOn();			//Step3
 RadioActiveReg();				//Step4
 RadioEnableRegMode();			//Step5
 
 TwiWriteReg(0x10, 0x4705);		//Min Power
 tmp = TwiReadReg(0x06);
 tmp |= 0x0010; 				//Enable LBD
 TwiWriteReg(0x06, tmp);
 
 TwiOff();						
 TRISC = TRISC_CTRL;
 RF_Dat = 1;
 for(i=3; i!=0; i--)
 	UnitDelay();
 RF_Dat = 0;
 TwiRst();
 i = TwiReadCmd(0x3E)&0x0F;
 if(i<CHK_2V4)
 	LowVolt_F = 1;
 else
 	LowVolt_F = 0;
 
 RadioSoftRst();				//Step2
 for(i=5; i!=0; i--)			//		wait for 2ms	
 	UnitDelay();				
 
 RadioLdoAndOscOn();			//Step3
 RadioActiveReg();				//Step4
 RadioEnableRegMode();			//Step5
 
 for(i=0; i<21; i++)			//Step6
 	{
 	TwiWriteReg(i, (word)CfgTable[i]);
	//TwiReadReg(i);
	}
 if(LowVolt_F) 
 	 TwiWriteReg(0x10, 0x4705);	//Min Power

 TwiOff();						//Step7
 RF_Dat = 0;
}

//************************************************
//RadioSoftRst
//************************************************
void RadioSoftRst(void)
{
 TwiWriteCmd(0x3D, 0x01);		//0xBD01
}

//************************************************
// RadioLdoAndOscOn/Off
//************************************************
void RadioLdoAndOscOn(void)
{
 TwiWriteCmd(0x02, 0x78);
}

void RadioLdoAndOscOff(void)
{
 TwiWriteCmd(0x02, 0x7F);
}

//************************************************
//Active Register Mode
//************************************************
void RadioActiveReg(void)
{
 TwiWriteCmd(0x2F, 0x80);	
 TwiWriteCmd(0x35, 0xCA);
 TwiWriteCmd(0x36, 0xEB);	
 TwiWriteCmd(0x37, 0x37);
 TwiWriteCmd(0x38, 0x82);
}

//************************************************
//Radio Enable Mode
//************************************************
void RadioEnableRegMode(void)
{
 TwiWriteCmd(0x12, 0x10);	
 TwiWriteCmd(0x12, 0x00);
 TwiWriteCmd(0x24, 0x07);	
 TwiWriteCmd(0x1D, 0x20);
}

//************************************************
//TwiWriteReg
//************************************************
void TwiWriteReg(byte adr, word WrPara)
{
 TwiWriteCmd(0x18, adr);		
 TwiWriteCmd(0x19, (byte)(WrPara));
 TwiWriteCmd(0x1A, (byte)(WrPara>>8));
 TwiWriteCmd(0x25, 0x01);
}

//************************************************
//TwiReadReg
//************************************************
word TwiReadReg(byte adr)
{
 byte Rd_H, Rd_L;
 
 TwiWriteCmd(0x18, adr);		
 Rd_L = TwiReadCmd(0x1b);
 Rd_H = TwiReadCmd(0x1c);
 return((((word)Rd_H)<<8)|(Rd_L));
}

//************************************************
//Twi Write Command
//************************************************
void TwiWriteCmd(byte adr, byte WrPara)
{
 TwiInit();	
 adr |= 0x80;
 adr &= 0xBF;
 TwiWriteByte(adr);
 TwiWriteByte(WrPara);
 TwiTddDelay();
}

//************************************************
//Twi Read Command
//************************************************
byte TwiReadCmd(byte adr)
{
 byte tmp;
 TwiInit();
 adr |= 0xC0;

 TwiWriteByte(adr);
 tmp =  TwiReadByte();
 TwiTddDelay();
 return(tmp);
}

//************************************************
//TwiRst
//************************************************
void TwiRst(void)
{
 byte i;
 TwiInit();
 
 RF_Dat = 0;
 for(i=32; i!=0; i--)
 	{
 	RF_Clk = 1;
 	NOP();
 	NOP();
 	NOP();
 	NOP();
 	RF_Clk = 0;
	}
 TwiTddDelay();
 TwiWriteCmd(0x0D, 0x00);	 
}

//************************************************
//TwiOff
//************************************************
void TwiOff(void)
{
 TwiInit();		
 TwiWriteByte(0x8D);
 TwiWriteByte(0x02);
 TwiTddDelay();
}

//************************************************
//TwiWriteByte
//************************************************
void TwiWriteByte(byte WrPara)
{
 byte i;

 RF_Dat = 1;
 for(i=8;i!=0;i--)
 	{
 	RF_Clk = 1;
 	if(WrPara&0x80)
 		RF_Dat = 1;
 	else
 		RF_Dat = 0;
 	RF_Clk = 0;
 	WrPara <<= 1;
 	}
}

//************************************************
//TwiReadByte
//************************************************
byte TwiReadByte(void)
{
 byte i, RdPara;
 
 TRISC = TRISC_READ;
 
 for(i=8;i!=0;i--)
 	{
 	RF_Clk = 1;
 	RdPara <<= 1;
 	RF_Clk = 0; 	
 	if(RF_Dat)
 		RdPara |= 0x01;
 	else
 		asm("NOP");
 	}
 
 TRISC = TRISC_CTRL;	
 return(RdPara);
}

void TwiTddDelay(void)
{  
 byte i;
 RF_Clk = 1;
 for(i=10; i!=0; i--)
 	NOP();
 TRISC = TRISC_DEF;
 PORTC = PORTC_DEF;
}

void TwiInit(void)
{
 RF_Dat = 0;	
 RF_Clk = 1;
 TRISC = TRISC_CTRL;
 return;
}

