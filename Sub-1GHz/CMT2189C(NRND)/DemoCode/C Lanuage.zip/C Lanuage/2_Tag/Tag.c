//******************************************************************************
// THE FOLLOWING FIRMWARE IS PROVIDED: 
//  (1) "AS IS" WITH NO WARRANTY; 
//  (2) TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
// CONSEQUENTLY, HopeRF SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
// CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
// OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
// CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
// 
// Copyright (C) HopeRF
// website: www.HopeRF.com
//          www.HopeRF.cn
//******************************************************************************

//******************************************************************************
//   CMT2189B DEMO
//******************************************************************************
//Schematic:        --------------
//               1-|AVDD      XTAL|-14
//               2-|GND        GND|-13
//               3-|PAP    PC4/DAT|-12-LED
//               4-|PAN       DVDD|-11
//               5-|PC2/CLK    GND|-10
//         KEY3--6-|PA5        PA1|-9--KEY1
//         KEY4--7-|PA2        PA0|-8--KEY2
//                  --------------
//
//Function: 
//1. Press KEY1��2��3��4��and send packet
//2. RadioCfgTable can used to change tx power & frequency, etc.
//3. WDT used for wakeup timer
//******************************************************************************

#include "CMT.h"     
#include "CMT60F02X.h"

typedef  unsigned char byte;
typedef  unsigned int  word;

											// 	   mode	 dat  Pullup   IOC
//#define	Unused    	RA0					//		0     0     0       0
//#define 	Unused 	    RA1					//		0     0     0       0
//#define	Unused		RA2					//		0     0     0       0 
//#define	Unused		RA3					//		0     0     0       0
//#define	Unused		RA4					//		0     0     0       0
//#define	Unused		RA5					//		1     1     0       0
//#define 	Unused		RA6					//		0	  0	    0       0
//#define	Unused		RA7					//      0     0     0       0

											//     moode  dat   
//#define	Unused		RC0					//      0     0             
//#define	Unused		RC1					//      0     0
#define 	RF_Clk		RC2 				//      1     1
//#define 	Unused 		RC3					//      0	  0
#define 	RF_Dat		RC4					//      1     0
//#define 	Unused		RC5					//      0     0
//#define 	Unused 		RC6					//      0     0 
//#define 	Unused		RC7					//      0     0


#define		PORTA_DEF	0b00100000
#define		PORTC_DEF	0b00000100
                                             
#define		TRISA_DEF	0b00100000  
#define		TRISC_DEF	0b00010100			//Sleep for let USB Programmer to burn CMT2119A
#define		TRISC_CTRL	0b00000000			//Control mode for mcu configure the CMT2119A
#define		TRISC_READ	0b00010000			//Control mode for mcu read from twi
                                             
#define		WPUA_DEF	0b00000000
#define		IOCA_DEF	0b00000000

//******************
//Constant Define
//******************
#define		INTCON_DEF          0b00000000  //Disable GIE, TMR0IE etc.

#define		OPTION_DEF          0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV1_DEF     0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV2_DEF		0b00000001	//PORTA pull-ups are enable;Timer0 1:4
#define		OPTION_DIV3_DEF		0b00000010	//PORTA pull-ups are enable;Timer0 1:8
#define		OPTION_DIV4_DEF		0b00000011	//PORTA pull-ups are enable;Timer0 1:16
#define		OPTION_DIV5_DEF		0b00000100	//PORTA pull-ups are enable;Timer0 1:32
#define		OPTION_DIV6_DEF		0b00000101	//PORTA pull-ups are enable;Timer0 1:64
#define		OPTION_DIV7_DEF		0b00000110	//PORTA pull-ups are enable;Timer0 1:128
#define		OPTION_DIV8_DEF		0b00000111	//PORTA pull-ups are enable;Timer0 1:256

#define		OSCCON_16M_DEF      0b01110101  //16MHz INTERNAL OSC
#define		OSCCON_8M_DEF       0b01100101  //8MHz INTERNAL OSC
#define		OSCCON_4M_DEF       0b01010101  //4MHz INTERNAL OSC
#define		OSCCON_2M_DEF       0b01000101  //2MHz INTERNAL OSC
#define		OSCCON_1M_DEF       0b00110101  //1MHz INTERNAL OSC
#define		OSCCON_0M5_DEF      0b00100101  //500KHz INTERNAL OSC
#define		OSCCON_250K_DEF     0b00010101  //250KHz INTERNAL OSC
#define		OSCCON_32K_DEF      0b00010101  //32KHz INTERNAL OSC
#define		CMCON0_DEF			0b00000111	//all for digtal IO

#define		WDTCON_DIV5_DEF		0b00000000
#define		WDTCON_DIV6_DEF		0b00000010
#define		WDTCON_DIV7_DEF		0b00000100
#define		WDTCON_DIV8_DEF		0b00000110
#define		WDTCON_DIV9_DEF		0b00001000
#define		WDTCON_DIV10_DEF	0b00001010
#define		WDTCON_DIV11_DEF	0b00001100
#define		WDTCON_DIV12_DEF	0b00001110
#define		WDTCON_DIV13_DEF	0b00010000
#define		WDTCON_DIV14_DEF	0b00010010
#define		WDTCON_DIV15_DEF	0b00010100
#define		WDTCON_DIV16_DEF	0b00010110

#define		TOUTPS_DIV1_DEF		0b00000000		//TOUTPS 1:1
#define		TOUTPS_DIV2_DEF		0b00001000		//TOUTPS 1:2
#define		TOUTPS_DIV3_DEF		0b00010000		//TOUTPS 1:3
#define		TOUTPS_DIV4_DEF		0b00011000		//TOUTPS 1:4
#define		TOUTPS_DIV5_DEF		0b00100000		//TOUTPS 1:5
#define		TOUTPS_DIV6_DEF		0b00101000		//TOUTPS 1:6
#define		TOUTPS_DIV7_DEF		0b00110000		//TOUTPS 1:7
#define		TOUTPS_DIV8_DEF		0b00111000		//TOUTPS 1:8
#define		TOUTPS_DIV9_DEF		0b01000000		//TOUTPS 1:9
#define		TOUTPS_DIV10_DEF	0b01001000		//TOUTPS 1:10
#define		TOUTPS_DIV11_DEF	0b01010000		//TOUTPS 1:11
#define		TOUTPS_DIV12_DEF	0b01011000		//TOUTPS 1:12
#define		TOUTPS_DIV13_DEF	0b01100000		//TOUTPS 1:13
#define		TOUTPS_DIV14_DEF	0b01101000		//TOUTPS 1:14
#define		TOUTPS_DIV15_DEF	0b01110000		//TOUTPS 1:15
#define		TOUTPS_DIV16_DEF	0b01111000		//TOUTPS 1:16

#define		T2CKPS_DIV0_DEF		0b00000000		//T2CKPS 1:1
#define		T2CKPS_DIV2_DEF		0b00000001		//T2CKPS 1:4
#define		T2CKPS_DIV4_DEF		0b00000010		//T2CKPS 1:16

//******************
//Global Variable
//******************
byte SysTimer;
byte TxBuf[8];


const byte IdTable[4] @0x08 = {'\1', '\2', '\3', '\4'};

const word CfgTable[21] = {
	                    	0x007F,					//Mode                = Advanced                                
							0x5400,					//Part Number         = CMT2119A                                
							0x0000,					//Frequency           = 433.92 MHz                              
							0x0000,					//Modulation          = FSK                                     
							0x0000,					//Symbol Rate         = 0.5-100.0 ksps                          
							0xF000,					//Tx Power            = +13 dBm                                 
							0x0000,					//Deviation           = 35 kHz                                  
							0xC1C5,					//PA Ramping Time     = NA                                      
							0x4208,					//Xtal Cload          = 15.00 pF                                
							0x0160,					//Data Representation = 0:F-low,1:F-high                        
							0x2401,					//Tx Start by         = DATA Pin Rising Edge                    
							0x0081,					//Tx Stop by          = DATA Pin Holding Low For 20 ms          
							0x8000,					//Increase XO Current = No                                      
							0x0000,					//FILE CRC            = C710                                    
							0xFFFF,					//
							0x0020,					//
							0x5FD9,					//
							0xA2D6,					//
							0x0E13,					//
							0x0019,					//
							0x0000
	                      };

/*
const word CfgTable[21] = {
                            0x007F,					//Mode                = Advanced                                
							0x5000,					//Part Number         = CMT2119A                                
							0x0000,					//Frequency           = 868.35 MHz                              
							0x0000,					//Modulation          = FSK                                     
							0x0000,					//Symbol Rate         = 0.5-100.0 ksps                          
							0xF000,					//Tx Power            = +13 dBm                                 
							0x0000,					//Deviation           = 35 kHz                                  
							0xCBCE,					//PA Ramping Time     = NA                                      
							0x4208,					//Xtal Cload          = 15.00 pF                                
							0x00B0,					//Data Representation = 0:F-low,1:F-high                        
							0x2401,					//Tx Start by         = DATA Pin Rising Edge                    
							0x0081,					//Tx Stop by          = DATA Pin Holding Low For 20 ms          
							0x8000,					//Increase XO Current = No                                      
							0x0000,					//FILE CRC            = 1942                                    
							0xFFFF,					//
							0x0020,					//
							0x5F1E,					//
							0xA2D6,					//
							0x0E13,					//
							0x0019,					//
							0x0000					//
                          };
*/

void TwiRst(void);
void TwiOff(void);
void TwiInit(void);
void TwiTddDelay(void);
byte TwiReadByte(void);
void TwiWriteByte(byte WrPara);
byte TwiReadCmd(byte adr);
void TwiWriteCmd(byte adr, byte WrPara);
word TwiReadReg(byte adr);
void TwiWriteReg(byte adr, word WrPara);
void RadioEnableRegMode(void);
void RadioActiveReg(void);
void RadioLdoAndOscOff(void);
void RadioLdoAndOscOn(void);
void RadioSoftRst(void);
void RadioGoTx(void);


void Timer0Irq(void)
{
 if(T0IF)	
 	{
 	T0IF = 0;
 	SysTimer++;
 	}
}

void AssemblePacket(void)
{
 byte tmp;
 
 TxBuf[0] = 0x2D;				//Sync0
 TxBuf[1] = 0xD4;				//Sync1
 TxBuf[2] = 0x04;				//Length
 TxBuf[3] = IdTable[0];
 TxBuf[4] = IdTable[1];
 TxBuf[5] = IdTable[2];
 TxBuf[6] = IdTable[3];
}

void UnitDelay(void)
{
 byte i;
 for(i=35; i!=0; i--)
 	{
	CLRWDT();  		
	Timer0Irq();
	}
}

void SendByte(byte tx_dat)
{
 byte i;
 
 for(i=0x80; i!=0; i>>=1)
 	{
 	if(tx_dat&i)
 		RF_Dat = 1;
 	else
 		RF_Dat = 0;
 	UnitDelay();
 	}
}

void SendPacket(void)
{
 byte i, z;
 
 TRISC = TRISC_CTRL;
 
 RF_Dat  = 1;
 UnitDelay();
 UnitDelay();
 UnitDelay();
 
 for(i=8; i!=0; i--)
 	SendByte(0xAA);
 
 for(i=0; i<7; i++)
 	SendByte(TxBuf[i]);
 
 SendByte(0xAA);
 SendByte(0xAA);
}

void Initial(void)
{
 OSCCON = OSCCON_8M_DEF;		

 PORTA  = PORTA_DEF;    		//Port initial
 TRISA  = TRISA_DEF;    
 WPUA   = WPUA_DEF;    	
 IOCA	= IOCA_DEF;

 PORTC  = PORTC_DEF;
 TRISC  = TRISC_DEF;

 OPTION = OPTION_DIV6_DEF;  	//
 INTCON = INTCON_DEF;          	//Disable interrutp
 
 CMCON0 = CMCON0_DEF;
 
 WDTCON = WDTCON_DIV16_DEF;
}



void main(void)
{
 byte i;
 Initial();
 
 for(SysTimer=0; SysTimer<4; ) 
 	Timer0Irq();
 
 while(1)
 	{
 	SWDTEN = 1;
 	SLEEP();
 	SWDTEN = 0;

	AssemblePacket();
	RadioGoTx();
	SendPacket();
	RadioSoftRst();
 	}
}


//************************************************
//Radio HAL
//************************************************
//************************************************
//RadioGoTx
//************************************************
void RadioGoTx(void)
{
 byte i;
 
 TwiRst();						//Step1
 RadioSoftRst();				//Step2
 for(i=5; i!=0; i--)			//		wait for 2ms	
 	UnitDelay();				
 
 RadioLdoAndOscOn();			//Step3
 RadioActiveReg();				//Step4
 RadioEnableRegMode();			//Step5
 
 for(i=0; i<21; i++)			//Step6
 	{
 	TwiWriteReg(i, (word)CfgTable[i]);
	//TwiReadReg(i);
	}
 
 TwiOff();						//Step7
 RF_Dat = 0;
}

//************************************************
//RadioSoftRst
//************************************************
void RadioSoftRst(void)
{
 TwiWriteCmd(0x3D, 0x01);		//0xBD01
}

//************************************************
// RadioLdoAndOscOn/Off
//************************************************
void RadioLdoAndOscOn(void)
{
 TwiWriteCmd(0x02, 0x78);
}

void RadioLdoAndOscOff(void)
{
 TwiWriteCmd(0x02, 0x7F);
}

//************************************************
//Active Register Mode
//************************************************
void RadioActiveReg(void)
{
 TwiWriteCmd(0x2F, 0x80);	
 TwiWriteCmd(0x35, 0xCA);
 TwiWriteCmd(0x36, 0xEB);	
 TwiWriteCmd(0x37, 0x37);
 TwiWriteCmd(0x38, 0x82);
}

//************************************************
//Radio Enable Mode
//************************************************
void RadioEnableRegMode(void)
{
 TwiWriteCmd(0x12, 0x10);	
 TwiWriteCmd(0x12, 0x00);
 TwiWriteCmd(0x24, 0x07);	
 TwiWriteCmd(0x1D, 0x20);
}

//************************************************
//TwiWriteReg
//************************************************
void TwiWriteReg(byte adr, word WrPara)
{
 TwiWriteCmd(0x18, adr);		
 TwiWriteCmd(0x19, (byte)(WrPara));
 TwiWriteCmd(0x1A, (byte)(WrPara>>8));
 TwiWriteCmd(0x25, 0x01);
}

//************************************************
//TwiReadReg
//************************************************
word TwiReadReg(byte adr)
{
 byte Rd_H, Rd_L;
 
 TwiWriteCmd(0x18, adr);		
 Rd_L = TwiReadCmd(0x1b);
 Rd_H = TwiReadCmd(0x1c);
 return((((word)Rd_H)<<8)|(Rd_L));
}

//************************************************
//Twi Write Command
//************************************************
void TwiWriteCmd(byte adr, byte WrPara)
{
 TwiInit();	
 adr |= 0x80;
 adr &= 0xBF;
 TwiWriteByte(adr);
 TwiWriteByte(WrPara);
 TwiTddDelay();
}

//************************************************
//Twi Read Command
//************************************************
byte TwiReadCmd(byte adr)
{
 byte tmp;
 TwiInit();
 adr |= 0xC0;

 TwiWriteByte(adr);
 tmp =  TwiReadByte();
 TwiTddDelay();
 return(tmp);
}

//************************************************
//TwiRst
//************************************************
void TwiRst(void)
{
 byte i;
 TwiInit();
 
 RF_Dat = 0;
 for(i=32; i!=0; i--)
 	{
 	RF_Clk = 1;
 	NOP();
 	NOP();
 	NOP();
 	NOP();
 	RF_Clk = 0;
	}
 TwiTddDelay();
 TwiWriteCmd(0x0D, 0x00);	 
}

//************************************************
//TwiOff
//************************************************
void TwiOff(void)
{
 TwiInit();		
 TwiWriteByte(0x8D);
 TwiWriteByte(0x02);
 TwiTddDelay();
}

//************************************************
//TwiWriteByte
//************************************************
void TwiWriteByte(byte WrPara)
{
 byte i;

 RF_Dat = 1;
 for(i=8;i!=0;i--)
 	{
 	RF_Clk = 1;
 	if(WrPara&0x80)
 		RF_Dat = 1;
 	else
 		RF_Dat = 0;
 	RF_Clk = 0;
 	WrPara <<= 1;
 	}
}

//************************************************
//TwiReadByte
//************************************************
byte TwiReadByte(void)
{
 byte i, RdPara;
 
 TRISC = TRISC_READ;
 
 for(i=8;i!=0;i--)
 	{
 	RF_Clk = 1;
 	RdPara <<= 1;
 	RF_Clk = 0; 	
 	if(RF_Dat)
 		RdPara |= 0x01;
 	else
 		asm("NOP");
 	}
 
 TRISC = TRISC_CTRL;	
 return(RdPara);
}

void TwiTddDelay(void)
{  
 byte i;
 RF_Clk = 1;
 for(i=10; i!=0; i--)
 	NOP();
 TRISC = TRISC_DEF;
 PORTC = PORTC_DEF;
}

void TwiInit(void)
{
 RF_Dat = 0;	
 RF_Clk = 1;
 TRISC = TRISC_CTRL;
 return;
}

