.\objects\startup_n32g031.o: Common\startup_n32g031.s
