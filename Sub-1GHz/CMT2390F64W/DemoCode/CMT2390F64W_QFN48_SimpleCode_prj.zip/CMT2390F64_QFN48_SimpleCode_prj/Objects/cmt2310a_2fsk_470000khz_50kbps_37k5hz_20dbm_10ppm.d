.\objects\cmt2310a_2fsk_470000khz_50kbps_37k5hz_20dbm_10ppm.o: RadioExport\CMT2310A_2fsk_470000kHz_50kbps_37k5Hz_20dBm_10ppm.c
.\objects\cmt2310a_2fsk_470000khz_50kbps_37k5hz_20dbm_10ppm.o: .\Radio\CMT2310A_reg.h
.\objects\cmt2310a_2fsk_470000khz_50kbps_37k5hz_20dbm_10ppm.o: .\Radio\CMT2310A_def.h
