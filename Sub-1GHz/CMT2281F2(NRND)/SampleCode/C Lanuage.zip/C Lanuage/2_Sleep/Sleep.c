//******************************************************************************
// THE FOLLOWING FIRMWARE IS PROVIDED: 
//  (1) "AS IS" WITH NO WARRANTY; 
//  (2) TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
// CONSEQUENTLY, HopeRF SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
// CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
// OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
// CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
// 
// Copyright (C) HopeRF
// website: www.HopeRF.com
//          www.HopeRF.cn
//******************************************************************************

//******************************************************************************
//   CMT2281F2 DEMO
//******************************************************************************
//Schematic:        --------------
//               1-|VDDL      XTAL|-16
//               2-|RFIN        NC|-15
//          GND--3-|GND   PC4/DOUT|-14
//               4-|AVDD/PC0  DVDD|-13
//          KEY--5-|PA5        PA6|-12
//               6-|PA4        PA7|-11
//         BUZZ--7-|PA3        PA1|-10--LED2
//         LED3--8-|PA2        PA0|-9---LED1
//                  --------------
//
//Function: 
//1. KEY press and hold, MCU run, LED2 On
//2. KEY release, MCU Sleep, LED2 off
//
//Result, @3.3V
//1. UCFG_LVDEN = OFF, Isleep < 0.5uA
//2. UCFG_LVDEN = ON,  Isleep = 15uA
//3. OSCCON = IRC_16M, Irun   = 2.79mA (include LED & KEY, about 1.7mA)
//4. OSCCON = IRC_8M,  Irun   = 2.53mA (include LED & KEY, about 1.7mA)
//5. OSCCON = IRC_4M,  Irun   = 2.25mA (include LED & KEY, about 1.7mA)
//6. OSCCON = IRC_2M,  Irun   = 2.10mA (include LED & KEY, about 1.7mA)
//7. OSCCON = IRC_1M,  Irun   = 2.02mA (include LED & KEY, about 1.7mA)
//8. OSCCON = IRC_0M5, Irun   = 1.99mA (include LED & KEY, about 1.7mA)
//9. OSCCON = IRC_250K,Irun   = 1.97mA (include LED & KEY, about 1.7mA)
//******************************************************************************

#include "CMT.h"     
#include "CMT60F02X.h"

typedef  unsigned char byte;
typedef  unsigned int  word;

											//    mode   dat  pull-up  ioc
#define		LED1      	RA0					//		0     0     0       0 
#define 	LED2        RA1					//		0     0     0       0 
#define		LED3		RA2					//		0     0     0       0 
//#define	Unused		RA3					//		0     0     0       0 
//#define	Unused		RA4					//		0     0     0       0 
#define		KEY			RA5					//		1     1     1       1 
//#define 	Unused		RA6					//		0	  0	    0       0 
//#define	Unused		RA7					//      0     0     0       0 

										 	//    moode  dat   
#define		RF_VDD		RC0					//      0     0              
//#define	Unused		RC1					//      0     0 
#define 	RF_SCLK		RC2 				//      0     0 
#define 	RF_CSB 		RC3					//      0     0 
#define 	RF_SDIO		RC4					//      1     1 
//#define 	Unused		RC5					//      0     0 
//#define  	Unused		RC6					//      0     0  
//#define 	Unused		RC7					//      0     0 

#define		PORTA_DEF	0b00100000
#define		PORTC_DEF	0b00010000
                                           
#define		TRISA_DEF	0b00100000 
#define		TRISC_DEF	0b00010000
                                           
#define		WPUA_DEF	0b00100000
#define		IOCA_DEF	0b00100000


//******************
//Constant Define
//******************
#define		INTCON_DEF          0b00000000  //Disable GIE, TMR0IE etc.
#define		OPTION_DEF          0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OSCCON_16M_DEF      0b01110101  //16MHz INTERNAL OSC
#define		OSCCON_8M_DEF       0b01100101  //8MHz INTERNAL OSC
#define		OSCCON_4M_DEF       0b01010101  //4MHz INTERNAL OSC
#define		OSCCON_2M_DEF       0b01000101  //2MHz INTERNAL OSC
#define		OSCCON_1M_DEF       0b00110101  //1MHz INTERNAL OSC
#define		OSCCON_0M5_DEF      0b00100101  //500KHz INTERNAL OSC
#define		OSCCON_250K_DEF     0b00010101  //250KHz INTERNAL OSC
#define		OSCCON_32K_DEF      0b00010101  //32KHz INTERNAL OSC
#define		CMCON0_DEF			0b00000111	//all for digtal IO

void initial(void)
{
 OSCCON = OSCCON_8M_DEF;		

 PORTA  = PORTA_DEF;    		//Port initial
 TRISA  = TRISA_DEF;    
 WPUA   = WPUA_DEF;    	
 IOCA	= IOCA_DEF;

 PORTC  = PORTC_DEF;
 TRISC  = TRISC_DEF;

 OPTION = OPTION_DEF;  	
 INTCON = INTCON_DEF;          	//Disable interrutp
 
 CMCON0 = CMCON0_DEF;
}

void soft_delay(void)
{
 byte i, j, k;
 for(i=1; i!=0; i--)
 	{
 	for(j=0xff; j!=0; j--)
 		{
 		for(k=0xff; k!=0; k--)
 			CLRWDT();  			//clear wdt

 		}	
 	}
}

void main(void)
{
 byte i;
 initial();
 soft_delay();
 soft_delay();
 
 while(1)
 	{
 	CLRWDT();	
 	if((PORTA&0b00100000)==0b00100000)	
 		{
 		LED2  = 0;	
 		PAIF  = 0;	
 		PEIE  = 1;
 		PAIE  = 1;
 		PORTA = PORTA;
 		SLEEP();
 		for(i=100; i!=0; i--)
			CLRWDT();
 		}
 	else
 		{
 		LED2  = 1;
 		}
 	}
}
