//******************************************************************************
// THE FOLLOWING FIRMWARE IS PROVIDED: 
//  (1) "AS IS" WITH NO WARRANTY; 
//  (2) TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
// CONSEQUENTLY, HopeRF SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
// CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
// OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
// CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
// 
// Copyright (C) HopeRF
// website: www.HopeRF.com
//          www.HopeRF.cn
//******************************************************************************

//******************************************************************************
//   CMT2281F2 DEMO
//******************************************************************************
//Schematic:        --------------
//               1-|VDDL      XTAL|-16
//               2-|RFIN        NC|-15
//          GND--3-|GND   PC4/DOUT|-14
//               4-|AVDD/PC0  DVDD|-13
//          KEY--5-|PA5        PA6|-12
//               6-|PA4        PA7|-11
//         BUZZ--7-|PA3        PA1|-10--LED2
//         LED3--8-|PA2        PA0|-9---LED1
//                  --------------
//
//Function: 
//1. LED Breath Blink with Timer0 & Timer2
//   a. Timer2 used for PWM
//   b. Timer0 used for breath rate
//******************************************************************************

#include "CMT.h"     
#include "CMT60F02X.h"

typedef  unsigned char byte;
typedef  unsigned int  word;


											//    mode   dat  pull-up  ioc
#define		LED1      	RA0					//		0     0     0       0 
#define 	LED2        RA1					//		0     0     0       0 
#define		LED3		RA2					//		0     0     0       0 
//#define	Unused		RA3					//		0     0     0       0 
//#define	Unused		RA4					//		0     0     0       0 
#define		KEY			RA5					//		1     1     0       0
//#define 	Unused		RA6					//		0	  0	    0       0 
//#define	Unused		RA7					//      0     0     0       0 

										 	//    moode  dat   
#define		RF_VDD		RC0					//      0     0              
//#define	Unused		RC1					//      0     0 
#define 	RF_SCLK		RC2 				//      0     0 
#define 	RF_CSB 		RC3					//      0     0 
#define 	RF_SDIO		RC4					//      1     1 
//#define 	Unused		RC5					//      0     0 
//#define  	Unused		RC6					//      0     0  
//#define 	Unused		RC7					//      0     0 

#define		PORTA_DEF	0b00100000
#define		PORTC_DEF	0b00010000
                                           
#define		TRISA_DEF	0b00100000 
#define		TRISC_DEF	0b00010000
                                           
#define		WPUA_DEF	0b00000000
#define		IOCA_DEF	0b00000000


//******************
//Constant Define
//******************
#define		INTCON_DEF          0b00000000  //Disable GIE, TMR0IE etc.

#define		OPTION_DEF          0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV1_DEF     0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV2_DEF		0b00000001	//PORTA pull-ups are enable;Timer0 1:4
#define		OPTION_DIV3_DEF		0b00000010	//PORTA pull-ups are enable;Timer0 1:8
#define		OPTION_DIV4_DEF		0b00000011	//PORTA pull-ups are enable;Timer0 1:16
#define		OPTION_DIV5_DEF		0b00000100	//PORTA pull-ups are enable;Timer0 1:32
#define		OPTION_DIV6_DEF		0b00000101	//PORTA pull-ups are enable;Timer0 1:64
#define		OPTION_DIV7_DEF		0b00000110	//PORTA pull-ups are enable;Timer0 1:128
#define		OPTION_DIV8_DEF		0b00000111	//PORTA pull-ups are enable;Timer0 1:256

#define		OSCCON_16M_DEF      0b01110101  //16MHz INTERNAL OSC
#define		OSCCON_8M_DEF       0b01100101  //8MHz INTERNAL OSC
#define		OSCCON_4M_DEF       0b01010101  //4MHz INTERNAL OSC
#define		OSCCON_2M_DEF       0b01000101  //2MHz INTERNAL OSC
#define		OSCCON_1M_DEF       0b00110101  //1MHz INTERNAL OSC
#define		OSCCON_0M5_DEF      0b00100101  //500KHz INTERNAL OSC
#define		OSCCON_250K_DEF     0b00010101  //250KHz INTERNAL OSC
#define		OSCCON_32K_DEF      0b00010101  //32KHz INTERNAL OSC
#define		CMCON0_DEF			0b00000111	//all for digtal IO

#define		WDTCON_DIV5_DEF		0b00000000
#define		WDTCON_DIV6_DEF		0b00000010
#define		WDTCON_DIV7_DEF		0b00000100
#define		WDTCON_DIV8_DEF		0b00000110
#define		WDTCON_DIV9_DEF		0b00001000
#define		WDTCON_DIV10_DEF	0b00001010
#define		WDTCON_DIV11_DEF	0b00001100
#define		WDTCON_DIV12_DEF	0b00001110
#define		WDTCON_DIV13_DEF	0b00010000
#define		WDTCON_DIV14_DEF	0b00010010
#define		WDTCON_DIV15_DEF	0b00010100
#define		WDTCON_DIV16_DEF	0b00010110

#define		TOUTPS_DIV1_DEF		0b00000000		//TOUTPS 1:1
#define		TOUTPS_DIV2_DEF		0b00001000		//TOUTPS 1:2
#define		TOUTPS_DIV3_DEF		0b00010000		//TOUTPS 1:3
#define		TOUTPS_DIV4_DEF		0b00011000		//TOUTPS 1:4
#define		TOUTPS_DIV5_DEF		0b00100000		//TOUTPS 1:5
#define		TOUTPS_DIV6_DEF		0b00101000		//TOUTPS 1:6
#define		TOUTPS_DIV7_DEF		0b00110000		//TOUTPS 1:7
#define		TOUTPS_DIV8_DEF		0b00111000		//TOUTPS 1:8
#define		TOUTPS_DIV9_DEF		0b01000000		//TOUTPS 1:9
#define		TOUTPS_DIV10_DEF	0b01001000		//TOUTPS 1:10
#define		TOUTPS_DIV11_DEF	0b01010000		//TOUTPS 1:11
#define		TOUTPS_DIV12_DEF	0b01011000		//TOUTPS 1:12
#define		TOUTPS_DIV13_DEF	0b01100000		//TOUTPS 1:13
#define		TOUTPS_DIV14_DEF	0b01101000		//TOUTPS 1:14
#define		TOUTPS_DIV15_DEF	0b01110000		//TOUTPS 1:15
#define		TOUTPS_DIV16_DEF	0b01111000		//TOUTPS 1:16

#define		T2CKPS_DIV0_DEF		0b00000000		//T2CKPS 1:1
#define		T2CKPS_DIV2_DEF		0b00000001		//T2CKPS 1:4
#define		T2CKPS_DIV4_DEF		0b00000010		//T2CKPS 1:16

//******************
//Global Variable
//******************
byte Timer0Cnout;
byte BreathPtr;

const byte BreathTable[32] = {
	                         240, 238, 231, 221, 207, 190, 171, 150, 128, 106,
	                          85,  66,  49,  35,  25,  18,  16,  18,  25,  35,
	                          49,  66,  85, 106, 128, 150, 171, 190, 207, 221, 
	                         231, 238
	                         };


void interrupt ISR(void)
{
 GIE=0;
 if(T0IF)
  	{ 
    T0IF = 0;
    Timer0Cnout++;
    if((Timer0Cnout&0x08)==0x08)
    	{
    	Timer0Cnout &= 0xF7;	
    	BreathPtr++;
    	BreathPtr &= 0x1F;
    	}
  	}
 GIE=1; 
}

void initial(void)
{
 OSCCON = OSCCON_8M_DEF;		

 PORTA  = PORTA_DEF;    		//Port initial
 TRISA  = TRISA_DEF;    
 WPUA   = WPUA_DEF;    	
 IOCA	= IOCA_DEF;

 PORTC  = PORTC_DEF;
 TRISC  = TRISC_DEF;

 OPTION = OPTION_DEF;  	
 INTCON = INTCON_DEF;          	//Disable interrutp
 
 CMCON0 = CMCON0_DEF;
 
 WDTCON = WDTCON_DIV16_DEF;
}

void soft_delay(void)
{
 byte i, j, k;
 for(i=1; i!=0; i--)
 	{
 	for(j=0x7f; j!=0; j--)
 		{
 		for(k=0x7f; k!=0; k--)
 			CLRWDT();  			//clear wdt

 		}	
 	}
}

void main(void)
{
 byte i;
 soft_delay();
 initial();
 
 //Cfg Timer0
 OSCCON = OSCCON_8M_DEF;		//Change OSCCON
 OPTION = OPTION_DIV8_DEF;		//Change Timer0 divider
 
 T0IF   = 0;
 T0IE   = 1;
 GIE    = 1; 
 
 //Cfg Timer2
 T2CON  = (TOUTPS_DIV8_DEF|T2CKPS_DIV0_DEF);
 TMR2   = 0;
 TMR2IF = 0;
 
 while(1)
 	{
	CLRWDT();
	i   = BreathPtr;
	PR2 = BreathTable[BreathPtr];
	
	while(BreathPtr==i)
		{
		TMR2IF = 0;
		TMR2ON = 1;
		while(!TMR2IF)
			{
			LED2 = 1;
			LED3 = 0;
			CLRWDT();
			}
		TMR2IF = 0;
		TMR2ON = 0;
		PR2 = ~PR2;
    	
		TMR2ON = 1;
		while(!TMR2IF)
			{
			LED2 = 0;
			LED3 = 1;
			CLRWDT();
			}
		TMR2IF = 0;
		TMR2ON = 0;
		PR2 = ~PR2;
		}
 	}
}
