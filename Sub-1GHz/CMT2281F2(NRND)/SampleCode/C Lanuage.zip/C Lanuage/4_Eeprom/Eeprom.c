//******************************************************************************
// THE FOLLOWING FIRMWARE IS PROVIDED: 
//  (1) "AS IS" WITH NO WARRANTY; 
//  (2) TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
// CONSEQUENTLY, HopeRF SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
// CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
// OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
// CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
// 
// Copyright (C) HopeRF
// website: www.HopeRF.com
//          www.HopeRF.cn
//******************************************************************************

//******************************************************************************
//   CMT2281F2 DEMO
//******************************************************************************
//Schematic:        --------------
//               1-|VDDL      XTAL|-16
//               2-|RFIN        NC|-15
//          GND--3-|GND   PC4/DOUT|-14
//               4-|AVDD/PC0  DVDD|-13
//          KEY--5-|PA5        PA6|-12
//               6-|PA4        PA7|-11
//         BUZZ--7-|PA3        PA1|-10--LED2
//         LED3--8-|PA2        PA0|-9---LED1
//                  --------------
//
//Function: 
//1. Check EEPROM write and read, blink LED2 
//******************************************************************************

#include "CMT.h"     
#include "CMT60F02X.h"

typedef  unsigned char byte;
typedef  unsigned int  word;

											//    mode   dat  pull-up  ioc
#define		LED1      	RA0					//		0     0     0       0 
#define 	LED2        RA1					//		0     0     0       0 
#define		LED3		RA2					//		0     0     0       0 
//#define	Unused		RA3					//		0     0     0       0 
//#define	Unused		RA4					//		0     0     0       0 
#define		KEY			RA5					//		1     1     0       0
//#define 	Unused		RA6					//		0	  0	    0       0 
//#define	Unused		RA7					//      0     0     0       0 

										 	//    moode  dat   
#define		RF_VDD		RC0					//      0     0              
//#define	Unused		RC1					//      0     0 
#define 	RF_SCLK		RC2 				//      0     0 
#define 	RF_CSB 		RC3					//      0     0 
#define 	RF_SDIO		RC4					//      1     1 
//#define 	Unused		RC5					//      0     0 
//#define  	Unused		RC6					//      0     0  
//#define 	Unused		RC7					//      0     0 

#define		PORTA_DEF	0b00100000
#define		PORTC_DEF	0b00010000
                                           
#define		TRISA_DEF	0b00100000 
#define		TRISC_DEF	0b00010000
                                           
#define		WPUA_DEF	0b00000000
#define		IOCA_DEF	0b00000000


//******************
//Constant Define
//******************
#define		INTCON_DEF          0b00000000  //Disable GIE, TMR0IE etc.

#define		OPTION_DEF          0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV1_DEF     0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV2_DEF		0b00000001	//PORTA pull-ups are enable;Timer0 1:4
#define		OPTION_DIV3_DEF		0b00000010	//PORTA pull-ups are enable;Timer0 1:8
#define		OPTION_DIV4_DEF		0b00000011	//PORTA pull-ups are enable;Timer0 1:16
#define		OPTION_DIV5_DEF		0b00000100	//PORTA pull-ups are enable;Timer0 1:32
#define		OPTION_DIV6_DEF		0b00000101	//PORTA pull-ups are enable;Timer0 1:64
#define		OPTION_DIV7_DEF		0b00000110	//PORTA pull-ups are enable;Timer0 1:128
#define		OPTION_DIV8_DEF		0b00000111	//PORTA pull-ups are enable;Timer0 1:256

#define		OSCCON_16M_DEF      0b01110101  //16MHz INTERNAL OSC
#define		OSCCON_8M_DEF       0b01100101  //8MHz INTERNAL OSC
#define		OSCCON_4M_DEF       0b01010101  //4MHz INTERNAL OSC
#define		OSCCON_2M_DEF       0b01000101  //2MHz INTERNAL OSC
#define		OSCCON_1M_DEF       0b00110101  //1MHz INTERNAL OSC
#define		OSCCON_0M5_DEF      0b00100101  //500KHz INTERNAL OSC
#define		OSCCON_250K_DEF     0b00010101  //250KHz INTERNAL OSC
#define		OSCCON_32K_DEF      0b00010101  //32KHz INTERNAL OSC
#define		CMCON0_DEF			0b00000111	//all for digtal IO

#define		WDTCON_DIV5_DEF		0b00000000
#define		WDTCON_DIV6_DEF		0b00000010
#define		WDTCON_DIV7_DEF		0b00000100
#define		WDTCON_DIV8_DEF		0b00000110
#define		WDTCON_DIV9_DEF		0b00001000
#define		WDTCON_DIV10_DEF	0b00001010
#define		WDTCON_DIV11_DEF	0b00001100
#define		WDTCON_DIV12_DEF	0b00001110
#define		WDTCON_DIV13_DEF	0b00010000
#define		WDTCON_DIV14_DEF	0b00010010
#define		WDTCON_DIV15_DEF	0b00010100
#define		WDTCON_DIV16_DEF	0b00010110

//******************
//Global Variable
//******************
byte Timer0Cnout;


void EeproomWrite(byte ee_adr, byte ee_dat);
byte EerpomRead(byte ee_adr);

void interrupt ISR(void)
{
 GIE=0;
 if(T0IF)
  	{ 
    T0IF = 0;
    Timer0Cnout++;
  	}
 GIE=1; 
}

void initial(void)
{
 OSCCON = OSCCON_4M_DEF;		

 PORTA  = PORTA_DEF;    		//Port initial
 TRISA  = TRISA_DEF;    
 WPUA   = WPUA_DEF;    	
 IOCA	= IOCA_DEF;

 PORTC  = PORTC_DEF;
 TRISC  = TRISC_DEF;

 OPTION = OPTION_DIV8_DEF;  	
 INTCON = INTCON_DEF;          	//Disable interrutp
 
 CMCON0 = CMCON0_DEF;
 
 WDTCON = WDTCON_DIV16_DEF;
}

void soft_delay(void)
{
 byte i, j, k;
 for(i=1; i!=0; i--)
 	{
 	for(j=0x7f; j!=0; j--)
 		{
 		for(k=0x7f; k!=0; k--)
 			CLRWDT();  			//clear wdt

 		}	
 	}
}

void main(void)
{
 byte i;
 byte tmp;
 byte x;
 byte adr;
 
 initial();
 soft_delay();
 
 T0IF = 0;
 T0IE = 1;
 GIE  = 1; 
 
 i    = 0;
 adr  = 0x10; 
 while(1)
 	{
 	EeproomWrite(adr, i);
 	tmp = EerpomRead(adr);
 	if(tmp!=i)
		x = 3;		//blink 3 for faild
	else
		x = 1;		//blink 1 for ok
	
	for(;x!=0;x--)
		{
		LED2 = 1;
		soft_delay();
		LED2 = 0;
		soft_delay();
		}
 		
 	i++;
	
	for(Timer0Cnout=0; Timer0Cnout<200; )
		CLRWDT();
 	}
}


//******************************************************************************
//EEPROM Operation
//******************************************************************************
void EeproomWrite(byte ee_adr, byte ee_dat)
{
 GIE  = 0;	
 EEIF = 0;
 
 EEADR  = ee_adr;
 EEDAT  = ee_dat;
 
 EECON1 = 0b00110100; 
 do
 	{
 	WR = 1;
	}while(!WR);
 GIE  = 1;
}

byte EerpomRead(byte ee_adr)
{
 GIE  = 0;
 EEIF = 0;
 EEADR = ee_adr;
 do
 	{
 	RD = 1;
 	}while(!RD);
 	
 GIE  = 1;
 return(EEDAT);
}
