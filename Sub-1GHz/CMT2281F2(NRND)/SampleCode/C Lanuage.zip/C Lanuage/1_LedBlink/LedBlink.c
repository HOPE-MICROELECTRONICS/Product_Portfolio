//******************************************************************************
// THE FOLLOWING FIRMWARE IS PROVIDED: 
//  (1) "AS IS" WITH NO WARRANTY; 
//  (2) TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
// CONSEQUENTLY, HopeRF SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
// CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
// OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
// CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
// 
// Copyright (C) HopeRF
// website: www.HopeRF.com
//          www.HopeRF.cn
//******************************************************************************

//******************************************************************************
//   CMT2281F2 DEMO
//******************************************************************************
//Schematic:        --------------
//               1-|VDDL      XTAL|-16
//               2-|RFIN        NC|-15
//          GND--3-|GND   PC4/DOUT|-14
//               4-|AVDD/PC0  DVDD|-13
//          KEY--5-|PA5        PA6|-12
//               6-|PA4        PA7|-11
//         BUZZ--7-|PA3        PA1|-10--LED2
//         LED3--8-|PA2        PA0|-9---LED1
//                  --------------
//
//Function: 
//1. LED will blink
//2. The blink speed depond on the value of OSCCON, OSCCON_16M_DEF, OSCCON_8M_DEF, etc.
//******************************************************************************

#include "CMT.h"     
#include "CMT60F02X.h"

typedef  unsigned char byte;
typedef  unsigned int  word;

											//    mode   dat  pull-up  ioc
#define		LED1      	RA0					//		0     0     0       0 
#define 	LED2        RA1					//		0     0     0       0 
#define		LED3		RA2					//		0     0     0       0 
//#define	Unused		RA3					//		0     0     0       0 
//#define	Unused		RA4					//		0     0     0       0 
#define		KEY			RA5					//		1     1     1       1 
//#define 	Unused		RA6					//		0	  0	    0       0 
//#define	Unused		RA7					//      0     0     0       0 

										 	//    moode  dat   
#define		RF_VDD		RC0					//      0     0              
//#define	Unused		RC1					//      0     0 
#define 	RF_SCLK		RC2 				//      0     0 
#define 	RF_CSB 		RC3					//      0     0 
#define 	RF_SDIO		RC4					//      1     1 
//#define 	Unused		RC5					//      0     0 
//#define  	Unused		RC6					//      0     0  
//#define 	Unused		RC7					//      0     0 

#define		PORTA_DEF	0b00100000
#define		PORTC_DEF	0b00010000
                                           
#define		TRISA_DEF	0b00100000 
#define		TRISC_DEF	0b00010000
                                           
#define		WPUA_DEF	0b00100000
#define		IOCA_DEF	0b00100000


//******************
//Constant Define
//******************
#define 	INTCON_DEF    		0b00000000	//Disable GIE, TMR0IE etc.
#define 	OPTION_DEF    		0b00000000	//PORTA pull-ups are enable;Timer0 1:2
#define 	OSCCON_16M_DEF		0b01110101	//16MHz INTERNAL OSC
#define 	OSCCON_8M_DEF 		0b01100101	//8MHz INTERNAL OSC
#define 	OSCCON_4M_DEF 		0b01010101	//4MHz INTERNAL OSC
#define 	OSCCON_1M_DEF 		0b00110101	//1MHz INTERNAL OSC


void initial(void)
{
 OSCCON = OSCCON_8M_DEF;		

 PORTA  = PORTA_DEF;    		//Port initial
 TRISA  = TRISA_DEF;    
 WPUA   = WPUA_DEF;    	
 IOCA	= IOCA_DEF;

 PORTC  = PORTC_DEF;
 TRISC  = TRISC_DEF;

 OPTION = OPTION_DEF;  	
 INTCON = 0;            		//Disable interrutp
}

void soft_delay(void)
{
 byte i, j, k;
 for(i=1; i!=0; i--)
 	{
 	for(j=0xff; j!=0; j--)
 		{
 		for(k=0xff; k!=0; k--)
 			CLRWDT();  			//clear wdt

 		}	
 	}
}

void main(void)
{
 initial();
 
 while(1)
 	{
 	LED2 = 1;
 	soft_delay();
 	soft_delay();
 	LED2 = 0;
 	soft_delay();
 	soft_delay();
 	}
}
