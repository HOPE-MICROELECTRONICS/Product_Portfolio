/*!********************************************************************************************************
* @file : lfrx for pke-eb.c
* @desc : 1. this is a demo for CMT2168A-EB to show LFRx Function
*         2. 
*         3. 
*            
*  
* @version 	1.0
* @date  	Nov 28 2019
* @author 
*
*Copyright (C) CMOSTEK MICROELECTRONICS CO., LTD.
*
***********************************************************************************************************/

#include "cmt216xa.h"

#define		FLASH_BOOT_DEBUG_MODE


//************************  selection of DATA output mode, only one of below  ********************************
//#define 	DATA_OUT_RAW								//Raw Data Output, but no DCLK & Wakeup
//#define 	DATA_OUT_AFTER_SIGNAL						//CDR Data + Dclk Output, After when lfrx_signal_ok == 1 
#define 	DATA_OUT_AFTER_WAKEUP						//Decode Data + Dclk Output, After when lfrx_wakup == 1


//************************************  selection of Packet Handler  *****************************************
#define		SYNC_LENGTH					3				// sync length, N+1
#define		SYNC_VALUE					0x999AA5A6		// sync value 	


#define		ENABLE_WAKEUP_ID							//
#define		WKID_LENGTH					1				// wkid length, N+1
#define		WKID_VALUE					0xDCBA			// wkid value 

#define		PAYLOAD_LENGTH				3

//##����г�񱨴������޷�Χ
#define		MIN_CAP_VALUE				3
#define		MAX_CAP_VALUE				29

byte 		systimer;

byte  		lfrx_data_buf;						// receive one byte buffer 
byte		lfrx_recv_bit_cnt;					// receive one byte's bit counter
byte 		lfrx_data_array[PAYLOAD_LENGTH];	// receive array buffer
byte		lfrx_recv_index;					// receive array buffer's index
byte 		lfrx_recv_timer;

byte		lfrx_rssi_tmp;
byte		lfrx_rssi_value;


byte bdata	sys_flag_1;
	sbit	lfrx_receiving_f = sys_flag_1^0;	// receiving
	sbit	lfrx_recv_done_f = sys_flag_1^1;	// receive process done


//********************************************* Interrupt config ************************************************
typedef void (*INTERRUPT_SERVICE_ROUTINE)(void);

xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt0_service_routine 		_at_ 0x0000;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt1_service_routine 		_at_ 0x0003;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt2_service_routine 		_at_ 0x0006;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt3_service_routine 		_at_ 0x0009;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt4_service_routine 		_at_ 0x000c;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt5_service_routine 		_at_ 0x000f;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt6_service_routine 		_at_ 0x0013;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt7_service_routine 		_at_ 0x0016;
xdata INTERRUPT_SERVICE_ROUTINE system_timer1_interrupt_service_routine    		_at_ 0x0019;
xdata INTERRUPT_SERVICE_ROUTINE system_serial_port0_interrupt_service_routine 	_at_ 0x001c;

#ifdef	FLASH_BOOT_DEBUG_MODE

	byte g_reserved_data_used_by_interrupt_rountine[20] _at_ 0x40; 				// each interrupt using two bytes, so total data = 10 interrupts * 2 = 20 
		
#else

	byte g_external_interrupt0_bank_store     			_at_ 0x40;
	byte g_external_interrupt0_hv_store       			_at_ 0x41;
	byte g_external_interrupt1_bank_store     			_at_ 0x42;
	byte g_external_interrupt1_hv_store       			_at_ 0x43;
	byte g_external_interrupt2_bank_store     			_at_ 0x44;
	byte g_external_interrupt2_hv_store       			_at_ 0x45;
	byte g_external_interrupt3_bank_store     			_at_ 0x46;
	byte g_external_interrupt3_hv_store       			_at_ 0x47;
	byte g_external_interrupt4_bank_store     			_at_ 0x48;
	byte g_external_interrupt4_hv_store       			_at_ 0x49;
	byte g_external_interrupt5_bank_store     			_at_ 0x4A;
	byte g_external_interrupt5_hv_store       			_at_ 0x4B;
	byte g_external_interrupt6_bank_store     			_at_ 0x4C;
	byte g_external_interrupt6_hv_store       			_at_ 0x4D;
	byte g_external_interrupt7_bank_store     			_at_ 0x4E;
	byte g_external_interrupt7_hv_store       			_at_ 0x4F;
	byte g_timer1_interrupt_bank_store        			_at_ 0x50;
	byte g_timer1_interrupt_hv_store          			_at_ 0x51;
	byte g_serial_port0_interrupt_bank_store  			_at_ 0x52;
	byte g_serial_port0_interrupt_hv_store    			_at_ 0x53;

	// EX0 interrupt vector
	void system_external_interrupt0(void) interrupt INT_EX0_VECTOR using 0  					
	{
    	sys_push_bank0_r0_2_r7_to_stack();
    	g_external_interrupt0_bank_store = sys_get_sfr_bank();
    	g_external_interrupt0_hv_store = sys_store_hv_interface();
    	
    	if(system_external_interrupt0_service_routine != NULL)
    	    system_external_interrupt0_service_routine();
    	
    	sys_restore_hv_interface(g_external_interrupt0_hv_store);
    	sys_set_sfr_bank(g_external_interrupt0_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();  
	}	

	// Timer1 interrupt vector
	void system_timer1_interrupt(void) interrupt INT_TIMER1_VECTOR using 0  					
	{
   		sys_push_bank0_r0_2_r7_to_stack();
    	g_timer1_interrupt_bank_store = sys_get_sfr_bank();
        g_timer1_interrupt_hv_store = sys_store_hv_interface();
    
    	if(system_timer1_interrupt_service_routine != NULL)
  	    	system_timer1_interrupt_service_routine();
    
    	sys_restore_hv_interface(g_timer1_interrupt_hv_store);
	    sys_set_sfr_bank(g_timer1_interrupt_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();  
	}	

#endif

void clear_interrupt_vector(void)
{
 system_external_interrupt0_service_routine    = NULL;   
 system_external_interrupt1_service_routine    = NULL;
 system_external_interrupt2_service_routine    = NULL;
 system_external_interrupt3_service_routine    = NULL;
 system_external_interrupt4_service_routine    = NULL;
 system_external_interrupt5_service_routine    = NULL;
 system_external_interrupt6_service_routine    = NULL;
 system_external_interrupt7_service_routine    = NULL;
 system_timer1_interrupt_service_routine       = NULL;
 system_serial_port0_interrupt_service_routine = NULL;
}

//************************************************** UHF-TX ***************************************************
//@select packet format
	#define PACKET_PREAMBLE_LEN 		16
	#define PACKET_PREAMBLE_VALUE		0xAA

	#define PACKET_SYNC_LEN				2				// for this sample code, it should be 2. If need change, should modify this code.
	#define	PACKET_SYNC_VALUE			0x2DD4
	
	#define	PACKET_VARIABLE_EN			0				// 0:Fixed Packet,  1:Variable Packet, other value no allow		
	
	#define PACKET_PAYLOAD_LEN 			8				// 8
	
	#define	PACKET_CRC_EN				1				// 0:Disable CRC, 	1:Enbable CRC16, other value no allow

	#if (PACKET_CRC_EN!=0)
		#define PACKET_TRANSMIT_LEN 	(PACKET_PREAMBLE_LEN + PACKET_SYNC_LEN + PACKET_VARIABLE_EN + PACKET_PAYLOAD_LEN + 2)
	#else
		#define PACKET_TRANSMIT_LEN 	(PACKET_PREAMBLE_LEN + PACKET_SYNC_LEN + PACKET_VARIABLE_EN + PACKET_PAYLOAD_LEN )
	#endif

	#define	PACKET_MSB_SHIFT_TX							//MSB shift to transmitt at first

	#define	ENCODE_WHITEN								//enable whiten encoding
	#define	WHITEN_SEED					0x01FF		

//@select pa output mode
	//#define		DIFFERENTIAL_TX						//enable  select differental pa output; 
                                    					//disable select singal pa output;

//@select modulation
	#define			MODULATION_SEL		M_TX_MODU		//0: OOK, 			M_TX_MODU: FSK
	#define			GUASS_ON_SEL		M_GUASS_ON		//0: Guass off, 	M_GUASS_ON: Guass on, when FSK active
	#define			RAMP_EN_SEL			M_RAMP_EN		//0:Ramp off, 		M_RAMP_EN:Ramp on
	#define			FREQ_DEV_SEL		0				//0:(+f=1, -f=0),   M_FREQ_DEV_INV:(+f=0, -f=1) 


//@select wireless bit rate, select one of below
	//#define		BR_100k_35kHz						//BR+Deviation
	//#define		BR_200k_50kHz						
	#define			BR_250k_75kHz
	//#define		BR_300k_75kHz

//@select tx output power
	#define 		PA_OUT_SEL			13				//range: 0-13, unit: dBm

//@select frequency band, only one of below
	#define			FREQ_FOR_434
	//#define		FREQ_FOR_868
	//#define		FREQ_FOR_915

//@frequency & modulation config
#ifdef	FREQ_FOR_434
	#define 		VCO_CFG1			32				//433.92MHz
	#define 		VCO_CFG0			15
	#define 		PLL_N_CFG			33
	#define			PLL_K_CFG1			96
	#define			PLL_K_CFG0			226
#endif	                           		 

#ifdef	FREQ_FOR_868
	#define 		VCO_CFG1			0				//868MHz
	#define 		VCO_CFG0			15
	#define 		PLL_N_CFG			33
	#define			PLL_K_CFG1			98
	#define			PLL_K_CFG0			153
#endif


#ifdef	FREQ_FOR_915
	#define 		VCO_CFG1			128				//915MHz
	#define 		VCO_CFG0			15
	#define 		PLL_N_CFG			35
	#define			PLL_K_CFG1			49
	#define			PLL_K_CFG0			95
#endif

//@low battery voltage
	#define			LOW_BATTERY_VALUE	106				//about 2.0V     255*2.0/4.8 

//********************************** Bit Rate & Deviation **************************************
#ifdef 	BR_100k_35kHz								
	#define PA_CFG						2
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			0

	#ifdef	FREQ_FOR_434
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			176
	#endif
	#ifdef	FREQ_FOR_868
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			88
	#endif
	#ifdef	FREQ_FOR_915
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			88
	#endif

	#define SYMBOL_TIME_CFG1			31
	#define SYMBOL_TIME_CFG0			130
#endif                              	
                                    	
#ifdef 	BR_200k_50kHz										
	#define PA_CFG						2
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			0

	#ifdef	FREQ_FOR_434
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			252
	#endif
	#ifdef	FREQ_FOR_868
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			126
	#endif
	#ifdef	FREQ_FOR_915
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			126
	#endif

	#define SYMBOL_TIME_CFG1			63
	#define SYMBOL_TIME_CFG0			4
#endif                              	
                                   	
#ifdef 	BR_250k_75kHz								
	#define PA_CFG						2
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			0

	#ifdef	FREQ_FOR_434
		#define FREQ_DEV_CFG1			1
		#define	FREQ_DEV_CFG0			122
	#endif
	#ifdef	FREQ_FOR_868
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			189
	#endif
	#ifdef	FREQ_FOR_915
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			189
	#endif

	#define SYMBOL_TIME_CFG1			78
	#define SYMBOL_TIME_CFG0			197
#endif                              	
                                    	
#ifdef 	BR_300k_75kHz										
	#define PA_CFG						2
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			0

	#ifdef	FREQ_FOR_434
		#define FREQ_DEV_CFG1			1
		#define	FREQ_DEV_CFG0			122
	#endif
	#ifdef	FREQ_FOR_868
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			189
	#endif
	#ifdef	FREQ_FOR_915
		#define FREQ_DEV_CFG1			0
		#define	FREQ_DEV_CFG0			189
	#endif

	#define SYMBOL_TIME_CFG1			94
	#define SYMBOL_TIME_CFG0			134
#endif                              	

//**************************** Output Power Amp. for different FREQ_BAND *********************************
#ifdef	FREQ_FOR_315
	#if (PA_OUT_SEL>5)
		#define PA_IDAC_CODE_CFG			63
	#else
		#define PA_IDAC_CODE_CFG			28
	#endif

									//  TH_9-------------------------------------TH_0
	byte code TX_POWER_SEL[14][10] = {
		                                {23, 24, 25, 26, 27,  28,  30,  32,  35,  38},             // +0dBm                      
		                                {25, 27, 29, 30, 31,  33,  35,  37,  39,  44},             // +1dBm                      
		                                {29, 31, 33, 34, 35,  37,  40,  42,  45,  50},             // +2dBm                      
		                                {33, 34, 35, 36, 38,  40,  42,  46,  50,  55},             // +3dBm                      
		 								{37, 39, 41, 42, 43,  46,  49,  52,  55,  61},             // +4dBm                      
										{40, 42, 44, 46, 48,  51,  54,  59,  61,  68},             // +5dBm  -----idac code = 28 
										{14, 15, 16, 17, 19,  21,  25,  29,  38,  51},             // +6dBm  -----idac code = 63 
										{16, 17, 18, 19, 21,  25,  30,  36,  44,  62},             // +7dBm                      
		                                {18, 20, 21, 22, 24,  28,  33,  42,  57,  80},             // +8dBm	                     
		                                {20, 21, 23, 26, 30,  35,  43,  54,  80, 120},             // +9dBm                      
		                                {24, 25, 28, 33, 38,  42,  54,  65, 100, 127},             //+10dBm	                     
		                                {27, 30, 32, 38, 42,  49,  73, 110, 127, 127},             //+11dBm                      
		                                {32, 39, 42, 50, 57,  72, 100, 127, 127, 127},             //+12dBm                      
		                                {38, 42, 48, 64, 78, 100, 120, 127, 127, 127},             //+13dBm                      
										};
#endif



#ifdef	FREQ_FOR_434
	#if (PA_OUT_SEL>5)
		#define PA_IDAC_CODE_CFG			63
	#else
		#define PA_IDAC_CODE_CFG			28
	#endif

									//  TH_9-------------------------------------TH_0
	byte code TX_POWER_SEL[14][10] = {
		                                {15, 15, 16, 17, 18, 19,  20,  21,  23,  25}, 				// +0dBm                             
		                                {17, 17, 18, 19, 20, 21,  22,  23,  25,  28}, 	        	// +1dBm                             
		                                {19, 20, 21, 22, 23, 24,  25,  26,  28,  32}, 	        	// +2dBm                             
		                                {22, 23, 24, 25, 26, 27,  29,  31,  34,  37}, 	        	// +3dBm                             
		 								{24, 25, 26, 27, 29, 31,  32,  34,  37,  41}, 	        	// +4dBm                             
										{27, 28, 29, 30, 32, 33,  35,  39,  43,  50}, 	        	// +5dBm  -----idac code = 28        
										{ 9, 10, 10, 11, 12, 14,  17,  21,  26,  37}, 	        	// +6dBm  -----idac code = 63        
										{10, 11, 12, 13, 14, 16,  20,  25,  31,  47}, 	        	// +7dBm                             
		                                {11, 12, 13, 15, 17, 20,  24,  31,  42,  70}, 	        	// +8dBm	                         
		                                {13, 14, 15, 17, 20, 24,  29,  40,  65, 119}, 	        	// +9dBm                             
		                                {15, 16, 18, 21, 25, 31,  42,  65, 103, 127}, 	        	//+10dBm	                         
		                                {19, 21, 24, 26, 34, 43,  59,  85, 115, 127}, 	        	//+11dBm                             
		                                {24, 27, 32, 37, 46, 62,  89, 113, 127, 127}, 	        	//+12dBm                             
		                                {32, 38, 45, 56, 73, 94, 115, 127, 127, 127}, 	        	//+13dBm                             
										};
#endif										


#ifdef	FREQ_FOR_868
	#if (PA_OUT_SEL>5)
		#define PA_IDAC_CODE_CFG			63
	#else
		#define PA_IDAC_CODE_CFG			30
	#endif
								
	//for Normal	   				//  TH_9-------------------------------------TH_0
	byte code TX_POWER_SEL[14][10] = {
										{15, 16, 17, 18, 19, 20, 21,  22,  23,  26},				// +0dBm                      
										{17, 18, 19, 20, 21, 22, 23,  24,  26,  30},                // +1dBm                      
										{19, 20, 21, 22, 23, 24, 25,  27,  29,  33},                // +2dBm                      
										{22, 23, 24, 25, 26, 27, 28,  30,  33,  38},                // +3dBm                      
										{25, 26, 27, 28, 29, 30, 32,  34,  37,  42},                // +4dBm                      
										{28, 29, 30, 32, 33, 35, 37,  39,  43,  49},                // +5dBm  -----idac code = 30 
										{11, 12, 13, 14, 16, 18, 21,  25,  32,  42},                // +6dBm  -----idac code = 63 
										{13, 14, 15, 16, 18, 21, 24,  29,  38,  51},                // +7dBm                      
										{15, 16, 17, 19, 21, 24, 29,  35,  46,  62},                // +8dBm	                  
										{17, 18, 20, 22, 24, 28, 33,  41,  55,  76},                // +9dBm                      
										{20, 21, 23, 25, 28, 33, 40,  50,  70, 105},                //+10dBm	                  
										{24, 26, 27, 30, 34, 40, 50,  68,  95, 127},                //+11dBm                      
										{27, 29, 31, 36, 43, 54, 65,  90, 127, 127},                //+12dBm                      
										{33, 36, 38, 44, 52, 65, 87, 127, 127, 127},                //+13dBm                      
									 };

	////for add TVS					//  TH_9-------------------------------------TH_0 
	//byte code TX_POWER_SEL[14][10] = {
	//									{17, 18, 19, 20, 21, 22, 23,  25,  27, 	30},				// +0dBm                      
	//									{20, 21, 22, 23, 24, 25, 26,  28,  30, 	34},            	// +1dBm                      
	//									{23, 24, 25, 26, 27, 28, 29,  31,  34, 	38},            	// +2dBm                      
	//									{26, 27, 28, 29, 30, 31, 33,  35,  38, 	43},            	// +3dBm                      
	//									{29, 30, 31, 32, 34, 36, 38,  40,  44, 	48},            	// +4dBm                      
	//									{32, 33, 34, 35, 38, 40, 42,  44,  48, 	53},            	// +5dBm  -----idac code = 30 
	//									{12, 13, 14, 15, 17, 19, 21,  26,  32, 	43},            	// +6dBm  -----idac code = 63 
	//									{14, 15, 16, 18, 19, 21, 25,  30,  39, 	52},            	// +7dBm                      
	//									{16, 17, 18, 20, 21, 25, 30,  36,  46, 	61},            	// +8dBm	                  
	//									{19, 20, 21, 23, 25, 28, 35,  43,  58, 	80},            	// +9dBm                      
	//									{22, 24, 25, 27, 31, 35, 41,  52,  71, 100},            	//+10dBm	                  
	//									{25, 27, 30, 33, 38, 44, 50,  66,  97, 127},            	//+11dBm                      
	//									{29, 32, 35, 39, 46, 52, 65, 110, 127, 127},            	//+12dBm                      
	//									{36, 39, 44, 48, 57, 72, 00, 127, 127, 127},            	//+13dBm                      
	//								};
									 
#endif

#ifdef	FREQ_FOR_915
	#if (PA_OUT_SEL>5)
		#define PA_IDAC_CODE_CFG			63
	#else
		#define PA_IDAC_CODE_CFG			30
	#endif
								
					   				//  TH_9-------------------------------------TH_0
	byte code TX_POWER_SEL[14][10] = {
										{19, 20, 21, 22, 23, 24,  25,  27,  29,	 33},				//  +0dBm                      
										{22, 23, 24, 25, 26, 27,  29,  31,  33,	 37},                // +1dBm                      
										{25, 26, 27, 28, 29, 31,  33,  35,  37,	 42},                // +2dBm                      
										{28, 29, 30, 31, 33, 35,  37,  39,  42,	 47},                // +3dBm                      
										{31, 32, 33, 34, 36, 38,  40,  43,  47,	 53},                // +4dBm                      
										{34, 36, 38, 40, 42, 44,  47,  50,  55,	 62},                // +5dBm  -----idac code = 30 
										{13, 14, 15, 16, 18, 21,  24,  29,  37,	 48},                // +6dBm  -----idac code = 63 
										{15, 16, 17, 19, 21, 23,  28,  34,  45,	 61},                // +7dBm                      
										{18, 19, 20, 22, 25, 28,  33,  41,  55,	 75},                // +8dBm	                  
										{20, 21, 23, 25, 29, 34,  40,  50,  68,	100},                // +9dBm                      
										{23, 25, 27, 29, 33, 40,  51,  65,  90,	127},                //+10dBm	                  
										{28, 30, 32, 36, 41, 49,  68,  95, 127,	127},                //+11dBm                      
										{33, 36, 41, 46, 54, 64,  85, 127, 127,	127},                //+12dBm                      
										{38, 41, 48, 55, 68, 85, 120, 127, 127,	127},                //+13dBm                      
									 };
#endif


//****************************************Battery Voltage**************************************************
#define 	TH_3V3		175						//((3.3/4.8)*255)
#define 	TH_3V0		159						//((3.0/4.8)*255)
#define 	TH_2V7		144						//((2.7/4.8)*255)
#define 	TH_2V4		128						//((2.4/4.8)*255)
#define		TH_2V2		117						//((2.2/4.8)*255)	
#define		TH_2V0		107						//((2.0/4.8)*255)		

byte xdata g_trans_buf[PACKET_TRANSMIT_LEN];
word	   g_whiten_seed;

byte whitening(byte dat)										//PN9 CCITT
{
 byte i;
 byte tmp = 0;
 
 for(i=8; i!=0; i--)
 	{
 	tmp <<= 1;
 	
 	if(dat&0x80)
 		UGF0 = 1;
 	else
 		UGF0 = 0;
 	
 	if(g_whiten_seed&0x0001)
 		UGF1 = 1;
 	else
 		UGF1 = 0;
 		
 	if(UGF0^UGF1)
 		tmp |= 0x01;
 	
 	if(g_whiten_seed&0x0020)
 		UGF0 = 1;
 	else
 		UGF0 = 0;
 	
 	if(UGF0^UGF1)
 		g_whiten_seed |= 0x0200;
 	else
		g_whiten_seed &= 0xFDFF;
 	
	g_whiten_seed >>= 1;
	dat <<= 1;	
 	}
 return(tmp); 
}

/*************************************************************************************************************
*@name:    assemble_packet
*@desc:    
*@param:   none
*@return:  none 
**************************************************************************************************************/
byte assemble_packet(void)
{
 byte ind;
 byte i;
 byte crc_sta;
 word crc_result; 
 STRU_CRC16_CFG crc_cfg;	


 for(ind=0; ind<PACKET_PREAMBLE_LEN; ind++)						//Preamble 
	g_trans_buf[ind] = PACKET_PREAMBLE_VALUE;
 
 switch(PACKET_SYNC_LEN)										//SyncWord
 	{
 	case 4:
 		g_trans_buf[ind++] = (byte)(PACKET_SYNC_VALUE>>24);
 	case 3:
 		g_trans_buf[ind++] = (byte)(PACKET_SYNC_VALUE>>16);
 	case 2:
 		g_trans_buf[ind++] = (byte)(PACKET_SYNC_VALUE>>8);	
 	case 1:
 		g_trans_buf[ind++] = (byte)PACKET_SYNC_VALUE;
 		break;
 	}
 crc_sta = ind;
 
 g_trans_buf[ind++] = '2';										//Payload
 g_trans_buf[ind++] = '1';
 g_trans_buf[ind++] = '6';
 g_trans_buf[ind++] = 'x';
 g_trans_buf[ind++] = 'A';
 g_trans_buf[ind++] = lfrx_data_array[0];
 g_trans_buf[ind++] = lfrx_data_array[1];
 g_trans_buf[ind++] = lfrx_data_array[2];
 
 if(PACKET_CRC_EN!=0)
 	{	
 	crc_cfg.pbuf     = &g_trans_buf[crc_sta];	
 	crc_cfg.data_len = (PACKET_VARIABLE_EN+PACKET_PAYLOAD_LEN);
 	crc_cfg.crc_poly = 0x1021;
 	crc_cfg.crc_init = 0x0000;
 	crc_cfg.bit_order= 0;
	crc_result = sys_crc16_calc(&crc_cfg);
 	g_trans_buf[ind++] = (byte)(crc_result>>8);
 	g_trans_buf[ind++] = (byte)crc_result;
 	}

 #ifdef ENCODE_WHITEN											
 	g_whiten_seed = WHITEN_SEED;								//�׻�
 	i = crc_sta;			
 	for( ; i<ind; i++)
		g_trans_buf[i] = whitening(g_trans_buf[i]);	
 #endif

 return(ind);
}

/*************************************************************************************************************
*@name:    set_tx_modu_config
*@desc:    
*@param:   none
*@return:  none 
**************************************************************************************************************/
void set_tx_modu_config(void)
{
 xdata STRU_TX_MODU_SETUP tx_modu_setup; 
 byte i;
                   
 tx_modu_setup.mod_cfg = (MODULATION_SEL|GUASS_ON_SEL|RAMP_EN_SEL|FREQ_DEV_SEL);			
    
 tx_modu_setup.vco_cfg1  = VCO_CFG1;
 tx_modu_setup.vco_cfg0  = VCO_CFG0;
       
 tx_modu_setup.plln_cfg  = PLL_N_CFG;
 tx_modu_setup.pllk_cfg1 = PLL_K_CFG1;
 tx_modu_setup.pllk_cfg0 = PLL_K_CFG0;
    
 #ifndef DIFFERENTIAL_TX
    tx_modu_setup.pa_cfg = PA_CFG&(~M_PA_DIFF_SEL);
 #else
    tx_modu_setup.pa_cfg = PA_CFG|M_PA_DIFF_SEL;
 #endif
 
 tx_modu_setup.pa_idac_code_cfg    = PA_IDAC_CODE_CFG;

 tx_modu_setup.ramp_step_time_cfg1 = RAMP_STEP_TIME_CFG1;
 tx_modu_setup.ramp_step_time_cfg0 = RAMP_STEP_TIME_CFG0;
    
 tx_modu_setup.freq_dev_cfg1       = FREQ_DEV_CFG1;
 tx_modu_setup.freq_dev_cfg0       = FREQ_DEV_CFG0;
    
 tx_modu_setup.symbol_time_cfg1    = SYMBOL_TIME_CFG1;
 tx_modu_setup.symbol_time_cfg0    = SYMBOL_TIME_CFG0;
    
 tx_modu_setup_config(&tx_modu_setup);

 sys_set_sfr_bank(1);   

 if(PA_OUT_SEL>=13)
	i = 13;
 else
 	i = PA_OUT_SEL;
		
 PA_POWER_TH_9 = TX_POWER_SEL[i][0];
 PA_POWER_TH_8 = TX_POWER_SEL[i][1];
 PA_POWER_TH_7 = TX_POWER_SEL[i][2];
 PA_POWER_TH_6 = TX_POWER_SEL[i][3];
 PA_POWER_TH_5 = TX_POWER_SEL[i][4];
 PA_POWER_TH_4 = TX_POWER_SEL[i][5];
 PA_POWER_TH_3 = TX_POWER_SEL[i][6];
 PA_POWER_TH_2 = TX_POWER_SEL[i][7];
 PA_POWER_TH_1 = TX_POWER_SEL[i][8];
 PA_POWER_TH_0 = TX_POWER_SEL[i][9];

}

/*************************************************************************************************************
*@name:    transmit_packet
*@desc:    transmit packet from 'g_trans_buf' buffer
*@param:   none
*@return:  none 
**************************************************************************************************************/
void transmit_packet(void)
{    
 byte tx_sym_setup;
                  
 set_tx_modu_config();
    
 if(2 != tx_sym_prepare_for_transmission(LOW_BATTERY_VALUE))
	{
	// bit1: 0 - pll is not locked, 1 - pll is locked 
	// bit0: 0 - system voltage is higer than voltage_th, 1 - system voltage is lower than voltage_th 
	sys_disable_pll_module();
	sys_disable_xo_crystal();		
	return;
	}
      
 // tx_sym_setup:
 // bit[7:6]:    reserved
 // bit[5:3]:    tx group with
 // bit[2]  :    endian(0-small endian, 1-big endian)
 // bit[1:0]:    tx_sym_ctrl
 //       00:    shundown transmission after last bit
 //       01:    reuse tha last symbol group for transmission
 //       10:    all 0s data
 //       11:    all 1s data  
 //
 #ifdef PACKET_MSB_SHIFT_TX
 	tx_sym_setup = 0x3C;
 #else    
    tx_sym_setup = 0x38;
 #endif 
 tx_sym_setup_config(tx_sym_setup); 				// set tx sym config
    
 //EA = 0; 
 tx_sym_transmit(g_trans_buf, PACKET_TRANSMIT_LEN);	// transmit data from g_trans_buf
 //EA = 1; 

    
 sys_disable_pll_module();							// disable PLL module, it takes about 2.3mA
 sys_disable_xo_crystal();							// disable XO crystal, it takes about 400uA
}



//************************************************** LF-RX ***************************************************

/*************************************************************************************************************
*@name:    system_set_lfrx_config
*@desc:    set lfrx config
*@param:   none
*@return:  none 
**************************************************************************************************************/
void system_set_lfrx_config(void)
{      
    STRU_LFRX_SETUP xdata lfrx_cfg;
    
    #define lfrx_pga_ibias_val             	4 					//export from cmt216xa RFPDK
    #define lfrx_rssiamp_ibias_val         	4 
    #define lfrx_rssirec_ibias_val         	4 
    #define lfrx_startup_manual_val        	3 
    #define lfrx_ant_mode_val               3 					// 2'b00 or 2'b01---normal ant mode;    2'b10---x and y scan ant mode;    2'b11---x/y/z scan ant mode
    #define lfrx_ch_x_val                  	0 					
    #define lfrx_ch_y_val                  	0 
    #define lfrx_ch_z_val                  	0 
    #define lfrx_dr_sel_val                	3					// 3 equ 4kbps 
    #define lfrx_data_c1_val               	6 			
    #define lfrx_data_c0_val               	1 
    #define lfrx_data_r0_val               	3 
    #define lfrx_data_r1_val               	3 
    #define lfrx_data_c2_val               	3 
    #define lfrx_data_c3_val               	10 
    #define lfrx_data_clk_val              	2 
    #define lfrx_peakdet_clk_val           	1 
    #define lfrx_peakdet_c_val             	3
    #define lfrx_agc_vhref_val             	10 
    #define lfrx_agc_vlref_val             	3 
    #define lfrx_agc_cnt_val               	2 
    #define lfrx_agc_en_val                	1 
    #define lfrx_agc_in_val                	2 
    #define lfrx_agc_start_sel_val         	1 
    #define lfrx_agc_step_val              	1 
    #define lfrx_agc_cnt_th_val            	4 
    #define lfrx_agc_min_index_val         	0 
    #define lfrx_dqres_val                 	5 
    #define lfrx_cadet_win_val             	1 
    #define lfrx_cadet_ok_cnt_val          	0 
    #define lfrx_cadet_th_h_val            	55 
    #define lfrx_cadet_th_l_val            	45 
    #define lfrx_cmp_noise_mask_val        	1 
    #define lfrx_cmp_sw_val                	1 
    #define lfrx_cmp_ref_val               	14 
    #define lfrx_snrdet_snr_val            	7 
    #define lfrx_snrdet_valid_win_val      	1 
    #define lfrx_snrdet_invalid_win_val    	0
    #define lfrx_snrdet_win_val            	5 
    #define lfrx_snrdet_refin_sel_val      	0          
    #define lfrx_signal_ok_type_val        	0 					// 0: Carrier Detect        1: SNR Detect
    #define lfrx_signal_ok_autoclr_dis_val 	0 
    #define lfrx_signal_ok_clr_th_val      	50 					// N * unit for auto clear signal_ok, when lfrx_signal_ok_autoclr_dis == 0
    #define lfrx_wakeup_autoclr_dis_val    	1 					// 0: always on				1: change to manual when lfrx_wakeup = 1
    #define lfrx_meas_win_val              	1 
    #define lfrx_meas_source_val           	0 
    #define lfrx_rssi_meas_dis_val         	0 					// 	
    #define lfrx_decode_seq_val            	0 					// 0: MSB first;			1: LSB first
    #define lfrx_sync_length_val           	SYNC_LENGTH			// sync length, range: 0-3, n+1
    #define lfrx_sync_value_val            	SYNC_VALUE
	
	#ifdef ENABLE_WAKEUP_ID
    	#define lfrx_wkid_en_val           	1 					// 0: disable wkid;			1: enable wkid
    #else
    	#define lfrx_wkid_en_val           	0 					// 0: disable wkid;			1: enable wkid    
	#endif

    #define lfrx_wkid_length_val           	WKID_LENGTH			// wikd length, range:0-3, n+1
    #define lfrx_wkid_value_val            	WKID_VALUE

    #define lfrx_man_type_val              	1 					// 0: '01'==1, '10'==0;    	1: '10'==1, '01'==0
    #define lfrx_wkid_man_en_val           	1 					// 0: dianble man.wkid;		1: enable man.wkid;	
    #define lfrx_data_man_en_val           	1 					// 0: disable man.payload;	1: enable man.payload;
    #define lfrx_data_length_val           	2 
    #define lfrx_dbuf_dis_val              	0 					// 0: enable delay buffer;	1: disable delay buffer
    #define lfrx_dbuf_length_val           	3 					// receive data delay buffer length, range 0-7 
    #define lfrx_en_val                    	1 
    #define lfrx_enable_mode_val           	0 					// 0: listen & decode;    	1: only decode
    #define always_lfrx_val                	1 					// 0: for DC mode;			1: always receive
    #define lfrx_duty_cycle_en_val         	0 					// 0: disable DC mode;		1: enable DC mode (and always_lfrx_val should be 0)
    #define duty_cycle_method_val          	0 					// 0: auto extend DC mode;	1: fixed DC mode
    #define lfrx_timer_extend_mode_val     	0 					// extend condition select, 2'b00: by signal_ok;	2'b01: by sync_pass; 	2'b10: by wkid_pass;	3'b11: no used
    #define lfrx_timer_m_sleep_val         	0 
    #define lfrx_timer_r_sleep_val         	0 
    #define lfrx_timer_m_rx_t1_val         	1 
    #define lfrx_timer_r_rx_t1_val         	0 
    #define lfrx_timer_m_rx_t2_val         	0 
    #define lfrx_timer_r_rx_t2_val         	0 
    #define lfrx_wakeup_mode_val           	2 					// 2'b00: signal_ok;  		2'b01: sync_passs;		2'b10: wkid_pass; 		2'b11:reserved
    #define lfrx_mode_val                  	0 					// 2'b00: wakeup internal mcu; 	2'b01: wakeup external mcu;
    #define lfrx_clkgate_dis_val           	0 					
    #define lfrx_agc_clkgate_dis_val       	0 
    #define lfrx_demod_th_hold_val         	1 
    #define lfrx_hold_rst_sel_val          	0 

	//DATA Output selection
	#ifdef	DATA_OUT_RAW										//Raw Data Output
		#define	lfrx_dataout_sel_val       	1
		#define lfrx_dig_dataout_sel_val   	0			
	#endif
	
	#ifdef 	DATA_OUT_AFTER_SIGNAL								//CDR Data + Dclk Output, After when lfrx_signal_ok == 1 
		#define	lfrx_dataout_sel_val		0
		#define lfrx_dig_dataout_sel_val   	1
	#endif
	
	#ifdef	DATA_OUT_AFTER_WAKEUP								//Decode Data + Dclk Output, After when lfrx_wakup == 1
		#define	lfrx_dataout_sel_val		0
		#define lfrx_dig_dataout_sel_val   	0
	#endif

    #define lfosc_f_sel_val                	1 
    #define lfrx_osc_vref_val              	2 
    
    #define pad_group1_en_val             	0 					// select A5/A6/A7 
    #define pad_group2_en_val             	1 					// select A1/A2/A3
    #define lfrx_dout_sel_val             	0 					// 0:A1/A5,   1:A2/A6,   2:A3/A7  
    #define lfrx_wpint_sel_val            	1 					//
    #define lfrx_dclk_sel_val             	2 					//
    #define lfrx_ext_clr_en_val           	0 					// 1:select A4
    #define lfrx_decode_err_out_en_val    	0					// enable output, group1 for B5/ group2 for B6 
    
    
    //lfrx_agc_cfg0
    //bit[7:6]: reserved
    //bit[5:4]: lfrx_agc_in  AGC Input 
    //bit[3:0]: lfrx_agc_vhref 
    lfrx_cfg.lfrx_agc_cfg0 = ((lfrx_agc_in_val << BIT4) & M_LFRX_AGC_IN) | ((lfrx_agc_vhref_val << BIT0) & M_LFRX_AGC_VHREF);
    
    //lfrx_agc_cfg1
    //bit[7:6]: reserved
    //bit[5:4]: lfrx_agc_cnt 
    //bit[3:0]: lfrx_agc_vlref 
    lfrx_cfg.lfrx_agc_cfg1 = ((lfrx_agc_cnt_val << BIT4) & M_LFRX_AGC_CNT) | ((lfrx_agc_vlref_val << BIT0) & M_LFRX_AGC_VLREF);
    
    //lfrx_cadet_cfg
    //bit[7:6]: lfrx_cadet_win 
    //bit[5:4]: lfrx_cadet_ok_cnt 
    //bit[3:2]: lfrx_peakdet_clk  
    //bit[1:0]: lfrx_data_clk
    lfrx_cfg.lfrx_cadet_cfg = ((lfrx_cadet_win_val << BIT6) & M_LFRX_CADET_WIN) | ((lfrx_cadet_ok_cnt_val << BIT4) & M_LFRX_CADET_OK_CNT) | ((lfrx_peakdet_clk_val << BIT2) & M_LFRX_PEAKDET_CLK) | ((lfrx_data_clk_val << BIT0) & M_LFRX_DATA_CLK);
    
    //lfrx_data_cfg0
    //bit[7:6]: lfrx_data_r0
    //bit[5:4]: lfrx_data_r1 
    //bit[3:2]: lfrx_peakdet_c
    //bit[1:0]: lfosc_f_sel
    lfrx_cfg.lfrx_data_cfg0 = ((lfrx_data_r0_val << BIT6) & M_LFRX_DATA_R0) | ((lfrx_data_r1_val << BIT4) & M_LFRX_DATA_R1) | ((lfrx_peakdet_c_val << BIT2) & M_LFRX_PEAKDET_C) | ((lfosc_f_sel_val << BIT0) & M_LFOSC_F_SEL);
    
    //lfrx_data_cfg1
    //bit[7:4]: lfrx_data_c1 
    //bit[3:0]: lfrx_data_c0 
    lfrx_cfg.lfrx_data_cfg1 = ((lfrx_data_c1_val << BIT4) & M_LFRX_DATA_C1) | ((lfrx_data_c0_val << BIT0) & M_LFRX_DATA_C0);
    
    //lfrx_data_cfg2
    //bit[7:6]: lfrx_data_c3 
    //bit[3:0]: lfrx_data_c2 
    lfrx_cfg.lfrx_data_cfg2 = ((lfrx_data_c3_val << BIT6) & M_LFRX_DATA_C3) | ((lfrx_data_c2_val << BIT0) & M_LFRX_DATA_C2);
    
    //lfrx_cmp_cfg0
    //bit[7]: 	lfrx_cmp_noise_mask 
    //bit[6]: 	lfrx_cmp_sw 
    //bit[5:3]: lfrx_rssiamp_ibias 
    //bit[2:0]: lfrx_pga_ibias
    lfrx_cfg.lfrx_cmp_cfg0 = ((lfrx_cmp_noise_mask_val << BIT7) & M_LFRX_CMP_NOISE_MASK) | ((lfrx_cmp_sw_val << BIT6) & M_LFRX_CMP_SW) | ((lfrx_rssiamp_ibias_val << BIT3) & M_LFRX_RSSIAMP_IBIAS) | ((lfrx_pga_ibias_val << BIT0) & M_LFRX_PGA_IBIAS);
    
    //lfrx_cmp_cfg1
    //bit[7:4]: lfrx_cmp_ref 
    //bit[3]: 	lfrx_demod_th_hold
    //bit[2:0]: lfrx_rssirec_ibias
    lfrx_cfg.lfrx_cmp_cfg1 = ((lfrx_cmp_ref_val << BIT4) & M_LFRX_CMP_REF) | ((lfrx_demod_th_hold_val << BIT3) & M_LFRX_DEMOD_TH_HOLD) | ((lfrx_rssirec_ibias_val << BIT0) & M_LFRX_RSSIREC_IBIAS);
    
    //lfrx_snrdet_cfg0
    //bit[7:6]: lfrx_snrdet_invalid_win
    //bit[5:4]: lfrx_snrdet_valid_win 
    //bit[3:0]: lfrx_snrdet_snr  
    lfrx_cfg.lfrx_snrdet_cfg0 = ((lfrx_snrdet_invalid_win_val << BIT6) & M_LFRX_SNRDET_INVALID_WIN) | ((lfrx_snrdet_valid_win_val << BIT4) & M_LFRX_SNRDET_VALID_WIN) | ((lfrx_snrdet_snr_val << BIT0) & M_LFRX_SNRDET_SNR);
    
    //lfrx_ch_cfg
    //bit[7]: 	lfrx_meas_source
    //bit[6:5]: lfrx_osc_vref
    //bit[4]: 	lfrx_ch_z
    //bit[3]: 	lfrx_ch_y
    //bit[2]: 	lfrx_ch_x
    //bit[1:0]: lfrx_startup_manual
    lfrx_cfg.lfrx_ch_cfg = ((lfrx_meas_source_val << BIT7) & M_LFRX_MEAS_SOURCE) | ((lfrx_osc_vref_val << BIT5) & M_LFRX_OSC_VREF) | ((lfrx_ch_z_val << BIT4) & M_LFRX_CH_Z) | ((lfrx_ch_y_val << BIT3) & M_LFRX_CH_Y) | ((lfrx_ch_x_val << BIT2) & M_LFRX_CH_X) | ((lfrx_startup_manual_val << BIT0) & M_LFRX_STARTUP_MANUAL);
    
    //lfrx_mode_cfg
    //bit[7:6]: lfrx_mode  
    //bit[5]: 	lfrx_signal_ok_type 
    //bit[4:3]: lfrx_timer_extend_mode 
    //bit[2]: 	duty_cycle_method 
    //bit[1]: 	lfrx_duty_cycle_en 
    //bit[0]: 	always_lfrx  
    lfrx_cfg.lfrx_mode_cfg = ((lfrx_mode_val << BIT6) & M_LFRX_MODE) | ((lfrx_signal_ok_type_val << BIT5) & M_LFRX_SIGNAL_OK_TYPE) | ((lfrx_timer_extend_mode_val << BIT3) & M_LFRX_TIMER_EXTEND_MODE) | ((duty_cycle_method_val << BIT2) & M_DUTY_CYCLE_METHOD) | ((lfrx_duty_cycle_en_val << BIT1) & M_LFRX_DUTY_CYCLE_EN) | ((always_lfrx_val << BIT0) & M_ALWAYS_LFRX);
    
    //lfrx_timer_cfg0
    //bit[7:3]: lfrx_timer_m_rx_t1 
    //bit[2:0]: lfrx_timer_r_rx_t1 
    lfrx_cfg.lfrx_timer_cfg0 = ((lfrx_timer_m_rx_t1_val << BIT3) & M_LFRX_TIMER_M_RX_T1) | ((lfrx_timer_r_rx_t1_val << BIT0) & M_LFRX_TIMER_R_RX_T1);
    
    //lfrx_timer_cfg1
    //bit[7:3]: lfrx_timer_m_rx_t2 
    //bit[2:0]: lfrx_timer_r_rx_t2 
    lfrx_cfg.lfrx_timer_cfg1 = ((lfrx_timer_m_rx_t2_val << BIT3) & M_LFRX_TIMER_M_RX_T2) | ((lfrx_timer_r_rx_t2_val << BIT0) & M_LFRX_TIMER_R_RX_T2);
    
    //lfrx_timer_cfg2
    //bit[7:0]: lfrx_timer_m_sleep
    lfrx_cfg.lfrx_timer_cfg2 = lfrx_timer_m_sleep_val;
    
    //lfrx_timer_cfg3
    //bit[7:6]: reserved
    //bit[5]:   lfrx_wakeup_autoclr_dis
    //bit[4:3]: lfrx_wakeup_mode  
    //bit[2:0]: lfrx_timer_r_sleep  
    lfrx_cfg.lfrx_timer_cfg3 = ((lfrx_wakeup_autoclr_dis_val << BIT5) & M_LFRX_WAKEUP_AUTOCLR_DIS) | ((lfrx_wakeup_mode_val << BIT3) & M_LFRX_WAKEUP_MODE) | ((lfrx_timer_r_sleep_val << BIT0) & M_LFRX_TIMER_R_SLEEP);
    
    //lfrx_snrdet_cfg1
    //bit[7]: 	lfrx_rssi_meas_dis 
    //bit[6]: 	lfrx_dbuf_dis
    //bit[5:3]: lfrx_snrdet_win 
    //bit[2:0]: lfrx_meas_win 0: 
    lfrx_cfg.lfrx_snrdet_cfg1 = ((lfrx_rssi_meas_dis_val << BIT7) & M_LFRX_RSSI_MEAS_DIS) | ((lfrx_dbuf_dis_val << BIT6) & M_LFRX_DBUF_DIS) | ((lfrx_snrdet_win_val << BIT3) & M_LFRX_SNRDET_WIN) | ((lfrx_meas_win_val << BIT0) & M_LFRX_MEAS_WIN);
    
    //lfrx_packet_cfg0
    //bit[7:5]: lfrx_dbuf_length
    //bit[4]: 	lfrx_wkid_en 
    //bit[3:2]: lfrx_wkid_length 
    //bit[1:0]: lfrx_sync_lenth 
    lfrx_cfg.lfrx_packet_cfg0 = ((lfrx_dbuf_length_val << BIT5) & M_LFRX_DBUF_LENGTH) | ((lfrx_wkid_en_val << BIT4) & M_LFRX_WKID_EN) | ((lfrx_wkid_length_val << BIT2) & M_LFRX_WKID_LENGTH) | ((lfrx_sync_length_val << BIT0) & M_LFRX_SYNC_LENGTH);
    
    //lfrx_packet_cfg1
    //bit[7:6]: lfrx_ant_mode  
    //bit[5]: 	lfrx_hold_rst_sel  
    //bit[4]: 	lfrx_snrdet_refin_sel 
    //bit[3]: 	lfrx_man_type 
    //bit[2]: 	lfrx_wkid_man_en 
    //bit[1]: 	lfrx_dig_dataout_sel
    //bit[0]: 	lfrx_data_man_en 
    lfrx_cfg.lfrx_packet_cfg1 = ((lfrx_ant_mode_val << BIT6) & M_LFRX_ANT_MODE) | ((lfrx_hold_rst_sel_val << BIT5) & M_LFRX_HOLD_RST_SEL) | ((lfrx_snrdet_refin_sel_val << BIT4) & M_LFRX_SNRDET_REFIN_SEL) | ((lfrx_man_type_val << BIT3) & M_LFRX_MAN_TYPE) | ((lfrx_wkid_man_en_val << BIT2) & M_LFRX_WKID_MAN_EN) | ((lfrx_dig_dataout_sel_val << BIT1) & M_LFRX_DIG_DATAOUT_SEL) | ((lfrx_data_man_en_val << BIT0) & M_LFRX_DATA_MAN_EN);
    
    //lfrx_sync_value_cfg0
    //bit[7:0]: lfrx_sync_value[7:0]
    lfrx_cfg.lfrx_sync_value_cfg0 = lfrx_sync_value_val;
    
    //lfrx_sync_value_cfg1
    //bit[7:0]: lfrx_sync_value[15:8]
    lfrx_cfg.lfrx_sync_value_cfg1 = (lfrx_sync_value_val >> 8);
    
    //lfrx_sync_value_cfg2
    //bit[7:0]: lfrx_sync_value[23:16]
    lfrx_cfg.lfrx_sync_value_cfg2 = (lfrx_sync_value_val >> 16);
    
    //lfrx_sync_value_cfg3
    //bit[7:0]: lfrx_sync_value[31:24]
    lfrx_cfg.lfrx_sync_value_cfg3 = (lfrx_sync_value_val >> 24);
    
    //lfrx_wkid_value_cfg0
    //bit[7:0]: lfrx_wkid_value[7:0]
    lfrx_cfg.lfrx_wkid_value_cfg0 = lfrx_wkid_value_val;
    
    //lfrx_wkid_value_cfg1
    //bit[7:0]: lfrx_wkid_value[15:8]
    lfrx_cfg.lfrx_wkid_value_cfg1 = (lfrx_wkid_value_val >> 8);
    
    //lfrx_wkid_value_cfg2
    //bit[7:0]: lfrx_wkid_value[23:16]
    lfrx_cfg.lfrx_wkid_value_cfg2 = (lfrx_wkid_value_val >> 16);
    
    //lfrx_wkid_value_cfg3
    //bit[7:0]: lfrx_wkid_value[31:24]
    lfrx_cfg.lfrx_wkid_value_cfg3 = (lfrx_wkid_value_val >> 24);
    
    //lfrx_agc_cfg2
    //bit[7]: 	lfrx_dataout_sel 
    //bit[6]: 	lfrx_decode_seq 
    //bit[5]: 	lfrx_signal_ok_autoclr_dis  
    //bit[4]: 	lfrx_agc_en 
    //bit[3]: 	lfrx_agc_step  
    //bit[2:0]: lfrx_agc_cnt_th  
    lfrx_cfg.lfrx_agc_cfg2 = ((lfrx_dataout_sel_val << BIT7) & M_LFRX_DATAOUT_SEL) | ((lfrx_decode_seq_val << BIT6) & M_LFRX_DECODE_SEQ) | ((lfrx_signal_ok_autoclr_dis_val << BIT5) & M_LFRX_SIGNAL_OK_AUTOCLR_DIS) | ((lfrx_agc_en_val << BIT4) & M_LFRX_AGC_EN) | ((lfrx_agc_step_val << BIT3) & M_LFRX_AGC_STEP) | ((lfrx_agc_cnt_th_val << BIT0) & M_LFRX_AGC_CNT_TH);
    
    //lfrx_agc_cfg3
    //bit[7:4]: lfrx_dqres 
    //bit[3:0]: lfrx_agc_min_index  
    lfrx_cfg.lfrx_agc_cfg3 = ((lfrx_dqres_val << BIT4) & M_LFRX_DQRES) | ((lfrx_agc_min_index_val << BIT0) & M_LFRX_AGC_MIN_INDEX);
    
    //lfrx_agc_cfg4
    //bit[7:4]: lfrx_dr_sel
    //bit[3]: 	lfrx_clkgate_dis 
    //bit[2]: 	lfrx_enable_mode 
    //bit[1]: 	lfrx_agc_clkgate_dis
    //bit[0]: 	lfrx_agc_start_sel 
    lfrx_cfg.lfrx_agc_cfg4 = ((lfrx_dr_sel_val << BIT4) & M_LFRX_DR_SEL) | ((lfrx_clkgate_dis_val << BIT3) & M_LFRX_CLKGATE_DIS) | ((lfrx_enable_mode_val << BIT2) & M_LFRX_ENABLE_MODE) | ((lfrx_agc_clkgate_dis_val << BIT1) & M_LFRX_AGC_CLKGATE_DIS) | ((lfrx_agc_start_sel_val << BIT0) & M_LFRX_AGC_START_SEL);
    
    //lfrx_cadet_th_h_cfg
    //bit[7:0]: lfrx_cadet_th_h 
    lfrx_cfg.lfrx_cadet_th_h_cfg = lfrx_cadet_th_h_val;
    
    //lfrx_cadet_th_l_cfg
    //bit[7:0]: lfrx_cadet_th_l  
    lfrx_cfg.lfrx_cadet_th_l_cfg = lfrx_cadet_th_l_val;
    
    //lfrx_signal_ok_clr_th_cfg
    //bit[7:0]: lfrx_signal_ok_clr_th 
    lfrx_cfg.lfrx_signal_ok_clr_th_cfg = lfrx_signal_ok_clr_th_val;
    
    //lfrx_data_length_cfg
    //bit[7:0]: lfrx_data_length 
    lfrx_cfg.lfrx_data_length_cfg = lfrx_data_length_val;
    
    lfrx_setup_config(&lfrx_cfg);									// config lfrx setup

    sys_set_hv_reg(CUS_SYSCTL18_ADDR, ((lfrx_dout_sel_val << BIT6) & M_LFRX_DOUT_SEL) | ((lfrx_wpint_sel_val << BIT4) & M_LFRX_WPINT_SEL) | ((pad_group2_en_val << BIT3) & M_PAD_GROUP2_EN) | ((pad_group1_en_val << BIT2) & M_PAD_GROUP1_EN), (M_LFRX_DOUT_SEL | M_LFRX_WPINT_SEL | M_PAD_GROUP2_EN | M_PAD_GROUP1_EN));
    sys_set_hv_reg(CUS_SYSCTL19_ADDR, ((lfrx_ext_clr_en_val << BIT5) & M_LFRX_EXT_CLR_EN) | ((lfrx_decode_err_out_en_val << BIT2) & M_LFRX_DECODE_ERR_OUT_EN) | ((lfrx_dclk_sel_val << BIT0) & M_LFRX_DCLK_SEL), (M_LFRX_EXT_CLR_EN | M_LFRX_DECODE_ERR_OUT_EN | M_LFRX_DCLK_SEL));
    sys_set_hv_reg(CUS_SYSCTL3_ADDR, ((lfrx_en_val << BIT2) & M_LFRX_EN), M_LFRX_EN);
}

/*************************************************************************************************************
*@name:    lfrx_rx_data_routine
*@desc:    receive lfrx data interrupt routine
*@param:   none
*@return:  none 
**************************************************************************************************************/
void lfrx_data_routine(void) 
{
    sys_set_sfr_bank(0);															// set sfr bank to bank 0

	lfrx_recv_timer = 0;															// clear timer counter
    lfrx_data_buf <<= 1;
    if(CLK_SYS_DIV&M_LFRX_MCU_RDATA)												// read lfrx_mcu_rdata
        lfrx_data_buf |= 0x01;
    lfrx_recv_bit_cnt++;															// receive bit counter increase

 
 	lfrx_rssi_tmp  = sys_read_hv_reg(CUS_LFRX31_ADDR);
 	lfrx_rssi_tmp &= 0x3F;
 	if(lfrx_rssi_tmp>=lfrx_rssi_value)
 	lfrx_rssi_value = lfrx_rssi_tmp;


    lfrx_receiving_f = 1;															// receiving process active
    
    if(lfrx_recv_bit_cnt >= 8)
    	{
       	lfrx_data_array[lfrx_recv_index++] = lfrx_data_buf;							// stored
       	
       	lfrx_data_buf = 0;															// for the next byte
        lfrx_recv_bit_cnt = 0;
       	
       	if(lfrx_recv_index >= PAYLOAD_LENGTH) 										// does receive enough?
        	{
        	lfrx_recv_index  = 0;													// for the next time
        	lfrx_recv_done_f = 1;													// received ok
        	sys_set_hv_reg(CUS_SYSCTL11_ADDR, M_LFRX_MANU_CLR, M_LFRX_MANU_CLR);	// clear lfrx receive process this time
			EX0 = 0;
        	}
	    }
	
	sys_set_sfr_bank(0);
	while(CLK_SYS_DIV&M_LFRX_MCU_RCLK);												// wait until DCLK over
}


void lfrx_init(void)
{
	byte i;
	
 	lfrx_receiving_f = 0;
 	lfrx_recv_done_f = 0;
 	lfrx_recv_bit_cnt= 0;
 	lfrx_data_buf    = 0;
 	lfrx_recv_index  = 0;
   
    for(i=0; i<PAYLOAD_LENGTH; i++)
    	lfrx_data_array[i] = 0x00;
  
 	lfrx_recv_timer  = 0;
 	system_external_interrupt0_service_routine = lfrx_data_routine;				
 	sys_set_external_interrupt0_config(INT_POLAR | INT_SRC_LFRX_MCU_RCLK);  	
	TCON |= M_IT0;																	//edge interrupt
 	EX0 = 1;			
 	//IPL_EX0 = 1;	
}

//***************************************** Timer *******************************************************

#define		TIMER_INTERVAL			20000					// TIMER_INTERVAL/2 us, and Max 65536

//*****************************************************************************
//Name: timer1_interrupt_service_routine
//Func: timer1 interrupt service function
//input:int_ms, period time
//*****************************************************************************
void timer1_interrupt_service_routine(void)
{
 	TF1 = 0;
 	TH1  = (byte)((65536-TIMER_INTERVAL)>>8); 				
 	TL1  = (byte)(65536-TIMER_INTERVAL);
 
 	systimer++;
 	lfrx_recv_timer++;
}

//*****************************************************************************
//Name: init_timer1_mode1
//Func: initial timer1 as mode1, & enable timer1 interrupt
//input:int_ms, period time
//*****************************************************************************
void init_timer1_mode1(void)
{
 	// timer 1 mode1 setting 
 	TMOD = 0x10; 											// mode 1: 16-bit (Max=65536),  Timer1 Clock = HFOSC/12 = 24/12 = 2MHz, so that Max. Intevral about 65536*0.5=32.768ms
 	TH1  = (byte)((65536-TIMER_INTERVAL)>>8); 				
 	TL1  = (byte)(65536-TIMER_INTERVAL);

 	// interrupt vector 
 	system_timer1_interrupt_service_routine = timer1_interrupt_service_routine;

 	ET1 = 1;												//enable interrupt
 	TR1 = 1;												//enable timer1  
}



void delay_1ms(void)
{
 	sys_delay_us_count(250);
 	sys_delay_us_count(250);
 	sys_delay_us_count(250);
 	sys_delay_us_count(250);
} 

void delay_Nms(byte cnt)
{
 for( ; cnt!=0; cnt--)
	delay_1ms();
}

void main(void)   
{
 byte tmp;
 byte i;
 byte battery_voltage;

 IEN0 = 0x00;
 IEN1 = 0x00;
 sys_clear_system_flag();
 clear_interrupt_vector();
 
 //init port
 sys_set_hv_reg(CUS_PADCTL2_ADDR, (GPIO5_MODE_AS_DIG_OUTPUT|GPIO6_MODE_AS_DIG_OUTPUT|GPIO7_MODE_AS_DIG_OUTPUT), (M_GPIO5_MODE|M_GPIO6_MODE|M_GPIO7_MODE));
 sys_set_hv_reg(CUS_PADCTL4_ADDR, (GPIO13_MODE_AS_DIG_OUTPUT|GPIO12_MODE_AS_DIG_OUTPUT), (M_GPIO13_MODE|M_GPIO12_MODE));
 sys_set_hv_reg(CUS_PADCTL5_ADDR, (GPIO5_CNF_OUTPUT_PUSH_PULL|GPIO6_CNF_OUTPUT_PUSH_PULL|GPIO7_CNF_OUTPUT_PUSH_PULL), (M_GPIO5_CNF|M_GPIO6_CNF|M_GPIO7_CNF)); 	
 sys_set_hv_reg(CUS_PADCTL6_ADDR, (GPIO13_CNF_OUTPUT_PUSH_PULL|GPIO12_CNF_OUTPUT_PUSH_PULL), (M_GPIO13_CNF|M_GPIO12_CNF));	
 sys_set_hv_reg(CUS_PADCTL11_ADDR, (GPIO5_INPUT_FLOATING|GPIO6_INPUT_FLOATING|GPIO7_INPUT_FLOATING), (M_GPIO5_ODR|M_GPIO6_ODR|M_GPIO7_ODR));		
 sys_set_hv_reg(CUS_PADCTL12_ADDR, (GPIO13_INPUT_FLOATING|GPIO12_INPUT_FLOATING), (M_GPIO13_ODR|M_GPIO12_ODR));
 																			   	
 sys_set_hv_reg(CUS_SYSCTL20_ADDR, (GPIO16_MODE_AS_DIG_OUTPUT|GPIO16_CNF_OUTPUT_PUSH_PULL|GPIO16_INPUT_FLOATING), 0x0F);	//D1 as push-pull output
  
 sys_set_hv_reg(INT_SYSCTL3_ADDR, M_S3S_DISABLE, M_S3S_DISABLE);						//S3S Disable for use B4 

 sys_set_sfr_bank(0);
 B4_OUT_H;  

 init_timer1_mode1();
 EA = 1;


 if(sys_is_first_power_up())
    {
    sys_enable_low_32khz_clock(0);														// lfrx need to enable 32khz clock
    delay_1ms();
	           

	afe_check_system_voltage(TH_2V7);						
 	battery_voltage = sys_read_hv_reg(CUS_SYSCTL17_ADDR);	
 		
 	if(battery_voltage>TH_3V0)
 		i = 4;
 	else if(battery_voltage>TH_2V7)
 		i = 3;
 	else if(battery_voltage>TH_2V4)
 		i = 2;
 	else 
 		i = 1;
 			
 	for( ; i!=0; i--)
 		{
		sys_set_sfr_bank(0);
 		B4_OUT_L;  
		D1_OUT_L;  
 		delay_Nms(100);
		sys_set_sfr_bank(0);
 		B4_OUT_H;  
		D1_OUT_H; 
		delay_Nms(100);
		}
	
	delay_Nms(250);
	delay_Nms(250);

	//check low frequency
	cal_lfrx_osc_amplitude_calibration(125);
	tmp  = sys_read_hv_reg(CUS_LFRX32_ADDR);
	tmp &= 0x07;
	if(tmp==0x07)													//quick flash indicate hardware has problem
		{
		while(1)													//��ƷʧЧ	
			{
			sys_set_sfr_bank(0);
 			B4_OUT_L;  
			D1_OUT_L;  
 			delay_Nms(25);
			sys_set_sfr_bank(0);
 			B4_OUT_H;  
			D1_OUT_H; 
			delay_Nms(25);			
			}
		}
	else
		{
		cal_lfrx_osc_frequency_calibration(125);	
  		i = 0;
		tmp  = sys_read_hv_reg(CAL_LFRX_TCAP0_ADDR);
		tmp &= 0x1F;
		if((tmp<MIN_CAP_VALUE)||(tmp>MAX_CAP_VALUE))
			i += 1;
		tmp  = sys_read_hv_reg(CAL_LFRX_TCAP1_ADDR);
		tmp &= 0x1F;
		if((tmp<MIN_CAP_VALUE)||(tmp>MAX_CAP_VALUE))
			i += 2;
		
		if(i!=0)
			{
			for( ; i!=0; i--)
 				{
				sys_set_sfr_bank(0);
 				B4_OUT_L;  
				D1_OUT_L;  
 				delay_Nms(100);
				sys_set_sfr_bank(0);
 				B4_OUT_H;  
				D1_OUT_H;
 				delay_Nms(100);
 				}
			}
	    sys_set_hv_reg(CUS_SYSCTL11_ADDR, M_LFRX_MANU_CLR, M_LFRX_MANU_CLR);				
		system_set_lfrx_config();	
		 	
		#ifndef	FLASH_BOOT_DEBUG_MODE
			 sys_set_hv_reg(CUS_SYSCTL3_ADDR, M_LFRX_DEBUG_EN, M_LFRX_DEBUG_EN);				
		#endif
		}

	#ifdef	FLASH_BOOT_DEBUG_MODE
		sys_set_gpio_hold(GPIO_HOLD_ENA);	
		sys_shutdown();
    #endif
    } 

 while(1)
 	{
 	tmp = sys_read_hv_reg(CUS_SYSCTL12_ADDR);											// read wakup flag

	if(tmp&M_WKID_PASS)																	// does it is wkid_pass
		{
		lfrx_init();																	// init lfrx interrupt serve

		#ifdef	FLASH_BOOT_DEBUG_MODE
			do																			// wait for lfrx data done
				{
				PCON |= M_IDLE;															// go into idle mode, for power saving
				if(lfrx_recv_done_f)
					break;
				}while(lfrx_recv_timer<5);
		#else
			do																			// wait for lfrx data done
				{
				PCON |= M_IDLE;															// go into idle mode, for power saving
				if(lfrx_recv_done_f)
					break;
				}while(1);
		#endif			

		
		if(lfrx_recv_done_f)
			{
			assemble_packet();
			transmit_packet();

			sys_set_sfr_bank(0);
 			B4_OUT_L;  
			D1_OUT_L;  
			delay_Nms(50);
			sys_set_sfr_bank(0);
 			B4_OUT_H;  
			D1_OUT_H;  
			}
		sys_set_hv_reg(CUS_SYSCTL11_ADDR, M_LFRX_MANU_CLR, M_LFRX_MANU_CLR);	
		delay_1ms();																	// wait 
		}
	
	#ifdef	FLASH_BOOT_DEBUG_MODE
		sys_set_gpio_hold(GPIO_HOLD_ENA);	
		sys_shutdown();
    #endif
	}

}
