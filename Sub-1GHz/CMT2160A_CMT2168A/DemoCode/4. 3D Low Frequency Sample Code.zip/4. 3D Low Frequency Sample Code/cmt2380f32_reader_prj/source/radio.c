#include "rfm380.h"

/**************************************************************************************************
State Ctrl
**************************************************************************************************/
/**********************************************************
**Name:     vSoftReset
**Function: Software reset Chipset
**Input:    none
**Output:   none
**********************************************************/
void vSoftReset(void)
{
 vSpi3Write(((word)CUS_SOFTRST<<8)+0xFF); 
 _delay_us(10000);							//wait 15ms		
}

/**********************************************************
**Name:     bGoSleep
**Function: Entry Sleep Mode
**Input:    none
**Output:   none
**********************************************************/
byte bGoSleep(void)
{
 byte tmp;
 
 vSpi3Write(((word)CUS_MODE_CTL<<8)+MODE_GO_SLEEP);	
 _delay_us(100);		
 tmp = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));	
 
 if(tmp==MODE_STA_SLEEP)
 	return(1);
 else
 	return(0);
}

/**********************************************************
**Name:     bGoStandby
**Function: Entry Standby Mode
**Input:    none
**Output:   none
**********************************************************/
byte bGoStandby(void)
{
 byte tmp, i;	
 
 RssiTrig = 0;
 PktRevError = 0;
 
 vSpi3Write(((word)CUS_MODE_CTL<<8)+MODE_GO_STBY);	
 for(i=0; i<10; i++)
 	{
 	_delay_us(100);	
	tmp = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));	
	if(tmp==MODE_STA_STBY)
		break;
	}
 
 if(i>=10)
 	return(0);
 else
 	return(1);
}

/**********************************************************
**Name:     bGoTx
**Function: Entry Tx Mode
**Input:    none
**Output:   none
**********************************************************/
byte bGoTx(void)
{
 byte tmp, i;		
 
 vSpi3Write(((word)CUS_MODE_CTL<<8)+MODE_GO_TFS);	
 for(i=0; i<3; i++)
 	{
 	_delay_us(1000);	
	tmp = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));	
	if(tmp==MODE_STA_TFS)
		break;
	}
 if(i>=3)
 	{
 	if(tmp==MODE_STA_UNLOCK)
 		{
		bGoStandby();
		_delay_us(3000);	//about 2.1ms
		vSpi3Write(((word)CUS_MODE_CTL<<8)+MODE_GO_TFS);	
		_delay_us(2000);
		tmp = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));	
		if(tmp!=MODE_STA_TFS)
			return(0);
 		}	
 	else
 		return(0);
	}
	
 vSpi3Write(((word)CUS_MODE_CTL<<8)+MODE_GO_TX);		
 for(i=0; i<3; i++)
 	{
 	_delay_us(1000);	
	tmp = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));	
	if(tmp==MODE_STA_TX)
		break;
	}
 if(i>=3)
 	return(0);
 else
 	return(1);
}

/**********************************************************
**Name:     bGoRx
**Function: Entry Rx Mode
**Input:    none
**Output:   none
**********************************************************/
byte bGoRx(void)
{
 byte tmp, i;
 
 RssiTrig = 0;
 PktRevError = 0;
 
 vSetPayloadLength(0, PayloadLength);						//Set traget reveive length

 vEnableRdFifo();											//when FIFO Merge Active, set fifo to Rd
 
 vSpi3Write(((word)CUS_MODE_CTL<<8)+MODE_GO_RFS);			//for JackPrj use
 for(i=0; i<3; i++)
 	{
 	_delay_us(1000);	
	tmp = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));	
	if(tmp==MODE_STA_RFS)
		break;
	}
 if(i>=3)
 	{
 	if(tmp==MODE_STA_UNLOCK)
 		{
		bGoStandby();
		_delay_us(3000);	//about 2.1ms
		vSpi3Write(((word)CUS_MODE_CTL<<8)+MODE_GO_RFS);	
		_delay_us(2000);
		tmp = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));	
		if(tmp!=MODE_GO_RFS)
			return(0);
 		}	
 	else
 		return(0);
 	}
 
 vSpi3Write(((word)CUS_MODE_CTL<<8)+MODE_GO_RX);		
 for(i=0; i<3; i++)
 	{
 	_delay_us(1000);	
	tmp = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));	
	if(tmp==MODE_STA_RX)
		break;
	}
 if(i>=3)
 	return(0);
 else
 	return(1);
}

/**********************************************************
**Name:     bGoSwitch
**Function: Tx to Rx  or  Rx to Tx, use for quick switch 
**Input:    none
**Output:   none
**********************************************************/
byte bGoSwitch(void)
{
 byte tmp, i, z;

 tmp = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));	
 
 if((tmp!=MODE_STA_RX)&&(tmp!=MODE_STA_TX))
 	return(0);
 
 vSpi3Write(((word)CUS_MODE_CTL<<8)+MODE_GO_SWITCH);	
 
 for(i=0; i<3; i++)
 	{
 	_delay_us(1000);		
 	z = (MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));
 	if(tmp==MODE_STA_RX)
 		{
	 	if(z==MODE_STA_TX)
 			break;
 		}
 	else
 		{
 		if(z==MODE_STA_RX)	
 			break;
 		}
 	}
 if(i>=3)
 	return(0);
 else
 	return(1);
}

/**********************************************************
**Name:     bReadStatus
**Function: read chipset status
**Input:    none
**Output:   none
**********************************************************/
byte bReadStatus(void)
{
 return(MODE_MASK_STA & bSpi3Read(CUS_MODE_STA));		
}

/**********************************************************
**Name:     bReadRssi
**Function: Read Rssi
**Input:    true------dBm;
            false-----Code;
**Output:   none
**********************************************************/
byte bReadRssi(byte unit_dbm)
{
 byte readout;
 switch(unit_dbm)
 	{
 	case 0: 
 		readout = bSpi3Read(CUS_RSSI_CODE);			//code
 		break;
 	case 1:
 		readout = (bSpi3Read(CUS_RSSI_DBM)-128);	//with sign
 		break;
 	default:
 		readout = bSpi3Read(CUS_RSSI_DBM);			////without sign
 		break;
 	}
 return(readout);
}

/**************************************************************************************************
GPIO & Interrupt CFG
**************************************************************************************************/
/**********************************************************
**Name:     vGpioFuncCfg
**Function: GPIO Function config
**Input:    none
**Output:   none
**********************************************************/
void vGpioFuncCfg(byte io_cfg)
{
 vSpi3Write(((word)CUS_IO_SEL<<8)+io_cfg);
}

/**********************************************************
**Name:     vIntSrcCfg
**Function: config interrupt source  
**Input:    int_1, int_2
**Output:   none
**********************************************************/
void vIntSrcCfg(byte int_1, byte int_2)
{
 byte tmp;
 tmp = INT_MASK & bSpi3Read(CUS_INT1_CTL);
 vSpi3Write(((word)CUS_INT1_CTL<<8)+(tmp|int_1));
 
 tmp = INT_MASK & bSpi3Read(CUS_INT2_CTL);
 vSpi3Write(((word)CUS_INT2_CTL<<8)+(tmp|int_2));
}

/**********************************************************
**Name:     vInt1SrcCfg
**Function: config interrupt source 1
**Input:    int_1
**Output:   none
**********************************************************/
void vInt1SrcCfg(byte int_1)
{
 byte tmp;
 tmp = INT_MASK & bSpi3Read(CUS_INT1_CTL);
 vSpi3Write(((word)CUS_INT1_CTL<<8)+(tmp|int_1));
}


/**********************************************************
**Name:     vInt2SrcCfg
**Function: config interrupt source 2 
**Input:    int_2
**Output:   none
**********************************************************/
void vInt2SrcCfg(byte int_2)
{
 byte tmp;
 tmp = INT_MASK & bSpi3Read(CUS_INT2_CTL);
 vSpi3Write(((word)CUS_INT2_CTL<<8)+(tmp|int_2));
}

/**********************************************************
**Name:     vIntSrcEnable
**Function: enable interrupt source 
**Input:    en_int
**Output:   none
**********************************************************/
void vIntSrcEnable(byte en_int)
{
 vSpi3Write(((word)CUS_INT_EN<<8)+en_int);				
}

/**********************************************************
**Name:     vIntSrcFlagClr
**Function: clear flag
**Input:    none
**Output:   equ CMT23_INT_EN
**     .7      .6     .5        .4       .3       .2       .1       .0
**   SL_TMO  RX_TMO  TX_TMO  PREAM_OK  SYNC_OK  NODE_OK  CRC_OK  PKT_DONE
**********************************************************/
byte bIntSrcFlagClr(void)
{
 byte tmp;
 byte int_clr2 = 0;
 byte int_clr1 = 0;
 byte flg = 0;
 
 tmp = bSpi3Read(CUS_INT_FLAG);
 if(IntPolarFlag)
 	{
 	if(tmp&LBD_FLG)					//LBD_FLG_Active
 		int_clr2 |= LBD_CLR;
 	
 	if(tmp&PREAM_OK_FLG)			//Preamble Active
 		{
 		int_clr2 |= PREAM_OK_CLR;
 		flg |= PREAM_OK_EN;
		}
 	if(tmp&SYNC_OK_FLG)				//Sync Active
 		{
 		int_clr2 |= SYNC_OK_CLR;		
 		flg |= SYNC_OK_EN;		
 		}
 	if(tmp&NODE_OK_FLG)				//Node Addr Active
 		{
 		int_clr2 |= NODE_OK_CLR;	
 		flg |= NODE_OK_EN;
 		}
 	if(tmp&CRC_OK_FLG)				//Crc Pass Active
 		{
 		int_clr2 |= CRC_OK_CLR;
 		flg |= CRC_OK_EN;
 		}
 	if(tmp&PKT_OK_FLG)				//Rx Done Active
 		{
 		int_clr2 |= PKT_DONE_CLR;
 		flg |= PKT_DONE_EN;
 		}
 		
 	if(tmp&COL_ERR_FLG)				//������������ͨ��RX_DONE���
 		int_clr2 |= PKT_DONE_CLR;
 	if(tmp&PKT_ERR_FLG)
 		int_clr2 |= PKT_DONE_CLR;
 	}
 else
 	{
 	if((tmp&LBD_FLG)==0)			//LBD_FLG_Active
 		int_clr2 |= LBD_CLR;
 	
 	if((tmp&PREAM_OK_FLG)==0)		//Preamble Active
 		{
 		int_clr2 |= PREAM_OK_CLR;
 		flg |= PREAM_OK_EN;
		}
 	if((tmp&SYNC_OK_FLG)==0)		//Sync Active
 		{
 		int_clr2 |= SYNC_OK_CLR;		
 		flg |= SYNC_OK_EN;		
 		}
 	if((tmp&NODE_OK_FLG)==0)		//Node Addr Active
 		{
 		int_clr2 |= NODE_OK_CLR;	
 		flg |= NODE_OK_EN;
 		}
 	if((tmp&CRC_OK_FLG)==0)			//Crc Pass Active
 		{
 		int_clr2 |= CRC_OK_CLR;
 		flg |= CRC_OK_EN;
 		}
 	if((tmp&PKT_OK_FLG)==0)			//Rx Done Active
 		{
 		int_clr2 |= PKT_DONE_CLR;
 		flg |= PKT_DONE_EN;
 		}
 		
 	if((tmp&COL_ERR_FLG)==0)		//������������ͨ��RX_DONE���
 		int_clr2 |= PKT_DONE_CLR;
 	if((tmp&PKT_ERR_FLG)==0)
 		int_clr2 |= PKT_DONE_CLR; 	
 	}
	
 vSpi3Write(((word)CUS_INT_CLR2<<8)+int_clr2);	//Clear flag
 
 
 tmp = bSpi3Read(CUS_INT_CLR1);
 
 if(IntPolarFlag)
 	{
  	if(tmp&TX_DONE_FLG)
 		{
 		int_clr1 |= TX_DONE_CLR;
 		flg |= TX_DONE_EN;
 		}	
 	if(tmp&SL_TMO_FLG)
 		{
 		int_clr1 |= SL_TMO_CLR;
 		flg |= SL_TMO_EN;
 		} 
 	if(tmp&RX_TMO_FLG)
 		{
 		int_clr1 |= RX_TMO_CLR;
 		flg |= RX_TMO_EN;
 		}
 	}
 else
 	{
 	if((tmp&TX_DONE_FLG)==0)
 		{
 		int_clr1 |= TX_DONE_CLR;
 		flg |= TX_DONE_EN;
 		}	
 	if((tmp&SL_TMO_FLG)==0)
 		{
 		int_clr1 |= SL_TMO_CLR;
 		flg |= SL_TMO_EN;
 		} 
 	if((tmp&RX_TMO_FLG)==0)
 		{
 		int_clr1 |= RX_TMO_CLR;
 		flg |= RX_TMO_EN;
 		} 	
 	}

 vSpi3Write(((word)CUS_INT_CLR1<<8)+int_clr1);	//Clear flag 
 
 return(flg);
}

/**********************************************************
**Name:     vEnableAntSwitch
**Function:  
**Input:    
**Output:   none
**********************************************************/
void vEnableAntSwitch(byte mode)
{
 byte tmp;
 tmp = bSpi3Read(CUS_INT1_CTL);
 tmp&= 0x3F;
 switch(mode)
 	{
 	case 1:
 		tmp |= RF_SWT1_EN; break;		//GPO1=RxActive; GPO2=TxActive	
 	case 2:
 		tmp |= RF_SWT2_EN; break;		//GPO1=RxActive; GPO2=!RxActive
 	case 0:
 	default:
 		break;							//Disable	
 	}
 vSpi3Write(((word)CUS_INT1_CTL<<8)+tmp);
}

/**************************************************************************************************
Fifo Packet Handle
**************************************************************************************************/
/**********************************************************
**Name:     vClearFIFO
**Function: clear FIFO buffer
**Input:    none
**Output:   none
**********************************************************/
void vClearFifo(void)
{
 vSpi3Write(((word)CUS_FIFO_CLR<<8)+FIFO_CLR_RX+FIFO_CLR_TX);
}

/**********************************************************
**Name:     bReadFifoFlag
**Function: read fifo state flag
**Input:    none
**Output:   FIFO state
**********************************************************/
byte bReadFifoFlag(void)
{
 return(bSpi3Read(CUS_FIFO_FLAG));
}

/**********************************************************
**Name:     bReadIntFlag
**Function: read interrupt flag
**Input:    none
**Output:   interrupt flag
**********************************************************/
word wReadIntFlag(void)
{
 word tmp;
 tmp = bSpi3Read(CUS_INT_CLR1);
 tmp<<=8;
 tmp|= bSpi3Read(CUS_INT_FLAG);
 return(tmp);	
}

/**********************************************************
**Name:     vEnableRdFifo
**Function: set Fifo for read
**Input:    none
**Output:   none
**********************************************************/
void vEnableRdFifo(void)
{
 byte tmp;
 tmp = bSpi3Read(CUS_FIFO_CTL);
 tmp &= (~(SPI_FIFO_RD_WR_SEL|FIFO_RX_TX_SEL));
 if(PayloadLength>31)
 	tmp |= FIFO_MERGE_EN;
 else
 	tmp &= (~FIFO_MERGE_EN);
 vSpi3Write(((word)CUS_FIFO_CTL<<8)+tmp);
}

/**********************************************************
**Name:     vEnableWrFifo
**Function: set Fifo for wirte
**Input:    none
**Output:   none
**********************************************************/
void vEnableWrFifo(void)
{
 byte tmp;
 tmp = bSpi3Read(CUS_FIFO_CTL);
 tmp |= (SPI_FIFO_RD_WR_SEL|FIFO_RX_TX_SEL);
 if(PayloadLength>31)
 	tmp |= FIFO_MERGE_EN;
 else
 	tmp &= (~FIFO_MERGE_EN);
 vSpi3Write(((word)CUS_FIFO_CTL<<8)+tmp);
}

/**********************************************************
**Name:     vSetPayloadLength
**Function: set Fifo length to used
**Input:    none
**Output:   none
**********************************************************/
void vSetPayloadLength(byte mode, byte length)
{
 byte tmp;	
 byte len;
 bGoStandby();
 
 tmp = bSpi3Read(CUS_PKT14);
 tmp&= 0x8F;				//length<256
 tmp&= (~0x01);				//Packet Mode
 if(length!=0)
 	{
 	if(mode)                //Tx
 		{
 		if(FixedPktLength)
			len = length-1;
 		else
			len = length;
 		}
 	else					//Rx
		len = length - 1;
 		
 	if(FixedPktLength)
		tmp |= PKT_TYPE_FIXED;
 	else
		tmp |= PKT_TYPE_VARIABLE;
	}
 else
 	return;

 vSpi3Write(((word)CUS_PKT14<<8)+tmp);
 vSpi3Write(((word)CUS_PKT15<<8)+(byte)len);	//Payload length
}

/**********************************************************
**Name:     vEnableAckPacket
**Function: Ack Packet
**Input:    [1] Enable; [0] Disable
**Output:   none
**********************************************************/
void vEnableAckPacket(byte en)
{
 byte tmp;		
 
 tmp = bSpi3Read(CUS_PKT14);
 if(en)
   	tmp|= AUTO_ACK_EN;
 else
 	tmp&= (~AUTO_ACK_EN);
 vSpi3Write(((word)CUS_PKT14<<8)+tmp);
}

/**********************************************************
**�������ƣ�bReadFifo
**�������ܣ����ճ����õĶ�ȡFifo
**���������none
**���������none
**Note��    should be call vEnableRdFifo() at GoRx
**********************************************************/
byte bReadFifo(void)
{
 return(bSpi3ReadFIFO());
}

/**********************************************************
**�������ƣ�vWriteFifo
**�������ܣ����ճ����õĶ�ȡFifo
**���������none
**���������none
**Note��    should be call  vEnableWrFifo() at first
**********************************************************/
void vWriteFifo(byte dat)
{
 vSpi3WriteFIFO(dat);
}	

/**************************************************************************************************
CFG
**************************************************************************************************/
/**********************************************************
**Name:     vInit
**Function: Init. CMT2300A
**Input:    none
**Output:   none
**********************************************************/
void vRadioInit(void)
{
 IntPolarFlag = 1;								//default is high_edge for interrupt

 vSoftReset();
 bGoStandby();
}


void vCfgBank(word cfg[], byte length)
{
 byte i;
 
 if(length!=0)
 	{	
 	for(i=0; i<length; i++)	
 		vSpi3Write(cfg[i]);
 	}	
}

void vAfterCfg(void)            //call after vCfgBank
{
 byte tmp;	

 tmp = bSpi3Read(CUS_MODE_STA);
 tmp|= CFG_RETAIN;
 tmp&= (~RSTN_IN_EN);			//Disable RstPin	
 vSpi3Write(((word)CUS_MODE_STA<<8)+tmp);

 tmp = 0x00;                    //Disable All Calibration, when no need to use DutyCycleMode
 vSpi3Write(((word)CUS_SYS2<<8)+tmp);

 tmp  = bSpi3Read(0x09);		//xosc_acc_code = 2;	
 tmp &= 0xF8;
 tmp |= 0x02;
 vSpi3Write(0x0900+tmp);
 
 tmp  = bSpi3Read(CUS_EN_CTL);
 tmp |= UNLOCK_STOP_EN;			//enable pll unlock stop to shift status
 vSpi3Write(((word)CUS_EN_CTL<<8)+tmp);

 tmp  = bSpi3Read(CUS_SYS10);
 tmp &= (~RX_AUTO_EXIT_DIS);	//PktOk active, then auto go to stby
 vSpi3Write(((word)CUS_SYS10<<8)+tmp);

 bIntSrcFlagClr();
}

void vReadCfgBank(byte sta_adr,  byte rd_cfg[], byte length)
{
 byte i, j;
 
 if(length!=0)
 	{	
 	for(i=sta_adr, j=0; i<(sta_adr+length); i++, j++)	
 		rd_cfg[j] = bSpi3Read(i);
 	}	
}

void vSetIntPolar(byte polar)
{
 byte tmp;
 IntPolarFlag = polar;
 tmp = bSpi3Read(CUS_INT1_CTL);
 if(polar)
 	tmp &= (INT_POLAR^0xFF);
 else
 	tmp |= INT_POLAR; 	
 vSpi3Write(((word)CUS_INT1_CTL<<8)+tmp);
}

/**************************************************************************************************
appliciation
**************************************************************************************************/
/**********************************************************
**�������ƣ�bGetMessage
**�������ܣ�����һ������
**�����������
**�����������0�������ճɹ�
**            0��������ʧ��
**��ע:     ��Ҫ��GPO���жϴ���ʹ�ã�������MCU�жϳ���
**********************************************************/
byte bGetMessage(byte msg[])
{
 byte i;	
 
 if(FixedPktLength)
 	{
 	vSpi3BurstReadFIFO(msg, PayloadLength);
	i = PayloadLength;
	}
 else
 	{
	i = bSpi3ReadFIFO();	
 	vSpi3BurstReadFIFO(msg, i);
 	}
 return(i);
}

/**********************************************************
**�������ƣ�vSendMessage
**�������ܣ�����һ������
**���������none
**���������none
**��ע    ����Ҫ��GPO���жϴ���ʹ�ã�������MCU�жϳ���          
**********************************************************/
void vSendMessage(byte msg[], byte length)
{
 //mode1       
 bIntSrcFlagClr();
 vSetPayloadLength(1, length);
 bGoStandby();
 vClearFifo(); 
 vEnableWrFifo();	
 vSpi3BurstWriteFIFO(msg, length);
 bGoTx();
 
 //mode2
 //bIntSrcFlagClr();
 //vSetPayloadLength(true, length);
 //vClearFifo();
 //vEnableWrFifo();	
 //bGoTx();
 //vSpi3BurstWriteFIFO(msg, length);
}

/**********************************************************
**�������ƣ�vSetChannelOffset
**�������ܣ�������Ƶ���
**���������interval  unit:KHz
**���������none
**��ע    ��
**********************************************************/
void vSetChannelOffset(word interval)
{
 byte offset;
 offset = (interval<<1)/5;			//unit:2.5KHz
 vSpi3Write(((word)CUS_FREQ_OFS<<8)+offset);
}

/**********************************************************
**�������ƣ�vSetChannel
**�������ܣ�����Ƶ��
**���������channel
**���������none
**��ע    ��
**********************************************************/
void vSetChannel(word channel)
{
 vSpi3Write(((word)CUS_FREQ_CHNL<<8)+channel);
}

/**********************************************************
**�������ƣ�vSetTxPreamble
**�������ܣ����÷����Preamble����
**���������length
**���������none
**��ע    ��
**********************************************************/
void vSetTxPreamble(word length)
{
 vSpi3Write(((word)CUS_PKT3<<8)+(byte)(length>>8));
 vSpi3Write(((word)CUS_PKT2<<8)+(byte)length);
}






