#include "rfm380.h"

//��ʱ��0�жϷ�����, 10ms
void Time0_Irq(void)
{
    Bt_ClearIntFlag(TIM0);
    SysTimer++;
    ResetTimer++;
    LftxTimer++;
	
    mS_Count++;
    if(mS_Count>=100)
    	{
    	mS_Count = 0;
    	Sec_Count++;
    	if(Sec_Count>=60)
    		{
    		Sec_Count = 0;
    		Min_Count++;
    		if(Min_Count>=60)
				{
				Min_Count = 0;
				Hour_Count++;
				if(Hour_Count>=24)
					Hour_Count = 0;
				}
    		}
    	}
}

