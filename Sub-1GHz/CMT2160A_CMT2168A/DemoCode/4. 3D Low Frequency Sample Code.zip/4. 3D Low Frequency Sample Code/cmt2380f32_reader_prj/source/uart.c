#include "rfm380.h"


//uint8_t  u8TxData[UART_TXD_LENGTH] = {0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55};

uint32_t  u32RxData[UART_RXD_LENGTH];
uint8_t   u8TxData[UART_TXD_LENGTH];
uint8_t   u8TxCnt;
uint8_t   u8RxCnt;
uint8_t	  u8TxLength;

void TxIntCallback(void)
{

 if(u8TxCnt<u8TxLength)
    {
    M0P_UART1->SBUF = u8TxData[u8TxCnt];
    u8TxCnt++;
    }
 else 
    {
    u8TxCnt = 0;
    Uart_ClrStatus(UARTCH1,UartTxEmpty);   
    Uart_DisableIrq(UARTCH1,UartTxIrq);
    Uart_EnableIrq(UARTCH1,UartRxIrq);
    }
    
}

void RxIntCallback(void)
{
 u32RxData[u8RxCnt]=Uart_ReceiveData(UARTCH1);
 u8RxCnt++;
 if(u8RxCnt>=UART_RXD_LENGTH)
    {
    Uart_DisableIrq(UARTCH1,UartRxIrq);
    }

}
void ErrIntCallback(void)
{
  
}

void vUart1Init(void)
{
 uint16_t timer;
 uint32_t pclk;
 stc_clk_config_t       stcCfg;
 stc_uart_config_t      stcConfig;
 stc_uart_irq_cb_t      stcUartIrqCb;
 stc_uart_multimode_t   stcMulti;
 stc_uart_baud_config_t stcBaud;
 stc_bt_config_t        stcBtConfig;
 en_uart_mmdorck_t      enTb8;
 
 
 DDL_ZERO_STRUCT(stcConfig);
 DDL_ZERO_STRUCT(stcUartIrqCb);
 DDL_ZERO_STRUCT(stcMulti);
 DDL_ZERO_STRUCT(stcBaud);
 DDL_ZERO_STRUCT(stcBtConfig);
 
 
 //ʱ�Ӳ�������
 stcCfg.enClkSrc  = ClkRCH;  						//ClkXTH;
 stcCfg.enHClkDiv = ClkDiv1;
 stcCfg.enPClkDiv = ClkDiv1;
 Clk_Init(&stcCfg);
 
 //ͨ���˿�����
 Gpio_SetFunc_UART1TX_P35();						//P3.5 -> UART1 TxD
 Gpio_SetFunc_UART1RX_P36();						//P3.6 -> UART1 RxD
 
 //����ʱ��ʹ��
 Clk_SetPeripheralGate(ClkPeripheralBt,TRUE);        //ģʽ0/2���Բ�ʹ��
 Clk_SetPeripheralGate(ClkPeripheralUart1,TRUE);
 
 stcUartIrqCb.pfnRxIrqCb    = RxIntCallback;
 stcUartIrqCb.pfnTxIrqCb    = TxIntCallback;
 stcUartIrqCb.pfnRxErrIrqCb = ErrIntCallback;
 stcConfig.pstcIrqCb        = &stcUartIrqCb;
 stcConfig.bTouchNvic       = TRUE;
 
 
 stcConfig.enRunMode        = UartMode1;			//��������Ĵ˴���ת��4��ģʽ����
 stcMulti.enMulti_mode      = UartNormal;			//��������Ĵ˴���ת��������ģʽ��mode2/3���ж�����ģʽ
 enTb8 = DataOrEven;
 Uart_SetMMDOrCk(UARTCH1,enTb8);
 stcConfig.pstcMultiMode = &stcMulti;
 
 
 stcBaud.bDbaud  = 1u;								//˫�������ʹ���
 stcBaud.u32Baud = 115200u;							//���²�����λ��
 stcBaud.u8Mode  = UartMode1; 						//���㲨������Ҫģʽ����
 pclk = Clk_GetPClkFreq();
 timer=Uart_SetBaudRate(UARTCH1,pclk,&stcBaud);
 
 stcBtConfig.enMD = BtMode2;
 stcBtConfig.enCT = BtTimer;
 Bt_Init(TIM1, &stcBtConfig);						//����basetimer1���ú�������������
 Bt_ARRSet(TIM1,timer);
 Bt_Cnt16Set(TIM1,timer);
 Bt_Run(TIM1);
 
 Uart_Init(UARTCH1, &stcConfig);
 Uart_EnableIrq(UARTCH1,UartRxIrq);
 Uart_ClrStatus(UARTCH1,UartRxFull);
 Uart_EnableFunc(UARTCH1,UartRx);
}    

