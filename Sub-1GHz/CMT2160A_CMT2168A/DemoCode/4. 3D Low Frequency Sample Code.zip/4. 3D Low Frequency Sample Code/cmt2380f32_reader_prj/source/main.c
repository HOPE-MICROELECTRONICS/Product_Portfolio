//*************************************************************************************************
//* @prj  :   CMT2380F32 LF Reader
//* @desc :   
//* 
//* @version  1.0
//* @date     Jun 29 2020
//* @author   QY.Ruan	
//*
//* Copyright (C) HOPERF MICROELECTRONICS CO., LTD.
//*
//* Resuorce:
//*     1. RCH select 24MHz;
//*     2. BaseTimer0 was used for system timer�� per unit 10ms;
//*     3. BaseTimer1 was used for UART1, 8N1 format,  115200;
//*     4. BaseTimer2 was used for LF Bit Rate control, as 4ksps or 8ksps
//*     5. AdvTimer5  was used for 125kHz pwm;
//*
//*************************************************************************************************
#include "rfm380.h"

int32_t main(void)
{
 byte tmp;
 byte i;
 byte tx_cnt;
 byte rx_cnt;
 //word n;
	
 vMcuInit();
 for(SysTimer=0; SysTimer<5; );
	
 /*
 //Test code for BaseTimer0
 while(1)
 	{
 	if(SysTimer&0x0008)
 		Set_LED();
 	else
 		Clr_LED();	
 	}
*/
 
 /*
 //Test code for Buzzer
 while(1)
	{
  SysTimer = 0;
	while(SysTimer<200);	
	Set_BUZZ();
  SysTimer = 0;
	while(SysTimer<10);	
	Clr_BUZZ();	
	}
 */
 
 /* 
 //Test code for KEY
 while(1)
	{
	if(KEY_L())
		Clr_LED();
	else
		Set_LED();
	}
 */
	
 /*
 //Test code for _delay_us()
 while(1)
 	{
 	Set_LED();		//2.56us
 	_delay_us(1);	//4==1,9us 3==1.58  1==0.96
 	Clr_LED();		//2.56us
 	_delay_us(1);
 	}
 */
 
 /*
 //Test code for uart
 for(i=0; i<UART_TXD_LENGTH; i++)
 	u8TxData[i] = '0' + i;
 vUart1Init();
 while(1)
 	{
 	for(SysTimer=0; SysTimer<100; );
	u8TxLength = UART_TXD_LENGTH;
 	Uart_EnableIrq(UARTCH1,UartTxIrq);
 	M0P_UART1->SBUF = u8TxData[0];
    u8TxCnt = 1;
 	}
*/
 
 /*
 //Test code for PWM
 vBaseTime2Init();
 pwm_init();
 while(1)
 	{
 	Adt_StartCount(enAdt);	
 	//Set_LED();
 	vTime2Unit();
 	Adt_StopCount(enAdt);
	//Clr_LED();
	vTime2Unit();
 	}
 */
 
 /*
 //test code for LF transmit packet
 vBaseTime2Init();
 pwm_init();
 while(1)
 	{
 	for(SysTimer=0; SysTimer<100; );
 	Clr_LED();
 	lftx_process(0x00);
 	Set_LED();
 	}
 */
 

 SysTimer = 0;

 vBaseTime2Init();
 pwm_init();

 vUart1Init();
 vInitRadio();
 vIntSrcCfg(INT_PKT_DONE, INT_RX_FIFO_WBYTE);
 PayloadLength = RX_LEN;		

 
 mS_Count  = 0;
 Sec_Count = 0;
 Min_Count = 0;
 Hour_Count= 0;
 
 u8TxCnt   = 0;
 u8RxCnt   = 0;
 
 rx_cnt = 0;
 tx_cnt = 0;

 while(1)
 	{
 	if(LftxTimer&0x0080)
		{
		if(tx_cnt==0)
			{
			vUartPrintStart();
			rx_cnt = 0;
			}
				
		vIntSrcCfg(INT_PKT_DONE, INT_RX_FIFO_WBYTE);
		PayloadLength = RX_LEN;
		bGoRx();
		
		lftx_process(tx_cnt++);
	
		for(SysTimer=0; SysTimer<30; )
			{
			if(GPIO2_H())
				{
				ResetTimer = 0;	
				bGoStandby();
				
				bGetMessage(RX_Buffer);
				tmp = bIntSrcFlagClr();
				vClearFifo(); 
				
				tmp &= 0x03;
				switch(tmp)
					{
					case 0x03:													//CRC OK & PKT DONE
						Clr_LED();	
						for(i=0; i<5; i++)
							{
							if(RX_Buffer[i]!=Cmp_Buf[i])
								break;
							}
						if(i>=5)
							{	
							rx_cnt++;
							Set_BUZZ();				
							vUartNewLine();
							while(u8TxCnt!=0);									//��Ҫ�ȴ�UART�������
							for(i=0; i<RX_LEN; i++)
								u8TxData[i] = RX_Buffer[i];
							u8TxLength = RX_LEN;	
							Uart_EnableIrq(UARTCH1,UartTxIrq);					//ʹ��uart�ж�	
							M0P_UART1->SBUF = u8TxData[0];						//��䷢��
							u8TxCnt = 1;					
							for(SysTimer=0; SysTimer<5; );		
							Clr_BUZZ();	
							}
						for(SysTimer=0; SysTimer<1; );		
						Set_LED();
					break;
					case 0x01:													//CRC NG & PKT DONE
					default:
						break;
					}
	
				}
			}
	
		if(tx_cnt>=100)	
			{
			vUartNewLine();
			vUartPrintCounter(rx_cnt);
			tx_cnt = 0;
			vInitRadio();
			vIntSrcCfg(INT_PKT_DONE, INT_RX_FIFO_WBYTE);
			}
		bGoStandby();				
		LftxTimer &= 0x007F;
		}
 	}
}

/****************Radio MAC******************/						


/****************Radio PHY******************/
void vInitRadio(void)
{
 FixedPktLength    = 1;				
 PayloadLength     = RX_LEN;	
 vRadioInit();
 
 #ifdef	USE_433MHz
	 vCfgBank((word* )CMTBank433, 12);
 	vCfgBank((word *)SystemBank433, 12);
 	vCfgBank((word *)FrequencyBank433, 8);
 	vCfgBank((word *)DataRateBank433, 24);
 	vCfgBank((word *)BasebandBank433, 29);
 	vCfgBank((word *)TXBank433, 11);
 #endif
 
 #ifdef	USE_915MHz 	
  	vCfgBank((word* )CMTBank915, 12);
	 vCfgBank((word *)SystemBank915, 12);
 	vCfgBank((word *)FrequencyBank915, 8);
 	vCfgBank((word *)DataRateBank915, 24);
 	vCfgBank((word *)BasebandBank915, 29);
 	vCfgBank((word *)TXBank915, 11);
	#endif
 
 vAfterCfg();
 vEnableAntSwitch(0);
 
 vGpioFuncCfg(GPIO1_DCLK+GPIO2_INT1+GPIO3_DATA+GPIO4_DOUT);  
 //vGpioFuncCfg(GPIO1_INT1+GPIO2_INT1+GPIO3_DATA+GPIO4_DOUT);  
 vIntSrcEnable(PKT_DONE_EN+CRC_OK_EN+PREAM_OK_EN+SYNC_OK_EN+TX_DONE_EN); 
 bIntSrcFlagClr();
 vClearFifo();
 bGoSleep();
}

byte vGetRssi(void)									//Rssi
{
 word noise_rssi = 0;
 byte tmp;
 
 for(tmp=0; tmp<8; tmp++)
 	{
 	_delay_us(1000);
 	noise_rssi += bReadRssi(2);
		}
 noise_rssi >>= 3;
 return((byte)noise_rssi);
}

void vUartPrintStart(void)
{
 byte const start_tbl[29] = {'*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'S', 'T', 'A', 'R', 'T', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*'};
 byte i;

 for(i=0; i<29; i++)
	u8TxData[i] = start_tbl[i];
 u8TxLength = 29;	 
 Uart_EnableIrq(UARTCH1,UartTxIrq);
 M0P_UART1->SBUF = u8TxData[0];
 u8TxCnt = 1;
 while(u8TxCnt!=0);	 
 vUartNewLine();
 vUartNewLine();	 
}	

void vUartPrintCounter(byte cnt)
{
 byte const total_tbl[29] = {'*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'T', 'O', 'T', 'A', 'L', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*'};
 byte const line_tbl[29] = {'*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*'};
 byte i;

 for(i=0; i<29; i++)
	u8TxData[i] = total_tbl[i];
 u8TxLength = 29;	 
 Uart_EnableIrq(UARTCH1,UartTxIrq);
 M0P_UART1->SBUF = u8TxData[0];
 u8TxCnt = 1;
 while(u8TxCnt!=0);	 
 vUartNewLine();	 

	 
 u8TxData[0] = '0'+(cnt/100);
 u8TxData[1] = '0'+(cnt%100/10);
 u8TxData[2] = '0'+(cnt%10);
 u8TxLength = 3;	 
 Uart_EnableIrq(UARTCH1,UartTxIrq);
 M0P_UART1->SBUF = u8TxData[0]; 
 u8TxCnt = 1;
 while(u8TxCnt!=0);	
 vUartNewLine();

 for(i=0; i<29; i++)
	u8TxData[i] = line_tbl[i];
 u8TxLength = 29;	 
 Uart_EnableIrq(UARTCH1,UartTxIrq);
 M0P_UART1->SBUF = u8TxData[0];
 u8TxCnt = 1;
 while(u8TxCnt!=0);	 
 vUartNewLine();	 
 vUartNewLine();
 vUartNewLine();
}

void vUartNewLine(void)
{
 u8TxData[0] = 0x0D;
 u8TxData[1] = 0x0A; 	
 u8TxLength = 2;	 
 Uart_EnableIrq(UARTCH1,UartTxIrq);
 M0P_UART1->SBUF = u8TxData[0];
 u8TxCnt = 1;
 while(u8TxCnt!=0);	
}	
