#include "rfm380.h"

/******************************
**Name: vMcuInit
**Func: Initial uC Control
*Input: None
Output: None
********************************/
void vMcuInit(void)
{
    vMcuConfig();               //24M
    vIOInit();                  //IO
    vBaseTime0Init();           //T0    
}



/************************************
**Name: vBaseTime0Init  		10MS
**Func����ʼ��������ʱ��0
*Input����
Output����
************************************/
void vBaseTime0Init(void)
{
    stc_bt_config_t BaseTime0Buf;
    Clk_SetPeripheralGate(ClkPeripheralBt,TRUE);		//����ʱ��
	
    BaseTime0Buf.enGateP = BtPositive;		
    BaseTime0Buf.enGate  = BtGateDisable;				//��ֹ�ſ�
    BaseTime0Buf.enPRS   = BtPCLKDiv16;					//16��Ƶ
    BaseTime0Buf.enTog   = BtTogDisable;	  			//
    BaseTime0Buf.enCT    = BtTimer;						//��ʱ������
    BaseTime0Buf.enMD    = BtMode2;						//16λ�Զ����ض�ʱ
    BaseTime0Buf.pfnTim0Cb=Time0_Irq;		
    
    Bt_Init(TIM0,&BaseTime0Buf);
    Bt_Cnt16Set(TIM0,(65536-14936));					//��ֵ
    Bt_ARRSet(TIM0,(65536-14936));						//����ֵ
    Bt_ClearIntFlag(TIM0);								//���־
    Bt_EnableIrq(TIM0);									//�����ж�
    EnableNvic(TIM0_IRQn,3,TRUE);
    Bt_Run(TIM0);										//����
}

/******************************
**Name: vIOInit
**Func: ��ʼ��MCU IO
*Input: None
Output: None
********************************/
void vIOInit(void)
{
    Clk_SetPeripheralGate(ClkPeripheralGpio,TRUE);		//����ʱ��	
    M0P_GPIO->P0DIR = P0DIR_Data;
    M0P_GPIO->P1DIR = P1DIR_Data;
    M0P_GPIO->P2DIR = P2DIR_Data;
    M0P_GPIO->P3DIR = P3DIR_Data;
    
    M0P_GPIO->P0OUT = P0OUT_Data;
    M0P_GPIO->P1OUT = P1OUT_Data;
    M0P_GPIO->P2OUT = P2OUT_Data;
    M0P_GPIO->P3OUT = P3OUT_Data;
    
    M0P_GPIO->P0PU  = P0PU_Data;
    M0P_GPIO->P1PU  = P1PU_Data;
    M0P_GPIO->P2PU  = P2PU_Data;
    M0P_GPIO->P3PU  = P3PU_Data;
}	

/******************************
**Name: vMcuConfig
**Func: ��ʼ������MCU 16M
*Input: None
Output: None
********************************/
void vMcuConfig(void)
{
    Clk_SetRCHFreq(ClkFreq24Mhz);		//24M
    Clk_SetHClkDiv(ClkDiv1);			//CPUʱ��
    Clk_SetPClkDiv(ClkDiv1);			//����ʱ��
}


