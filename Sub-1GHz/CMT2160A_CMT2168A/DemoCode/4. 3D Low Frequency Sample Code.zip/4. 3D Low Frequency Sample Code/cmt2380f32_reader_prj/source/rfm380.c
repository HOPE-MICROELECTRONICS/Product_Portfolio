#include "rfm380.h"

word 	SysTimer;
word    ResetTimer;
byte 	LftxTimer;

byte 	mS_Count;
byte  	Sec_Count;
byte    Min_Count;
byte 	Hour_Count;

byte 	TX_Payload[TX_LEN];
byte 	RX_Buffer[RX_LEN];

byte 	RssiTrig;
byte 	PktRevError;
byte	IntPolarFlag;

byte 	PayloadLength;
byte 	FixedPktLength;

byte const 	Cmp_Buf[5] = {'2', '1', '6', 'x', 'A'};
