#include "rfm380.h"


#define SPI3_SPEED 		1
#define INTVL_4US		10

void _delay_us(word cnt)
{
 for( ; cnt!=0; cnt--)
 	{
 	__nop();
	}
}

/**********************************************************
**Name:	vSpi3WriteByte
**Func: Spi3 send one byte
*INput: None
Output: None
**********************************************************/
void vSpi3WriteByte(byte dat, byte sda_in)
{
    byte i;
    
    Set_FCSB();
    
    SDIO_Output();
    Set_SDIO();
    
    Clr_SCLK();
    Clr_CSB();
    
    _delay_us(SPI3_SPEED);

    for(i=8; i!=0; i--)			
    	{			
        Clr_SCLK();
        if(dat&0x80)
            Set_SDIO();	
        else
            Clr_SDIO();
        _delay_us(SPI3_SPEED);
        Set_SCLK();
        dat <<= 1;
        _delay_us(SPI3_SPEED);
  	 	}
    
    if(sda_in)
    	{
    	SDIO_Input();
    	Clr_SCLK();
    	}
    else
    	{
    	Clr_SCLK();
    	Set_SDIO();	
    	}
}

/**********************************************************
**Name: bSpi3ReadByte
**Func: SPI3 Read
*Input: None
Output: Data
**********************************************************/
byte bSpi3ReadByte(void)
{
    byte RdPara = 0;
    byte i;						
    
    Clr_SCLK();
    SDIO_Input();
    Clr_CSB();
    
    _delay_us(SPI3_SPEED);
    
    for(i=8; i!=0; i--)		
    	{
        Set_SCLK();
        RdPara <<= 1;
        _delay_us(SPI3_SPEED);
		if(SDIO_H()) 
			RdPara |= 0x01;
		else
			RdPara |= 0x00;      
        Clr_SCLK();
        _delay_us(SPI3_SPEED);
    	}	
	Clr_SCLK();
	return(RdPara);    
}


/**********************************************************
**Name: vSpi3Write
**Func: SPI3 Wirte one word
*input: Write word
Output: None
**********************************************************/
void vSpi3Write(word dat)
{
    vSpi3WriteByte(((byte)(dat>>8)&0x7F), 0);
    vSpi3WriteByte(((byte)dat), 0);
    Set_CSB();
}

void vSpi3WriteCmd(byte dat)
{
 	vSpi3WriteByte((dat&0x7F), 0);
 	Set_CSB();
}

/**********************************************************
**Name: vSpi3Read
**Func: SPI3 Read one byte 
*Input: readout address
Output: readout byte 
**********************************************************/
byte bSpi3Read(byte addr)
{	
	byte dat;
	vSpi3WriteByte((addr|0x80), 1);
	dat = bSpi3ReadByte();
	SDIO_Output();
	Set_SDIO();
	_delay_us(SPI3_SPEED);
	Set_CSB();
    return(dat);
}

/***************************************************************
**Name: vSpi3WriteFIFO
**Func: Spi3 send one byte to FIFO
*Input: one byte buffer
Output: none               
****************************************************************/
void vSpi3WriteFIFO(byte dat)
{
    byte bitcnt;
   	
   	Set_CSB();
   	SDIO_Output();
   	Clr_SCLK();
   	Clr_FCSB();
   	
   	_delay_us(SPI3_SPEED);
   	
    for(bitcnt=8; bitcnt!=0; bitcnt--)  
   	 	{
   	 	Clr_SCLK();
        
        if(dat&0x80)
            Set_SDIO();
        else
            Clr_SDIO();
        
        _delay_us(SPI3_SPEED);
        
        Set_SCLK();
        
        _delay_us(SPI3_SPEED);
        
        dat <<= 1;
    	}
 	
 	Clr_SCLK();
 	_delay_us(INTVL_4US);			//Time Critical
 	Set_FCSB();
 	Set_SDIO();
    _delay_us(INTVL_4US);			//Time Critical
}

/***************************************************************
**Name: bSpi3ReadFIFO
**Func: Spi3 read one byte to FIFO
*Input: None
Output: one byte buffer                 
****************************************************************/
byte bSpi3ReadFIFO(void)
{
    byte bitcnt;
    byte RdPara = 0;
    
      
    Set_CSB();
    SDIO_Input();
    Clr_SCLK();
    Clr_FCSB();
    _delay_us(INTVL_4US);			//Time Critical   
    
    for(bitcnt=8; bitcnt!=0; bitcnt--)  
    	{
        Set_SCLK();
        _delay_us(SPI3_SPEED);
        RdPara <<= 1;
        if(SDIO_H())
            RdPara |= 0x01;
        else
            RdPara |= 0x00;
		Clr_SCLK();
		_delay_us(SPI3_SPEED);
    	}
    
    Clr_SCLK();
    _delay_us(INTVL_4US);			//Time Critical
    
	Set_FCSB();
    SDIO_Output();
    Set_SDIO();
    _delay_us(INTVL_4US);			//Time Critical
    
    return(RdPara);
}

/**********************************************************
**Name:	 	vSpi3BurstWriteFIFO
**Func: 	burst wirte N byte to FIFO
**Input: 	array length & head pointer
**Output:	none
**********************************************************/
void vSpi3BurstWriteFIFO(byte ptr[], byte length)
{
 	byte i;
 	if(length!=0x00)
	 	{
 		for(i=0;i<length;i++)
 			vSpi3WriteFIFO(ptr[i]);
 		}
 	return;
}

/**********************************************************
**Name:	 	vSpiBurstRead
**Func: 	burst wirte N byte to FIFO
**Input: 	array length  & head pointer
**Output:	none
**********************************************************/
void vSpi3BurstReadFIFO(byte ptr[], byte length)
{
	byte i;
 	if(length!=0)
 		{
 		for(i=0;i<length;i++)
 			ptr[i] = bSpi3ReadFIFO();
 		}	
 	return;
}

