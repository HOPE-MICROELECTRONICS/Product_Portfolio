
#ifndef	_RFM380_

	#define _RFM380_

	#include "ddl.h"
	#include "uart.h"
	#include "adt.h"
	#include "rfm380_Register.h"

typedef unsigned char byte;
typedef unsigned int  word;
typedef unsigned long lword;

#define   _RFM380_


//********************************************* UHF Config ************************************************************
//select UHF radio frequency
	//#define		USE_915MHz	
	#define			USE_433MHz


//**************************************** LF Tx Format Config ********************************************************
//select LF bit rate
	#define			LF_TX_UNIT_VAL		5600			//250us for 4kbps
	//#define		LF_TX_UNIT_VAL		2675			//125us for 8kbps

//@ select packet format 
	#define			ENABLE_CW_TX						//enable, send carrier wave
	#define			CW_LENGTH			32				//unit: symbol
	
	#define			PREAMBLE_LENGTH		4				//for 4ksps
	
	#define			SYNC_LENGTH			4				//unit: byte
	#define			SYNC_VALUE			0x999aa5a6
	
	#define			ENABLE_WAKEUP_ID					//enable wakeup_id part
	#define			ENABLE_WAKEUP_ID_MAN			    //enable wakeup_id manchester encode; when disable, used NRZ encode
	#define			WAKEUP_ID_LENGTH	2				//length of wakeup_id, unit: byte
	#define			WAKEUP_ID_VALUE		0xdcba						
	
	#define			PAYLOAD_MAN	
	#define			PAYLOAD_LENGTH		3

	//#define		MAN_CODE_PHASE						//enable 2b10='0', 2b01='1';   disable 2b10='1', 2b01='0'

typedef union 					
{
 struct 
 	{
 	byte  _FlagBit0: 1;			
 	byte  _FlagBit1: 1;	 		
 	byte  _FlagBit2: 1;			
 	byte  _FlagBit3: 1;			
 	byte  _FlagBit4: 1;			
 	byte  _FlagBit5: 1;			
 	byte  _FlagBit6: 1;			
 	byte  _FlagBit7: 1;			
 	}BBITS;
 byte BBYTE;
}FlagSTR;

#define	 	TX_LEN				8
#define		RX_LEN				8		

#define	  	UART_TXD_LENGTH		32
#define	 	UART_RXD_LENGTH		32



//RF
#define CMT_Bank_Origin     0x00     //CMT
#define CMT_Bank_End        0x0B     //CMT

#define System_Origin       0x0C    //System
#define System_End          0x17    //System

#define Frequency_Origin    0x18    //Frequency
#define Frequency_End       0x1F    //Frequency

#define Data_Rete_Origin    0x20    //Data_Rete
#define Data_Rete_End       0x37    //Data_Rete

#define Baseband_Origin     0x38    //Baseband
#define Baseband_End        0x54    //Baseband

#define TX_Origin           0x55    //TX
#define TX_End              0x5F    //TX

#define PackNum_N           0x56
#define SyncNum_N           0x23

/******************************************************************************
Pxx_SEL:����GPIO�Ĺ���(��Ϊ��ͨGPIO�����������ù���)
PxDIR:  ����������üĴ���                        	1=����      0=���
PxIN:   ����ֵ�Ĵ���(��ȡ�˿ڵ�ƽ״̬)
PxOUT:  �����ƽ״̬���üĴ���
PxADS:  ��ģ���üĴ���		                       	1=ģ��	    0=����(Ĭ��)
PxDR:   �����������üĴ���		 	               	1=������	0=������(Ĭ��)
PxPU:	����ʹ�����üĴ���							1=ʹ��		0=��ֹ(Ĭ��)
PxPD:	����ʹ�����üĴ���							1=ʹ��		0=��ֹ(Ĭ��)
PxOD:	��©������üĴ���							1=ʹ��		0=��ֹ(Ĭ��)
******************************************************************************/

//P0                               PxDIR   PxOUT    PxADS     PxDR    PxPU    PxPD   PxOD		
  #define	KEY		0x01	//		 1       0        0        0       1       0      0
  #define   BUZZ    0x02	//       0       0        0        0       0       0      0
  #define   LED     0x04    //       0       1        0        0       0       0      0
  #define   CSB     0x08	//       0       1        0        0       0       0      0
                                                                                      
//P1                                                                                  
  #define   X32IN   0x10	//       0       0        0        0       0       0      0
  #define   X32OUT  0x20	//       0       0        0        0       0       0      0
                                                                                      
//P2                                                                                  
//                  0x01    //       0       0        0        0       0       0      0   
//                  0x02    //       0       0        0        0       0       0      0
//                  0x04    //       0       0        0        0       0       0      0
  #define   SDIO    0x08    //       0       0        0        0       0       0      0
  #define   SCLK    0x10    //       0       0        0        0       0       0      0
  #define   LFTX    0x20    //       0       0        0        0       0       0      0
  #define   GPIO1   0x40    //       1       0        0        0       0       0      0
//#define  (SWDIO)  0x80    //       0       0        0        0       0       0      0
                                                                                      
//P3               
//                  0x01    //       0       0        0        0       0       0      0  
//#define  (SWDCLK) 0x02	//       0       0        0        0       0       0      0                                                                  
  #define   FCSB    0x04    //       0       1        0        0       0       0      0
  #define   GPIO3   0x08    //       1       0        0        0       0       0      0
  #define   GPIO2   0x10    //       1       0        0        0       0       0      0
  #define	TxD     0x20    //       0       1        0        0       0       0      0
  #define   RxD   	0x40    //       1       0        0        0       0       0      0
//                  0x80    //       0       0        0        0       0       0      0

#define	P0DIR_Data    	0x00000001
#define	P1DIR_Data    	0x00000000
#define	P2DIR_Data    	0x00000040
#define	P3DIR_Data    	0x00000058
                      	
#define	P0OUT_Data    	0x0000000C
#define	P1OUT_Data    	0x00000000
#define	P2OUT_Data    	0x00000000
#define	P3OUT_Data    	0x00000044
                      	
#define	P0PU_Data     	0x00000001
#define	P1PU_Data     	0x00000000
#define	P2PU_Data     	0x00000000
#define	P3PU_Data     	0x00000000


#define	Set_FCSB()    	Gpio_SetIO(3,2,1)
#define	Clr_FCSB()    	Gpio_SetIO(3,2,0)
                    	
#define	Set_CSB()	    Gpio_SetIO(0,3,1)
#define	Clr_CSB()	    Gpio_SetIO(0,3,0)
                    	
#define	Set_SCLK()    	Gpio_SetIO(2,4,1)
#define	Clr_SCLK()    	Gpio_SetIO(2,4,0)
                    	
#define	Set_SDIO()    	Gpio_SetIO(2,3,1)
#define	Clr_SDIO()    	Gpio_SetIO(2,3,0)

#define Set_LED()		Gpio_SetIO(0,2,1)
#define	Clr_LED()		Gpio_SetIO(0,2,0)

#define	Set_BUZZ()		Gpio_SetIO(0,1,1)
#define Clr_BUZZ()		Gpio_SetIO(0,1,0)


#define SDIO_Output()   (M0P_GPIO->P2DIR&=(~SDIO))
#define	SDIO_Input()  	(M0P_GPIO->P2DIR|=SDIO)


#define	KEY_H()			(M0P_GPIO->P0IN&KEY)
#define SDIO_H()    	(M0P_GPIO->P2IN&SDIO)
#define GPIO1_H()   	(M0P_GPIO->P2IN&GPIO1)
#define GPIO2_H()   	(M0P_GPIO->P3IN&GPIO2)
#define GPIO3_H()		(M0P_GPIO->P3IN&GPIO3)

#define	KEY_L()			((M0P_GPIO->P0IN&KEY)==0)
#define SDIO_L()		((M0P_GPIO->P2IN&SDIO)==0)
#define GPIO1_L()		((M0P_GPIO->P2IN&GPIO1)==0)
#define GPIO2_L()		((M0P_GPIO->P3IN&GPIO2)==0)
#define GPIO3_L()		((M0P_GPIO->P3IN&GPIO3)==0)



extern byte const ID_Tbl[4];

/******************************************************************************/
//����
/******************************************************************************/
extern word SysTimer;
extern word ResetTimer;
extern byte	LftxTimer;

extern byte mS_Count;
extern byte Sec_Count;
extern byte Min_Count;
extern byte Hour_Count;

extern byte TX_Payload[TX_LEN];
extern byte RX_Buffer[RX_LEN];

extern byte RssiTrig;
extern byte PktRevError;
extern byte IntPolarFlag;

extern byte PayloadLength;
extern byte FixedPktLength;


extern const unsigned int CMTBank433[12];
extern const unsigned int SystemBank433[12];
extern const unsigned int FrequencyBank433[8];
extern const unsigned int DataRateBank433[24];
extern const unsigned int BasebandBank433[29];
extern const unsigned int TXBank433[11];

extern const unsigned int CMTBank915[12];
extern const unsigned int SystemBank915[12];
extern const unsigned int FrequencyBank915[8];
extern const unsigned int DataRateBank915[24];
extern const unsigned int BasebandBank915[29];
extern const unsigned int TXBank915[11];

extern uint8_t  u8TxData[UART_TXD_LENGTH];
extern uint32_t u32RxData[UART_RXD_LENGTH];
extern uint8_t  u8TxCnt;
extern uint8_t  u8RxCnt;
extern uint8_t	u8TxLength;


extern uint16_t u16CompareA;
extern uint16_t u16Period;

extern en_adt_unit_t           enAdt;
extern en_adt_compare_t        enAdtCompareA;
extern stc_adt_basecnt_cfg_t   stcAdtBaseCntCfg;
extern stc_adt_CHxX_port_cfg_t stcAdtTIM5ACfg;

extern stc_bt_config_t         BaseTime2Buf;

extern uint8_t const Cmp_Buf[5];

/******************************************************************************/
//����
/******************************************************************************/
//Main.c
extern void vInitRadio(void);
extern byte vGetRssi(void);
extern void vUartNewLine(void);
extern void vUartPrintCounter(byte cnt);
extern void vUartPrintStart(void);

//Base.c
extern void vMcuInit(void);
extern void vBaseTime0Init(void);
extern void vIOInit(void);
extern void vMcuConfig(void);

//interrupt.c
extern void Time0_Irq(void);

//uart.c
extern void TxIntCallback(void);
extern void RxIntCallback(void);
extern void ErrIntCallback(void);
extern void vUart1Init(void);

//pwm.c
extern void pwm_init(void);
extern void vBaseTime2Init(void);
extern void vTime2Unit(void);
extern void vSendByte(byte ch);
extern void vSendBuffer(byte ch);
extern void lftx_process(byte cmd);
extern byte crc8_calc(byte crc_dat, byte crc_result);


//Radio.c
/***********State Ctrl**********/
extern void vSoftReset(void);
extern byte bGoSleep(void);
extern byte bGoStandby(void);
extern byte bGoTx(void);
extern byte bGoRx(void);
extern byte bGoSwitch(void);
extern byte bReadStatus(void);
extern byte bReadRssi(byte unit_dbm);
/*******GPIO & Interrupt CFG*****/
extern void vGpioFuncCfg(byte io_cfg);
extern void vIntSrcCfg(byte int_1, byte int_2);
extern void vInt1SrcCfg(byte int_1);
extern void vInt2SrcCfg(byte int_2);
extern void vIntSrcEnable(byte en_int);
extern byte bIntSrcFlagClr(void);
extern void vEnableAntSwitch(byte mode);
/********Fifo Packet Handle*******/
extern void vClearFifo(void);
extern byte bReadFifoFlag(void);
extern word wReadIntFlag(void);
extern void vEnableRdFifo(void);
extern void vEnableWrFifo(void);
extern void vSetPayloadLength(byte mode, byte length);
extern void vEnableAckPacket(byte en);
extern byte bReadFifo(void);
extern void vWriteFifo(byte dat);
/**************CFG****************/
extern void vRadioInit(void);
extern void vInitTestRadio(void);
extern void vCfgBank(word cfg[], byte length);
extern void vAfterCfg(void) ;
extern void vReadCfgBank(byte sta_adr,  byte rd_cfg[], byte length);
extern void vSetIntPolar(byte polar);
/************Application**********/
extern byte bGetMessage(byte msg[]);
extern void vSendMessage(byte msg[], byte length);
extern void vSetChannelOffset(word interval);
extern void vSetChannel(word channel);
extern void vSetTxPreamble(word length);


//spi3.c 
extern void vSpi3BurstWriteFIFO(byte ptr[], byte length);
extern void vSpi3BurstReadFIFO(byte ptr[], byte length);
extern byte bSpi3ReadFIFO(void);
extern void vSpi3WriteFIFO(byte dat);
extern byte bSpi3Read(byte addr);
extern void vSpi3WriteCmd(byte dat);
extern void vSpi3Write(word dat);
extern byte bSpi3ReadByte(void);
extern void vSpi3WriteByte(byte dat, byte sda_in);
extern void _delay_us(word cnt);


#endif


