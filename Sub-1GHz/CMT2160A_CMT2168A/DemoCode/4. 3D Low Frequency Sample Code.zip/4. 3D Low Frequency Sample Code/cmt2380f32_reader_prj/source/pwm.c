#include "rfm380.h"


byte const LF_ID[2] = {0x12, 0x34};


uint16_t u16CompareA;
uint16_t u16Period;

en_adt_unit_t           enAdt;
en_adt_compare_t        enAdtCompareA;
stc_adt_basecnt_cfg_t   stcAdtBaseCntCfg;
stc_adt_CHxX_port_cfg_t stcAdtTIM5ACfg;

stc_bt_config_t         BaseTime2Buf;
 
void pwm_init(void)
{
 DDL_ZERO_STRUCT(stcAdtBaseCntCfg);
 DDL_ZERO_STRUCT(stcAdtTIM5ACfg);
 
 Gpio_SetFunc_IA1_P25();
     
 Clk_SetPeripheralGate(ClkPeripheralAdt, TRUE);						//ADT����ʱ��ʹ��
 
 enAdt = AdTIM5;
 stcAdtBaseCntCfg.enCntMode   = AdtSawtoothMode;
 stcAdtBaseCntCfg.enCntDir    = AdtCntUp;
 stcAdtBaseCntCfg.enCntClkDiv = AdtClkPClk0;
 Adt_Init(enAdt, &stcAdtBaseCntCfg);                      			//ADT�ز�������ģʽ��ʱ������
 
 u16Period = 192;										  			// 24M*8us = 192, ����
 Adt_SetPeriod(enAdt, u16Period);                         			//��������
 
 enAdtCompareA = AdtCompareA;
 u16CompareA = 96;										  			// 50%ռ�ձ�	
 Adt_SetCompareValue(enAdt, enAdtCompareA, u16CompareA);  			//ͨ�ñȽϻ�׼ֵ�Ĵ���A����
 
 stcAdtTIM5ACfg.enCap = AdtCHxCompareOutput;
 stcAdtTIM5ACfg.bOutEn = TRUE;
 stcAdtTIM5ACfg.enPerc = AdtCHxPeriodLow;
 stcAdtTIM5ACfg.enCmpc = AdtCHxCompareHigh;
 stcAdtTIM5ACfg.enStaStp = AdtCHxStateSelSS;
 stcAdtTIM5ACfg.enStaOut = AdtCHxPortOutLow;
 Adt_CHxXPortConfig(enAdt, AdtCHxA, &stcAdtTIM5ACfg);    			//�˿�CHA����
 
}


/************************************
**Name: vBaseTime2Init  		
**Func:
*Input:
Output:
************************************/
void vBaseTime2Init(void)
{

 Clk_SetPeripheralGate(ClkPeripheralBt,TRUE);		
	
 BaseTime2Buf.enGateP = BtPositive;		
 BaseTime2Buf.enGate  = BtGateDisable;				
 BaseTime2Buf.enPRS   = BtPCLKDiv1;									//24MHz
 BaseTime2Buf.enTog   = BtTogDisable;	  							//
 BaseTime2Buf.enCT    = BtTimer;									//
 BaseTime2Buf.enMD    = BtMode1;									//��ʱģʽ
 BaseTime2Buf.pfnTim0Cb=NULL;		
    
 Bt_Init(TIM2, &BaseTime2Buf);
 Bt_DisableIrq(TIM2);								
}

void vTime2Unit(void)
{
  Bt_Cnt32Set(TIM2, (0xFFFFFFFF-LF_TX_UNIT_VAL));		
  Bt_ClearIntFlag(TIM2);								
  Bt_Run(TIM2);
  while(!Bt_GetIntFlag(TIM2));
  Bt_Stop(TIM2);
}

void vSendByte(byte ch)												// Manchester Encoder
{
 byte j;	
 j = 0x80;
 for(j=0x80; j!=0; j>>=1)											//Msg
 	{
 	#ifdef 	MAN_CODE_PHASE
 		if(j&ch)	
 			{
 			Adt_StopCount(enAdt);
 			vTime2Unit();	
 			Adt_StartCount(enAdt);	
 			vTime2Unit();	
 			}
 		else
 			{	
 			Adt_StartCount(enAdt);	
 			vTime2Unit();	
 			Adt_StopCount(enAdt);
 			vTime2Unit();	
 			}
 	#else	
 		if(j&ch)	
 			{
 			Adt_StartCount(enAdt);	
 			vTime2Unit();	
 			Adt_StopCount(enAdt);
 			vTime2Unit();	
 			}
 		else
 			{	
 			Adt_StopCount(enAdt);
 			vTime2Unit();	
 			Adt_StartCount(enAdt);	
 			vTime2Unit();	
 			}
 	#endif	
 	} 	
}

void vSendBuffer(byte ch)											// NRZ Encoder
{
 byte j;	
 j = 0x80;
 for(j=0x80; j!=0; j>>=1)		
 	{
 	if(j&ch)	
 		{
   		Adt_StartCount(enAdt);	
 		vTime2Unit();	
 		}
 	else
 		{	
 		Adt_StopCount(enAdt);
 		vTime2Unit();	
 		}
 	} 
}

void lftx_process(byte cmd)
{
 byte i;
 byte lf_send_buf[3];												
 
 lf_send_buf[0] = '0'+(cmd/100);
 lf_send_buf[1] = '0'+(cmd%100/10);
 lf_send_buf[2] = '0'+(cmd%10);

 #ifdef	ENABLE_CW_TX					//CW Send
 	Adt_StartCount(enAdt);   			
	for(i=0; i<CW_LENGTH; i++)	
		vTime2Unit();
	Adt_StopCount(enAdt);
	vTime2Unit();						//CW separation bit
 #endif	
	
 for(i=0; i<PREAMBLE_LENGTH; i++)		//Preamble Send
 	{
 	Adt_StartCount(enAdt);	
 	vTime2Unit();
 	Adt_StopCount(enAdt);
 	vTime2Unit();	 	
 	}

 switch(SYNC_LENGTH)					//Sync Send
 	{
 	case 4: vSendBuffer((byte)(SYNC_VALUE>>24)); 
 	case 3: vSendBuffer((byte)(SYNC_VALUE>>16)); 
 	case 2: vSendBuffer((byte)(SYNC_VALUE>>8)); 
 	case 1: vSendBuffer((byte)SYNC_VALUE); break;
 	}

 #ifdef ENABLE_WAKEUP_ID				//wkid send
 	#ifdef	ENABLE_WAKEUP_ID_MAN
 		switch(WAKEUP_ID_LENGTH)
 			{
 			case 4: vSendByte((byte)(WAKEUP_ID_VALUE>>24)); 
 			case 3: vSendByte((byte)(WAKEUP_ID_VALUE>>16));
 			case 2: vSendByte((byte)(WAKEUP_ID_VALUE>>8));
 			case 1: vSendByte((byte)WAKEUP_ID_VALUE); break;
 			}
 	#else
 		switch(WAKEUP_ID_LENGTH)
 			{
 			case 4: vSendBuffer((byte)(WAKEUP_ID_VALUE>>24)); 
 			case 3: vSendBuffer((byte)(WAKEUP_ID_VALUE>>16));
 			case 2: vSendBuffer((byte)(WAKEUP_ID_VALUE>>8));
 			case 1: vSendBuffer((byte)WAKEUP_ID_VALUE); break;
 			}
 	#endif
 #endif
	
 for(i=0; i<PAYLOAD_LENGTH; i++)		//Payload Send	
 	{ 
 	#ifdef	PAYLOAD_MAN
		vSendByte(lf_send_buf[i]);
 	#else
 		vSendBuffer(lf_send_buf[i]);
 	#endif
		}	

 Adt_StartCount(enAdt);	
 vTime2Unit();
 Adt_StopCount(enAdt);
}

