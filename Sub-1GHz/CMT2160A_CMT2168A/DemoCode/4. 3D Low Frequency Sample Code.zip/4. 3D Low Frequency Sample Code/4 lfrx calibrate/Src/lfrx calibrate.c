/*!********************************************************************************************************
* @file : lfrx hands on.c
* @desc : 1. this is a demo for lfrx
*         2. 
*         3. 
*            
*  
* @version 	1.0
* @date  	Sep 29 2019
* @author 
*
*Copyright (C) CMOSTEK MICROELECTRONICS CO., LTD.
*
***********************************************************************************************************/

#include "cmt216xa.h"

extern void transmit_packet(void);
extern void assemble_packet(void);

byte 	cal_amp;
byte 	cal_cap_x;
byte	cal_cap_y;
byte	cal_cap_z;



void delay_1ms(void)
{
 sys_delay_us_count(250);
 sys_delay_us_count(250);
 sys_delay_us_count(250);
 sys_delay_us_count(250);
} 

void delay_10ms(void)
{
 byte ind;
 for(ind = 0; ind < 10; ind++)
	delay_1ms();
}

void delay_100ms(void)
{
 byte ind;
 for(ind = 0; ind < 10; ind++)
	delay_10ms();
}

void delay_500ms(void)
{
 byte ind;
 for(ind = 0; ind < 5; ind++)
	delay_100ms();
}

                 
void main(void)   
{
 IEN0 = 0x00;
 IEN1 = 0x00;
 sys_clear_system_flag();
 
 while(1)
 	{
	delay_500ms();

	cal_lfrx_osc_amplitude_calibration(125);
	cal_amp &= sys_read_hv_reg(CUS_LFRX32_ADDR);

	cal_lfrx_osc_frequency_calibration(125);
	cal_cap_x = sys_read_hv_reg(CAL_LFRX_TCAP0_ADDR);
	cal_cap_x &= 0x1F;

	cal_cap_y = sys_read_hv_reg(CAL_LFRX_TCAP1_ADDR);
	cal_cap_y &= 0x1F;

	cal_cap_z = sys_read_hv_reg(CAL_LFRX_TCAP2_ADDR);
	cal_cap_z &= 0x1F;
	
	assemble_packet();
    transmit_packet();
	}
}
