#include "lfrx link test.h"

//@select packet format
	#define 	PACKET_PREAMBLE_LEN 		8
	#define 	PACKET_PREAMBLE_VALUE		0xAA

	#define 	PACKET_SYNC_LEN				2			// for this sample code, it should be 2. If need change, should modify this code.
	#define		PACKET_SYNC_VALUE			0x2DD4
	
	#define		PACKET_VARIABLE_EN			0			// 0:Fixed Packet,  1:Variable Packet, other value no allow		
	#define		PACKET_ID_LEN				4
	#define 	PACKET_PAYLOAD_LEN 			8			// include PACKET_ID_LEN(32-bit UUID) + 4Byte
	
	#define		PACKET_CRC_EN				1			// 0:Disable CRC, 	1:Enbable CRC16, other value no allow

	#if (PACKET_CRC_EN!=0)
		#define PACKET_TRANSMIT_LEN 	(PACKET_PREAMBLE_LEN + PACKET_SYNC_LEN + PACKET_VARIABLE_EN + PACKET_PAYLOAD_LEN + 2)
	#else
		#define PACKET_TRANSMIT_LEN 	(PACKET_PREAMBLE_LEN + PACKET_SYNC_LEN + PACKET_VARIABLE_EN + PACKET_PAYLOAD_LEN )
	#endif

	#define		PACKET_MSB_SHIFT_TX						//MSB shift to transmitt at first


//@select pa output mode
#ifdef		CMT2163F_EB
	#define			DIFFERENTIAL_TX						//enable  select differental pa output; 
                                    					//disable select singal pa output;
#endif

//@select modulation
	#define			MODULATION_SEL		M_TX_MODU		//0: OOK, 			M_TX_MODU: FSK
	#define			GUASS_ON_SEL		M_GUASS_ON		//0: Guass off, 	M_GUASS_ON: Guass on, when FSK active
	#define			RAMP_EN_SEL			M_RAMP_EN		//0:Ramp off, 		M_RAMP_EN:Ramp on
	#define			FREQ_DEV_SEL		0				//0:(+f=1, -f=0),   M_FREQ_DEV_INV:(+f=0, -f=1) 
	
//@select wireless bit rate, select one of below
	//#define		BR_2400_5kHz						//BR+Deviation
	//#define		BR_9600_10kHz
	//#define		BR_19200_20kHz
	#define			BR_50k_25kHz
	//#define		BR_100k_35kHz
	//#define		BR_200k_50kHz

//@select tx output power
	#define 		PA_OUT_SEL			13				//range: 0-13, unit: dBm

//@frequency & modulation config
	#define 		VCO_CFG1			32				//433.92MHz 
	#define 		VCO_CFG0			15
	#define 		PLL_N_CFG			33
	#define			PLL_K_CFG1			96
	#define			PLL_K_CFG0			226

//@select frequency band, only one of below
	//#define		FREQ_FOR_315
	#define			FREQ_FOR_434
	//#define		FREQ_FOR_868
	//#define		FREQ_FOR_915

//@low battery voltage
	#define			LOW_BATTERY_VALUE	106				//about 2.0V     255*2.0/4.8 
//********************************** Bit Rate & Deviation **************************************
#ifdef 	BR_2400_5kHz								
	#define PA_CFG						5
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			7
	#define FREQ_DEV_CFG1				0
	#define	FREQ_DEV_CFG0				25
	#define SYMBOL_TIME_CFG1			0
	#define SYMBOL_TIME_CFG0			194
#endif                              	
                                    	
#ifdef 	BR_9600_10kHz										
	#define PA_CFG						4
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			3
	#define FREQ_DEV_CFG1				0
	#define	FREQ_DEV_CFG0				50
	#define SYMBOL_TIME_CFG1			3
	#define SYMBOL_TIME_CFG0			6
#endif                              	
                                    	
#ifdef 	BR_19200_20kHz								
	#define PA_CFG						3
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			1
	#define FREQ_DEV_CFG1				0
	#define	FREQ_DEV_CFG0				100
	#define SYMBOL_TIME_CFG1			6
	#define SYMBOL_TIME_CFG0			13
#endif                              	
                                    	
#ifdef 	BR_50k_25kHz										
	#define PA_CFG						2
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			0
	#define FREQ_DEV_CFG1				0
	#define	FREQ_DEV_CFG0				126
	#define SYMBOL_TIME_CFG1			15
	#define SYMBOL_TIME_CFG0			193
#endif                              	
                                    	
#ifdef	BR_100k_35kHz								
	#define PA_CFG						2
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			0
	#define FREQ_DEV_CFG1				0
	#define	FREQ_DEV_CFG0				178
	#define SYMBOL_TIME_CFG1			31
	#define SYMBOL_TIME_CFG0			130
#endif                              	
                                    	
#ifdef	BR_200k_50kHz						
	#define PA_CFG						2
	#define RAMP_STEP_TIME_CFG1			0
	#define RAMP_STEP_TIME_CFG0			0
	#define FREQ_DEV_CFG1				0
	#define	FREQ_DEV_CFG0				252
	#define SYMBOL_TIME_CFG1			63
	#define SYMBOL_TIME_CFG0			4
#endif

//**************************** Output Power Amp. for different FREQ_BAND *********************************
#ifdef	FREQ_FOR_315
	#if (PA_OUT_SEL>5)
		#define PA_IDAC_CODE_CFG			63
	#else
		#define PA_IDAC_CODE_CFG			28
	#endif

									//  TH_9-------------------------------------TH_0
	byte code TX_POWER_SEL[14][10] = {
		                                {23, 24, 25, 26, 27,  28,  30,  32,  35,  38},             // +0dBm                      
		                                {25, 27, 29, 30, 31,  33,  35,  37,  39,  44},             // +1dBm                      
		                                {29, 31, 33, 34, 35,  37,  40,  42,  45,  50},             // +2dBm                      
		                                {33, 34, 35, 36, 38,  40,  42,  46,  50,  55},             // +3dBm                      
		 								{37, 39, 41, 42, 43,  46,  49,  52,  55,  61},             // +4dBm                      
										{40, 42, 44, 46, 48,  51,  54,  59,  61,  68},             // +5dBm  -----idac code = 28 
										{14, 15, 16, 17, 19,  21,  25,  29,  38,  51},             // +6dBm  -----idac code = 63 
										{16, 17, 18, 19, 21,  25,  30,  36,  44,  62},             // +7dBm                      
		                                {18, 20, 21, 22, 24,  28,  33,  42,  57,  80},             // +8dBm	                     
		                                {20, 21, 23, 26, 30,  35,  43,  54,  80, 120},             // +9dBm                      
		                                {24, 25, 28, 33, 38,  42,  54,  65, 100, 127},             //+10dBm	                     
		                                {27, 30, 32, 38, 42,  49,  73, 110, 127, 127},             //+11dBm                      
		                                {32, 39, 42, 50, 57,  72, 100, 127, 127, 127},             //+12dBm                      
		                                {38, 42, 48, 64, 78, 100, 120, 127, 127, 127},             //+13dBm                      
										};
#endif



#ifdef	FREQ_FOR_434
	#if (PA_OUT_SEL>5)
		#define PA_IDAC_CODE_CFG			63
	#else
		#define PA_IDAC_CODE_CFG			28
	#endif

									//  TH_9-------------------------------------TH_0
	byte code TX_POWER_SEL[14][10] = {
		                                {15, 15, 16, 17, 18, 19,  20,  21,  23,  25}, 				// +0dBm                             
		                                {17, 17, 18, 19, 20, 21,  22,  23,  25,  28}, 	        	// +1dBm                             
		                                {19, 20, 21, 22, 23, 24,  25,  26,  28,  32}, 	        	// +2dBm                             
		                                {22, 23, 24, 25, 26, 27,  29,  31,  34,  37}, 	        	// +3dBm                             
		 								{24, 25, 26, 27, 29, 31,  32,  34,  37,  41}, 	        	// +4dBm                             
										{27, 28, 29, 30, 32, 33,  35,  39,  43,  50}, 	        	// +5dBm  -----idac code = 28        
										{ 9, 10, 10, 11, 12, 14,  17,  21,  26,  37}, 	        	// +6dBm  -----idac code = 63        
										{10, 11, 12, 13, 14, 16,  20,  25,  31,  47}, 	        	// +7dBm                             
		                                {11, 12, 13, 15, 17, 20,  24,  31,  42,  70}, 	        	// +8dBm	                         
		                                {13, 14, 15, 17, 20, 24,  29,  40,  65, 119}, 	        	// +9dBm                             
		                                {15, 16, 18, 21, 25, 31,  42,  65, 103, 127}, 	        	//+10dBm	                         
		                                {19, 21, 24, 26, 34, 43,  59,  85, 115, 127}, 	        	//+11dBm                             
		                                {24, 27, 32, 37, 46, 62,  89, 113, 127, 127}, 	        	//+12dBm                             
		                                {32, 38, 45, 56, 73, 94, 115, 127, 127, 127}, 	        	//+13dBm                             
										};
#endif										


#ifdef	FREQ_FOR_868
	#if (PA_OUT_SEL>5)
		#define PA_IDAC_CODE_CFG			63
	#else
		#define PA_IDAC_CODE_CFG			30
	#endif
								
					   				//  TH_9-------------------------------------TH_0
	byte code TX_POWER_SEL[14][10] = {
										{15, 16, 17, 18, 19, 20, 21,  22,  23,  26},				// +0dBm                      
										{17, 18, 19, 20, 21, 22, 23,  24,  26,  30},                // +1dBm                      
										{19, 20, 21, 22, 23, 24, 25,  27,  29,  33},                // +2dBm                      
										{22, 23, 24, 25, 26, 27, 28,  30,  33,  38},                // +3dBm                      
										{25, 26, 27, 28, 29, 30, 32,  34,  37,  42},                // +4dBm                      
										{28, 29, 30, 32, 33, 35, 37,  39,  43,  49},                // +5dBm  -----idac code = 30 
										{11, 12, 13, 14, 16, 18, 21,  25,  32,  42},                // +6dBm  -----idac code = 63 
										{13, 14, 15, 16, 18, 21, 24,  29,  38,  51},                // +7dBm                      
										{15, 16, 17, 19, 21, 24, 29,  35,  46,  62},                // +8dBm	                  
										{17, 18, 20, 22, 24, 28, 33,  41,  55,  76},                // +9dBm                      
										{20, 21, 23, 25, 28, 33, 40,  50,  70, 105},                //+10dBm	                  
										{24, 26, 27, 30, 34, 40, 50,  68,  95, 127},                //+11dBm                      
										{27, 29, 31, 36, 43, 54, 65,  90, 127, 127},                //+12dBm                      
										{33, 36, 38, 44, 52, 65, 87, 127, 127, 127},                //+13dBm                      
									 };
#endif

#ifdef	FREQ_FOR_915
	#if (PA_OUT_SEL>5)
		#define PA_IDAC_CODE_CFG			63
	#else
		#define PA_IDAC_CODE_CFG			30
	#endif
								
					   				//  TH_9-------------------------------------TH_0
	byte code TX_POWER_SEL[14][10] = {
										{15, 16, 17, 18, 19, 20, 21,  22,  23,  26},				// +0dBm                      
										{17, 18, 19, 20, 21, 22, 23,  24,  26,  30},                // +1dBm                      
										{19, 20, 21, 22, 23, 24, 25,  27,  29,  33},                // +2dBm                      
										{22, 23, 24, 25, 26, 27, 28,  30,  33,  38},                // +3dBm                      
										{25, 26, 27, 28, 29, 30, 32,  34,  37,  42},                // +4dBm                      
										{28, 29, 30, 32, 33, 35, 37,  39,  43,  49},                // +5dBm  -----idac code = 30 
										{11, 12, 13, 14, 16, 18, 21,  25,  32,  42},                // +6dBm  -----idac code = 63 
										{13, 14, 15, 16, 18, 21, 24,  29,  38,  51},                // +7dBm                      
										{15, 16, 17, 19, 21, 24, 29,  35,  46,  62},                // +8dBm	                  
										{17, 18, 20, 22, 24, 28, 33,  41,  55,  76},                // +9dBm                      
										{20, 21, 23, 25, 28, 33, 40,  50,  70, 105},                //+10dBm	                  
										{24, 26, 27, 30, 34, 40, 50,  68,  95, 127},                //+11dBm                      
										{27, 29, 31, 36, 43, 54, 65,  90, 127, 127},                //+12dBm                      
										{33, 36, 38, 44, 52, 65, 87, 127, 127, 127},                //+13dBm                      
									 };
#endif


byte xdata 	g_trans_buf[PACKET_TRANSMIT_LEN];	


//*****************************************************************************
//name:    assemble_packet
//desc:    assemble transmit packet(preamble(8bytes) + sync(2bytes) + id(4bytes) + 4Byte)
//param:   none
//return:  none 
//*****************************************************************************
void assemble_start_packet(void)
{
 byte ind;
 byte i;
 byte crc_sta;
 word crc_result; 
 byte xdata g_id_array[4];			
 STRU_CRC16_CFG crc_cfg;		

 sys_get_uuid(g_id_array);										//get uuid						

 for(ind=0; ind<PACKET_PREAMBLE_LEN; ind++)						//Preamble 
	g_trans_buf[ind] = PACKET_PREAMBLE_VALUE;
 
 switch(PACKET_SYNC_LEN)										//SyncWord
 	{
 	case 4:
 		g_trans_buf[ind++] = (byte)(PACKET_SYNC_VALUE>>24);
 	case 3:
 		g_trans_buf[ind++] = (byte)(PACKET_SYNC_VALUE>>16);
 	case 2:
 		g_trans_buf[ind++] = (byte)(PACKET_SYNC_VALUE>>8);	
 	case 1:
 		g_trans_buf[ind++] = (byte)PACKET_SYNC_VALUE;
 		break;
 	}
 crc_sta = ind;
 
 for(i=0; i<PACKET_ID_LEN; i++)									//Payload
	g_trans_buf[ind++] = g_id_array[i];
 g_trans_buf[ind++] = 's';
 g_trans_buf[ind++] = 't';
 g_trans_buf[ind++] = 'a';
 g_trans_buf[ind++] = 'r';
 
 if(PACKET_CRC_EN!=0)
 	{	
 	crc_cfg.pbuf     = &g_trans_buf[crc_sta];	
 	crc_cfg.data_len = (PACKET_VARIABLE_EN+PACKET_PAYLOAD_LEN);
 	crc_cfg.crc_poly = 0x1021;
 	crc_cfg.crc_init = 0x0000;
 	crc_cfg.bit_order= 0;
	crc_result = sys_crc16_calc(&crc_cfg);
 	g_trans_buf[ind++] = (byte)(crc_result>>8);
 	g_trans_buf[ind++] = (byte)crc_result;
 	}
 
}

void assemble_lf_packet(void)
{
 byte  ind;
 byte  i;
 byte crc_sta;
 word crc_result;
 STRU_CRC16_CFG crc_cfg;
	
 for(ind=0; ind<PACKET_PREAMBLE_LEN; ind++)						//Preamble 
	g_trans_buf[ind] = PACKET_PREAMBLE_VALUE;
 
 switch(PACKET_SYNC_LEN)										//SyncWord
 	{
 	case 4:
 		g_trans_buf[ind++] = (byte)(PACKET_SYNC_VALUE>>24);
 	case 3:
 		g_trans_buf[ind++] = (byte)(PACKET_SYNC_VALUE>>16);
 	case 2:
 		g_trans_buf[ind++] = (byte)(PACKET_SYNC_VALUE>>8);	
 	case 1:
 		g_trans_buf[ind++] = (byte)PACKET_SYNC_VALUE;
 		break;
 	}
 
 crc_sta = ind;
 	
 for(i=0; i<PACKET_PAYLOAD_LEN; i++)							//Payload
	g_trans_buf[ind++] = lfrx_data_array[i];
 
 if(PACKET_CRC_EN!=0)
 	{	
 	crc_cfg.pbuf     = &g_trans_buf[crc_sta];	
 	crc_cfg.data_len = (PACKET_VARIABLE_EN+PACKET_PAYLOAD_LEN);
 	crc_cfg.crc_poly = 0x1021;
 	crc_cfg.crc_init = 0x0000;
 	crc_cfg.bit_order= 0;
	crc_result = sys_crc16_calc(&crc_cfg);
 	g_trans_buf[ind++] = (byte)(crc_result>>8);
 	g_trans_buf[ind++] = (byte)crc_result;
 	}

}

/*************************************************************************************************************
*@name:    set_tx_modu_config
*@desc:    set tx modu config (freq=433.92mhz, fsk , datarate=10kbps)
*@param:   0---ook, 1---fsk, other=MODE_CFG
*@return:  none 
**************************************************************************************************************/
void set_tx_modu_config(byte mod)
{
 xdata STRU_TX_MODU_SETUP tx_modu_setup; 
 byte i;
  
 switch(mod)
 	{                  
 	case 0:  tx_modu_setup.mod_cfg = (GUASS_ON_SEL|RAMP_EN_SEL|FREQ_DEV_SEL); break;
 	case 1:	 tx_modu_setup.mod_cfg = (M_TX_MODU|GUASS_ON_SEL|RAMP_EN_SEL|FREQ_DEV_SEL); break;
 	default: tx_modu_setup.mod_cfg = (MODULATION_SEL|GUASS_ON_SEL|RAMP_EN_SEL|FREQ_DEV_SEL); break;
	}
	
 tx_modu_setup.vco_cfg1  = VCO_CFG1;
 tx_modu_setup.vco_cfg0  = VCO_CFG0;
       
 tx_modu_setup.plln_cfg  = PLL_N_CFG;
 tx_modu_setup.pllk_cfg1 = PLL_K_CFG1;
 tx_modu_setup.pllk_cfg0 = PLL_K_CFG0;
    
 #ifndef DIFFERENTIAL_TX
    tx_modu_setup.pa_cfg = PA_CFG&(~M_PA_DIFF_SEL);
 #else
    tx_modu_setup.pa_cfg = PA_CFG|M_PA_DIFF_SEL;
 #endif
 
 tx_modu_setup.pa_idac_code_cfg    = PA_IDAC_CODE_CFG;

 tx_modu_setup.ramp_step_time_cfg1 = RAMP_STEP_TIME_CFG1;
 tx_modu_setup.ramp_step_time_cfg0 = RAMP_STEP_TIME_CFG0;
    
 tx_modu_setup.freq_dev_cfg1       = FREQ_DEV_CFG1;
 tx_modu_setup.freq_dev_cfg0       = FREQ_DEV_CFG0;
    
 tx_modu_setup.symbol_time_cfg1    = SYMBOL_TIME_CFG1;
 tx_modu_setup.symbol_time_cfg0    = SYMBOL_TIME_CFG0;
    
 tx_modu_setup_config(&tx_modu_setup);

 sys_set_sfr_bank(1);   

 if(PA_OUT_SEL>=13)
	i = 13;
 else
 	i = PA_OUT_SEL;
		
 PA_POWER_TH_9 = TX_POWER_SEL[i][0];
 PA_POWER_TH_8 = TX_POWER_SEL[i][1];
 PA_POWER_TH_7 = TX_POWER_SEL[i][2];
 PA_POWER_TH_6 = TX_POWER_SEL[i][3];
 PA_POWER_TH_5 = TX_POWER_SEL[i][4];
 PA_POWER_TH_4 = TX_POWER_SEL[i][5];
 PA_POWER_TH_3 = TX_POWER_SEL[i][6];
 PA_POWER_TH_2 = TX_POWER_SEL[i][7];
 PA_POWER_TH_1 = TX_POWER_SEL[i][8];
 PA_POWER_TH_0 = TX_POWER_SEL[i][9];
}

/*************************************************************************************************************
*@name:    transmit_packet
*@desc:    transmit packet from 'g_trans_buf' buffer
*@param:   none
*@return:  none 
**************************************************************************************************************/
void transmit_packet(void)
{   
 byte tx_sym_setup;
	
 set_tx_modu_config(2);
    
 if(2 != tx_sym_prepare_for_transmission(LOW_BATTERY_VALUE))
	{
	// bit1: 0 - pll is not locked, 1 - pll is locked 
	// bit0: 0 - system voltage is higer than voltage_th, 1 - system voltage is lower than voltage_th 
	sys_disable_pll_module();
	sys_disable_xo_crystal();		
	return;
	}
      
 // tx_sym_setup:
 // bit[7:6]:    reserved
 // bit[5:3]:    tx group with
 // bit[2]  :    endian(0-small endian, 1-big endian)
 // bit[1:0]:    tx_sym_ctrl
 //       00:    shundown transmission after last bit
 //       01:    reuse tha last symbol group for transmission
 //       10:    all 0s data
 //       11:    all 1s data  
 //
 #ifdef PACKET_MSB_SHIFT_TX
 	tx_sym_setup = 0x3C;
 #else    
    tx_sym_setup = 0x38;   
 #endif 
 tx_sym_setup_config(tx_sym_setup); 				// set tx sym config
    

 //  led_cfg: the led config
 //      bit[7]  : reserved
 //      bit[6]  : led_on (0:disable led, 1: enable led)
 //      bit[5]  : led_out_sel(0: led signal is from tx data, 1: led signal is from pwm signal)
 //      bit[4]  : pwm output rate (0:3.3khz, 1:6.68khz)
 //      bit[3:0]: pwm interval select when pwm output rate is 6.68khz(0:1/16, 1:2/16, ... , 15: 16/16)
 //
 sys_enable_led_flash(0x47);
 
 //EA = 0; 
 tx_sym_transmit(g_trans_buf, PACKET_TRANSMIT_LEN);	// transmit data from g_trans_buf
 //EA = 1; 

 sys_enable_led_flash(0x00); 						// disable led flash module
    
 sys_disable_pll_module();							// disable PLL module, it takes about 2.3mA
 sys_disable_xo_crystal();							// disable XO crystal, it takes about 400uA	
}


