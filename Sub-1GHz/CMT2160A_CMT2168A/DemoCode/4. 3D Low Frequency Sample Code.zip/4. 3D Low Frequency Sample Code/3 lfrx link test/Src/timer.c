#include "lfrx link test.h"

#define		TIMER_INTERVAL			20000					// TIMER_INTERVAL/2 us, and Max 65536

//*****************************************************************************
//**SOFTWARE DELAY
//*****************************************************************************
void delay_Nms(byte tmp)
{
 if(tmp==0)
 	return;	
 for( ; tmp!=0; tmp--)
 	{	
 	sys_delay_us_count(250);
 	sys_delay_us_count(250);
 	sys_delay_us_count(250);
 	sys_delay_us_count(250);
	}
} 

//*****************************************************************************
//** TIMER1
//*****************************************************************************
//*****************************************************************************
//Name: init_timer1
//Func: initial timer1 as mode1, & enable timer1 interrupt
//input:int_ms, period time
//*****************************************************************************
void init_timer1(void)
{
 // timer 1 mode1 setting 
 TMOD = 0x10; 									// mode 1: 16-bit (Max=65536),  Timer1 Clock = HFOSC/12 = 24/12 = 2MHz, so that Max. Intevral about 65536*0.5=32.768ms
 TH1  = (byte)((65536-TIMER_INTERVAL)>>8); 				
 TL1  = (byte)(65536-TIMER_INTERVAL);
 TR1  = 1; 										// Timer1 Start
 
 system_timer1_interrupt_service_routine = timer1_interrupt_service_routine;		// interrupt setting 
 ET1 = 1; 																			// enable timer1 interrupt
}

//*****************************************************************************
//Name: timer1_interrupt_service_routine
//Func: timer1 interrupt service function
//input:int_ms, period time
//*****************************************************************************
void timer1_interrupt_service_routine(void)
{
 TF1 = 0;
 TH1 = (byte)((65536-TIMER_INTERVAL)>>8); 				
 TL1 = (byte)(65536-TIMER_INTERVAL);
 systimer++;
 lfrx_recv_timer++;
}