#include "lfrx link test.h"

xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt0_service_routine 		_at_ 0x0000;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt1_service_routine 		_at_ 0x0003;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt2_service_routine 		_at_ 0x0006;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt3_service_routine 		_at_ 0x0009;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt4_service_routine 		_at_ 0x000c;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt5_service_routine 		_at_ 0x000f;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt6_service_routine 		_at_ 0x0013;
xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt7_service_routine 		_at_ 0x0016;
xdata INTERRUPT_SERVICE_ROUTINE system_timer1_interrupt_service_routine    		_at_ 0x0019;
xdata INTERRUPT_SERVICE_ROUTINE system_serial_port0_interrupt_service_routine 	_at_ 0x001c;

#ifdef	FLASH_BOOT_DEBUG_MODE		

	byte g_reserved_data_used_by_interrupt_rountine[20] _at_ 0x40; 						// each interrupt using two bytes, so total data = 10 interrupts * 2 = 20

#else

	byte g_external_interrupt0_bank_store     _at_ 0x40;
	byte g_external_interrupt0_hv_store       _at_ 0x41;
	byte g_external_interrupt1_bank_store     _at_ 0x42;
	byte g_external_interrupt1_hv_store       _at_ 0x43;
	byte g_external_interrupt2_bank_store     _at_ 0x44;
	byte g_external_interrupt2_hv_store       _at_ 0x45;
	byte g_external_interrupt3_bank_store     _at_ 0x46;
	byte g_external_interrupt3_hv_store       _at_ 0x47;
	byte g_external_interrupt4_bank_store     _at_ 0x48;
	byte g_external_interrupt4_hv_store       _at_ 0x49;
	byte g_external_interrupt5_bank_store     _at_ 0x4A;
	byte g_external_interrupt5_hv_store       _at_ 0x4B;
	byte g_external_interrupt6_bank_store     _at_ 0x4C;
	byte g_external_interrupt6_hv_store       _at_ 0x4D;
	byte g_external_interrupt7_bank_store     _at_ 0x4E;
	byte g_external_interrupt7_hv_store       _at_ 0x4F;
	byte g_timer1_interrupt_bank_store        _at_ 0x50;
	byte g_timer1_interrupt_hv_store          _at_ 0x51;
	byte g_serial_port0_interrupt_bank_store  _at_ 0x52;
	byte g_serial_port0_interrupt_hv_store    _at_ 0x53;

	// EX_INT0
	void system_external_interrupt0(void) interrupt INT_EX0_VECTOR using 0    		
	{
    	sys_push_bank0_r0_2_r7_to_stack();		    									// push r0-r7 to stack
    	g_external_interrupt0_bank_store = sys_get_sfr_bank();							// store the sfr bank value
    	g_external_interrupt0_hv_store   = sys_store_hv_interface();   					// store hv interface
    	if(system_external_interrupt0_service_routine != NULL)							// run the interrupt service routine
    	    system_external_interrupt0_service_routine();               				
    	sys_restore_hv_interface(g_external_interrupt0_hv_store);						// restore hv interface
    	sys_set_sfr_bank(g_external_interrupt0_bank_store);								// restore the sfr bank value
    	sys_pop_bank0_r7_2_r0_from_stack();												// pop r7-r0 from stack
	}

	// EX_INT1 
	void system_external_interrupt1(void) interrupt INT_EX1_VECTOR using 0  			
	{
    	sys_push_bank0_r0_2_r7_to_stack();
    	g_external_interrupt1_bank_store = sys_get_sfr_bank();
    	g_external_interrupt1_hv_store   = sys_store_hv_interface();
	    if(system_external_interrupt1_service_routine != NULL)
        	system_external_interrupt1_service_routine();
    	sys_restore_hv_interface(g_external_interrupt1_hv_store);
    	sys_set_sfr_bank(g_external_interrupt1_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();
	}

	// TIMER1_INT
	void system_timer1_interrupt(void) interrupt INT_TIMER1_VECTOR using 0  		
	{
   		sys_push_bank0_r0_2_r7_to_stack();
    	g_timer1_interrupt_bank_store = sys_get_sfr_bank();
        g_timer1_interrupt_hv_store   = sys_store_hv_interface();
    	if(system_timer1_interrupt_service_routine != NULL)
  	    	system_timer1_interrupt_service_routine();
    	sys_restore_hv_interface(g_timer1_interrupt_hv_store);
	    sys_set_sfr_bank(g_timer1_interrupt_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();  
	}

	// SERIAL_PORT0_INT
	void system_serial_port0_interrupt(void) interrupt INT_UART_VECTOR using 0 		
	{
	    sys_push_bank0_r0_2_r7_to_stack();
	    g_serial_port0_interrupt_bank_store = sys_get_sfr_bank();
	    g_serial_port0_interrupt_hv_store   = sys_store_hv_interface();
        if(system_serial_port0_interrupt_service_routine != NULL)
	        system_serial_port0_interrupt_service_routine();
	    sys_restore_hv_interface(g_serial_port0_interrupt_hv_store);
	    sys_set_sfr_bank(g_serial_port0_interrupt_bank_store);
	    sys_pop_bank0_r7_2_r0_from_stack();  
	}

	// EX_INT2
	void system_external_interrupt2(void) interrupt INT_EX2_VECTOR using 0   	
	{
    	sys_push_bank0_r0_2_r7_to_stack();
    	g_external_interrupt2_bank_store = sys_get_sfr_bank();
    	g_external_interrupt2_hv_store   = sys_store_hv_interface();
    	if(system_external_interrupt2_service_routine != NULL)
    	    system_external_interrupt2_service_routine();
    	sys_restore_hv_interface(g_external_interrupt2_hv_store);
    	sys_set_sfr_bank(g_external_interrupt2_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();           
	}

	// EX_INT3
	void system_external_interrupt3(void) interrupt INT_EX3_VECTOR using 0    		
	{ 
    	sys_push_bank0_r0_2_r7_to_stack();
    	g_external_interrupt3_bank_store = sys_get_sfr_bank();
    	g_external_interrupt3_hv_store   = sys_store_hv_interface();
    	if (system_external_interrupt3_service_routine != NULL)
    	    system_external_interrupt3_service_routine();
    	sys_restore_hv_interface(g_external_interrupt3_hv_store);
    	sys_set_sfr_bank(g_external_interrupt3_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();   
	}

	// EX_INT4
	void system_external_interrupt4(void) interrupt INT_EX4_VECTOR using 0  
	{
    	sys_push_bank0_r0_2_r7_to_stack();
    	g_external_interrupt4_bank_store = sys_get_sfr_bank();
    	g_external_interrupt4_hv_store   = sys_store_hv_interface();
    	if (system_external_interrupt4_service_routine != NULL)
    	    system_external_interrupt4_service_routine();
    	sys_restore_hv_interface(g_external_interrupt4_hv_store);
    	sys_set_sfr_bank(g_external_interrupt4_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();
	}

	// EX_INT5
	void system_external_interrupt5(void) interrupt INT_EX5_VECTOR using 0  	
	{
    	sys_push_bank0_r0_2_r7_to_stack();
    	g_external_interrupt5_bank_store = sys_get_sfr_bank();
    	g_external_interrupt5_hv_store   = sys_store_hv_interface();
    	if (system_external_interrupt5_service_routine != NULL)
    	    system_external_interrupt5_service_routine();
    	sys_restore_hv_interface(g_external_interrupt5_hv_store);
    	sys_set_sfr_bank(g_external_interrupt5_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();
	}

	// EX_INT6
	void system_external_interrupt6(void) interrupt INT_EX6_VECTOR using 0  	
	{
    	sys_push_bank0_r0_2_r7_to_stack();
    	g_external_interrupt6_bank_store = sys_get_sfr_bank();
    	g_external_interrupt6_hv_store   = sys_store_hv_interface();
    	if (system_external_interrupt6_service_routine != NULL)
    	    system_external_interrupt6_service_routine();
    	sys_restore_hv_interface(g_external_interrupt6_hv_store);
    	sys_set_sfr_bank(g_external_interrupt6_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();
	}

	// EX_INT7
	void system_external_interrupt7(void) interrupt INT_EX7_VECTOR using 0  	
	{
    	sys_push_bank0_r0_2_r7_to_stack();
    	g_external_interrupt7_bank_store = sys_get_sfr_bank();
    	g_external_interrupt7_hv_store   = sys_store_hv_interface();
    	if (system_external_interrupt7_service_routine != NULL)
    	    system_external_interrupt7_service_routine();
    	sys_restore_hv_interface(g_external_interrupt7_hv_store);
    	sys_set_sfr_bank(g_external_interrupt7_bank_store);
    	sys_pop_bank0_r7_2_r0_from_stack();
	}

#endif


void clear_interrupt_vector(void)
{
 system_external_interrupt0_service_routine    = NULL;   
 system_external_interrupt1_service_routine    = NULL;
 system_external_interrupt2_service_routine    = NULL;
 system_external_interrupt3_service_routine    = NULL;
 system_external_interrupt4_service_routine    = NULL;
 system_external_interrupt5_service_routine    = NULL;
 system_external_interrupt6_service_routine    = NULL;
 system_external_interrupt7_service_routine    = NULL;
 system_timer1_interrupt_service_routine       = NULL;
 system_serial_port0_interrupt_service_routine = NULL;
}


