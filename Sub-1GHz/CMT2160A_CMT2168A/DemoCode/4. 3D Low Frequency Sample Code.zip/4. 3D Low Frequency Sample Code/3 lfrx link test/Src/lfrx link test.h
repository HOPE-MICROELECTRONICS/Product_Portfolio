/*!********************************************************************************************************
* @file : lfrx link test.c
* @desc : 1. This is a demo for LFRX to evaluate link test��
*         2. Base on CMT2163F-EB
*         3.  
*         GFSK 433.92MHz 
*          Fixed Packet Format = Preamble   + SyncWord + Payload
*                              = 0xAA*8Byte +  0xAA2DD4  + 8Byte
* 
*       
* @version  1.1
* @date     Oct 10 2019
* @author 	
*
* Copyright (C) CMOSTEK MICROELECTRONICS CO., LTD.
*
***********************************************************************************************************/

#include "cmt216xa.h"

#define		FLASH_BOOT_DEBUG_MODE

#define		ENABLE_LFRX_PINOUT					//enable mapping LFRX pinout as below
												//		A1----LF Data
												//		A2----LF Wakuep signal
												//		A3----LF Dclk

#define		CMT2163F_EB							//enable for select CMT2163F-EB; disable for select CMT2168A-EB



//********************************************* Port Config ************************************************
// Port  Function 	NorFlash	System		  CUS_PADCTL[1:4]			         CUS_PADCTL[5:6]			CUS_PADCTL[7:8]		CUS_PADCTL[9:10]		  CUS_PADCTL[11:12]
//                                   			    Mode                             CNF                            IOC            	  IDR      		             ODR      
//	A0	   NC								GPIO0_MODE_AS_DIG_INPUT			GPIO0_CNF_INPUT_PULLUP														GPIO0_INPUT_PULLUP_DOWN
//  A1     NC/LF Data						GPIO1_MODE_AS_DIG_INPUT			GPIO1_CNF_INPUT_PULLUP														GPIO1_INPUT_PULLUP_DOWN
//  A2     NC/LF Wakeup signal				GPIO2_MODE_AS_DIG_INPUT			GPIO2_CNF_INPUT_PULLUP														GPIO2_INPUT_PULLUP_DOWN
//  A3     NC/LF Dclk						GPIO3_MODE_AS_DIG_INPUT			GPIO3_CNF_INPUT_PULLUP							  	 						GPIO3_INPUT_PULLUP_DOWN
//  A4     NC								GPIO4_MODE_AS_DIG_INPUT			GPIO4_CNF_INPUT_PULLUP														GPIO4_INPUT_PULLUP_DOWN
//  A5     NC								GPIO5_MODE_AS_DIG_INPUT			GPIO5_CNF_INPUT_PULLUP														GPIO5_INPUT_PULLUP_DOWN	
//  A6     KEY3(63F) FLASH_SI				GPIO6_MODE_AS_DIG_INPUT			GPIO6_CNF_INPUT_PULLUP				M_GPIO6_IOC			M_GPIO6_IDR			GPIO6_INPUT_PULLUP_DOWN
//  A7     LED1(63F)						GPIO7_MODE_AS_DIG_INPUT			GPIO7_CNF_INPUT_PULLUP														GPIO7_INPUT_PULLUP_DOWN
//                                                                                                                          			    			
//  B0     NC					1-Wire		GPIO8_MODE_AS_DIG_INPUT			GPIO8_CNF_INPUT_PULLUP														GPIO8_INPUT_PULLUP_DOWN
//  B1     KEY1					VPP			GPIO9_MODE_AS_DIG_INPUT			GPIO9_CNF_INPUT_PULLUP				M_GPIO9_IOC			M_GPIO9_IDR			GPIO9_INPUT_PULLUP_DOWN
//  B2     NC 		FLASH_CS	S3S_CS		GPIO10_MODE_AS_DIG_INPUT		GPIO10_CNF_INPUT_PULLUP														GPIO10_INPUT_PULLUP_DOWN
//  B3     KEY2		FLASH_SCK	S3S_CLK		GPIO11_MODE_AS_DIG_INPUT		GPIO11_CNF_INPUT_PULLUP				M_GPIO11_IOC		M_GPIO11_IDR		GPIO11_INPUT_PULLUP_DOWN
//  B4     LED2					S3S_DIO		GPIO12_MODE_AS_DIG_INPUT		GPIO12_CNF_INPUT_PULLUP														GPIO12_INPUT_PULLUP_DOWN
//  B5     NC		FLASH_SO				GPIO13_MODE_AS_DIG_INPUT		GPIO13_CNF_INPUT_PULLUP														GPIO13_INPUT_PULLUP_DOWN
//  B6     KEY3(68)	FLASH_SI				GPIO14_MODE_AS_DIG_INPUT		GPIO14_CNF_INPUT_PULLUP				M_GPIO14_IOC		M_GPIO14_IDR		GPIO14_INPUT_PULLUP_DOWN
//  B7     NC								GPIO15_MODE_AS_DIG_INPUT		GPIO15_CNF_INPUT_PULLUP														GPIO15_INPUT_PULLUP_DOWN

// 	D1	   LED1(68)     					GPIO16_MODE_AS_DIG_INPUT		GPIO16_CNF_INPUT_PULLUP 	                                              	GPIO16_INPUT_PULLUP_DOWN                                                                   			    				



	#define		CUS_PADCTL1_VALUE		(GPIO3_MODE_AS_DIG_INPUT|GPIO2_MODE_AS_DIG_INPUT|GPIO1_MODE_AS_DIG_INPUT|GPIO0_MODE_AS_DIG_INPUT)
	#define     CUS_PADCTL2_VALUE		(GPIO7_MODE_AS_DIG_INPUT|GPIO6_MODE_AS_DIG_INPUT|GPIO5_MODE_AS_DIG_INPUT|GPIO4_MODE_AS_DIG_INPUT)
	#define 	CUS_PADCTL3_VALUE		(GPIO11_MODE_AS_DIG_INPUT|GPIO10_MODE_AS_DIG_INPUT|GPIO9_MODE_AS_DIG_INPUT|GPIO8_MODE_AS_DIG_INPUT)
	#define		CUS_PADCTL4_VALUE		(GPIO15_MODE_AS_DIG_INPUT|GPIO14_MODE_AS_DIG_INPUT|GPIO13_MODE_AS_DIG_INPUT|GPIO12_MODE_AS_DIG_INPUT)

	#define		CUS_PADCTL5_VALUE		(GPIO7_CNF_INPUT_PULLUP|GPIO6_CNF_INPUT_PULLUP|GPIO5_CNF_INPUT_PULLUP|GPIO4_CNF_INPUT_PULLUP|GPIO3_CNF_INPUT_PULLUP|GPIO2_CNF_INPUT_PULLUP|GPIO1_CNF_INPUT_PULLUP|GPIO0_CNF_INPUT_PULLUP)
	#define		CUS_PADCTL6_VALUE		(GPIO15_CNF_INPUT_PULLUP|GPIO14_CNF_INPUT_PULLUP|GPIO13_CNF_INPUT_PULLUP|GPIO12_CNF_INPUT_PULLUP|GPIO11_CNF_INPUT_PULLUP|GPIO10_CNF_INPUT_PULLUP|GPIO9_CNF_INPUT_PULLUP|GPIO8_CNF_INPUT_PULLUP)

	#define		CUS_PADCTL7_VALUE		0
	#define		CUS_PADCTL8_VALUE		0

	#define		CUS_PADCTL9_VALUE		(M_GPIO6_IDR)
	#define		CUS_PADCTL10_VALUE		(M_GPIO14_IDR|M_GPIO11_IDR|M_GPIO9_IDR)

	#define		CUS_PADCTL7_SDN_VALUE	(M_GPIO6_IOC)
	#define		CUS_PADCTL8_SDN_VALUE	(M_GPIO11_IOC|M_GPIO9_IOC)


	#define		CUS_PADCTL11_VALUE		(GPIO7_INPUT_PULLUP_DOWN|GPIO6_INPUT_PULLUP_DOWN|GPIO5_INPUT_PULLUP_DOWN|GPIO4_INPUT_PULLUP_DOWN|GPIO3_INPUT_PULLUP_DOWN|GPIO2_INPUT_PULLUP_DOWN|GPIO1_INPUT_PULLUP_DOWN|GPIO0_INPUT_PULLUP_DOWN)
	#define		CUS_PADCTL12_VALUE		(GPIO15_INPUT_PULLUP_DOWN|GPIO14_INPUT_PULLUP_DOWN|GPIO13_INPUT_PULLUP_DOWN|GPIO12_INPUT_PULLUP_DOWN|GPIO11_INPUT_PULLUP_DOWN|GPIO10_INPUT_PULLUP_DOWN|GPIO9_INPUT_PULLUP_DOWN|GPIO8_INPUT_PULLUP_DOWN)

	#define		CUS_SYSCTL20_VALUE		(GPIO16_MODE_AS_DIG_INPUT|GPIO16_CNF_INPUT_PULLUP|GPIO16_INPUT_PULLUP_DOWN)			

	#define		CUS_D1_LED1_OUT			(GPIO16_MODE_AS_DIG_OUTPUT|GPIO16_CNF_OUTPUT_PUSH_PULL|GPIO16_INPUT_FLOATING)				//output for Active

	//Port Function assign
	#define		LED2					P04
	#define		LED						P04
	
	#define		LED1_H					A7_OUT_H
	#define		LED1_L					A7_OUT_L

	#define		ARM_KEY					P01
	#define		TRUNK_KEY				P02
	#define		DISARM_KEY				P03

	#define		KEY_MASK_VALUE			0x0E

	#define		ARM_KEY_IDR				M_GPIO9_IDR
	#define		TRUNK_KEY_IDR			M_GPIO11_IDR
	#define		DISARM_KEY_IDR			M_GPIO6_IDR

	#define		ARM_KEY_ODR				M_GPIO9_ODR
	#define		TRUNK_KEY_ODR			M_GPIO11_ODR
	#define		DISARM_KEY_ODR			M_GPIO6_ODR

//**************************************** Variable Declaration ********************************************
extern byte 	systimer;
extern byte 	key_value;

extern byte 	lfrx_data_array[8];			// receive array buffer
extern byte 	lfrx_recv_timer;

extern byte bdata	sys_flag_1;
	extern bit	lfrx_receiving_f;					
	extern bit	lfrx_recv_done_f;					

//***************************************** Function Declaration *******************************************
//timer
extern void delay_Nms(byte tmp);
extern void init_timer1(void);
extern void timer1_interrupt_service_routine(void);

//interrupt
extern void clear_interrupt_vector(void);

//uhf tx
extern void assemble_lf_packet(void);
extern void assemble_start_packet(void);
extern void set_tx_modu_config(byte mod);
extern void transmit_packet(void);

//lfrx decode
extern void system_set_lfrx_config(void);
extern void lfrx_data_routine(void) ;
extern void lfrx_init(void);

//main
extern void init_port_mode(void);
extern void init_port_mapping(void);
extern void input_port_ioc(void);
extern void output_port_sdn(void);
extern byte key_scan(void);



//****************************************** interrupt Vecto************************************************
typedef void (*INTERRUPT_SERVICE_ROUTINE)(void);

extern xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt0_service_routine;
extern xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt1_service_routine;
extern xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt2_service_routine;
extern xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt3_service_routine;
extern xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt4_service_routine;
extern xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt5_service_routine;
extern xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt6_service_routine;
extern xdata INTERRUPT_SERVICE_ROUTINE system_external_interrupt7_service_routine;
extern xdata INTERRUPT_SERVICE_ROUTINE system_timer1_interrupt_service_routine;
extern xdata INTERRUPT_SERVICE_ROUTINE system_serial_port0_interrupt_service_routine;

extern byte g_reserved_data_used_by_interrupt_rountine[20];			

	











