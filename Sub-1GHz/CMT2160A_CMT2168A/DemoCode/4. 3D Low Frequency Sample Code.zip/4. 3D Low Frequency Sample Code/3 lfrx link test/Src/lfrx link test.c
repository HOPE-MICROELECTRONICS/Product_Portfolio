#include "lfrx link test.h"

byte 	systimer;
byte 	key_value;

void main(void)
{
 byte tmp;
    
 sys_clear_system_flag();
 sys_set_gpio_hold(GPIO_HOLD_DIS);									

 IEN0 = 0x00;
 IEN1 = 0x00;
 clear_interrupt_vector();
 init_timer1();
 EA = 1;

 init_port_mode();
 init_port_mapping();
 
 LED = 1;
 
 if(sys_is_first_power_up())
    {
   	sys_enable_low_32khz_clock(0);														// lfrx need to enable 32khz clock
    delay_Nms(1);
	           
    sys_set_hv_reg(CUS_SYSCTL11_ADDR, M_LFRX_MANU_CLR, M_LFRX_MANU_CLR);				// set lfrx_manu_clr = 1
	system_set_lfrx_config();															// config lfrx setup 
	
	#ifndef	FLASH_BOOT_DEBUG_MODE
		sys_set_hv_reg(CUS_SYSCTL3_ADDR, M_LFRX_DEBUG_EN, M_LFRX_DEBUG_EN);				// set 1 for 1-wire debug
	#else
	    input_port_ioc();
    	output_port_sdn();												
		sys_shutdown();
    #endif
    }
 
 while(1)
    {

	tmp = sys_read_hv_reg(CUS_SYSCTL12_ADDR);											//read wakeup flag
	
	if(tmp&M_KEY_LAUNCH)																// IOC wakeup?
		{
    	key_value = key_scan();	
    	if(key_value!=0)
    		{ 
 			sys_set_gpio12_out_sel(M_GPIO_SEL_LED_OUT_LV); 								//B4 as LED    	
    		assemble_start_packet();
   			transmit_packet();
  			sys_set_gpio12_out_sel(M_GPIO_SEL_P0_OUT);			
	    	}
	    }	
	else if(tmp&M_WKID_PASS)															// LFRx wakeup ?
	    {
	    lfrx_init();																	// init lfrx interrupt serve

		#ifdef	FLASH_BOOT_DEBUG_MODE
			do																			// wait for lfrx data done
				{
				PCON |= M_IDLE;															// go into idle mode, for power saving
				if(lfrx_recv_done_f)
					break;
				}while(lfrx_recv_timer<3);	
		#else										
			do																			// wait for lfrx data done
				{
				PCON |= M_IDLE;															// go into idle mode, for power saving
				if(lfrx_recv_done_f)
					break;
				}while(1);
		#endif			

		
		if(lfrx_recv_done_f)
			{
			LED = 0;
			delay_Nms(15);

			assemble_lf_packet();
			transmit_packet();
			
			delay_Nms(30);
			LED = 1;
			}
		sys_set_hv_reg(CUS_SYSCTL11_ADDR, M_LFRX_MANU_CLR, M_LFRX_MANU_CLR);	
		delay_Nms(1);																	// wait 
	    }	
	else
		{
		
		}		

    input_port_ioc();
    output_port_sdn();		
    sys_shutdown();		
	}
}

void init_port_mode(void)											
{
 //initial port mode 
 sys_write_hv_reg(CUS_PADCTL1_ADDR, CUS_PADCTL1_VALUE);
 sys_write_hv_reg(CUS_PADCTL2_ADDR, CUS_PADCTL2_VALUE);
 sys_write_hv_reg(CUS_PADCTL3_ADDR, CUS_PADCTL3_VALUE);
 sys_write_hv_reg(CUS_PADCTL4_ADDR, CUS_PADCTL4_VALUE);
 
 sys_write_hv_reg(CUS_PADCTL5_ADDR, CUS_PADCTL5_VALUE);
 sys_write_hv_reg(CUS_PADCTL6_ADDR, CUS_PADCTL6_VALUE);
 
 sys_write_hv_reg(CUS_PADCTL7_ADDR, CUS_PADCTL7_VALUE);
 sys_write_hv_reg(CUS_PADCTL8_ADDR, CUS_PADCTL8_VALUE);

 sys_write_hv_reg(CUS_PADCTL9_ADDR, CUS_PADCTL9_VALUE);
 sys_write_hv_reg(CUS_PADCTL10_ADDR, CUS_PADCTL10_VALUE);
 
 sys_write_hv_reg(CUS_PADCTL11_ADDR, CUS_PADCTL11_VALUE);
 sys_write_hv_reg(CUS_PADCTL12_ADDR, CUS_PADCTL12_VALUE); 
 
 sys_set_hv_reg(CUS_SYSCTL20_ADDR, CUS_SYSCTL20_VALUE, 0x0F);

 //pull-up config
 sys_set_hv_reg(CUS_LFRX4_ADDR, 0, M_PD_PULLUP2);								//enable 500k 
 //sys_set_hv_reg(CUS_LFRX4_ADDR, M_PD_PULLUP2, M_PD_PULLUP2);					//disable 500k 

 sys_set_hv_reg(INT_SYSCTL3_ADDR, M_S3S_DISABLE, M_S3S_DISABLE);				//S3S Disable for use B4 
}



void init_port_mapping(void)						
{
 P0 = 0xFF;											//initial value

 sys_set_hv_reg(CUS_PADCTL2_ADDR, GPIO7_MODE_AS_DIG_OUTPUT, M_GPIO7_MODE);		//LED1 output	
 sys_set_hv_reg(CUS_PADCTL4_ADDR, GPIO12_MODE_AS_DIG_OUTPUT, M_GPIO12_MODE);	//LED2 output
 
 //output assign 
 sys_set_gpio7_out_sel(M_GPIO_SEL_OUT_R); 			// A7 -> GPIO7, LED1
 sys_set_sfr_bank(0);
 LED1_H;

 sys_set_gpio12_out_sel(M_GPIO_SEL_P0_OUT); 		// B4=P04=LED2
 LED = 1;

 //input assign
 sys_set_p0_1_input_from_gpio(9); 					// P01=B1=ARM_KEY
 sys_set_p0_2_input_from_gpio(11);					// P02=B3=TRUNK_KEY
 sys_set_p0_3_input_from_gpio(6);					// P03=A6=DISARM_KEY
}

void input_port_ioc(void)
{
 byte tmp = 0;

 if(ARM_KEY)
  	tmp |= ARM_KEY_IDR;
 if(TRUNK_KEY)
  	tmp |= TRUNK_KEY_IDR;
 sys_set_hv_reg(CUS_PADCTL10_ADDR, tmp, (ARM_KEY_IDR|TRUNK_KEY_IDR)); 
  
 if(tmp!=(TRUNK_KEY_IDR|ARM_KEY_IDR))								//when key is hold, shift to 500k pull-up
  	{
  	tmp ^= 0xFF;
  	tmp &= (TRUNK_KEY_ODR|ARM_KEY_ODR);
  	}
 else
 	tmp = 0;		
 sys_set_hv_reg(CUS_PADCTL12_ADDR, tmp, (TRUNK_KEY_ODR|ARM_KEY_ODR));
 
  
 tmp=0;
 if(DISARM_KEY)
 	tmp |= DISARM_KEY_IDR;
 sys_set_hv_reg(CUS_PADCTL9_ADDR, tmp, DISARM_KEY_IDR); 
 
 if(tmp!=DISARM_KEY_IDR)
 	{
 	tmp ^= 0xFF;
 	tmp &= DISARM_KEY_ODR;
 	}
 else
 	tmp = 0;
 sys_set_hv_reg(CUS_PADCTL11_ADDR, tmp, DISARM_KEY_ODR);
 		
 sys_write_hv_reg(CUS_PADCTL7_ADDR, CUS_PADCTL7_SDN_VALUE);
 sys_write_hv_reg(CUS_PADCTL8_ADDR, CUS_PADCTL8_SDN_VALUE);

 sys_set_hv_reg(CUS_SYSCTL11_ADDR, M_BUT_MANU_CLR, M_BUT_MANU_CLR);		//clear IOC wakeup flag
}

void output_port_sdn(void)								
{				
 sys_set_hv_reg(CUS_PADCTL2_ADDR, GPIO7_MODE_AS_DIG_INPUT, M_GPIO7_MODE);
 sys_set_hv_reg(CUS_PADCTL4_ADDR, GPIO12_MODE_AS_DIG_INPUT, M_GPIO12_MODE);	
}

byte key_scan(void)
{
 byte tmp = 0;
 byte key;
 
 P0 = 0xFF;
 
 for(systimer=0; systimer<5;);						

 if((P0&KEY_MASK_VALUE)==KEY_MASK_VALUE)
 	return(0);
 
 key = P0&KEY_MASK_VALUE;
 
 for(systimer=0; systimer<200;)						//2s for hold key press
 	{
 	delay_Nms(2);
 	tmp = P0&KEY_MASK_VALUE;	
  	if(tmp==KEY_MASK_VALUE)
 		break; 	
	else
		{
		if(key!=tmp)
			key = tmp;
		}
 	}	
 
 tmp  = key^0xFF;
 tmp &= KEY_MASK_VALUE;
 return(tmp);
}

