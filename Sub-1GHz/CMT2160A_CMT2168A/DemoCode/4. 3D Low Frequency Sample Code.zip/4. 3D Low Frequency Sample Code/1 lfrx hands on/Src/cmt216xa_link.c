#include "cmt216xa_types.h"

#define	ROM_API_DATA_USED_START_ADDR			(0x30-2)    // 0x2E,0x2F for storing sp
#define	ROM_API_IDATA_USED_START_ADDR			0x80	    //  8 bytes idata is used
#define ROM_API_XDATA_USED_START_ADDR			0x03F0	    //  16 bytes is used  0x3F0


#define ROM_API_DATA_USED_BYTE_COUNT			(0x10+2)    // 16 bytes + 2bytes for store sp

#define ROM_API_IDATA_USED_BYTE_COUNT			0x08        // 8bytes  0x0080-0x0087

#define ROM_API_XDATA_USED_BYTE_COUNT			0x10        // 16bytes  0x03F0-0x03FF



uint8_t data rom_api_data_used_reserved[ROM_API_DATA_USED_BYTE_COUNT]		_at_ ROM_API_DATA_USED_START_ADDR;

uint8_t idata rom_api_idata_used_reserved[ROM_API_IDATA_USED_BYTE_COUNT]	_at_ ROM_API_IDATA_USED_START_ADDR;

uint8_t xdata rom_api_xdata_used_reserved[ROM_API_XDATA_USED_BYTE_COUNT]	_at_ ROM_API_XDATA_USED_START_ADDR;



