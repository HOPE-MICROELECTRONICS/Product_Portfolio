#ifndef _CMT216XA_H_
#define _CMT216XA_H_
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "intrins.h"
#include "cmt216xa_types.h"
#include "cmt216xa_sfr.h"
#include "cmt216xa_macro.h"


/*
the crc calc config 
*/
typedef struct CRC16_CFG_STRU{
    uint8_t *pbuf;      /* point to the buffer of data which will be crc calc */
    uint16_t data_len;  /* the length of data which will be crc calc */
    uint16_t crc_poly;  /* the crc16 calc poly */
    uint16_t crc_init;  /* the crc16 init value */
    uint8_t bit_order;  /* the bit order of data in crc calc, 0: msb first, 1: lsb first */
}STRU_CRC16_CFG;

/* struct for lfrx setup */
typedef struct LFRX_SETUP_STRU{
    /* lfrx_agc_cfg0
    bit[7:6]: reserved
    bit[5:4]: lfrx_agc_in  AGC Input 
    bit[3:0]: lfrx_agc_vhref 
    */
    uint8_t lfrx_agc_cfg0;
    
    /* lfrx_agc_cfg1
    bit[7:6]: reserved
    bit[5:4]: lfrx_agc_cnt 
    bit[3:0]: lfrx_agc_vlref 
    */
    uint8_t lfrx_agc_cfg1;
    
    /* lfrx_cadet_cfg
    bit[7:6]: lfrx_cadet_win 
    bit[5:4]: lfrx_cadet_ok_cnt 
    bit[3:2]: lfrx_peakdet_clk  
    bit[1:0]: lfrx_data_clk
    */
    uint8_t lfrx_cadet_cfg;
    
    /* lfrx_data_cfg0
    bit[7:6]: lfrx_data_r0
    bit[5:4]: lfrx_data_r1 
    bit[3:2]: lfrx_peakdet_c
    bit[1:0]: lfosc_f_sel
    */
    uint8_t lfrx_data_cfg0;
    
    /* lfrx_data_cfg1
    bit[7:4]: lfrx_data_c1 
    bit[3:0]: lfrx_data_c0 
    */
    uint8_t lfrx_data_cfg1;
    
    /* lfrx_data_cfg2
    bit[7:6]: lfrx_data_c3 
    bit[3:0]: lfrx_data_c2 
    */
    uint8_t lfrx_data_cfg2;
    
    /* lfrx_cmp_cfg0
    bit[7]: lfrx_cmp_noise_mask 
    bit[6]: lfrx_cmp_sw 
    bit[5:3]: lfrx_rssiamp_ibias 
    bit[2:0]: lfrx_pga_ibias
    */
    uint8_t lfrx_cmp_cfg0;
    
    /* lfrx_cmp_cfg1
    bit[7:4]: lfrx_cmp_ref 
    bit[3]: lfrx_demod_th_hold
    bit[2:0]: lfrx_rssirec_ibias
    */
    uint8_t lfrx_cmp_cfg1;
    
    /* lfrx_snrdet_cfg0
    bit[7:6]: lfrx_snrdet_invalid_win
    bit[5:4]: lfrx_snrdet_valid_win 
    bit[3:0]: lfrx_snrdet_snr  
    */
    uint8_t lfrx_snrdet_cfg0;
    
    /* lfrx_ch_cfg
    bit[7]: lfrx_meas_source
    bit[6:5]: lfrx_osc_vref
    bit[4]: lfrx_ch_z
    bit[3]: lfrx_ch_y
    bit[2]: lfrx_ch_x
    bit[1:0]: lfrx_startup_manual
    */
    uint8_t lfrx_ch_cfg;
    
    /* lfrx_mode_cfg
    bit[7:6]: lfrx_mode  
    bit[5]: lfrx_signal_ok_type  
    bit[4:3]: lfrx_timer_extend_mode 
    bit[2]: duty_cycle_method 
    bit[1]: lfrx_duty_cycle_en 
    bit[0]: always_lfrx  
    */
    uint8_t lfrx_mode_cfg;
    
    /* lfrx_timer_cfg0
    bit[7:3]: lfrx_timer_m_rx_t1 
    bit[2:0]: lfrx_timer_r_rx_t1 
    */
    uint8_t lfrx_timer_cfg0;
    
    /* lfrx_timer_cfg1
    bit[7:3]: lfrx_timer_m_rx_t2 
    bit[2:0]: lfrx_timer_r_rx_t2 
    */
    uint8_t lfrx_timer_cfg1;
    
    /* lfrx_timer_cfg2
    bit[7:0]: lfrx_timer_m_sleep
    */
    uint8_t lfrx_timer_cfg2;
    
    /* lfrx_timer_cfg3
    bit[7:6]: reserved
    bit[5]:   lfrx_wakeup_autoclr_dis
    bit[4:3]: lfrx_wakeup_mode  
    bit[2:0]: lfrx_timer_r_sleep  
    */
    uint8_t lfrx_timer_cfg3;
    
    /* lfrx_snrdet_cfg1
    bit[7]: lfrx_rssi_meas_dis 
    bit[6]: lfrx_dbuf_dis
    bit[5:3]: lfrx_snrdet_win 
    bit[2:0]: lfrx_meas_win 0: 
    */
    uint8_t lfrx_snrdet_cfg1;
    
    /* lfrx_packet_cfg0
    bit[7:5]: lfrx_dbuf_length
    bit[4]: lfrx_wkid_en 
    bit[3:2]: lfrx_wkid_length 
    bit[1:0]: lfrx_sync_lenth 
    */
    uint8_t lfrx_packet_cfg0;
    
    /* lfrx_packet_cfg1
    bit[7:6]: lfrx_ant_mode  
    bit[5]: lfrx_hold_rst_sel  
    bit[4]: lfrx_snrdet_refin_sel 
    bit[3]: lfrx_man_type 
    bit[2]: lfrx_wkid_man_en 
    bit[1]: lfrx_dig_dataout_sel
    bit[0]: lfrx_data_man_en 
    */
    uint8_t lfrx_packet_cfg1;
    
    /* lfrx_sync_value_cfg0
    bit[7:0]: lfrx_sync_value[7:0]
    */
    uint8_t lfrx_sync_value_cfg0;
    
    /* lfrx_sync_value_cfg1
    bit[7:0]: lfrx_sync_value[15:8]
    */
    uint8_t lfrx_sync_value_cfg1;
    
    /* lfrx_sync_value_cfg2
    bit[7:0]: lfrx_sync_value[23:16]
    */
    uint8_t lfrx_sync_value_cfg2;
    
    /* lfrx_sync_value_cfg3
    bit[7:0]: lfrx_sync_value[31:24]
    */
    uint8_t lfrx_sync_value_cfg3;
    
    /* lfrx_wkid_value_cfg0
    bit[7:0]: lfrx_wkid_value[7:0]
    */
    uint8_t lfrx_wkid_value_cfg0;
    
    /* lfrx_wkid_value_cfg1
    bit[7:0]: lfrx_wkid_value[15:8]
    */
    uint8_t lfrx_wkid_value_cfg1;
    
    /* lfrx_wkid_value_cfg2
    bit[7:0]: lfrx_wkid_value[23:16]
    */
    uint8_t lfrx_wkid_value_cfg2;
    
    /* lfrx_wkid_value_cfg3
    bit[7:0]: lfrx_wkid_value[31:24]
    */
    uint8_t lfrx_wkid_value_cfg3;
    
    /* lfrx_agc_cfg2
    bit[7]: lfrx_dataout_sel 
    bit[6]: lfrx_decode_seq 
    bit[5]: lfrx_signal_ok_autoclr_dis  
    bit[4]: lfrx_agc_en 
    bit[3]: lfrx_agc_step  
    bit[2:0]: lfrx_agc_cnt_th  
    */
    uint8_t lfrx_agc_cfg2;
    
    /* lfrx_agc_cfg3
    bit[7:4]: lfrx_dqres 
    bit[3:0]: lfrx_agc_min_index  
    */
    uint8_t lfrx_agc_cfg3;
    
    /* lfrx_agc_cfg4
    bit[7:4]: lfrx_dr_sel
    bit[3]: lfrx_clkgate_dis 
    bit[2]: lfrx_enable_mode 
    bit[1]: lfrx_agc_clkgate_dis
    bit[0]: lfrx_agc_start_sel 
    */
    uint8_t lfrx_agc_cfg4;
    
    /* lfrx_cadet_th_h_cfg
    bit[7:0]: lfrx_cadet_th_h 
    */
    uint8_t lfrx_cadet_th_h_cfg;
    
    /* lfrx_cadet_th_l_cfg
    bit[7:0]: lfrx_cadet_th_l  
    */
    uint8_t lfrx_cadet_th_l_cfg;
    
    /* lfrx_signal_ok_clr_th_cfg
    bit[7:0]: lfrx_signal_ok_clr_th 
    */
    uint8_t lfrx_signal_ok_clr_th_cfg;
    
    /* lfrx_data_length_cfg
    bit[7:0]: lfrx_data_length 
    */
    uint8_t lfrx_data_length_cfg;
    
}STRU_LFRX_SETUP;


/*
*  structure for tx modulate setup
*/
typedef struct TX_MODU_SETUP_STRU{
    /*
    mod_cfg define:
        bit[7:4]: reserved
        bit[3]  : ramp_en -- 0: ramp off, 1: ramp on
        bit[2]  : tx_modu -- 0: ook, 1: fsk       
        bit[1]  : freq_dev_inv -- freq deviation control (0:(+f:1,-f:0), 1:(+f:0,-f:1)
        bit[0]  : guass_on -- 0:guass off, 1:guass on
    */
    uint8_t mod_cfg;
    
    /*
    vco_cfg1 define:
        bit[7]  : vco_hband -- pll hband
        bit[6]  : pdcplf_cpbias_code -- charge pump bias current control
        bit[5:4]: divx_code -- pll divider1(/1/2/3)
        bit[3:0]: divx_sel -- pll divider(/1/2/4/8/16)
    */
    uint8_t vco_cfg1;
    
    /*
    vco_cfg0 define:
        bit[7-5]  : reserved        
        bit[4:2]: vco_gain_code -- vco gain code
        bit[1:0]: pll_bw_sel -- pll bandwidth control: 0-300khz, 1-210khz
    */
    uint8_t vco_cfg0;
       
    /* pll n value config */
    uint8_t plln_cfg;       
    
    /* pll k value[15:8] */
    uint8_t pllk_cfg1;
    
    /* pll k value[7:0] */
    uint8_t pllk_cfg0;
    
    /*
    pa_cfg define:
        bit[7:5]: reserved
        bit[4]  : pa_diff_sel -- pa output mode (1:differential mode, 0:single-ended mode)
        bit[3]  : pa_rcramp_selb -- pa ramp rc filter select (1: rc filter is not selected, 0: rc filter is selected) 
        bit[2:0]: pa_ramp_rsel -- select rc filter conrner of pa ramp control (0:640khz, 1:320khz, 2:160khz, 3:80khz,4:40khz, 5:20khz, 6:10khz, 7:5khz)
    */
    uint8_t pa_cfg;     
    
    /* 
    pa_idac_code_cfg define:
        bit[7:6]: reserved
        bit[5:0]: pa_idac_code -- pa current control bits for power control
    */
    uint8_t pa_idac_code_cfg;
    
    /* 
    ramp_step_time_cfg1 define:
        bit[7]  : reserved
        bit[6:0]: ramp step time[14:8]
    */
    uint8_t ramp_step_time_cfg1;
    
    /* ramp step time[7:0] */
    uint8_t ramp_step_time_cfg0;
    
    /* freq deviation[15:8] */
    uint8_t freq_dev_cfg1;
    
    /* freq deviation[7:0] */
    uint8_t freq_dev_cfg0;
    
    /* symbol time[15:8] */
    uint8_t symbol_time_cfg1;
    
    /* symbol time[7:0] */
    uint8_t symbol_time_cfg0;

}STRU_TX_MODU_SETUP;


/* struct for afe front setup */
typedef struct AFE_FRONT_SETUP_STRU{
    /* afe_ia_cfg
    bit[7:6]: reserved
    bit[5]  : afe_ia_vcmx  AFE IA internal VCM output select 0: vdd/2 (default), 1: vdd/10 
    bit[4:3]: afe_oa_vcmx  AFE internal VCM input select 00: vdd/20 (default), 01: vdd/10, 10: vdd/4, 11: vdd/2
    bit[2:1]: afe_oa_outx  AFE IA output signal select for SAR ADC input 00: OA0 output (default), 01: OA1 output, 10: OA2 output, 11: general purpose external input
    bit[0]  : afe_ia1_cx   AFE non-inverted amplification select of the 1st-stage IA  0: enable,  1: disable (default)
    */
    uint8_t afe_ia_cfg;
    
    /* afe_oa0_cfg
    bit[7]  : afe_oa0_ox     AFE OA0 output signal select 0: IA feedback connection (default), 1: output to PAD
    bit[6:5]: afe_oa0_nx     AFE OA0 negative input signal select 00: invalid (default), 01: external input from PAD, 10: IA feedback connection, 11: buffer connection
    bit[4:2]: afe_oa0_px     AFE OA0 positive input signal select 000: invalid (default), 001: general purpose measurement channel, 010: IA feedback connection,011: OA1 output, 100: OA2 output, 101: LBD input, 110: diaga input, 111: internal opamp VCM input
    bit[1:0]: afe_oa0_na_gx  AFE gain setting for OA0 non-inverted amplification 00: invalid (default), 01: x2, 10: x4, 11: x7
    */
    uint8_t afe_oa0_cfg;
    
    /* afe_oa1_cfg
    bit[7]  : sar_direct_dis
    bit[6:5]: afe_oa1_ox     AFE OA1 output signal select 00: invalid (default), 01: output 1 to PAD, 10: output 2 to PAD, 11: IA feedback connection
    bit[4:3]: afe_oa1_nx     AFE OA1 negative input signal select 000: invalid (default), 001: external negative input 1 from PAD, 010: external negative input 2 from PAD, 011:  IA feedback connection, 100:  buffer connection, other: reserved
    bit[2:0]: afe_oa1_px     AFE OA1 positive input signal select 000: invalid (default), 001: external positive input 1 from PAD, 010: external positive input 2 from PAD,011: OA2 output, 100:  internal opamp VCM input, other: reserved
    */
    uint8_t afe_oa1_cfg;
    
    /* afe_oa2_cfg
    bit[7]  : reserved
    bit[6:5]: afe_oa2_ox     AFE OA2 output signal select 00: invalid (default), 01: output 1 to PAD, 10: output 2 to PAD, 11: IA feedback connection
    bit[4:3]: afe_oa2_nx     AFE OA2 negative input signal select 000: invalid (default), 001: external negative input 1 from PAD, 010: external negative input 2 from PAD,011:  IA feedback connection, 100:  buffer connection, other: reserved
    bit[2:0]: afe_oa2_px     AFE OA2 positive input signal select 000: invalid (default), 001: external positive input 1 from PAD, 010: external positive input 2 from PAD,011: OA2 output, 100:  internal opamp VCM input, other: reserved
    */
    uint8_t afe_oa2_cfg;
    
    /* afe_sar_cfg
    bit[7:6]: reserved
    bit[5:2]: sar_inx      SAR ADC general purpose analog input channel select 0000: invalid (default), 0001 - 1001: measurement channel select, other: reserved 
    bit[1:0]: sar_refx     SAR ADC reference voltage select 00: LDO output (2.2 V), 01: Bandgap output (1.2V), 10: external reference w/i buffer, 11: external reference w/o buffer
    */
    uint8_t afe_sar_cfg;
    
    /* afe_sen_chx_cfg
    bit[7:6]: reserved
    bit[5]  : afe_osadj_refx AFE offset calibration reference select signal 1: bandgap (about 1.2V), 0: LDO divider output (default)
    bit[4:3]: afe_te_rbx     AFE bridge resistor select for external temperature 00: invalid (default), 01: 7.0 kohm, 10: 7.5 kohm, 11: 8.0 kohm
    bit[2:0]: afe_sen_chx    AFE sensor channel select 000: invalid (default), 001: external sensor channel 1, 010: external sensor channel 2, 011: internal temperature channel, other: reserved 
    */
    uint8_t afe_sen_chx_cfg;
    
    /*
    bit[7:6]: afe_ia2_gx  AFE gain select of the 1st-stage IA 000: invalid (default), 001: x2, 010: x4, 011: x8, 100: x16, 101: x24, 110: x32, 111: x48
    bit[5:3]: reserved
    bit[2:0]: afe_ia1_gx  AFE gain select of the 2nd-stage IA 00: x1 (default), 01: x1.5, 10: x2, 11: x4
    */
    uint8_t afe_ia_gx_cfg;
    
    /* afe_ldo_cfg
    bit[7:6]: ldo_sar_vo_sel
    bit[5]  : ldo_sar_railb
    bit[4:0]: reserved
    */
    uint8_t afe_ldo_cfg;
    
}STRU_AFE_FRONT_SETUP;

/* struct for afe front power up setup */
typedef struct AFE_FRONT_POWERUP_SETUP_STRU{
    /* afe_front_powerup_cfg0
    bit[7:5]: reserved
    bit[4]  : pd_bg
    bit[3]  : sar_lbd_dis
    bit[2]  : sar_ref_dis
    bit[1]  : pd_ldo_sar
    bit[0]  : pd_afe_vtr
    */
    uint8_t afe_front_powerup_cfg0;
    
    /* afe_front_powerup_cfg1
    bit[7]  : pd_afe_oacmi
    bit[6]  : reserved
    bit[5]  : pd_afe_osadj
    bit[4]  : pd_afe_iacmo
    bit[3]  : pd_sar
    bit[2]  : pd_afe_oa2
    bit[1]  : pd_afe_oa1
    bit[0]  : pd_afe_oa0
    */
    uint8_t afe_front_powerup_cfg1;
    
}STRU_AFE_FRONT_POWERUP_SETUP;

/* struct for afe snooze setup */
typedef struct AFE_SNOOZE_SETUP_STRU{
    /* snooze_timer_m_value
    snooze time = m*2^(r+1) * 31.25 us
    */
    uint8_t snooze_timer_m_value;
    
    /* snooze_timer_r_value
    bit[7:6]: snooze_uth[9:8]     
    bit[5:4]: snooze_dth[9:8]    
    bit[3:0]: snooze timer r value
    */
    uint8_t snooze_timer_r_value;
    
    /* snooze_uth_cfg
    snooze_uth[7:0]
    */
    uint8_t snooze_uth_cfg;
    
    /* afe_oa2_cfg
    snooze_dth[7:0]
    */
    uint8_t snooze_dth_cfg;
    
    /* snooze_wakeup_cfg
    bit[7:4]: reserved
    bit[3]  : dwth_wk_en
    bit[2]  : upth_wk_en
    bit[1]  : wout_wk_en
    bit[0]  : win_wk_en
    */
    uint8_t snooze_wakeup_cfg;
      
}STRU_AFE_SNOOZE_SETUP;


/* struct spi_setup */
typedef struct SPI_SETUP_STRU{
    /* spi_cfg0 define
    bit[7]: bidi_mode  0: 2-line unidir mode, 1: 1-line bidir mode
    bit[6]: bidi_oe    0: bidir mode output disabled (rx-only), 1: bidir mode output enabled (tx-only) 
    bit[5]: rx_only    0: unidir mode full duplex (rx and tx), 1: unidir mode output disabled (rx-only)    
    bit[4]: dff        0: 8-bit data frame, 1: 16-bit data frame
    bit[3]: txdmaen    0: tx buffer dma disabled, 1: tx buffer dma enabled
    bit[2]: ssoe       0: NSS output disabled in master mode, 1: NSS output enabled in master mode
    bit[1]: ssm        0: software control slave NSS disabed, 1: software control slave NSS enabled (NSS = SSI)       
    bit[0]: ssi        used to replace NSS in software control slave NSS mode 
    */
    uint8_t spi_cfg0;
    
    /* spi_cfg1 define
    bit[7]  : lsb_first  0: MSB transmitted first, 1: LSB transmitted first 
    bit[6]  : reserved
    bit[3:5]: br         SPI baud rate, clk_per divided by 0: 2, 1: 8, 2: 16, 3: 24, 4: 32, 5: 64, 6: 128, 7: 256  
    bit[2]  : mstr       0: slave mode, 1: master mode
    bit[1]  : cpol       0: SCK is 0 when IDEL, 1: SCK is 1 when IDLE
    bit[0]  : cpha       0: first SCK edge to capture first data bit, 1: second SCK edge to capture first data bit
    */
    uint8_t spi_cfg1;
    
} STRU_SPI_SETUP;



// system
/**********************************************************************************************************
/**********************************************************************************************************
*@name:    sys_delay_10_cpu_clock_cycle
*@desc:    delay 10 mcu clk cycle  
*@param:   none 
*@return:  none
***********************************************************************************************************/
void sys_delay_10_cpu_clock_cycle(void);

/**********************************************************************************************************
*@name:    sys_delay_times_cpu_clks_cycle
*@desc:    delay times(30 clks * times_clks) mcu clk cycle  
*@param:   
*     ten_times_clks: delay mcu clk cycles (actual delay cycles = 30 * times_clks) 
*@return:  none
***********************************************************************************************************/
void sys_delay_times_cpu_clks_cycle(uint16_t times_clks);

/**********************************************************************************************************
*@name:    sys_set_mcu_to_stop_state
*@desc:    set mcu into stop state(clk_mcu and clk_perih are stoped); only int0/int1 interrupt can wakeup 
*           mcu again  
*@param:   none
*@return:  none
***********************************************************************************************************/
void sys_set_mcu_to_stop_state(void);

/**********************************************************************************************************
*@name:    sys_set_mcu_to_idle_state
*@desc:    set mcu into idle state(clk_mcu is stoped,but clk_perih are running); any interrupt can wakeup
*            mcu again 
*@param:   none
*@return:  none
***********************************************************************************************************/
void sys_set_mcu_to_idle_state(void);

/**********************************************************************************************************
*@name:    sys_write_hv_reg
*@desc:    write the value to hv sfr  
*@param:   
*    addr: the hv sfr address
*    val : the value will be written to hv sfr
*@return:  none
***********************************************************************************************************/
void sys_write_hv_reg(uint8_t addr, uint8_t val);

/**********************************************************************************************************
*@name:    sys_read_hv_reg
*@desc:    read the value from hv sfr  
*@param:   
*    addr: the hv sfr address
*@return:  the value of hv sfr
***********************************************************************************************************/
uint8_t sys_read_hv_reg(uint8_t addr);

/**********************************************************************************************************
*@name:    sys_set_hv_reg
*@desc:    set the value of some bits to hv reg; if you write 3 to bit[6:4] of hv reg(addr: 0x05), you must call 
*          this function by the way of sys_set_hv_reg(0x05, (3 << 4), 0x70).  
*@param:   
*    addr: the hv sfr address
*    val:  the value will be set to map bits
*    mask: the mask of bits to hv reg
*@return:  the value of hv sfr
***********************************************************************************************************/
void sys_set_hv_reg(uint8_t addr, uint8_t val, uint8_t mask);

/**********************************************************************************************************
*@name:    sys_delay_us_count
*@desc:    delay the count of us ( max 255) 
*@param:   
*      count: the count of  us will be delayed 
*@return:  none
***********************************************************************************************************/
void sys_delay_us_count(uint8_t count);

/**********************************************************************************************************
*@name:    sys_shutdown
*@desc:    set por_done = 1, and shutdown the lv domain
*@param:   none
*@return:  none
***********************************************************************************************************/
void sys_shutdown(void);

/**********************************************************************************************************
*@name:    sys_select_dldo_voltage
*@desc:    select dldo voltage for low power consumption 
*@param:   
*     dldo_vol: 0:0.8v 1:0.9v 2:1.0v 3:1.2v
*@return:  none
************************************************************************************************************/
void sys_select_dldo_voltage(uint8_t dldo_vol);


/**********************************************************************************************************
*@name:    sys_enable_afe_snooze
*@desc:    enable afe snooze
*@param:   none
*@return:  none 
***********************************************************************************************************/
void sys_enable_afe_snooze(void);

/**********************************************************************************************************
*@name:    sys_disable_afe_snooze
*@desc:    disable afe snooze
*@param:   none
*@return:  none 
***********************************************************************************************************/
void sys_disable_afe_snooze(void);

/**********************************************************************************************************
*@name:    sys_set_main_state
*@desc:    set state to SFR MAIN_STATE
*@param:   
*      state: the state will be set to SFR MAIN_STATE 
*@return:  none  
***********************************************************************************************************/
void sys_set_main_state(uint8_t state);

/**********************************************************************************************************
*@name:    sys_set_hfosc_clk_sel
*@desc:    set the value of hfosc_clk_sel
*@param:   
*      hfosc_clk_sel: the value will be set, must be HFOSC_CLK_SEL_48MHZ or HFOSC_CLK_SEL_24MHZ or 
*                     HFOSC_CLK_SEL_12MHZ or HFOSC_CLK_SEL_3MHZ
*@return:  none  
***********************************************************************************************************/
void sys_set_hfosc_clk_sel(uint8_t hfosc_clk_sel);

/**********************************************************************************************************
*@name:    sys_set_system_clk_divider
*@desc:    set the value of clk_sys_div
*@param:   
* clk_sys_div: the value will be set to clk_sys_div, must smaller than 16
*@return:  none  
***********************************************************************************************************/
void sys_set_system_clk_divider(uint8_t clk_sys_div);

/**********************************************************************************************************
*@name:    sys_set_external_interrupt0_config
*@desc:    set the trigger method and sources for external interrupt 0
*@param:   
*      cfg: the config value for external interrupt 0
*        bit[7]  : reserved
*        bit[6]  : the trigger method of external interrupt 0; 
*                  0: low level or falling edge (up to IT0; low level when IT0=0, falling edge when IT0=1)
*                  1: high level or rising edge (up to IT0; high level when IT0=0, rising edge when IT0=1)
*        bit[5:0]: the sources for external interrupt 0
*@return:  none  
***********************************************************************************************************/
void sys_set_external_interrupt0_config(uint8_t cfg);

/**********************************************************************************************************
*@name:    sys_set_external_interrupt1_config
*@desc:    set the trigger method and sources for external interrupt 1
*@param:   
*      cfg: the config value for external interrupt 1
*        bit[7]  : reserved
*        bit[6]  : the trigger method of external interrupt 1; 
*                  0: low level or falling edge (up to IT0; low level when IT0=0, falling edge when IT0=1)
*                  1: high level or rising edge (up to IT0; high level when IT0=0, rising edge when IT0=1)
*        bit[5:0]: the sources for external interrupt 1
*@return:  none  
***********************************************************************************************************/
void sys_set_external_interrupt1_config(uint8_t cfg);

/**********************************************************************************************************
*@name:    sys_set_external_interrupt2_config
*@desc:    set the trigger method and sources for external interrupt 2
*@param:   
*      cfg: the config value for external interrupt 2
*        bit[7]  : reserved
*        bit[6]  : the trigger method of external interrupt 2 (0: falling edge, 1: rising edge) 
*        bit[5:0]: the sources for external interrupt 2
*@return:  none  
***********************************************************************************************************/
void sys_set_external_interrupt2_config(uint8_t cfg);

/**********************************************************************************************************
*@name:    sys_set_external_interrupt3_config
*@desc:    set the trigger method and sources for external interrupt 3
*@param:   
*      cfg: the config value for external interrupt 3
*        bit[7]  : reserved
*        bit[6]  : the trigger method of external interrupt 3 (0: falling edge, 1: rising edge) 
*        bit[5:0]: the sources for external interrupt 3
*@return:  none  
***********************************************************************************************************/
void sys_set_external_interrupt3_config(uint8_t cfg);

/**********************************************************************************************************
*@name:    sys_set_external_interrupt4_config
*@desc:    set the trigger method and sources for external interrupt 4
*@param:   
*      cfg: the config value for external interrupt 4
*        bit[7]  : reserved
*        bit[6]  : the trigger method of external interrupt 4 (0: falling edge, 1: rising edge) 
*        bit[5:0]: the sources for external interrupt 4
*@return:  none  
***********************************************************************************************************/
void sys_set_external_interrupt4_config(uint8_t cfg);

/**********************************************************************************************************
*@name:    sys_set_external_interrupt5_config
*@desc:    set the trigger method and sources for external interrupt 5
*@param:   
*      cfg: the config value for external interrupt 5
*        bit[7]  : reserved
*        bit[6]  : the trigger method of external interrupt 5 (0: falling edge, 1: rising edge) 
*        bit[5:0]: the sources for external interrupt 5
*@return:  none  
***********************************************************************************************************/
void sys_set_external_interrupt5_config(uint8_t cfg);

/**********************************************************************************************************
*@name:    sys_set_external_interrupt6_config
*@desc:    set the trigger method and sources for external interrupt 6
*@param:   
*      cfg: the config value for external interrupt 6
*        bit[7]  : reserved
*        bit[6]  : the trigger method of external interrupt 6 (0: falling edge, 1: rising edge) 
*        bit[5:0]: the sources for external interrupt 6
*@return:  none  
***********************************************************************************************************/
void sys_set_external_interrupt6_config(uint8_t cfg);

/**********************************************************************************************************
*@name:    sys_set_external_interrupt7_config
*@desc:    set the trigger method and sources for external interrupt 7
*@param:   
*      cfg: the config value for external interrupt 7
*        bit[7]  : reserved
*        bit[6]  : the trigger method of external interrupt 7 (0: falling edge, 1: rising edge) 
*        bit[5:0]: the sources for external interrupt 7
*@return:  none  
***********************************************************************************************************/
void sys_set_external_interrupt7_config(uint8_t cfg);

/**********************************************************************************************************
*@name:    sys_set_gpio_hold
*@desc:    enable or disable gpio hold
*@param:   
*   gpio_hold: GPIO_HOLD_ENA -- enable gpio hold, GPIO_HOLD_DIS -- disable gpio hold 
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio_hold(uint8_t gpio_hold);

/**********************************************************************************************************
*@name:    sys_enable_sleep_timer
*@desc:    enable sleep timer
*@param:   none 
*@return:  none  
***********************************************************************************************************/
void sys_enable_sleep_timer(void);

/**********************************************************************************************************
*@name:    sys_disable_sleep_timer
*@desc:    disable sleep timer
*@param:   none 
*@return:  none  
***********************************************************************************************************/
void sys_disable_sleep_timer(void);

/**********************************************************************************************************
*@name:    sys_set_sleep_timer_working_mode
*@desc:    set sleep timer working mode
*@param:   
*     working_mode: SLEEP_TIMER_RTC_MODE(0) or SLEEP_TIMER_WAKEUP_MODE(0x20)
*           SLEEP_TIMER_RTC_MODE:   in this mode, whenever mcu is in sleep state or in working state, the sleep
*                                   timer can work aways
*           SLEEP_TIMER_WAKEUP_MODE: in this mode, sleep timer only work at mcu in sleep state 
*@return:  none  
***********************************************************************************************************/
void sys_set_sleep_timer_working_mode(uint8_t working_mode);

/**********************************************************************************************************
*@name:    sys_set_sleep_timer_m_r_value
*@desc:    set sleep timer m[11:0] value and r[3:0] value; real sleep time = m * 2^(r+1) * 31.25 us
*@param:   
*     m_value: the low byte value of m
*     r_value: the highest half byte of m value and r value
*         bit[7:4]: the highest half byte of m value
*         bit[3:0]: the r value
*@return:  none  
***********************************************************************************************************/
void sys_set_sleep_timer_m_r_value(uint8_t m_value, uint8_t r_value);

/**********************************************************************************************************
*@name:    sys_set_afe_sensor_channel
*@desc:    set AFE sensor channel
*@param:   
*     chnn: afe sensor channel 
*          000: invalid (default)
*          001: external sensor channel 1 
*          010: external sensor channel 2
*          011: internal temperature channel
*@return:  none  
***********************************************************************************************************/
void sys_set_afe_sensor_channel(uint8_t chnn);

/**********************************************************************************************************
*@name:    sys_set_sfr_bank
*@desc:    set sfr bank to bank0 or bank1
*@param:   
*     bank: 0 -- set sfr bank to bank0; 1 -- set sfr bank to bank1 
*@return:  none  
***********************************************************************************************************/
void sys_set_sfr_bank(uint8_t bank);

/**********************************************************************************************************
*@name:    sys_get_sfr_bank
*@desc:    get the sfr bank value
*@param:   none
*@return:  the sfr bank value
*          0: sfr bank0
*          1: sfr bank1  
***********************************************************************************************************/
uint8_t sys_get_sfr_bank(void);

/**********************************************************************************************************
*@name:    sys_wait_tx_stop_done
*@desc:    wait for tx stop done
*@param:   none
*@return:  none
***********************************************************************************************************/
void sys_wait_tx_stop_done(void);

/**********************************************************************************************************
*@name:    sys_start_stop_supply_voltage_supervision
*@desc:    start or stop supervise the supply voltage of system.
*@param:   
*     cfg: the config for superising the supply voltage of system
*       bit[7:3]: reserved
*       bit[2]  : the threshold of superisory voltage(0:1.8v, 1:2.0v)
*       bit[1]  : the power reset setting(1:power reset system when system voltage is lower than the threshold 
*                 superisory voltage, 0: do not power reset system when system voltage is lower than the threshold
*                 superisory voltage)
*       bit[0]  : 1 -- start to supervise the supply voltage of system, 0 -- stop supervising the supply voltage
*                 superisory voltage
*@return:  none
***********************************************************************************************************/
void sys_start_stop_supply_voltage_supervision(uint8_t cfg);

/**********************************************************************************************************
*@name:    sys_read_result_from_supply_voltage_supervision
*@desc:    read the result from supply voltage superision, and clear the voltage superision flag
*@param:   none 
*@return:  the result from supply boltage superision
*       0: system voltage is higher than the threshold of superisory voltage  
*       1: system voltage is lower than the threshold of superisory voltage
***********************************************************************************************************/
uint8_t sys_read_result_from_supply_voltage_supervision(void);

/**********************************************************************************************************
*@name:    sys_disable_pll_module
*@desc:    disable pll module
*@param:   none 
*@return:  none  
***********************************************************************************************************/
void sys_disable_pll_module(void);

/**********************************************************************************************************
*@name:    sys_check_pll_is_locked_or_not
*@desc:    check pll is locked or not
*@param:   none 
*@return:  
*      0: pll is not locked
*      1: pll is locked  
***********************************************************************************************************/
uint8_t sys_check_pll_is_locked_or_not(void);


/**********************************************************************************************************
*@name:    sys_enable_xo_crystal
*@desc:    enable xo crystal and wait stable
*@param:   none 
*@return:  none  
***********************************************************************************************************/
void sys_enable_xo_crystal(void);

/**********************************************************************************************************
*@name:    sys_disable_xo_crystal
*@desc:    disable xo crystal
*@param:   none 
*@return:  none  
***********************************************************************************************************/
void sys_disable_xo_crystal(void);

/**********************************************************************************************************
*@name:    sys_enable_low_32khz_clock
*@desc:    enable 32khz low clock
*@param:   
*     source: the 32khz clock source select (0: lfosc, other: lfxo) 
*@return:  none
***********************************************************************************************************/
void sys_enable_low_32khz_clock(uint8_t source);

/**********************************************************************************************************
*@name:    sys_enable_lfxo_crystal
*@desc:    enable 32khz lfxo clock
*@param:   
* lfxo_ibias_code: the greater the lfxo ibias code, the faster the lfox starting, but the greater the current too(0~31)
*@return:  none
***********************************************************************************************************/
void sys_enable_lfxo_crystal(uint8_t lfxo_ibias_code);

/**********************************************************************************************************
*@name:    sys_disable_low_32khz_clock
*@desc:    diable 32khz low clock (disable lfxo and lfosc)
*@param:   none
*@return:  none
***********************************************************************************************************/
void sys_disable_low_32khz_clock(void);

/**********************************************************************************************************
*@name:    sys_is_first_power_up
*@desc:    check is first power up or not
*@param:   none
*@return:  1 - is the first power up, 0 - is not the first power up
***********************************************************************************************************/
uint8_t sys_is_first_power_up(void);

/**********************************************************************************************************
*@name:    sys_enable_led_flash
*@desc:    enable or disable led flash
*@param:   
*   led_cfg: the led config
*       bit[7]  : reserved
*       bit[6]  : led_on (0:disable led, 1: enable led)
*       bit[5]  : led_out_sel(0: led signal is from tx data, 1: led signal is from pwm signal)
*       bit[4]  : pwm output rate (0:3.3khz, 1:6.68khz)
*       bit[3:0]: pwm interval select when pwm output rate is 6.68khz(0:1/16, 1:2/16, ... , 15: 16/16)
*@return:  none
***********************************************************************************************************/
void sys_enable_led_flash(uint8_t led_cfg);


/**********************************************************************************************************
*@name:    sys_get_product_id
*@desc:    get product id
*@param:   none
*@return:  product id 
***********************************************************************************************************/
uint16_t sys_get_product_id(void);

/**********************************************************************************************************
*@name:    sys_get_uuid
*@desc:    get uuid
*@param:   
*     uuid: point to buffer which is stored uuid data
*@return:  none  
***********************************************************************************************************/
void sys_get_uuid(uint8_t xdata *uuid);

/**********************************************************************************************************
*@name:    sys_push_bank0_r0_2_r7_to_stack
*@desc:    push r0 ~ r7 of bank0 to stack
*@param:   none
*@return:  none 
***********************************************************************************************************/
void sys_push_bank0_r0_2_r7_to_stack(void);

/**********************************************************************************************************
*@name:    sys_pop_bank0_r7_2_r0_from_stack
*@desc:    pop r7 ~ r0 of bank0 from stack
*@param:   none
*@return:  none 
***********************************************************************************************************/
void sys_pop_bank0_r7_2_r0_from_stack(void);

/**********************************************************************************************************
*@name:    sys_store_hv_interface
*@desc:    store hv reg interface
*@param:   none
*@return:  the hv interface value which is stored
***********************************************************************************************************/
uint8_t sys_store_hv_interface(void);

/**********************************************************************************************************
*@name:    sys_restore_hv_interface
*@desc:    restore hv reg interface
*@param:   
*     hv_store: the value which is restore to hv interface
*@return:  none 
***********************************************************************************************************/
void sys_restore_hv_interface(uint8_t hv_store);

/**********************************************************************************************************
*@name:    sys_set_gpio0_out_sel
*@desc:    set which port output via gpio0 when gpio0 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.0, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov) 
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio0_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio1_out_sel
*@desc:    set which port output via gpio1 when gpio1 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.1, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio1_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio2_out_sel
*@desc:    set which port output via gpio2 when gpio2 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.2, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio2_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio3_out_sel
*@desc:    set which port output via gpio3 when gpio3 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.3, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio3_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio4_out_sel
*@desc:    set which port output via gpio4 when gpio4 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.4, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio4_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio5_out_sel
*@desc:    set which port output via gpio5 when gpio5 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.5, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov) 
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio5_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio6_out_sel
*@desc:    set which port output via gpio6 when gpio6 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.6, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio6_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio7_out_sel
*@desc:    set which port output via gpio7 when gpio7 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.7, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov) 
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio7_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio8_out_sel
*@desc:    set which port output via gpio8 when gpio8 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.0, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio8_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio9_out_sel
*@desc:    set which port output via gpio9 when gpio9 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.1, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio9_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio10_out_sel
*@desc:    set which port output via gpio10 when gpio10 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.2, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio10_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio11_out_sel
*@desc:    set which port output via gpio11 when gpio11 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.3, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio11_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio12_out_sel
*@desc:    set which port output via gpio12 when gpio12 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.4, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio12_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio13_out_sel
*@desc:    set which port output via gpio13 when gpio13 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.5, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio13_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio14_out_sel
*@desc:    set which port output via gpio14 when gpio14 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.6, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio14_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_set_gpio15_out_sel
*@desc:    set which port output via gpio15 when gpio15 as an output pin
*@param:   
*     gpio_out_sel:the gpio output select 
*            bit[7:4]: reserved
*            bit[3:0]: (0:gpio0_out_r, 1:p0.7, 2:tb_out0, 3:tb_out1, 4:tb_out2, 5:nss_out, 6:sck_out, 7:miso_out,
*            8:mosi_out, 9:rxd0_out, 10:txd0, 11:ta_out0, 12:ta_out1, 13:ta_out2, 14:led_out_lv, 15:t1_ov)  
*@return:  none  
***********************************************************************************************************/
void sys_set_gpio15_out_sel(uint8_t gpio_out_sel);

/**********************************************************************************************************
*@name:    sys_get_input_value_from_gpio0_7
*@desc:    get gpio input value when gpio as an input pin
*@param:   none
*@return:  the gpio input value(bit0:gpio0, bit1:gpio1, ..., bit7:gpio7)  
***********************************************************************************************************/
uint8_t sys_get_input_value_from_gpio0_7(void);

/**********************************************************************************************************
*@name:    sys_get_input_value_from_gpio8_15
*@desc:    get gpio input value when gpio as an input pin
*@param:   none
*@return:  the gpio input value(bit0:gpio8, bit1:gpio9, ..., bit7:gpio15)  
***********************************************************************************************************/
uint8_t sys_get_input_value_from_gpio8_15(void);

/**********************************************************************************************************
*@name:    sys_set_output_value_to_gpio0_7
*@desc:    set the value for gpio when gpio as an output pin
*@param:   
*    gpio_value: the gpio output value(bit0:gpio0, bit1:gpio1, ..., bit7:gpio7) 
*@return:  none 
***********************************************************************************************************/
void sys_set_output_value_to_gpio0_7(uint8_t gpio_value);

/**********************************************************************************************************
*@name:    sys_set_output_value_to_gpio8_15
*@desc:    set the value for gpio when gpio as an output pin
*@param:   
*    gpio_value: the gpio output value(bit0:gpio8, bit1:gpio9, ..., bit7:gpio15) 
*@return:  none 
***********************************************************************************************************/
void sys_set_output_value_to_gpio8_15(uint8_t gpio_value);

/**********************************************************************************************************
*@name:    sys_get_output_value_from_gpio0_7
*@desc:    get the output value from gpio when gpio as an output pin
*@param:   none 
*@return:  the gpio output value(bit0:gpio0, bit1:gpio1, ..., bit7:gpio7) 
***********************************************************************************************************/
uint8_t sys_get_output_value_from_gpio0_7(void);

/**********************************************************************************************************
*@name:    sys_get_output_value_from_gpio8_15
*@desc:    get the output value from gpio when gpio as an output pin
*@param:   none 
*@return:  the gpio output value(bit0:gpio8, bit1:gpio9, ..., bit7:gpio15) 
***********************************************************************************************************/
uint8_t sys_get_output_value_from_gpio8_15(void);

/**********************************************************************************************************
*@name:    sys_set_p0_0_input_from_gpio
*@desc:    set the input of p0.0 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_p0_0_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_p0_1_input_from_gpio
*@desc:    set the input of p0.1 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_p0_1_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_p0_2_input_from_gpio
*@desc:    set the input of p0.2 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_p0_2_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_p0_3_input_from_gpio
*@desc:    set the input of p0.3 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_p0_3_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_p0_4_input_from_gpio
*@desc:    set the input of p0.4 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_p0_4_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_p0_5_input_from_gpio
*@desc:    set the input of p0.5 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_p0_5_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_p0_6_input_from_gpio
*@desc:    set the input of p0.6 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_p0_6_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_p0_7_input_from_gpio
*@desc:    set the input of p0.7 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_p0_7_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_uart_rxd_input_from_gpio
*@desc:    set the input of uart rxd is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_uart_rxd_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_timer1_input_from_gpio
*@desc:    set the input of timer 1 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_timer1_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_timer_a_cci0_input_from_gpio
*@desc:    set the input of timer a cci0 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_timer_a_cci0_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_timer_a_cci1_input_from_gpio
*@desc:    set the input of timer a cci1 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_timer_a_cci1_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_timer_b_cci0_input_from_gpio
*@desc:    set the input of timer b cci0 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_timer_b_cci0_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_timer_b_cci1_input_from_gpio
*@desc:    set the input of timer b cci1 is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_timer_b_cci1_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_spi_nss_input_from_gpio
*@desc:    set the input of spi nss is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_spi_nss_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_spi_sck_input_from_gpio
*@desc:    set the input of spi sck is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_spi_sck_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_spi_miso_input_from_gpio
*@desc:    set the input of spi miso is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_spi_miso_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_set_spi_mosi_input_from_gpio
*@desc:    set the input of spi mosi is from which gpio
*@param:   
*    gpio_num: (0:gpio0, 1: gpio1, ..., 15:gpio15, other:invalid) 
*@return:  none 
***********************************************************************************************************/
void sys_set_spi_mosi_input_from_gpio(uint8_t gpio_num);

/**********************************************************************************************************
*@name:    sys_change_system_main_clock
*@desc:    change system main clock (1: xo crystal, 0:hfosc clk)
*@param:   
*    clk_sw: (1: xo crystal, 0:hfosc clk)
*@return:  none 
***********************************************************************************************************/
void sys_change_system_main_clock(uint8_t clk_sw);

/**********************************************************************************************************
*@name:    sys_get_lfrx_state
*@desc:    get lfrx state
*@param:   none
*@return:  lfrx state (0:idle, 1: mode_sel, 2:listen, 3:sleep, 6:decode) 
***********************************************************************************************************/
uint8_t sys_get_lfrx_state(void);

/**********************************************************************************************************
*@name:    sys_get_random_data
*@desc:    get random data
*@param:   
*    random_data: point to buffer which is stored random data 
*    byte_cnt:    the count of random data 
*@return:  none
************************************************************************************************************/
void sys_get_random_data(uint8_t xdata *random_data, uint8_t byte_cnt);


/**********************************************************************************************************
*@name:    sys_clear_system_flag
*@desc:    this function clear some system flag(very important) at mcu starting running. so function will be 
*          called when mcu starting running 
*@param:   none
*@return:  none
************************************************************************************************************/
void sys_clear_system_flag(void);


/**********************************************************************************************************
*@name:    sys_crc16_calc
*@desc:    this function implements crc16 calc  
*@param:   
*    crc_cfig: point to crc config
*                    (
                      *pbuf: point to the buffer of data which will be crc calc 
                      data_len: the length of data which will be crc calc 
                      crc_poly: the crc16 calc poly
                      crc_init: crc init value
                      bit_order: the bit order of data in crc calc, 0: msb first, 1: lsb first
*                     )
*@return:  crc calc result
*
*example:
* crc16_ccitt(x16+x12+x5+1, crc_poly=0x1021, crc_init=0x0000, bit_order=1)
* crc16_ccitt_false(x16+x12+x5+1, crc_poly=0x1021, crc_init=0xffff, bit_order=0)
* crc16_ibm(x16+x15+x2+1, crc_poly=0x8005, crc_init=0x0000, bit_order=1)
************************************************************************************************************/
uint16_t sys_crc16_calc(STRU_CRC16_CFG *cfg);

/**********************************************************************************************************
*@name:    sys_get_differential_pa_calibration_capacitor_code
*@desc:    get capacitor code of differential pa calibration 
*@param:   
*    pa_power_code:    pa power code 
*    pa_idac_code:     pa idac code 
*@return:  pa calibration capacitor code 
************************************************************************************************************/
uint8_t sys_get_differential_pa_calibration_capacitor_code(uint8_t pa_power_code, uint8_t pa_idac_code);


// mctl 
/**********************************************************************************************************
*@name:    mctl_set_source_addr
*@desc:    set source addr of mctl  
*@param:   
*    src_addr:    the source addr of mctl memory data 
*@return:  none
************************************************************************************************************/
void mctl_set_source_addr(uint16_t src_addr);

/**********************************************************************************************************
*@name:    mctl_set_destion_addr
*@desc:    set destion addr of mctl  
*@param:   
*    dest_addr:    the destion addr of pram/xram/iram memory data  
*@return:  none
************************************************************************************************************/
void mctl_set_destion_addr(uint16_t dest_addr);

/**********************************************************************************************************
*@name:    mctl_set_copy_size
*@desc:    set size of mctl data which will be copied 
*@param:   
*    copy_size:    size of mctl data which will be copied  
*@return:  none
************************************************************************************************************/
void mctl_set_copy_size(uint16_t copy_size);

/**********************************************************************************************************
*@name:    mctl_start_operation_and_wait_done
*@desc:    start the memory operation and wait done(pram/xram/iram) 
*@param:   
*    mem_cmd:    memory type(MCTL_CMD_WPRAM/MCTL_CMD_WXRAM/MCTL_CMD_WIRAM)
*@return:  none
************************************************************************************************************/
void mctl_start_operation_and_wait_done(uint8_t mem_cmd);



// AES
/**********************************************************************************************************
*@name:    aes_generate_decrypted_key
*@desc:    implements aes generate decrypt key
*@param:   
*    ptr_encrypt_key: input aes encryption key and output aes decryption key which is used for aes decryption 
*@return:  none
************************************************************************************************************/
void aes_generate_decrypted_key(uint8_t idata *ptr_encrypt_key);

/**********************************************************************************************************
*@name:    aes_encryption
*@desc:    implements aes data encryption
*@param:   
*    ptr_aes_data: input plain text and output encrypted data
*    ptr_encrypt_key:  input aes encryption key  which is used for aes encryption and output unused data
*@return:  none
************************************************************************************************************/
void aes_encryption(uint8_t idata *ptr_aes_data,uint8_t idata *ptr_encrypt_key);

/**********************************************************************************************************
*@name:    aes_decryption
*@desc:    implements aes data decryption
*@param:   
*    ptr_decrypt_data: input encrypted data and output decrypted data
*    ptr_decrypt_key: input aes decryption key  which is used for aes  decryption and output unused data
*@return:  none
************************************************************************************************************/
void aes_decryption(uint8_t idata *ptr_decrypt_data, uint8_t idata *ptr_decrypt_key); 


// eeprom
/**********************************************************************************************************
*@name: eeprom_write_words
*@desc: write buffer data(in xdata) to eeprom(erase + program)
*@param:   
*   start_addr: write eeprom(eeprom) start addr, must be smaller than 0x20, or else will occur unexpected error
*   write_buf : (pointer to BYTE in xdata)pointer to data buffer which will be write to eeprom(MSB)
*   eeprom_size  : write eeprom size(word), (start_addr + eeprom_size) must be not larger than 0x20, or else will 
*               occur unexpected error
*@return: 
*       0: write eeprom successfully
*       1: erase eeprom failed
*       2: program eeprom failed    
***********************************************************************************************************/
uint8_t eeprom_write_words(uint8_t start_addr, uint8_t xdata *write_buf, uint8_t eeprom_size);

/**********************************************************************************************************
*@name:    eeprom_read_words
*@desc:    read eeprom content to buffer data(in xdata)  
*@param:  
*   start_addr: read eeprom(eeprom) start addr, must be smaller than 0x20, or will occur unexpected error 
*   read_buf  : (pointer to BYTE in xdata)pointer to data buffer which will be read from eeprom(MSB first) 
*   eeprom_size  : read eeprom size(word), (start_addr + eeprom_size) must be not larger than 0x20, or else will 
*               occur unexpected error
*@return: 
*       0: read eeprom successfully
*       1: read eeprom failed   
***********************************************************************************************************/
uint8_t eeprom_read_words(uint8_t start_addr, uint8_t xdata *read_buf, uint8_t eeprom_size);

/**********************************************************************************************************
*@name: eeprom_set_dec_count
*@desc: set a decimal value to index counter(gray format, *dec_value <= 0x3f0000) 
*@param:   
*  index:     must be 0 3 6 9, ... , or else will occur unexpected error
*  dec_value: point to a decimal value which will be written to eeprom(gray format)
*@return: 
*@return: 
*       0: write eeprom successfully
*       1: erase eeprom failed
*       2: program eeprom failed 
***********************************************************************************************************/
uint8_t eeprom_set_dec_count(uint8_t index, uint32_t *dec_value);

/**********************************************************************************************************
*@name: eeprom_get_dec_count
*@desc: get a decimal value from index counter 
*@param:   
*  index:      must be 0 3 6 9, ... , or else will occur unexpected error
*  dec_value: point to a decimal value which will be read from eeprom
*@return: 
*       0: read eeprom successfully
*       1: read eeprom failed  
***********************************************************************************************************/
uint8_t eeprom_get_dec_count(uint8_t index, uint32_t *dec_value);


// txmod
/***********************************************************************************************************
*@name:    tx_modu_setup_config
*@desc:    implement setup tx modulate config 
*@param:   
*    ptr_stru_tx_modu_setup: structure tTxmod_Setup pointer to Tx modulate parameters (in xdata) which will 
*                           be configed
*@return: none    
************************************************************************************************************/
void tx_modu_setup_config(STRU_TX_MODU_SETUP xdata *ptr_stru_tx_modu_setup);



// txsym
/**********************************************************************************************************
*@name:    tx_sym_setup_config
*@desc:    implement setup tx sym config 
*@param:   
*    tx_sym_setup:
*        bit[7]  :    reserved
*        bit[6]  :    tx_direct_en  0:disable tx direct mode, 1: enable tx direct mode(the tx data come from 
*                     tx_direct_data, and don't care tx_group_with, endian, tx_sym_ctrl)
*        bit[5:3]:    tx group with
*        bit[2]  :    endian(0-small endian, 1-big endian)
*        bit[1:0]:    tx_sym_ctrl
*               00:    shundown transmission after last bit
*               01:    reuse tha last symbol group for transmission
*               10:    all 0s data
*               11:    all 1s data    
*@return: none
***********************************************************************************************************/
void tx_sym_setup_config(uint8_t tx_sym_setup);

/**********************************************************************************************************
*@name:    tx_sym_transmit
*@desc:    implement transmit data from transBuf
*@param:   
*    ptr_trans_buf: (uint8_t pointer in xdata)pointer to data which will be transmitted
*    tx_length:     the bytes of data  which will be transmitted
*@return: none
***********************************************************************************************************/
void tx_sym_transmit(uint8_t xdata *ptr_trans_buf,uint8_t tx_length);

/**********************************************************************************************************
*@name:    tx_sym_prepare_for_transmission
*@desc:    do something before transmission such as enable xo crystal, check the system voltage is higher than 
*          the threshold 'voltage_th' or not, check pll is locked or not
*@param:   
*    voltage_th: the hreshold value is compared with system voltage
*@return: 
*     bit[7:2]: reserved
*     bit[1]  : 0 - pll is not locked, 1 - pll is locked
*     bit[0]  : 0 - system voltage is higher than voltage_th, 1 - system voltage is lower than voltage_th 
***********************************************************************************************************/
uint8_t tx_sym_prepare_for_transmission(uint8_t voltage_th);

/**********************************************************************************************************
*@name:    tx_sym_check_system_voltage
*@desc:    check the system voltage is higher than the threshold 'voltage_th' or not
*@param:   
*    voltage_th: the hreshold value is compared with system voltage
*@return:  0 - system voltage is higher than voltage_th, 1 - system voltage is lower than voltage_th 
***********************************************************************************************************/
uint8_t tx_sym_check_system_voltage(uint8_t voltage_th);

/**********************************************************************************************************
*@name:    tx_sym_start_direct_transmit
*@desc:    start direct transmit
*@param:   none
*@return: none
***********************************************************************************************************/
void tx_sym_start_direct_transmit(void);

/**********************************************************************************************************
*@name:    tx_sym_stop_direct_transmit
*@desc:    stop direct transmit
*@param:   none
*@return: none
***********************************************************************************************************/
void tx_sym_stop_direct_transmit(void);


// lfrx
/*************************************************************************************************************
*@name:    lfrx_setup_config
*@desc:    config lfrx parameters
*@param:   none
*@return:  none 
**************************************************************************************************************/
void lfrx_setup_config(STRU_LFRX_SETUP xdata *ptr_lfrx_setup);
/*************************************************************************************************************
*@name:    lfrx_enable_lfrx_osc_out
*@desc:    enable lfrx osc out(set pd_lfrx_vtr =0, pd_lfrx_osc = 0, lfrx_agc_en = 0, lfrx_agc_min_index = 0, 
*                            lfrx_dqres = 0)
*@param:   none
*@return:  none 
**************************************************************************************************************/
void lfrx_enable_lfrx_osc_out(void);

/*************************************************************************************************************
*@name:    lfrx_disable_lfrx_osc_out
*@desc:    disable lfrx osc out(set pd_lfrx_vtr =1, pd_lfrx_osc = 1)
*@param:   none
*@return:  none 
**************************************************************************************************************/
void lfrx_disable_lfrx_osc_out(void);

// afe
/*************************************************************************************************************
*@name:    afe_front_setup_config
*@desc:    config afe ana front parameters
*@param:   none
*@return:  none 
**************************************************************************************************************/
void afe_front_setup_config(STRU_AFE_FRONT_SETUP xdata *ptr_afe_front_setup);

/*************************************************************************************************************
*@name:    afe_open_analog_front_power
*@desc:    open afe analog front power
*@param:   
* ptr_front_powerup_cfg: point to afe analog front power up configuration
*@return:  none 
**************************************************************************************************************/
void afe_open_analog_front_power(STRU_AFE_FRONT_POWERUP_SETUP xdata *ptr_front_powerup_cfg);

/*************************************************************************************************************
*@name:    afe_close_analog_front
*@desc:    close analog front
*@param:   none
*@return:  none 
**************************************************************************************************************/
void afe_close_analog_front(void);

/*************************************************************************************************************
*@name:    afe_open_pir_front_power
*@desc:    open pir front power
*@param:   none
*@return:  none 
**************************************************************************************************************/
void afe_open_pir_front_power(void);

/*************************************************************************************************************
*@name:    afe_close_pir_front_power
*@desc:    close pir front power
*@param:   none
*@return:  none 
**************************************************************************************************************/
void afe_close_pir_front_power(void);

/************************************************************************
*@name:    afe_read_sar_adc_data
*@desc:    read sar_adc value  
*@param:   none
*@return:  the value of sar_adc
**************************************************************************/
uint16_t afe_read_sar_adc_data(void);

/*************************************************************************************************************
*@name:    afe_snooze_setup_config
*@desc:    config afe snooze parameters
*@param:   none
*@return:  none 
**************************************************************************************************************/
void afe_snooze_setup_config(STRU_AFE_SNOOZE_SETUP xdata *ptr_afe_snooze_setup);

/**********************************************************************************************************
*@name:    afe_check_system_voltage
*@desc:    check the system voltage
*@param:   
*     voltage_th: the value of voltage which is compared with the system voltage 
*@return:  
*      0: system voltage is higher than voltage_th
*      1: system voltage is lower than voltage_th 
***********************************************************************************************************/
uint8_t afe_check_system_voltage(uint8_t voltage_th);

// spi
void spi_setup_config(STRU_SPI_SETUP xdata *ptr_cfg);
void spi_set_one_line_direction(uint8_t dir);
void spi_set_enabled(uint8_t enable);
void spi_set_software_nss(uint8_t level);

// cal
/**********************************************************************************************************
*@name:    cal_vco_calibration                                                                             
*@desc:    implement vco_vtr, vcoreg and vco_ib calibration                                                
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_vco_calibration(void);                                                                            
                                                                                                           
/**********************************************************************************************************
*@name:    cal_afe_vtr_calibration                                                                         
*@desc:    implement afe_vtr calibration                                                                   
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_afe_vtr_calibration(void);                                                                        
                                                                                                           
/**********************************************************************************************************
*@name:    cal_lfrx_vtr_calibration                                                                        
*@desc:    implement lfrx_vtr calibration                                                                  
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_lfrx_vtr_calibration(void);                                                                       
                                                                                                           
/**********************************************************************************************************
*@name:    cal_hfosc_vtr_calibration                                                                       
*@desc:    implement hfosc_vtr calibration                                                                 
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_hfosc_vtr_calibration(void);                                                                      
                                                                                                           
/**********************************************************************************************************
*@name:    cal_pir_vtr_calibration                                                                         
*@desc:    implement pir_vtr calibration                                                                   
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_pir_vtr_calibration(void); 

/**********************************************************************************************************
*@name:    cal_hfosc_clk_high_coase_calibration                                                            
*@desc:    implement hfosc_clk_high_coase calibration                                                      
*@param:   none                                                         
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_hfosc_clk_high_coase_calibration(void);                                         
                                                                                                           
/**********************************************************************************************************
*@name:    cal_start_hfosc_clk_high_fine_calibration                                                       
*@desc:    start to do hfosc_clk_high_fine calibration                                                     
*@param: none                                                         
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_start_hfosc_clk_high_fine_calibration(void);                                    
                                                                                                           
/**********************************************************************************************************
*@name:    cal_stop_hfosc_clk_high_fine_calibration                                                        
*@desc:    stop to do hfosc_clk_high_fine calibration                                                      
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_stop_hfosc_clk_high_fine_calibration(void);                                                       
                                                                                                           
/**********************************************************************************************************
*@name:    cal_hfosc_clk_low_calibration                                                                   
*@desc:    implement hfosc_clk_low calibration                                                             
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_hfosc_clk_low_calibration(void);                                                                  
                                                                                                           
/**********************************************************************************************************
*@name:    cal_lfosc_clk_coase_calibration                                                                 
*@desc:    implement lfosc_clk_coase calibration                                                           
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_lfosc_clk_coase_calibration(void);                                                                
                                                                                                           
/**********************************************************************************************************
*@name:    cal_start_lfosc_clk_fine_calibration                                                            
*@desc:    start to do lfosc_clk_fine calibration                                                          
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_start_lfosc_clk_fine_calibration(void);                                                           
                                                                                                           
/**********************************************************************************************************
*@name:    cal_stop_lfosc_clk_fine_calibration                                                             
*@desc:    stop doing lfosc_clk_fine calibration                                                           
*@param:   none                                                                                            
*@return:  none                                                                                            
***********************************************************************************************************/
void cal_stop_lfosc_clk_fine_calibration(void);                                                            
                                                                                                           
/*************************************************************************************************************
*@name:    cal_start_and_wait_afc_done
*@desc:    start and wait afc done
*@param:   none 
*@return:  none  
****************************************************************************************************************/
void cal_start_and_wait_afc_done(void);

/**********************************************************************************************************
*@name:    cal_adc_calibration
*@desc:    process adc calibration 
*@param:   none
*@return:  none
************************************************************************************************************/
void cal_adc_calibration(void);

/**********************************************************************************************************
*@name:    cal_lfrx_osc_amplitude_calibration
*@desc:    process lfrx antenna osc amplitude calibration  
*@param:   
*       lfrx_ant_ref: the referrence of antenna 
*@return:  none
************************************************************************************************************/
void cal_lfrx_osc_amplitude_calibration(uint8_t lfrx_ant_ref);

/**********************************************************************************************************
*@name:    cal_lfrx_osc_frequency_calibration
*@desc:    process lfrx antenna osc frequency calibration  
*@param:   
*       lfrx_ant_ref: the referrence of antenna 
*@return:  none
************************************************************************************************************/
void cal_lfrx_osc_frequency_calibration(uint8_t lfrx_ant_ref);




#endif