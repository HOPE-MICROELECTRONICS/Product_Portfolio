#ifndef _CMT216XA_MACRO_H_
#define _CMT216XA_MACRO_H_

/* Bit VAL define  */
#define VAL_BIT0                    0x01
#define VAL_BIT1                    0x02
#define VAL_BIT2                    0x04
#define VAL_BIT3                    0x08
#define VAL_BIT4                    0x10
#define VAL_BIT5                    0x20
#define VAL_BIT6                    0x40
#define VAL_BIT7                    0x80


//******************************Memory Control*************************************/
/* Memory  physics addr      define  */
#define MEM_PRAM_SADDR       		0x0000    						// 0x0000-0x1FFF
#define MEM_XRAM_SADDR       		0x2000    						// 0x2000-0x21FF
#define MEM_IRAM_SADDR       		0x7000    						// 0x7000-0x70FF

/* Memory size */
#define MEM_PRAM_SIZE               0x2000
#define MEM_XRAM_SIZE               0x0200
#define MEM_IRAM_SIZE               0x0100
#define MEM_XREG_SIZE               0x0100
#define MEM_NVM_SIZE                0x2000

/* Momory operation  */
#define MCTL_CMD_DMA                0x0A
#define MCTL_CMD_SPI2PRAM           0x1B
#define MCTL_CMD_SPI2XRAM           0x1C
#define MCTL_CMD_XRAM2SPI           0x1D

/* sfr bank sel */                  
#define BANK0_SEL                   0x00							// access Block1 Bank0 SFR	
#define BANK1_SEL                   0x01							//access Block1 Bank1 SFR	

/************************** T8051 Core SFR (Block1) ********************************/
/* PCON 0x87 */
#define M_SMOD1                     VAL_BIT7
#define M_SMOD0                     VAL_BIT6
#define M_GF1                       VAL_BIT3
#define M_GF0                       VAL_BIT2
#define M_STOP                      VAL_BIT1
#define M_IDLE                      VAL_BIT0

/* TCON 0x88 */
#define M_TF1                       VAL_BIT7
#define M_TR1                       VAL_BIT6
#define M_IE1                       VAL_BIT3
#define M_IT1                       VAL_BIT2
#define M_IE0                       VAL_BIT1
#define M_IT0                       VAL_BIT0

/* TMOD 0x89 */
#define M_GATE1                     VAL_BIT7
#define M_C_T1                      VAL_BIT6
#define M_M1                        (VAL_BIT5|VAL_BIT4)

/* SCON0 0x98 */
#define M_FE0                       VAL_BIT7
#define M_SM00                      VAL_BIT7
#define M_SM10                      VAL_BIT6
#define M_SM20                      VAL_BIT5
#define M_REN0                      VAL_BIT4
#define M_TB80                      VAL_BIT3
#define M_RB80                      VAL_BIT2
#define M_TI0                       VAL_BIT1
#define M_RI0                       VAL_BIT0

/* IEN0 0xA8 */
#define M_EA                       VAL_BIT7
#define M_ES0                      VAL_BIT4
#define M_ET1                      VAL_BIT3
#define M_EX1                      VAL_BIT2
#define M_EX0                      VAL_BIT0

/* IEN1 0xE6 */
#define M_EX7                       VAL_BIT7
#define M_EX6                       VAL_BIT6
#define M_EX5                       VAL_BIT5
#define M_EX4                       VAL_BIT4
#define M_EX3                       VAL_BIT3
#define M_EX2                       VAL_BIT2

/*********************** CMT216xA SFR (Block1 Bank0) ******************************/
/* CLK_SYS_DIV 0x8F */
#define M_LFRX_MCU_RCLK             VAL_BIT6
#define M_LFRX_MCU_RDATA            VAL_BIT5
#define M_CODE_RUN_SYS              VAL_BIT4
#define M_CLK_SYS_DIV               (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

#define M_CLK_SYS_DIV_1				0x00							//divide by 1
#define	M_CLK_SYS_DIV_2				0x08							//divide by 2
#define	M_CLK_SYS_DIV_4				0x09							//divide by 4
#define M_CLK_SYS_DIV_8				0x0A							//divide by 8
#define	M_CLK_SYS_DIV_16			0x0B							//divide by 16
#define M_CLK_SYS_DIV_32			0x0C							//divide by 32
#define M_CLK_SYS_DIV_64			0x0D							//divide by 64
#define M_CLK_SYS_DIV_128			0x0E							//divide by 128
#define	M_CLK_SYS_DIV_256			0x0F							//divide by 256

/* SPI_CTL1_H 0x91 */
#define M_BIDI_MODE                 VAL_BIT7
#define M_BIDI_OE                   VAL_BIT6
#define M_RX_ONLY                   VAL_BIT5
#define M_DFF                       VAL_BIT4
#define M_TXDMAEN                   VAL_BIT3
#define M_SSOE                      VAL_BIT2
#define M_SSM                       VAL_BIT1
#define M_SSI                       VAL_BIT0

/* SPI_CTL1_L 0x92 */
#define M_LSB_FIRST                 VAL_BIT7
#define M_SPE                       VAL_BIT6
#define M_BR                        (VAL_BIT5|VAL_BIT4|VAL_BIT3)
#define M_MSTR                      VAL_BIT2
#define M_CPOL                      VAL_BIT1
#define M_CPHA                      VAL_BIT0

#define	M_SPI_BR_DIV_2				(0x00<<3)						//base on FPCLK, divide by 2, as default FPCLK = 24MHz
#define	M_SPI_BR_DIV_8				(0x01<<3)						//               divide by 8	
#define M_SPI_BR_DIV_16				(0x02<<3)						//				 divide by 16
#define M_SPI_BR_DIV_24				(0x03<<3)						//				 divide by 24
#define M_SPI_BR_DIV_32				(0x04<<3)						//				 divide by 32
#define M_SPI_BR_DIV_64				(0x05<<3)						//				 divide by 64
#define M_SPI_BR_DIV_128			(0x06<<3)						//				 divide by 128
#define M_SPI_BR_DIV_256			(0x02<<3)						//				 divide by 256

/* SPI_CTL2_H 0x93 */
#define M_SPI_BUSY                  VAL_BIT2
#define M_SPI_TXE                   VAL_BIT1
#define M_SPI_RXNE                  VAL_BIT0

/* UART_CTL 0x97 */
#define M_USART_SEL                 VAL_BIT0

/* TACH 0x9C */
#define M_TA_START                  VAL_BIT2
#define M_TACCI3                    VAL_BIT1
#define M_TACCI2                    VAL_BIT0

/* TACL 0x9D */
#define M_TA_CNT_MODE               (VAL_BIT4|VAL_BIT3)
#define M_TA_CLR                    VAL_BIT2
#define M_TMR_IE                    VAL_BIT1
#define M_TMR_IFG                   VAL_BIT0

/* TACCTL0H 0xA3 */
#define M_CCR0_CCI                  VAL_BIT6
#define M_CCR0_SCCI                 VAL_BIT5
#define M_CCR0_CM                   (VAL_BIT4|VAL_BIT3)
#define M_CCR0_CCIS                 (VAL_BIT2|VAL_BIT1)
#define M_CCR0_CAP                  VAL_BIT0

/* TACCTL0L 0xA4 */
#define M_CCR0_SCS                  VAL_BIT7
#define M_CCR0_OUTMODE              (VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_CCR0_IE                   VAL_BIT3
#define M_CCR0_OUT                  VAL_BIT2
#define M_CCR0_COV                  VAL_BIT1
#define M_CCR0_IFG                  VAL_BIT0

/* TACCTL1H 0xA9  */
#define M_CCR1_CCI                  VAL_BIT6
#define M_CCR1_SCCI                 VAL_BIT5
#define M_CCR1_CM                   (VAL_BIT4|VAL_BIT3)
#define M_CCR1_CCIS                 (VAL_BIT2|VAL_BIT1)
#define M_CCR1_CAP                  VAL_BIT0

/* TACCTL1L 0xAA */
#define M_CCR1_SCS                  VAL_BIT7
#define M_CCR1_OUTMODE              (VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_CCR1_IE                   VAL_BIT3
#define M_CCR1_OUT                  VAL_BIT2
#define M_CCR1_COV                  VAL_BIT1
#define M_CCR1_IFG                  VAL_BIT0

/* TACCTL2H 0xAD */
#define M_CCR2_CCI                  VAL_BIT6
#define M_CCR2_SCCI                 VAL_BIT5
#define M_CCR2_CM                   (VAL_BIT4|VAL_BIT3)
#define M_CCR2_CCIS                 (VAL_BIT2|VAL_BIT1)
#define M_CCR2_CAP                  VAL_BIT0

/* TACCTL2L 0xAE */
#define M_CCR2_SCS                  VAL_BIT7
#define M_CCR2_OUTMODE              (VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_CCR2_IE                   VAL_BIT3
#define M_CCR2_OUT                  VAL_BIT2
#define M_CCR2_COV                  VAL_BIT1
#define M_CCR2_IFG                  VAL_BIT0

#define	CCR_OUTPUT_DIRECT			(0<<4)
#define CCR_OUTPUT_SET				(1<<4)
#define CCR_OUTPUT_TOGGLE_RESET		(2<<4)
#define	CCR_OUTPUT_SET_RESET		(3<<4)
#define	CCR_OUTPUT_TOGGLE 			(4<<4)
#define	CCR_OUTPUT_RESET			(5<<4)
#define CCR_OUTPUT_TOGGLE_SET		(6<<4)
#define CCR_OUTPUT_RESET_SET		(7<<4)


/* IRQ0_SEL 0xAF */
#define M_IRQ_SW_0                  VAL_BIT6
#define M_IRQ0_SEL                  (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* IRQ1_SEL 0xB0 */
#define M_IRQ_SW_1                  VAL_BIT6
#define M_IRQ1_SEL                  (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* IRQ2_SEL 0xB1 */
#define M_IRQ_SW_2                  VAL_BIT6
#define M_IRQ2_SEL                  (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* IRQ3_SEL 0xB2 */
#define M_IRQ_SW_3                  VAL_BIT6
#define M_IRQ3_SEL                  (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* IRQ4_SEL 0xB3 */
#define M_IRQ_SW_4                  VAL_BIT6
#define M_IRQ4_SEL                  (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* IRQ5_SEL 0xB4 */
#define M_IRQ_SW_5                  VAL_BIT6
#define M_IRQ5_SEL                  (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* IRQ6_SEL 0xB5 */
#define M_IRQ_SW_6                  VAL_BIT6
#define M_IRQ6_SEL                  (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* IRQ7_SEL 0xB6 */
#define M_IRQ_SW_7                  VAL_BIT6
#define M_IRQ7_SEL                  (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* TIMER_IN_SEL 0xB7 */
#define M_T1_IN_GPIO_SEL            (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_RXD0_IN_GPIO_SEL          (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CCI_SEL 0xB9 */
#define M_CCI1_IN_GPIO_SEL          (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_CCI0_IN_GPIO_SEL          (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* SPI_IN_SEL0 0xBA */
#define M_SCK_IN_SEL                (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_NSS_IN_SEL                (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* SPI_IN_SEL1 0xBB */
#define M_MOSI_IN_SEL               (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_MISO_IN_SEL               (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* P0_IN_SEL0 0xBC */
#define M_PORT01_IN_GPIO_SEL        (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_PORT00_IN_GPIO_SEL        (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* P0_IN_SEL1 0xBD */
#define M_PORT03_IN_GPIO_SEL        (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_PORT02_IN_GPIO_SEL        (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* P0_IN_SEL2 0xBE */
#define M_PORT05_IN_GPIO_SEL        (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_PORT04_IN_GPIO_SEL        (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* P0_IN_SEL3 0xBF */
#define M_PORT07_IN_GPIO_SEL        (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_PORT06_IN_GPIO_SEL        (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* GPIO_OUT_SEL0 0xC4 */
#define M_GPIO1_OUT_SEL             (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_GPIO0_OUT_SEL             (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* GPIO_OUT_SEL1 0xC5 */
#define M_GPIO3_OUT_SEL             (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_GPIO2_OUT_SEL             (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* GPIO_OUT_SEL2 0xC6 */
#define M_GPIO5_OUT_SEL             (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_GPIO4_OUT_SEL             (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* GPIO_OUT_SEL3 0xC7 */
#define M_GPIO7_OUT_SEL             (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_GPIO6_OUT_SEL             (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* GPIO_OUT_SEL4 0xC8 */
#define M_GPIO9_OUT_SEL             (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_GPIO8_OUT_SEL             (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* GPIO_OUT_SEL5 0xC9 */
#define M_GPIO11_OUT_SEL            (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_GPIO10_OUT_SEL            (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* GPIO_OUT_SEL6 0xCA */
#define M_GPIO13_OUT_SEL            (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_GPIO12_OUT_SEL            (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* GPIO_OUT_SEL7 0xCB */
#define M_GPIO15_OUT_SEL            (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_GPIO14_OUT_SEL            (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)


/* GPIO_OUT_SEL */
#define	M_GPIO_SEL_OUT_R			0x00							//select GPIO_OUT_R_H/L (default)
#define M_GPIO_SEL_P0_OUT			0x01							//select P0.x output 
#define	M_GPIO_SEL_TB_OUT0			0x02							//select TimerB CCR Out0
#define	M_GPIO_SEL_TB_OUT1			0x03							//select TimerB CCR Out1
#define M_GPIO_SEL_TB_OUT2			0x04							//select TimerB CCR Out2
#define	M_GPIO_SEL_NSS				0x05							//select SPI Master NSS  Output
#define M_GPIO_SEL_SCK				0x06							//select SPI Master SCK  Output
#define	M_GPIO_SEL_MISO				0x07							//select SPI Slave 	MISO Output
#define M_GPIO_SEL_MOSI				0x08							//select SPI Master MOSI Output
#define M_GPIO_SEL_RxD0				0x09							//select SerialPort0 RxD Output (synchronized serial mode)
#define	M_GPIO_SEL_TxD0				0x0A							//select SerialPort0 TxD Output
#define	M_GPIO_SEL_TA_OUT0			0x0B							//select TimerA CCR Out0
#define	M_GPIO_SEL_TA_OUT1			0x0C							//select TimerA CCR Out1
#define	M_GPIO_SEL_TA_OUT2			0x0D							//select TimerA CCR Out2
#define M_GPIO_SEL_LED_OUT_LV		0x0E							//select LED moudle Output
#define	M_GPIO_SEL_T1_OV			0x0F							//select Timer1 Overflow Output


/* LED_CTL 0xCC */
#define M_SAR_DATA_UPDATE           VAL_BIT7
#define M_LED_ON                    VAL_BIT6
#define M_LED_OUT_SEL               VAL_BIT5
#define M_PWM_RATE_SEL              VAL_BIT4
#define M_PWM_INTERVAL_SEL          (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)


/* GPIO_IN_R_D1 0xDD */
#define M_GPIO_IN_R_16              VAL_BIT0

/* GPIO_OUT_R_D1 0xDE */
#define M_GPIO_OUT_R_16             VAL_BIT0


/* SYS_CTL 0xFF*/
#define M_SFR_CLK_GATE_EN           VAL_BIT7


/*********************** CMT216xA SFR (Block1 Bank1) ******************************/
/* PD_ANA 0x8A */
#define M_PD_PA_AAT_TEST			VAL_BIT7	
#define M_PD_PA						VAL_BIT5		

/* TX_SYM_GROUP 0xA9 */
#define M_TX_DIRECT_DATA            VAL_BIT0

/* TX_SYM_CTL 0xAA */
#define M_TX_DIRECT_EN              VAL_BIT6
#define M_TX_GROUP_WIDTH            (VAL_BIT5|VAL_BIT4|VAL_BIT3)
#define M_TX_SYM_ENDIAN             VAL_BIT2
#define M_TX_SYM_CTRL               (VAL_BIT1|VAL_BIT0)

/* TX_PKT_CTL 0xAB */
#define M_TX_NODATA					VAL_BIT7
#define M_TX_SYM_EMPTY				VAL_BIT6
#define M_TX_START 					VAL_BIT5
#define M_TX_PKT_DONE_HOLD			VAL_BIT4
#define M_RAMP_EN                   VAL_BIT3
#define M_TX_MODU                   VAL_BIT2
#define M_FREQ_DEV_INV              VAL_BIT1
#define M_GUASS_ON                  VAL_BIT0

/* RAMP_STEP_TIME_H 0xB0 */
#define M_RAMP_STEP_TIME_14_8       (VAL_BIT6|VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* PA_IDAC_CODE 0xB3 */
#define M_PA_IDAC_CODE             (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

#define	M_PA_POWER_CODE_SEL			VAL_BIT7
#define	M_PA_IDAC_CODE_SEL			VAL_BIT6
#define M_PA_IDAC_CODE_TEST			(VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)


/* PA_CTL0 0xB4 */
#define M_PA_DIFF_SEL               VAL_BIT4
#define M_PA_RCRAMP_SELB            VAL_BIT3
#define M_PA_RAMP_RSEL              (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* PA_CTL1 0xB5 */
#define	M_PD_PA_AAT_SEL				VAL_BIT4
#define M_PA_AAT_RSTN_TEST			VAL_BIT3


/* VCO_CTL0 0xB6 */
#define M_TX_STOP_DONE				VAL_BIT6		
#define M_TX_STOP_EN				VAL_BIT5		
#define M_VCO_GAIN_CODE             (VAL_BIT4|VAL_BIT3|VAL_BIT2)
#define M_PLL_BW_SEL                (VAL_BIT1|VAL_BIT0)

/* VCO_CTL1 0xB7 */
#define M_VCO_HBAND                 VAL_BIT7
#define M_PDCPLF_CPBIAS_CODE        VAL_BIT6
#define M_DIVX_CODE                 (VAL_BIT5|VAL_BIT4)
#define M_DIVX_SEL                  (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* PLL_CTL1 0xBD */
#define	M_PA_AAT_RSTN_SEL			VAL_BIT2

/* RNG_CTL 0xBE */
#define M_RNG_SUM_VLD               VAL_BIT4
#define M_RNG_START                 VAL_BIT0

/* LBD_CTL 0xC0 */
#define M_LBD_PRELOAD_SEL           VAL_BIT4
#define M_LBD_FLAG                  VAL_BIT3
#define M_LBD_VTH_SEL               VAL_BIT2
#define M_LBD_POR_EN                VAL_BIT1
#define M_LBD_ON                    VAL_BIT0


/* TBCH 0xD9 */
#define M_TB_START                  VAL_BIT2
#define M_TBCCI3                    VAL_BIT1
#define M_TBCCI2                    VAL_BIT0

/* TBCL 0xDA */
#define M_TB_CNT_MODE               (VAL_BIT4|VAL_BIT3)
#define M_TB_CLR                    VAL_BIT2
#define M_TMRB_IE                   VAL_BIT1
#define M_TMRB_IFG                  VAL_BIT0

/* TBCCTL0H 0xDF */
#define M_TBCCR0_CCI                VAL_BIT6
#define M_TBCCR0_SCCI               VAL_BIT5
#define M_TBCCR0_CM                 (VAL_BIT4|VAL_BIT3)
#define M_TBCCR0_CCIS               (VAL_BIT2|VAL_BIT1)
#define M_TBCCR0_CAP                VAL_BIT0

/* TBCCTL0L 0xE1 */
#define M_TBCCR0_SCS                VAL_BIT7
#define M_TBCCR0_OUTMODE            (VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_TBCCR0_IE                 VAL_BIT3
#define M_TBCCR0_OUT                VAL_BIT2
#define M_TBCCR0_COV                VAL_BIT1
#define M_TBCCR0_IFG                VAL_BIT0

/* TBCCTL1H 0xE4  */
#define M_TBCCR1_CCI                VAL_BIT6
#define M_TBCCR1_SCCI               VAL_BIT5
#define M_TBCCR1_CM                 (VAL_BIT4|VAL_BIT3)
#define M_TBCCR1_CCIS               (VAL_BIT2|VAL_BIT1)
#define M_TBCCR1_CAP                VAL_BIT0

/* TBCCTL1L 0xE5 */
#define M_TBCCR1_SCS                VAL_BIT7
#define M_TBCCR1_OUTMODE            (VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_TBCCR1_IE                 VAL_BIT3
#define M_TBCCR1_OUT                VAL_BIT2
#define M_TBCCR1_COV                VAL_BIT1
#define M_TBCCR1_IFG                VAL_BIT0

/* TBCCTL2H 0xE9 */
#define M_TBCCR2_CCI                VAL_BIT6
#define M_TBCCR2_SCCI               VAL_BIT5
#define M_TBCCR2_CM                 (VAL_BIT4|VAL_BIT3)
#define M_TBCCR2_CCIS               (VAL_BIT2|VAL_BIT1)
#define M_TBCCR2_CAP                VAL_BIT0

/* TBCCTL2L 0xEA */
#define M_TBCCR2_SCS                 VAL_BIT7
#define M_TBCCR2_OUTMODE             (VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_TBCCR2_IE                  VAL_BIT3
#define M_TBCCR2_OUT                 VAL_BIT2
#define M_TBCCR2_COV                 VAL_BIT1
#define M_TBCCR2_IFG                 VAL_BIT0

/* TBCCI_SEL 0xEB */
#define M_TBCCI1_GPIO_SEL            (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_TBCCI0_GPIO_SEL            (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)


/**************************** CMT216xA SFR (Block0) *********************************/

#define CUS_AFE1_ADDR               0x00
#define CUS_AFE2_ADDR               0x01
#define CUS_AFE3_ADDR               0x02
#define CUS_AFE4_ADDR               0x03
#define CUS_AFE5_ADDR               0x04
#define CUS_AFE6_ADDR               0x05
#define CUS_AFE7_ADDR               0x06
#define CUS_AFE8_ADDR               0x07
#define CUS_AFE9_ADDR               0x08
#define CUS_AFE10_ADDR              0x09
#define CUS_AFE11_ADDR              0x0A
#define CUS_AFE12_ADDR              0x0B
#define CUS_AFE13_ADDR              0x0C
#define CUS_AFE14_ADDR              0x0D
#define CUS_AFE15_ADDR              0x0E
#define CUS_AFE16_ADDR              0x0F
#define CUS_AFE17_ADDR              0x10
#define CUS_AFE18_ADDR              0x11

#define CUS_LFRX3_ADDR              0x12
#define CUS_LFRX4_ADDR              0x13
#define CUS_LFRX5_ADDR              0x14
#define CUS_LFRX6_ADDR              0x15
#define CUS_LFRX7_ADDR              0x16
#define CUS_LFRX8_ADDR              0x17
#define CUS_LFRX9_ADDR              0x18
#define CUS_LFRX10_ADDR             0x19
#define CUS_LFRX11_ADDR             0x1A
#define CUS_LFRX12_ADDR             0x1B

#define CUS_SNOOZE1_ADDR            0x1E
#define CUS_SNOOZE2_ADDR            0x1F
#define CUS_SNOOZE3_ADDR            0x20
#define CUS_SNOOZE4_ADDR            0x21
#define CUS_SNOOZE5_ADDR            0x22
#define CUS_SNOOZE6_ADDR            0x23

#define CUS_PADCTL1_ADDR            0x24
#define CUS_PADCTL2_ADDR            0x25
#define CUS_PADCTL3_ADDR            0x26
#define CUS_PADCTL4_ADDR            0x27
#define CUS_PADCTL5_ADDR            0x28
#define CUS_PADCTL6_ADDR            0x29
#define CUS_PADCTL7_ADDR            0x2A
#define CUS_PADCTL8_ADDR            0x2B
#define CUS_PADCTL9_ADDR            0x2C
#define CUS_PADCTL10_ADDR           0x2D
#define CUS_PADCTL11_ADDR           0x2E
#define CUS_PADCTL12_ADDR           0x2F


#define CAL_LFRX_TCAP2_ADDR         0x34
#define CAL_LFRX_TCAP1_ADDR         0x35
#define CAL_LFRX_TCAP0_ADDR         0x36
#define CAL_LFRX_OSC_CODE_ADDR      0x37

#define INT_SYSCTL3_ADDR            0x44

#define CUS_SYSCTL1_ADDR            0x46
#define CUS_SYSCTL2_ADDR            0x47

#define CUS_USER_HVRAM0_ADDR        0x48
#define CUS_USER_HVRAM1_ADDR        0x49
#define CUS_USER_HVRAM2_ADDR        0x4A
#define CUS_USER_HVRAM3_ADDR        0x4B
#define CUS_USER_HVRAM4_ADDR        0x4C
#define CUS_USER_HVRAM5_ADDR        0x4D
#define CUS_USER_HVRAM6_ADDR        0x4E
#define CUS_USER_HVRAM7_ADDR        0x4F

#define CUS_SYSCTL3_ADDR            0x50
#define CUS_SYSCTL4_ADDR            0x51
#define CUS_SYSCTL5_ADDR            0x52
#define CUS_SYSCTL6_ADDR            0x53
#define CUS_SYSCTL7_ADDR            0x54
#define CUS_SYSCTL8_ADDR            0x55
#define CUS_SYSCTL9_ADDR            0x56
#define CUS_SYSCTL10_ADDR           0x57

#define CUS_LFRX15_ADDR             0x58
#define CUS_LFRX16_ADDR             0x59
#define CUS_LFRX17_ADDR             0x5A
#define CUS_LFRX18_ADDR             0x5B
#define CUS_LFRX19_ADDR             0x5C
#define CUS_LFRX20_ADDR             0x5D
#define CUS_LFRX21_ADDR             0x5E
#define CUS_LFRX22_ADDR             0x5F
#define CUS_LFRX23_ADDR             0x60
#define CUS_LFRX24_ADDR             0x61
#define CUS_LFRX25_ADDR             0x62
#define CUS_LFRX26_ADDR             0x63
#define CUS_LFRX27_ADDR             0x64
#define CUS_LFRX28_ADDR             0x65
#define CUS_LFRX29_ADDR             0x66
#define CUS_LFRX30_ADDR             0x67

#define CUS_SYSCTL11_ADDR           0x68
#define CUS_SYSCTL12_ADDR           0x69
#define CUS_SYSCTL13_ADDR           0x6A
#define CUS_SYSCTL14_ADDR           0x6B
#define CUS_SYSCTL15_ADDR           0x6C
#define CUS_SYSCTL16_ADDR           0x6D
#define CUS_SYSCTL17_ADDR           0x6E
#define CUS_SYSCTL18_ADDR           0x6F
#define CUS_SYSCTL19_ADDR           0x70
#define CUS_SYSCTL20_ADDR           0x71

#define CUS_LFRX31_ADDR             0x72
#define CUS_LFRX32_ADDR             0x73
#define CUS_LFRX33_ADDR             0x74

#define CUS_RESV0_ADDR              0x75
#define CUS_RESV1_ADDR              0x76
#define CUS_RESV2_ADDR              0x77
#define CUS_RESV3_ADDR              0x78
#define CUS_RESV4_ADDR              0x79
#define CUS_RESV5_ADDR              0x7A



/* CUS_AFE4 0x03 */
#define M_AFE_IA2_GX                (VAL_BIT7|VAL_BIT6)

/* CUS_AFE6 0x05 */
#define M_AFE_IA1_GX                (VAL_BIT5|VAL_BIT4|VAL_BIT3)

/* CUS_AFE7 0x06 */
#define M_AFE_OSADJ_REFX            VAL_BIT5 
#define M_AFE_TE_RBX                (VAL_BIT4|VAL_BIT3) 
#define M_AFE_SEN_CHX               (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_AFE8 0x07 */
#define M_PD_HFOSC_REF              VAL_BIT6
#define M_HFOSC_CLK_SEL             (VAL_BIT4|VAL_BIT3)
#define M_LFOSC_LFXO_SEL            VAL_BIT2
#define M_PD_LFXO                   VAL_BIT1
#define M_PD_LFOSC                  VAL_BIT0

#define HFOSC_CLK_SEL_48MHZ         (VAL_BIT4|VAL_BIT3)
#define HFOSC_CLK_SEL_24MHZ         VAL_BIT4
#define HFOSC_CLK_SEL_12MHZ         VAL_BIT3
#define HFOSC_CLK_SEL_3MHZ          0

/* CUS_AFE9 0x08 */
#define M_LPOA0_VCM_DIS             VAL_BIT7
#define M_LPOA1_VCM_DIS             VAL_BIT6
#define M_AFE_IA_VCMX               VAL_BIT5
#define M_AFE_OA_VCMX               (VAL_BIT4|VAL_BIT3)
#define M_AFE_OA_OUTX               (VAL_BIT2|VAL_BIT1)
#define M_AFE_IA1_CX                VAL_BIT0

/* CUS_AFE10 0x09 */
#define M_AFE_OA0_OX                VAL_BIT7
#define M_AFE_OA0_NX                (VAL_BIT6|VAL_BIT5)
#define M_AFE_OA0_PX                (VAL_BIT4|VAL_BIT3|VAL_BIT2)
#define M_AFE_OA0_NA_GX             (VAL_BIT1|VAL_BIT0)

/* CUS_AFE11 0x0A */
#define M_SAR_DIRECT_DIS            VAL_BIT7
#define M_AFE_OA1_OX                (VAL_BIT6|VAL_BIT5)
#define M_AFE_OA1_NX                (VAL_BIT4|VAL_BIT3)
#define M_AFE_OA1_PX                (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_AFE12 0x0B */
#define M_LDO_PIR_RAILB             VAL_BIT7
#define M_AFE_OA2_OX                (VAL_BIT6|VAL_BIT5)
#define M_AFE_OA2_NX                (VAL_BIT4|VAL_BIT3)
#define M_AFE_OA2_PX                (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_AFE13 0x0C */
#define M_LDO_PIR_VO_SEL            (VAL_BIT7|VAL_BIT6)
#define M_SAR_INX                   (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2)
#define M_SAR_REFX                  (VAL_BIT1|VAL_BIT0)

/* CUS_AFE14 0x0D */
#define M_PD_AFE_OACMI              VAL_BIT7
#define M_PIR_ST                    VAL_BIT6 
#define M_PD_AFE_OSADJ              VAL_BIT5
#define M_PD_AFE_IACMO              VAL_BIT4
#define M_PD_SAR                    VAL_BIT3
#define M_PD_AFE_OA2                VAL_BIT2
#define M_PD_AFE_OA1                VAL_BIT1
#define M_PD_AFE_OA0                VAL_BIT0

/* CUS_AFE15 0x0E */
#define M_LDO_SAR_VO_SEL            (VAL_BIT7|VAL_BIT6)
#define M_LDO_SAR_RAILB             VAL_BIT5
#define M_PD_BG                     VAL_BIT4
#define M_SAR_LBD_DIS               VAL_BIT3
#define M_SAR_REF_DIS               VAL_BIT2
#define M_PD_LDO_SAR                VAL_BIT1
#define M_PD_AFE_VTR                VAL_BIT0


/* CUS_AFE16 0x0F */
#define M_SAR_MBC0                  VAL_BIT7
#define M_SAR_MBC1                  VAL_BIT6
#define M_SAR_STM                   (VAL_BIT5|VAL_BIT4)
#define M_PD_LDO_PIR                VAL_BIT3
#define M_PD_PIR_VTR                VAL_BIT2
#define M_PD_LPOA1                  VAL_BIT1
#define M_PD_LPOA0                  VAL_BIT0

/* CUS_AFE17 0x10 */
#define M_HDRV_SEL                  (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4|VAL_BIT3)
#define M_DRV_ENH                   VAL_BIT2
#define M_DRV_MAN_EN                VAL_BIT1
#define M_PD_DRV                    VAL_BIT0

/* CUS_AFE18 0x11 */
#define M_NDRV_SEL                  (VAL_BIT6|VAL_BIT5|VAL_BIT4|VAL_BIT3)
#define M_NDRV_EN                   VAL_BIT2
#define M_HDRV_EN                   VAL_BIT1
#define M_LDO_PIR_OE                VAL_BIT0

/* CUS_LFRX3 0x12 */
#define M_PD_P25                    VAL_BIT7
#define M_PD_P50                    VAL_BIT6
#define M_LFRX_AGC_IN               (VAL_BIT5|VAL_BIT4)
#define M_LFRX_AGC_VHREF            (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX4 0x13 */
#define M_PD_PULLUP2                VAL_BIT6
#define M_LFRX_AGC_CNT              (VAL_BIT5|VAL_BIT4)
#define M_LFRX_AGC_VLREF            (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX5 0x14 */
#define M_LFRX_CADET_WIN            (VAL_BIT7|VAL_BIT6)
#define M_LFRX_CADET_OK_CNT         (VAL_BIT5|VAL_BIT4)
#define M_LFRX_PEAKDET_CLK          (VAL_BIT3|VAL_BIT2)
#define M_LFRX_DATA_CLK             (VAL_BIT1|VAL_BIT0)

/* CUS_LFRX6 0x15 */
#define M_LFRX_DATA_R0              (VAL_BIT7|VAL_BIT6)
#define M_LFRX_DATA_R1              (VAL_BIT5|VAL_BIT4)
#define M_LFRX_PEAKDET_C            (VAL_BIT3|VAL_BIT2)
#define M_LFOSC_F_SEL               (VAL_BIT1|VAL_BIT0)

/* CUS_LFRX7 0x16 */
#define M_LFRX_DATA_C1              (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_LFRX_DATA_C0              (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX8 0x17 */
#define M_LFRX_DATA_C3              (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_LFRX_DATA_C2              (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX9 0x18 */
#define M_LFRX_CMP_NOISE_MASK       VAL_BIT7
#define M_LFRX_CMP_SW               VAL_BIT6
#define M_LFRX_RSSIAMP_IBIAS        (VAL_BIT5|VAL_BIT4|VAL_BIT3)
#define M_LFRX_PGA_IBIAS            (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX10 0x19 */
#define M_LFRX_CMP_REF              (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_LFRX_DEMOD_TH_HOLD        VAL_BIT3
#define M_LFRX_RSSIREC_IBIAS        (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX11 0x1A */
#define M_LFRX_SNRDET_INVALID_WIN   (VAL_BIT7|VAL_BIT6)
#define M_LFRX_SNRDET_VALID_WIN     (VAL_BIT5|VAL_BIT4)
#define M_LFRX_SNRDET_SNR           (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX12 0x1B */
#define M_LFRX_MEAS_SOURCE          VAL_BIT7
#define M_LFRX_OSC_VREF             (VAL_BIT6|VAL_BIT5)
#define M_LFRX_CH_Z                 VAL_BIT4
#define M_LFRX_CH_Y                 VAL_BIT3
#define M_LFRX_CH_X                 VAL_BIT2
#define M_LFRX_STARTUP_MANUAL       (VAL_BIT1|VAL_BIT0)

/* CUS_SNOOZE1 0x1E */

/* CUS_SNOOZE2 0x1F */
#define M_SNOOZE_UTH_9_8            (VAL_BIT7|VAL_BIT6)
#define M_SNOOZE_DTH_9_8            (VAL_BIT5|VAL_BIT4)
#define M_SNOOZE_TIMER_R_SLEEP      (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_SNOOZE3 0x20 */

/* CUS_SNOOZE4 0x21 */

/* CUS_SNOOZE5 0x22 */
#define M_SAR_CKX                   (VAL_BIT7|VAL_BIT6)
#define M_CAL_SAR_EN                VAL_BIT5
#define M_CAL_SAR_BSEL              VAL_BIT4
#define M_DWTH_WK_EN                VAL_BIT3
#define M_UPTH_WK_EN                VAL_BIT2
#define M_WOUT_WK_EN                VAL_BIT1
#define M_WIN_WK_EN                 VAL_BIT0
/* sar clk */
#define SAR_CKX_0P5MHZ              0
#define SAR_CKX_1MHZ                VAL_BIT6
#define SAR_CKX_1P5MHZ              VAL_BIT7
#define SAR_CKX_2MHZ                M_SAR_CKX

/* CUS_SNOOZE6 0x23 */
#define M_GPIO_HOLD                 VAL_BIT7
#define M_SNOOZE_STATE_R            (VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_DWTH_WK_INT               VAL_BIT3
#define M_UPTH_WK_INT               VAL_BIT2
#define M_WOUT_WK_INT               VAL_BIT1
#define M_WIN_WK_INT                VAL_BIT0
/* gpio hold */
#define GPIO_HOLD_ENA               M_GPIO_HOLD
#define GPIO_HOLD_DIS               0

/* CUS_PADCTL1 0x24 */
#define M_GPIO3_MODE                (VAL_BIT7|VAL_BIT6)
#define M_GPIO2_MODE                (VAL_BIT5|VAL_BIT4)
#define M_GPIO1_MODE                (VAL_BIT3|VAL_BIT2)
#define M_GPIO0_MODE                (VAL_BIT1|VAL_BIT0)
/* gpio mode */
#define GPIO3_MODE_AS_ANA            0
#define GPIO3_MODE_AS_DIG_INPUT      VAL_BIT6
#define GPIO3_MODE_AS_DIG_OUTPUT     VAL_BIT7

#define GPIO2_MODE_AS_ANA            0
#define GPIO2_MODE_AS_DIG_INPUT      VAL_BIT4
#define GPIO2_MODE_AS_DIG_OUTPUT     VAL_BIT5

#define GPIO1_MODE_AS_ANA            0
#define GPIO1_MODE_AS_DIG_INPUT      VAL_BIT2
#define GPIO1_MODE_AS_DIG_OUTPUT     VAL_BIT3

#define GPIO0_MODE_AS_ANA            0
#define GPIO0_MODE_AS_DIG_INPUT      VAL_BIT0
#define GPIO0_MODE_AS_DIG_OUTPUT     VAL_BIT1

/* CUS_PADCTL2 0x25 */
#define M_GPIO7_MODE                (VAL_BIT7|VAL_BIT6)
#define M_GPIO6_MODE                (VAL_BIT5|VAL_BIT4)
#define M_GPIO5_MODE                (VAL_BIT3|VAL_BIT2)
#define M_GPIO4_MODE                (VAL_BIT1|VAL_BIT0)
/* gpio mode */
#define GPIO7_MODE_AS_ANA            0
#define GPIO7_MODE_AS_DIG_INPUT      VAL_BIT6
#define GPIO7_MODE_AS_DIG_OUTPUT     VAL_BIT7

#define GPIO6_MODE_AS_ANA            0
#define GPIO6_MODE_AS_DIG_INPUT      VAL_BIT4
#define GPIO6_MODE_AS_DIG_OUTPUT     VAL_BIT5

#define GPIO5_MODE_AS_ANA            0
#define GPIO5_MODE_AS_DIG_INPUT      VAL_BIT2
#define GPIO5_MODE_AS_DIG_OUTPUT     VAL_BIT3

#define GPIO4_MODE_AS_ANA            0
#define GPIO4_MODE_AS_DIG_INPUT      VAL_BIT0
#define GPIO4_MODE_AS_DIG_OUTPUT     VAL_BIT1

/* CUS_PADCTL3 0x26 */
#define M_GPIO11_MODE               (VAL_BIT7|VAL_BIT6)
#define M_GPIO10_MODE               (VAL_BIT5|VAL_BIT4)
#define M_GPIO9_MODE                (VAL_BIT3|VAL_BIT2)
#define M_GPIO8_MODE                (VAL_BIT1|VAL_BIT0)
/* gpio mode */
#define GPIO11_MODE_AS_ANA           0
#define GPIO11_MODE_AS_DIG_INPUT     VAL_BIT6
#define GPIO11_MODE_AS_DIG_OUTPUT    VAL_BIT7

#define GPIO10_MODE_AS_ANA           0
#define GPIO10_MODE_AS_DIG_INPUT     VAL_BIT4
#define GPIO10_MODE_AS_DIG_OUTPUT    VAL_BIT5

#define GPIO9_MODE_AS_ANA            0
#define GPIO9_MODE_AS_DIG_INPUT      VAL_BIT2
#define GPIO9_MODE_AS_DIG_OUTPUT     VAL_BIT3

#define GPIO8_MODE_AS_ANA            0
#define GPIO8_MODE_AS_DIG_INPUT      VAL_BIT0
#define GPIO8_MODE_AS_DIG_OUTPUT     VAL_BIT1

/* CUS_PADCTL4 0x27 */
#define M_GPIO15_MODE               (VAL_BIT7|VAL_BIT6)
#define M_GPIO14_MODE               (VAL_BIT5|VAL_BIT4)
#define M_GPIO13_MODE               (VAL_BIT3|VAL_BIT2)
#define M_GPIO12_MODE               (VAL_BIT1|VAL_BIT0)
/* gpio mode */
#define GPIO15_MODE_AS_ANA          0
#define GPIO15_MODE_AS_DIG_INPUT    VAL_BIT6
#define GPIO15_MODE_AS_DIG_OUTPUT   VAL_BIT7

#define GPIO14_MODE_AS_ANA          0
#define GPIO14_MODE_AS_DIG_INPUT    VAL_BIT4
#define GPIO14_MODE_AS_DIG_OUTPUT   VAL_BIT5

#define GPIO13_MODE_AS_ANA          0
#define GPIO13_MODE_AS_DIG_INPUT    VAL_BIT2
#define GPIO13_MODE_AS_DIG_OUTPUT   VAL_BIT3

#define GPIO12_MODE_AS_ANA          0
#define GPIO12_MODE_AS_DIG_INPUT    VAL_BIT0
#define GPIO12_MODE_AS_DIG_OUTPUT   VAL_BIT1

/* CUS_PADCTL5 0x28 */
#define M_GPIO7_CNF                 VAL_BIT7
#define M_GPIO6_CNF                 VAL_BIT6
#define M_GPIO5_CNF                 VAL_BIT5
#define M_GPIO4_CNF                 VAL_BIT4
#define M_GPIO3_CNF                 VAL_BIT3
#define M_GPIO2_CNF                 VAL_BIT2
#define M_GPIO1_CNF                 VAL_BIT1
#define M_GPIO0_CNF                 VAL_BIT0
/* gpio config */
#define GPIO7_CNF_INPUT_PULLUP           0
#define GPIO7_CNF_INPUT_PULLDOWN         M_GPIO7_CNF
#define GPIO7_CNF_OUTPUT_PUSH_PULL       0
#define GPIO7_CNF_OUTPUT_OPEN_DRAIN      M_GPIO7_CNF
/* gpio config */
#define GPIO6_CNF_INPUT_PULLUP           0
#define GPIO6_CNF_INPUT_PULLDOWN         M_GPIO6_CNF
#define GPIO6_CNF_OUTPUT_PUSH_PULL       0
#define GPIO6_CNF_OUTPUT_OPEN_DRAIN      M_GPIO6_CNF
/* gpio config */
#define GPIO5_CNF_INPUT_PULLUP           0
#define GPIO5_CNF_INPUT_PULLDOWN         M_GPIO5_CNF
#define GPIO5_CNF_OUTPUT_PUSH_PULL       0
#define GPIO5_CNF_OUTPUT_OPEN_DRAIN      M_GPIO5_CNF
/* gpio config */
#define GPIO4_CNF_INPUT_PULLUP           0
#define GPIO4_CNF_INPUT_PULLDOWN         M_GPIO4_CNF
#define GPIO4_CNF_OUTPUT_PUSH_PULL       0
#define GPIO4_CNF_OUTPUT_OPEN_DRAIN      M_GPIO4_CNF
/* gpio config */
#define GPIO3_CNF_INPUT_PULLUP           0
#define GPIO3_CNF_INPUT_PULLDOWN         M_GPIO3_CNF
#define GPIO3_CNF_OUTPUT_PUSH_PULL       0
#define GPIO3_CNF_OUTPUT_OPEN_DRAIN      M_GPIO3_CNF
/* gpio config */
#define GPIO2_CNF_INPUT_PULLUP           0
#define GPIO2_CNF_INPUT_PULLDOWN         M_GPIO2_CNF
#define GPIO2_CNF_OUTPUT_PUSH_PULL       0
#define GPIO2_CNF_OUTPUT_OPEN_DRAIN      M_GPIO2_CNF
/* gpio config */
#define GPIO1_CNF_INPUT_PULLUP           0
#define GPIO1_CNF_INPUT_PULLDOWN         M_GPIO1_CNF
#define GPIO1_CNF_OUTPUT_PUSH_PULL       0
#define GPIO1_CNF_OUTPUT_OPEN_DRAIN      M_GPIO1_CNF
/* gpio config */
#define GPIO0_CNF_INPUT_PULLUP           0
#define GPIO0_CNF_INPUT_PULLDOWN         M_GPIO0_CNF
#define GPIO0_CNF_OUTPUT_PUSH_PULL       0
#define GPIO0_CNF_OUTPUT_OPEN_DRAIN      M_GPIO0_CNF

/* CUS_PADCTL6 0x29 */
#define M_GPIO15_CNF                VAL_BIT7
#define M_GPIO14_CNF                VAL_BIT6
#define M_GPIO13_CNF                VAL_BIT5
#define M_GPIO12_CNF                VAL_BIT4
#define M_GPIO11_CNF                VAL_BIT3
#define M_GPIO10_CNF                VAL_BIT2
#define M_GPIO9_CNF                 VAL_BIT1
#define M_GPIO8_CNF                 VAL_BIT0
/* gpio config */
#define GPIO15_CNF_INPUT_PULLUP          0
#define GPIO15_CNF_INPUT_PULLDOWN        M_GPIO15_CNF
#define GPIO15_CNF_OUTPUT_PUSH_PULL      0
#define GPIO15_CNF_OUTPUT_OPEN_DRAIN     M_GPIO15_CNF
/* gpio config */
#define GPIO14_CNF_INPUT_PULLUP          0
#define GPIO14_CNF_INPUT_PULLDOWN        M_GPIO14_CNF
#define GPIO14_CNF_OUTPUT_PUSH_PULL      0
#define GPIO14_CNF_OUTPUT_OPEN_DRAIN     M_GPIO14_CNF
/* gpio config */
#define GPIO13_CNF_INPUT_PULLUP          0
#define GPIO13_CNF_INPUT_PULLDOWN        M_GPIO13_CNF
#define GPIO13_CNF_OUTPUT_PUSH_PULL      0
#define GPIO13_CNF_OUTPUT_OPEN_DRAIN     M_GPIO13_CNF
/* gpio config */
#define GPIO12_CNF_INPUT_PULLUP          0
#define GPIO12_CNF_INPUT_PULLDOWN        M_GPIO12_CNF
#define GPIO12_CNF_OUTPUT_PUSH_PULL      0
#define GPIO12_CNF_OUTPUT_OPEN_DRAIN     M_GPIO12_CNF
/* gpio config */
#define GPIO11_CNF_INPUT_PULLUP          0
#define GPIO11_CNF_INPUT_PULLDOWN        M_GPIO11_CNF
#define GPIO11_CNF_OUTPUT_PUSH_PULL      0
#define GPIO11_CNF_OUTPUT_OPEN_DRAIN     M_GPIO11_CNF
/* gpio config */
#define GPIO10_CNF_INPUT_PULLUP          0
#define GPIO10_CNF_INPUT_PULLDOWN        M_GPIO10_CNF
#define GPIO10_CNF_OUTPUT_PUSH_PULL      0
#define GPIO10_CNF_OUTPUT_OPEN_DRAIN     M_GPIO10_CNF
/* gpio config */
#define GPIO9_CNF_INPUT_PULLUP           0
#define GPIO9_CNF_INPUT_PULLDOWN         M_GPIO9_CNF
#define GPIO9_CNF_OUTPUT_PUSH_PULL       0
#define GPIO9_CNF_OUTPUT_OPEN_DRAIN      M_GPIO9_CNF
/* gpio config */
#define GPIO8_CNF_INPUT_PULLUP           0
#define GPIO8_CNF_INPUT_PULLDOWN         M_GPIO8_CNF
#define GPIO8_CNF_OUTPUT_PUSH_PULL       0
#define GPIO8_CNF_OUTPUT_OPEN_DRAIN      M_GPIO8_CNF

/* CUS_PADCTL7 0x2A */
#define M_GPIO7_IOC                 VAL_BIT7
#define M_GPIO6_IOC                 VAL_BIT6
#define M_GPIO5_IOC                 VAL_BIT5
#define M_GPIO4_IOC                 VAL_BIT4
#define M_GPIO3_IOC                 VAL_BIT3
#define M_GPIO2_IOC                 VAL_BIT2
#define M_GPIO1_IOC                 VAL_BIT1
#define M_GPIO0_IOC                 VAL_BIT0

/* CUS_PADCTL8 0x2B */
#define M_GPIO15_IOC                VAL_BIT7
#define M_GPIO14_IOC                VAL_BIT6
#define M_GPIO13_IOC                VAL_BIT5
#define M_GPIO12_IOC                VAL_BIT4
#define M_GPIO11_IOC                VAL_BIT3
#define M_GPIO10_IOC                VAL_BIT2
#define M_GPIO9_IOC                 VAL_BIT1
#define M_GPIO8_IOC                 VAL_BIT0

/* CUS_PADCTL9 0x2C */
#define M_GPIO7_IDR                 VAL_BIT7
#define M_GPIO6_IDR                 VAL_BIT6
#define M_GPIO5_IDR                 VAL_BIT5
#define M_GPIO4_IDR                 VAL_BIT4
#define M_GPIO3_IDR                 VAL_BIT3
#define M_GPIO2_IDR                 VAL_BIT2
#define M_GPIO1_IDR                 VAL_BIT1
#define M_GPIO0_IDR                 VAL_BIT0

/* CUS_PADCTL10 0x2D */
#define M_GPIO15_IDR                VAL_BIT7
#define M_GPIO14_IDR                VAL_BIT6
#define M_GPIO13_IDR                VAL_BIT5
#define M_GPIO12_IDR                VAL_BIT4
#define M_GPIO11_IDR                VAL_BIT3
#define M_GPIO10_IDR                VAL_BIT2
#define M_GPIO9_IDR                 VAL_BIT1
#define M_GPIO8_IDR                 VAL_BIT0

/* CUS_PADCTL11 0x2E */
#define M_GPIO7_ODR                 VAL_BIT7
#define M_GPIO6_ODR                 VAL_BIT6
#define M_GPIO5_ODR                 VAL_BIT5
#define M_GPIO4_ODR                 VAL_BIT4
#define M_GPIO3_ODR                 VAL_BIT3
#define M_GPIO2_ODR                 VAL_BIT2
#define M_GPIO1_ODR                 VAL_BIT1
#define M_GPIO0_ODR                 VAL_BIT0
/* gpio input pullup or pulldown */
#define GPIO7_INPUT_PULLUP_DOWN     0
#define GPIO7_INPUT_FLOATING        M_GPIO7_ODR
/* gpio input pullup or pulldown */
#define GPIO6_INPUT_PULLUP_DOWN     0
#define GPIO6_INPUT_FLOATING        M_GPIO6_ODR
/* gpio input pullup or pulldown */
#define GPIO5_INPUT_PULLUP_DOWN     0
#define GPIO5_INPUT_FLOATING        M_GPIO5_ODR
/* gpio input pullup or pulldown */
#define GPIO4_INPUT_PULLUP_DOWN     0
#define GPIO4_INPUT_FLOATING        M_GPIO4_ODR
/* gpio input pullup or pulldown */
#define GPIO3_INPUT_PULLUP_DOWN     0
#define GPIO3_INPUT_FLOATING        M_GPIO3_ODR
/* gpio input pullup or pulldown */
#define GPIO2_INPUT_PULLUP_DOWN     0
#define GPIO2_INPUT_FLOATING        M_GPIO2_ODR
/* gpio input pullup or pulldown */
#define GPIO1_INPUT_PULLUP_DOWN     0
#define GPIO1_INPUT_FLOATING        M_GPIO1_ODR
/* gpio input pullup or pulldown */
#define GPIO0_INPUT_PULLUP_DOWN     0
#define GPIO0_INPUT_FLOATING        M_GPIO0_ODR

/* CUS_PADCTL12 0x2F */
#define M_GPIO15_ODR                VAL_BIT7
#define M_GPIO14_ODR                VAL_BIT6
#define M_GPIO13_ODR                VAL_BIT5
#define M_GPIO12_ODR                VAL_BIT4
#define M_GPIO11_ODR                VAL_BIT3
#define M_GPIO10_ODR                VAL_BIT2
#define M_GPIO9_ODR                 VAL_BIT1
#define M_GPIO8_ODR                 VAL_BIT0
/* gpio input pullup or pulldown */
#define GPIO15_INPUT_PULLUP_DOWN     0
#define GPIO15_INPUT_FLOATING        M_GPIO15_ODR
/* gpio input pullup or pulldown */
#define GPIO14_INPUT_PULLUP_DOWN     0
#define GPIO14_INPUT_FLOATING        M_GPIO14_ODR
/* gpio input pullup or pulldown */
#define GPIO13_INPUT_PULLUP_DOWN     0
#define GPIO13_INPUT_FLOATING        M_GPIO13_ODR
/* gpio input pullup or pulldown */
#define GPIO12_INPUT_PULLUP_DOWN     0
#define GPIO12_INPUT_FLOATING        M_GPIO12_ODR
/* gpio input pullup or pulldown */
#define GPIO11_INPUT_PULLUP_DOWN     0
#define GPIO11_INPUT_FLOATING        M_GPIO11_ODR
/* gpio input pullup or pulldown */
#define GPIO10_INPUT_PULLUP_DOWN     0
#define GPIO10_INPUT_FLOATING        M_GPIO10_ODR
/* gpio input pullup or pulldown */
#define GPIO9_INPUT_PULLUP_DOWN     0
#define GPIO9_INPUT_FLOATING        M_GPIO9_ODR
/* gpio input pullup or pulldown */
#define GPIO8_INPUT_PULLUP_DOWN     0
#define GPIO8_INPUT_FLOATING        M_GPIO8_ODR


/* CAL_LFRX_TCAP2 0x34 */
#define M_LFRX_TCAP_Z               (VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CAL_LFRX_TCAP1 0x35 */
#define M_LFRX_TCAP_Y               (VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CAL_LFRX_TCAP0 0x36 */
#define M_LFRX_TCAP_X               (VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CAL_LFRX_OSC_CODE 0x37 */
#define M_LFRX_OSC_IBIAS            (VAL_BIT6|VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)


/* INT_SYSCTL3 0x44 */
#define M_S3S_DISABLE               VAL_BIT5

/* CUS_SYSCTL1 0x46 */

/* CUS_SYSCTL2 0x47 */
#define M_TIMER_M_SLEEP_11_8        (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_TIMER_R_SLEEP             (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)


/* CUS_SYSCTL3 0x50 */
#define M_LED_INV                   VAL_BIT7
#define M_AFE_IR_EN                 VAL_BIT6
#define M_SNOOZE_EN                 VAL_BIT5
#define M_SNOOZE_DEBUG_EN           VAL_BIT4
#define M_LFRX_DEBUG_EN             VAL_BIT3
#define M_LFRX_EN                   VAL_BIT2
#define M_SLPT_WAKEUP_MODE          VAL_BIT1
#define M_SLEEP_TIMER_EN            VAL_BIT0
/* M_SLPT_WAKEUP_MODE */
#define SLEEP_TIMER_RTC_MODE        0
#define SLEEP_TIMER_WAKEUP_MODE     M_SLPT_WAKEUP_MODE

/* CUS_SYSCTL4 0x51 */
#define M_LFRX_MODE                 (VAL_BIT7|VAL_BIT6)
#define M_LFRX_SIGNAL_OK_TYPE       VAL_BIT5
#define M_LFRX_TIMER_EXTEND_MODE    (VAL_BIT4|VAL_BIT3)
#define M_DUTY_CYCLE_METHOD         VAL_BIT2
#define M_LFRX_DUTY_CYCLE_EN        VAL_BIT1
#define M_ALWAYS_LFRX               VAL_BIT0

/* CUS_SYSCTL5 0x52 */
#define M_LFRX_TIMER_M_RX_T1        (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_LFRX_TIMER_R_RX_T1        (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_SYSCTL6 0x53 */
#define M_LFRX_TIMER_M_RX_T2        (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_LFRX_TIMER_R_RX_T2        (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_SYSCTL7 0x54 */

/* CUS_SYSCTL8 0x55 */
#define M_LFRX_WAKEUP_AUTOCLR_DIS   VAL_BIT5
#define M_LFRX_WAKEUP_MODE          (VAL_BIT4|VAL_BIT3)
#define M_LFRX_TIMER_R_SLEEP        (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_SYSCTL9 0x56 */
#define M_LFRX_RSSI_MEAS_DIS        VAL_BIT7
#define M_LFRX_DBUF_DIS             VAL_BIT6
#define M_LFRX_SNRDET_WIN           (VAL_BIT5|VAL_BIT4|VAL_BIT3)
#define M_LFRX_MEAS_WIN             (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_SYSCTL10 0x57 */
#define M_LFRX_STATE_R              (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_GO_LFRX_CFG               VAL_BIT3
#define M_GO_LFRX_DECODE            VAL_BIT2
#define M_GO_LFRX_LISTEN            VAL_BIT1
#define M_GO_LFSLEEP                VAL_BIT0

/* lfrx state */
#define LFRX_STATE_IS_IDLE             0
#define LFRX_STATE_IS_LISTEN           2
#define LFRX_STATE_IS_SLEEP            3
#define LFRX_STATE_IS_DECODE           6

/* CUS_LFRX15 0x58 */
#define M_LFRX_DBUF_LENGTH          (VAL_BIT7|VAL_BIT6|VAL_BIT5)
#define M_LFRX_WKID_EN              VAL_BIT4
#define M_LFRX_WKID_LENGTH          (VAL_BIT3|VAL_BIT2)
#define M_LFRX_SYNC_LENGTH          (VAL_BIT1|VAL_BIT0)

/* CUS_LFRX16 0x59 */
#define M_LFRX_ANT_MODE             (VAL_BIT7|VAL_BIT6)
#define M_LFRX_HOLD_RST_SEL         VAL_BIT5
#define M_LFRX_SNRDET_REFIN_SEL     VAL_BIT4
#define M_LFRX_MAN_TYPE             VAL_BIT3
#define M_LFRX_WKID_MAN_EN          VAL_BIT2
#define M_LFRX_DIG_DATAOUT_SEL      VAL_BIT1
#define M_LFRX_DATA_MAN_EN          VAL_BIT0

/* CUS_LFRX17 0x5A */

/* CUS_LFRX18 0x5B */

/* CUS_LFRX19 0x5C */

/* CUS_LFRX20 0x5D */

/* CUS_LFRX21 0x5E */

/* CUS_LFRX22 0x5F */

/* CUS_LFRX23 0x60 */

/* CUS_LFRX24 0x61 */

/* CUS_LFRX25 0x62 */
#define M_LFRX_DATAOUT_SEL           VAL_BIT7
#define M_LFRX_DECODE_SEQ            VAL_BIT6
#define M_LFRX_SIGNAL_OK_AUTOCLR_DIS VAL_BIT5
#define M_LFRX_AGC_EN                VAL_BIT4
#define M_LFRX_AGC_STEP              VAL_BIT3
#define M_LFRX_AGC_CNT_TH            (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX26 0x63 */
#define M_LFRX_DQRES                (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_LFRX_AGC_MIN_INDEX        (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX27 0x64 */
#define M_LFRX_DR_SEL               (VAL_BIT7|VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_LFRX_CLKGATE_DIS          VAL_BIT3
#define M_LFRX_ENABLE_MODE          VAL_BIT2
#define M_LFRX_AGC_CLKGATE_DIS      VAL_BIT1
#define M_LFRX_AGC_START_SEL        VAL_BIT0

/* CUS_LFRX28 0x65 */

/* CUS_LFRX29 0x66 */

/* CUS_LFRX30 0x67 */

/* CUS_SYSCTL11 0x68 */
#define M_SLPT_MANU_RSTN            VAL_BIT7
#define M_SNOOZE_MANU_CLR           VAL_BIT4
#define M_LBD_MANU_CLR              VAL_BIT3
#define M_LFRX_MANU_CLR             VAL_BIT2
#define M_SLPT_MANU_CLR             VAL_BIT1
#define M_BUT_MANU_CLR              VAL_BIT0

/* CUS_SYSCTL12 0x69 */
#define M_LFRX_CFG_WAKEUP           VAL_BIT7
#define M_SNOOZE_WAKEUP             VAL_BIT6
#define M_DBMDET_OK                 VAL_BIT5
#define M_WKID_PASS                 VAL_BIT4
#define M_SYNC_PASS                 VAL_BIT3
#define M_LFRX_SIGNAL_OK            VAL_BIT2
#define M_SLEEP_TIMESUP             VAL_BIT1
#define M_KEY_LAUNCH                VAL_BIT0

/* CUS_SYSCTL13 0x6A */
#define M_LBD_STATUS                VAL_BIT7
#define M_LBD_FINISH                VAL_BIT6
#define M_LBD_AVG_SEL               VAL_BIT5
#define M_LBD_ENABLE                VAL_BIT4
#define M_SAR_DATA_UPDATE_HV        VAL_BIT3
#define M_SAR_MSTART                VAL_BIT2
#define M_SAR_TRIGGER               VAL_BIT1
#define M_SAR_CLK_EN                VAL_BIT0

/* CUS_SYSCTL14 0x6B */

/* CUS_SYSCTL15 0x6C */
#define M_SAR_DATA_3_0              (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_SYSCTL16 0x6D */

/* CUS_SYSCTL17 0x6E */

/* CUS_SYSCTL18 0x6F */
#define M_LFRX_DOUT_SEL             (VAL_BIT7|VAL_BIT6)
#define M_LFRX_WPINT_SEL            (VAL_BIT5|VAL_BIT4)
#define M_PAD_GROUP2_EN             VAL_BIT3
#define M_PAD_GROUP1_EN             VAL_BIT2
#define M_LFOSC_CLKOUT_EN           VAL_BIT1
#define M_HFOSC_CLKOUT_EN           VAL_BIT0

/* CUS_SYSCTL19 0x70 */
/* CUS_SYSCTL19 0x70 */
#define M_IRLED_DOUT_EN             VAL_BIT7
#define M_LFRX_OSC_OUT_EN           VAL_BIT6
#define M_LFRX_EXT_CLR_EN           VAL_BIT5
#define M_LFRX_DECODE_ERR_OUT_EN    VAL_BIT2 
#define M_LFRX_DCLK_SEL             (VAL_BIT1|VAL_BIT0)

/* CUS_SYSCTL20 0x71 */
#define M_OTP_CP_VCC_SELN           (VAL_BIT6|VAL_BIT5)
#define M_OTP_CP_VTH_SEL            VAL_BIT4
#define M_GPIO16_ODR                VAL_BIT3
#define M_GPIO16_CNF                VAL_BIT2
#define M_GPIO16_MODE               (VAL_BIT1|VAL_BIT0)
/* gpio input pullup or pulldown */
#define GPIO16_INPUT_PULLUP_DOWN    0
#define GPIO16_INPUT_FLOATING       M_GPIO16_ODR
/* gpio config */
#define GPIO16_CNF_INPUT_PULLUP          0
#define GPIO16_CNF_INPUT_PULLDOWN        M_GPIO16_CNF
#define GPIO16_CNF_OUTPUT_PUSH_PULL      0
#define GPIO16_CNF_OUTPUT_OPEN_DRAIN     M_GPIO16_CNF
/* gpio mode */
#define GPIO16_MODE_AS_ANA           0
#define GPIO16_MODE_AS_DIG_INPUT     VAL_BIT0
#define GPIO16_MODE_AS_DIG_OUTPUT    VAL_BIT1

/* CUS_LFRX31 0x72 */
#define M_LFRX_AGC_INDEX           (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_LFRX32 0x73 */
#define M_MAN_DECODE_ERR_FLAG       VAL_BIT7
#define M_LFRX_MEAS_OUT             (VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_LFRX_IBIAS_CAL_OVTS_FLAG  VAL_BIT3
#define M_LFRX_TCAP2_CAL_OVTS_FLAG  VAL_BIT2
#define M_LFRX_TCAP1_CAL_OVTS_FLAG  VAL_BIT1
#define M_LFRX_TCAP0_CAL_OVTS_FLAG  VAL_BIT0

/* CUS_LFRX33 0x74 */


/* CUS_RESV0 0x75 */

/* CUS_RESV1 0x76 */

/* CUS_RESV2 0x77 */


/* CUS_RESV4 0x79 */
#define M_CAL_SAR_T                 (VAL_BIT6|VAL_BIT5|VAL_BIT4)
#define M_CAL_SAR_B                 (VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* CUS_RESV5 0x7A */
#define M_LPOA0_PIN_DIS             VAL_BIT7
#define M_LPOA1_PIN_DIS             VAL_BIT6
#define M_WDT_REFRESH               VAL_BIT5
#define M_WDT_START                 VAL_BIT4
#define M_WDT_RESET_TH              (VAL_BIT3|VAL_BIT2|VAL_BIT1)
#define M_WDT_DIS                   VAL_BIT0  
/* watchdog reset threhold */
#define WDT_RESET_TH_32MS           (0 << BIT1) 
#define WDT_RESET_TH_64MS           (1 << BIT1)
#define WDT_RESET_TH_128MS          (2 << BIT1)
#define WDT_RESET_TH_256MS          (3 << BIT1)
#define WDT_RESET_TH_512MS          (4 << BIT1)
#define WDT_RESET_TH_1S             (5 << BIT1)
#define WDT_RESET_TH_2S             (6 << BIT1)
#define WDT_RESET_TH_4S             (7 << BIT1)

/* interrupt source */  
/* note: it can be assign to EXn_VECTOR, n is 0 to 7 */
#define INT_POLAR                    0x40            
#define INT_SRC_GPIO_PIN_0           0x00
#define INT_SRC_GPIO_PIN_1           0x01
#define INT_SRC_GPIO_PIN_2           0x02
#define INT_SRC_GPIO_PIN_3           0x03
#define INT_SRC_GPIO_PIN_4           0x04
#define INT_SRC_GPIO_PIN_5           0x05
#define INT_SRC_GPIO_PIN_6           0x06
#define INT_SRC_GPIO_PIN_7           0x07
#define INT_SRC_GPIO_PIN_8           0x08
#define INT_SRC_GPIO_PIN_9           0x09
#define INT_SRC_GPIO_PIN_10          0x0A
#define INT_SRC_GPIO_PIN_11          0x0B
#define INT_SRC_GPIO_PIN_12          0x0C
#define INT_SRC_GPIO_PIN_13          0x0D
#define INT_SRC_GPIO_PIN_14          0x0E
#define INT_SRC_GPIO_PIN_15          0x0F
#define INT_SRC_SLEEP_TIMESUP        0x10
#define INT_SRC_LFRX_MCU_RCLK        0x11
#define INT_SRC_LFRX_MCU_RDATA       0x12
#define INT_SRC_GPIO_IN_16           0x13
#define INT_SRC_WKID_PASS            0x14
#define INT_SRC_SYNC_PASS            0x15
#define INT_SRC_SAR_DATA_UPDATE      0x16
#define INT_SRC_LFRX_SIGNAL_OK       0x17
#define INT_SRC_TMR_IFG              0x18
#define INT_SRC_CCR0_IFG             0x19
#define INT_SRC_CCR1_IFG             0x1A
#define INT_SRC_CCR2_IFG             0x1B
#define INT_SRC_TX_SYM_EMPTY         0x1C
#define INT_SRC_SPI_TXE              0x1D
#define INT_SRC_SPI_RXNE             0x1E
#define INT_SRC_TMRB_IFG             0x1F
#define INT_SRC_TBCCR0_IFG           0x20
#define INT_SRC_TBCCR1_IFG           0x21
#define INT_SRC_TBCCR2_IFG           0x22

#define INT_SRC_TMRA_IFG             0x18
#define INT_SRC_TACCR0_IFG           0x19
#define INT_SRC_TACCR1_IFG           0x1A
#define INT_SRC_TACCR2_IFG           0x1B

/* interrupt vector number */
#define INT_EX0_VECTOR				 0
#define	INT_EX1_VECTOR				 2						
#define INT_TIMER1_VECTOR			 3
#define INT_UART_VECTOR				 4
#define INT_EX2_VECTOR	  			 9
#define INT_EX3_VECTOR				 10
#define INT_EX4_VECTOR				 11
#define INT_EX5_VECTOR				 12
#define INT_EX6_VECTOR				 13
#define INT_EX7_VECTOR				 14
  

#endif



































