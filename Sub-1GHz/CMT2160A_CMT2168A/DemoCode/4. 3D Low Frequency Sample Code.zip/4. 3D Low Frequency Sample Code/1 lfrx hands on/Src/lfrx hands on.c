/*!********************************************************************************************************
* @file : lfrx hands on.c
* @desc : 1. this is a demo for lfrx
*         2. 
*         3. 
*            
*  
* @version 	1.0
* @date  	Sep 29 2019
* @author 
*
*Copyright (C) CMOSTEK MICROELECTRONICS CO., LTD.
*
***********************************************************************************************************/

#include "cmt216xa.h"

//************************  selection of DATA output mode, only one of below  ********************************
#define 	DATA_OUT_RAW								//Raw Data Output, but no DCLK & Wakeup
//#define 	DATA_OUT_AFTER_SIGNAL						//CDR Data + Dclk Output, After when lfrx_signal_ok == 1 
//#define 	DATA_OUT_AFTER_WAKEUP						//Decode Data + Dclk Output, After when lfrx_wakup == 1


//************************************  selection of Packet Handler  *****************************************
//#define	SYNC_LENGTH				2				// sync length, N+1
//#define	SYNC_VALUE				0xAB8B32		// sync value 	

#define	SYNC_LENGTH					1				// sync length, N+1
#define	SYNC_VALUE					0x8B32			// sync value 	


#define	ENABLE_WAKEUP_ID							//
#define	WKID_LENGTH					3				// wkid length, N+1
#define	WKID_VALUE					0x34789A6C		// wkid value 


/*************************************************************************************************************
*@name:    system_set_lfrx_config
*@desc:    set lfrx config
*@param:   none
*@return:  none 
**************************************************************************************************************/
void system_set_lfrx_config(void)
{      
    STRU_LFRX_SETUP xdata lfrx_cfg;
    
    #define lfrx_pga_ibias_val             	4 					//export from cmt216xa RFPDK
    #define lfrx_rssiamp_ibias_val         	4 
    #define lfrx_rssirec_ibias_val         	4 
    #define lfrx_startup_manual_val        	3 
    #define lfrx_ant_mode_val              	2 					// 2'b00 or 2'b01---normal ant mode;    2'b10---x and y scan ant mode;    2'b11---x/y/z scan ant mode
    #define lfrx_ch_x_val                  	0 					
    #define lfrx_ch_y_val                  	0 
    #define lfrx_ch_z_val                  	0 
    #define lfrx_dr_sel_val                	3					// 3 equ 4kbps 
    #define lfrx_data_c1_val               	6 			
    #define lfrx_data_c0_val               	1 
    #define lfrx_data_r0_val               	3 
    #define lfrx_data_r1_val               	3 
    #define lfrx_data_c2_val               	3 
    #define lfrx_data_c3_val               	11 
    #define lfrx_data_clk_val              	3 
    #define lfrx_peakdet_clk_val           	1 
    #define lfrx_peakdet_c_val             	3
    #define lfrx_agc_vhref_val             	15 
    #define lfrx_agc_vlref_val             	8 
    #define lfrx_agc_cnt_val               	2 
    #define lfrx_agc_en_val                	1 
    #define lfrx_agc_in_val                	3 
    #define lfrx_agc_start_sel_val         	0 
    #define lfrx_agc_step_val              	1 
    #define lfrx_agc_cnt_th_val            	4 
    #define lfrx_agc_min_index_val         	0 
    #define lfrx_dqres_val                 	5 
    #define lfrx_cadet_win_val             	2 
    #define lfrx_cadet_ok_cnt_val          	0 
    #define lfrx_cadet_th_h_val            	124 
    #define lfrx_cadet_th_l_val            	101 
    #define lfrx_cmp_noise_mask_val        	1 
    #define lfrx_cmp_sw_val                	1 
    #define lfrx_cmp_ref_val               	13 
    #define lfrx_snrdet_snr_val            	5
    #define lfrx_snrdet_valid_win_val      	1 
    #define lfrx_snrdet_invalid_win_val    	0
    #define lfrx_snrdet_win_val            	5 
    #define lfrx_snrdet_refin_sel_val      	0          
    #define lfrx_signal_ok_type_val        	1 					// 0: Carrier Detect        1: SNR Detect
    #define lfrx_signal_ok_autoclr_dis_val 	0 
    #define lfrx_signal_ok_clr_th_val      	50 					// N * unit for auto clear signal_ok, when lfrx_signal_ok_autoclr_dis == 0
    #define lfrx_wakeup_autoclr_dis_val    	0 					// 0: always on				1: change to manual when lfrx_wakeup = 1
    #define lfrx_meas_win_val              	2 
    #define lfrx_meas_source_val           	1 
    #define lfrx_rssi_meas_dis_val         	0 					// 	
    #define lfrx_decode_seq_val            	0 					// 0: MSB first;			1: LSB first
    #define lfrx_sync_length_val           	SYNC_LENGTH			// sync length, range: 0-3, n+1
    #define lfrx_sync_value_val            	SYNC_VALUE
	
	#ifdef ENABLE_WAKEUP_ID
    	#define lfrx_wkid_en_val           	1 					// 0: disable wkid;			1: enable wkid
	#endif
    #define lfrx_wkid_length_val           	WKID_LENGTH			// wikd length, range:0-3, n+1
    #define lfrx_wkid_value_val            	WKID_VALUE

    #define lfrx_man_type_val              	1 					// 0: '01'==1, '10'==0;    	1: '10'==1, '01'==0
    #define lfrx_wkid_man_en_val           	1 					// 0: dianble man.wkid;		1: enable man.wkid;	
    #define lfrx_data_man_en_val           	1 					// 0: disable man.payload;	1: enable man.payload;
    #define lfrx_data_length_val           	8 
    #define lfrx_dbuf_dis_val              	0 					// 0: enable delay buffer;	1: disable delay buffer
    #define lfrx_dbuf_length_val           	7 					// receive data delay buffer length, range 0-7 
    #define lfrx_en_val                    	1 
    #define lfrx_enable_mode_val           	0 					// 0: listen & decode;    	1: only decode
    #define always_lfrx_val                	1 					// 0: for DC mode;			1: always receive
    #define lfrx_duty_cycle_en_val         	0 					// 0: disable DC mode;		1: enable DC mode (and always_lfrx_val should be 0)
    #define duty_cycle_method_val          	0 					// 0: auto extend DC mode;	1: fixed DC mode
    #define lfrx_timer_extend_mode_val     	0 					// extend condition select, 2'b00: by signal_ok;	2'b01: by sync_pass; 	2'b10: by wkid_pass;	3'b11: no used
    #define lfrx_timer_m_sleep_val         	0 
    #define lfrx_timer_r_sleep_val         	0 
    #define lfrx_timer_m_rx_t1_val         	1 
    #define lfrx_timer_r_rx_t1_val         	0 
    #define lfrx_timer_m_rx_t2_val         	0 
    #define lfrx_timer_r_rx_t2_val         	0 
    #define lfrx_wakeup_mode_val           	2 					// 2'b00: signal_ok;  		2'b01: sync_passs;		2'b10: wkid_pass; 		2'b11:reserved
    #define lfrx_mode_val                  	0 					// 2'b00: wakeup internal mcu; 	2'b01: wakeup external mcu;
    #define lfrx_clkgate_dis_val           	0 					
    #define lfrx_agc_clkgate_dis_val       	0 
    #define lfrx_demod_th_hold_val         	1 
    #define lfrx_hold_rst_sel_val          	0 

	//DATA Output selection
	#ifdef	DATA_OUT_RAW										//Raw Data Output
		#define	lfrx_dataout_sel_val       	1
		#define lfrx_dig_dataout_sel_val   	0			
	#endif
	
	#ifdef 	DATA_OUT_AFTER_SIGNAL								//CDR Data + Dclk Output, After when lfrx_signal_ok == 1 
		#define	lfrx_dataout_sel_val		0
		#define lfrx_dig_dataout_sel_val   	1
	#endif
	
	#ifdef	DATA_OUT_AFTER_WAKEUP								//Decode Data + Dclk Output, After when lfrx_wakup == 1
		#define	lfrx_dataout_sel_val		0
		#define lfrx_dig_dataout_sel_val   	0
	#endif

    #define lfosc_f_sel_val                	1 
    #define lfrx_osc_vref_val              	2 
    
    #define pad_group1_en_val             	0					// select A5/A6/A7 
    #define pad_group2_en_val             	1 					// select A1/A2/A3
    #define lfrx_dout_sel_val             	0 					// 0:A1/A5,   1:A2/A6,   2:A3/A7 
    #define lfrx_wpint_sel_val            	1 					//
    #define lfrx_dclk_sel_val             	2 					//
    #define lfrx_ext_clr_en_val           	0 					// 1:select A4
    #define lfrx_decode_err_out_en_val    	1					// select B5/B6 
    
    
    //lfrx_agc_cfg0
    //bit[7:6]: reserved
    //bit[5:4]: lfrx_agc_in  AGC Input 
    //bit[3:0]: lfrx_agc_vhref 
    lfrx_cfg.lfrx_agc_cfg0 = ((lfrx_agc_in_val << BIT4) & M_LFRX_AGC_IN) | ((lfrx_agc_vhref_val << BIT0) & M_LFRX_AGC_VHREF);
    
    //lfrx_agc_cfg1
    //bit[7:6]: reserved
    //bit[5:4]: lfrx_agc_cnt 
    //bit[3:0]: lfrx_agc_vlref 
    lfrx_cfg.lfrx_agc_cfg1 = ((lfrx_agc_cnt_val << BIT4) & M_LFRX_AGC_CNT) | ((lfrx_agc_vlref_val << BIT0) & M_LFRX_AGC_VLREF);
    
    //lfrx_cadet_cfg
    //bit[7:6]: lfrx_cadet_win 
    //bit[5:4]: lfrx_cadet_ok_cnt 
    //bit[3:2]: lfrx_peakdet_clk  
    //bit[1:0]: lfrx_data_clk
    lfrx_cfg.lfrx_cadet_cfg = ((lfrx_cadet_win_val << BIT6) & M_LFRX_CADET_WIN) | ((lfrx_cadet_ok_cnt_val << BIT4) & M_LFRX_CADET_OK_CNT) | ((lfrx_peakdet_clk_val << BIT2) & M_LFRX_PEAKDET_CLK) | ((lfrx_data_clk_val << BIT0) & M_LFRX_DATA_CLK);
    
    //lfrx_data_cfg0
    //bit[7:6]: lfrx_data_r0
    //bit[5:4]: lfrx_data_r1 
    //bit[3:2]: lfrx_peakdet_c
    //bit[1:0]: lfosc_f_sel
    lfrx_cfg.lfrx_data_cfg0 = ((lfrx_data_r0_val << BIT6) & M_LFRX_DATA_R0) | ((lfrx_data_r1_val << BIT4) & M_LFRX_DATA_R1) | ((lfrx_peakdet_c_val << BIT2) & M_LFRX_PEAKDET_C) | ((lfosc_f_sel_val << BIT0) & M_LFOSC_F_SEL);
    
    //lfrx_data_cfg1
    //bit[7:4]: lfrx_data_c1 
    //bit[3:0]: lfrx_data_c0 
    lfrx_cfg.lfrx_data_cfg1 = ((lfrx_data_c1_val << BIT4) & M_LFRX_DATA_C1) | ((lfrx_data_c0_val << BIT0) & M_LFRX_DATA_C0);
    
    //lfrx_data_cfg2
    //bit[7:6]: lfrx_data_c3 
    //bit[3:0]: lfrx_data_c2 
    lfrx_cfg.lfrx_data_cfg2 = ((lfrx_data_c3_val << BIT6) & M_LFRX_DATA_C3) | ((lfrx_data_c2_val << BIT0) & M_LFRX_DATA_C2);
    
    //lfrx_cmp_cfg0
    //bit[7]: 	lfrx_cmp_noise_mask 
    //bit[6]: 	lfrx_cmp_sw 
    //bit[5:3]: lfrx_rssiamp_ibias 
    //bit[2:0]: lfrx_pga_ibias
    lfrx_cfg.lfrx_cmp_cfg0 = ((lfrx_cmp_noise_mask_val << BIT7) & M_LFRX_CMP_NOISE_MASK) | ((lfrx_cmp_sw_val << BIT6) & M_LFRX_CMP_SW) | ((lfrx_rssiamp_ibias_val << BIT3) & M_LFRX_RSSIAMP_IBIAS) | ((lfrx_pga_ibias_val << BIT0) & M_LFRX_PGA_IBIAS);
    
    //lfrx_cmp_cfg1
    //bit[7:4]: lfrx_cmp_ref 
    //bit[3]: 	lfrx_demod_th_hold
    //bit[2:0]: lfrx_rssirec_ibias
    lfrx_cfg.lfrx_cmp_cfg1 = ((lfrx_cmp_ref_val << BIT4) & M_LFRX_CMP_REF) | ((lfrx_demod_th_hold_val << BIT3) & M_LFRX_DEMOD_TH_HOLD) | ((lfrx_rssirec_ibias_val << BIT0) & M_LFRX_RSSIREC_IBIAS);
    
    //lfrx_snrdet_cfg0
    //bit[7:6]: lfrx_snrdet_invalid_win
    //bit[5:4]: lfrx_snrdet_valid_win 
    //bit[3:0]: lfrx_snrdet_snr  
    lfrx_cfg.lfrx_snrdet_cfg0 = ((lfrx_snrdet_invalid_win_val << BIT6) & M_LFRX_SNRDET_INVALID_WIN) | ((lfrx_snrdet_valid_win_val << BIT4) & M_LFRX_SNRDET_VALID_WIN) | ((lfrx_snrdet_snr_val << BIT0) & M_LFRX_SNRDET_SNR);
    
    //lfrx_ch_cfg
    //bit[7]: 	lfrx_meas_source
    //bit[6:5]: lfrx_osc_vref
    //bit[4]: 	lfrx_ch_z
    //bit[3]: 	lfrx_ch_y
    //bit[2]: 	lfrx_ch_x
    //bit[1:0]: lfrx_startup_manual
    lfrx_cfg.lfrx_ch_cfg = ((lfrx_meas_source_val << BIT7) & M_LFRX_MEAS_SOURCE) | ((lfrx_osc_vref_val << BIT5) & M_LFRX_OSC_VREF) | ((lfrx_ch_z_val << BIT4) & M_LFRX_CH_Z) | ((lfrx_ch_y_val << BIT3) & M_LFRX_CH_Y) | ((lfrx_ch_x_val << BIT2) & M_LFRX_CH_X) | ((lfrx_startup_manual_val << BIT0) & M_LFRX_STARTUP_MANUAL);
    
    //lfrx_mode_cfg
    //bit[7:6]: lfrx_mode  
    //bit[5]: 	lfrx_signal_ok_type 
    //bit[4:3]: lfrx_timer_extend_mode 
    //bit[2]: 	duty_cycle_method 
    //bit[1]: 	lfrx_duty_cycle_en 
    //bit[0]: 	always_lfrx  
    lfrx_cfg.lfrx_mode_cfg = ((lfrx_mode_val << BIT6) & M_LFRX_MODE) | ((lfrx_signal_ok_type_val << BIT5) & M_LFRX_SIGNAL_OK_TYPE) | ((lfrx_timer_extend_mode_val << BIT3) & M_LFRX_TIMER_EXTEND_MODE) | ((duty_cycle_method_val << BIT2) & M_DUTY_CYCLE_METHOD) | ((lfrx_duty_cycle_en_val << BIT1) & M_LFRX_DUTY_CYCLE_EN) | ((always_lfrx_val << BIT0) & M_ALWAYS_LFRX);
    
    //lfrx_timer_cfg0
    //bit[7:3]: lfrx_timer_m_rx_t1 
    //bit[2:0]: lfrx_timer_r_rx_t1 
    lfrx_cfg.lfrx_timer_cfg0 = ((lfrx_timer_m_rx_t1_val << BIT3) & M_LFRX_TIMER_M_RX_T1) | ((lfrx_timer_r_rx_t1_val << BIT0) & M_LFRX_TIMER_R_RX_T1);
    
    //lfrx_timer_cfg1
    //bit[7:3]: lfrx_timer_m_rx_t2 
    //bit[2:0]: lfrx_timer_r_rx_t2 
    lfrx_cfg.lfrx_timer_cfg1 = ((lfrx_timer_m_rx_t2_val << BIT3) & M_LFRX_TIMER_M_RX_T2) | ((lfrx_timer_r_rx_t2_val << BIT0) & M_LFRX_TIMER_R_RX_T2);
    
    //lfrx_timer_cfg2
    //bit[7:0]: lfrx_timer_m_sleep
    lfrx_cfg.lfrx_timer_cfg2 = lfrx_timer_m_sleep_val;
    
    //lfrx_timer_cfg3
    //bit[7:6]: reserved
    //bit[5]:   lfrx_wakeup_autoclr_dis
    //bit[4:3]: lfrx_wakeup_mode  
    //bit[2:0]: lfrx_timer_r_sleep  
    lfrx_cfg.lfrx_timer_cfg3 = ((lfrx_wakeup_autoclr_dis_val << BIT5) & M_LFRX_WAKEUP_AUTOCLR_DIS) | ((lfrx_wakeup_mode_val << BIT3) & M_LFRX_WAKEUP_MODE) | ((lfrx_timer_r_sleep_val << BIT0) & M_LFRX_TIMER_R_SLEEP);
    
    //lfrx_snrdet_cfg1
    //bit[7]: 	lfrx_rssi_meas_dis 
    //bit[6]: 	lfrx_dbuf_dis
    //bit[5:3]: lfrx_snrdet_win 
    //bit[2:0]: lfrx_meas_win 0: 
    lfrx_cfg.lfrx_snrdet_cfg1 = ((lfrx_rssi_meas_dis_val << BIT7) & M_LFRX_RSSI_MEAS_DIS) | ((lfrx_dbuf_dis_val << BIT6) & M_LFRX_DBUF_DIS) | ((lfrx_snrdet_win_val << BIT3) & M_LFRX_SNRDET_WIN) | ((lfrx_meas_win_val << BIT0) & M_LFRX_MEAS_WIN);
    
    //lfrx_packet_cfg0
    //bit[7:5]: lfrx_dbuf_length
    //bit[4]: 	lfrx_wkid_en 
    //bit[3:2]: lfrx_wkid_length 
    //bit[1:0]: lfrx_sync_lenth 
    lfrx_cfg.lfrx_packet_cfg0 = ((lfrx_dbuf_length_val << BIT5) & M_LFRX_DBUF_LENGTH) | ((lfrx_wkid_en_val << BIT4) & M_LFRX_WKID_EN) | ((lfrx_wkid_length_val << BIT2) & M_LFRX_WKID_LENGTH) | ((lfrx_sync_length_val << BIT0) & M_LFRX_SYNC_LENGTH);
    
    //lfrx_packet_cfg1
    //bit[7:6]: lfrx_ant_mode  
    //bit[5]: 	lfrx_hold_rst_sel  
    //bit[4]: 	lfrx_snrdet_refin_sel 
    //bit[3]: 	lfrx_man_type 
    //bit[2]: 	lfrx_wkid_man_en 
    //bit[1]: 	lfrx_dig_dataout_sel
    //bit[0]: 	lfrx_data_man_en 
    lfrx_cfg.lfrx_packet_cfg1 = ((lfrx_ant_mode_val << BIT6) & M_LFRX_ANT_MODE) | ((lfrx_hold_rst_sel_val << BIT5) & M_LFRX_HOLD_RST_SEL) | ((lfrx_snrdet_refin_sel_val << BIT4) & M_LFRX_SNRDET_REFIN_SEL) | ((lfrx_man_type_val << BIT3) & M_LFRX_MAN_TYPE) | ((lfrx_wkid_man_en_val << BIT2) & M_LFRX_WKID_MAN_EN) | ((lfrx_dig_dataout_sel_val << BIT1) & M_LFRX_DIG_DATAOUT_SEL) | ((lfrx_data_man_en_val << BIT0) & M_LFRX_DATA_MAN_EN);
    
    //lfrx_sync_value_cfg0
    //bit[7:0]: lfrx_sync_value[7:0]
    lfrx_cfg.lfrx_sync_value_cfg0 = lfrx_sync_value_val;
    
    //lfrx_sync_value_cfg1
    //bit[7:0]: lfrx_sync_value[15:8]
    lfrx_cfg.lfrx_sync_value_cfg1 = (lfrx_sync_value_val >> 8);
    
    //lfrx_sync_value_cfg2
    //bit[7:0]: lfrx_sync_value[23:16]
    lfrx_cfg.lfrx_sync_value_cfg2 = (lfrx_sync_value_val >> 16);
    
    //lfrx_sync_value_cfg3
    //bit[7:0]: lfrx_sync_value[31:24]
    lfrx_cfg.lfrx_sync_value_cfg3 = (lfrx_sync_value_val >> 24);
    
    //lfrx_wkid_value_cfg0
    //bit[7:0]: lfrx_wkid_value[7:0]
    lfrx_cfg.lfrx_wkid_value_cfg0 = lfrx_wkid_value_val;
    
    //lfrx_wkid_value_cfg1
    //bit[7:0]: lfrx_wkid_value[15:8]
    lfrx_cfg.lfrx_wkid_value_cfg1 = (lfrx_wkid_value_val >> 8);
    
    //lfrx_wkid_value_cfg2
    //bit[7:0]: lfrx_wkid_value[23:16]
    lfrx_cfg.lfrx_wkid_value_cfg2 = (lfrx_wkid_value_val >> 16);
    
    //lfrx_wkid_value_cfg3
    //bit[7:0]: lfrx_wkid_value[31:24]
    lfrx_cfg.lfrx_wkid_value_cfg3 = (lfrx_wkid_value_val >> 24);
    
    //lfrx_agc_cfg2
    //bit[7]: 	lfrx_dataout_sel 
    //bit[6]: 	lfrx_decode_seq 
    //bit[5]: 	lfrx_signal_ok_autoclr_dis  
    //bit[4]: 	lfrx_agc_en 
    //bit[3]: 	lfrx_agc_step  
    //bit[2:0]: lfrx_agc_cnt_th  
    lfrx_cfg.lfrx_agc_cfg2 = ((lfrx_dataout_sel_val << BIT7) & M_LFRX_DATAOUT_SEL) | ((lfrx_decode_seq_val << BIT6) & M_LFRX_DECODE_SEQ) | ((lfrx_signal_ok_autoclr_dis_val << BIT5) & M_LFRX_SIGNAL_OK_AUTOCLR_DIS) | ((lfrx_agc_en_val << BIT4) & M_LFRX_AGC_EN) | ((lfrx_agc_step_val << BIT3) & M_LFRX_AGC_STEP) | ((lfrx_agc_cnt_th_val << BIT0) & M_LFRX_AGC_CNT_TH);
    
    //lfrx_agc_cfg3
    //bit[7:4]: lfrx_dqres 
    //bit[3:0]: lfrx_agc_min_index  
    lfrx_cfg.lfrx_agc_cfg3 = ((lfrx_dqres_val << BIT4) & M_LFRX_DQRES) | ((lfrx_agc_min_index_val << BIT0) & M_LFRX_AGC_MIN_INDEX);
    
    //lfrx_agc_cfg4
    //bit[7:4]: lfrx_dr_sel
    //bit[3]: 	lfrx_clkgate_dis 
    //bit[2]: 	lfrx_enable_mode 
    //bit[1]: 	lfrx_agc_clkgate_dis
    //bit[0]: 	lfrx_agc_start_sel 
    lfrx_cfg.lfrx_agc_cfg4 = ((lfrx_dr_sel_val << BIT4) & M_LFRX_DR_SEL) | ((lfrx_clkgate_dis_val << BIT3) & M_LFRX_CLKGATE_DIS) | ((lfrx_enable_mode_val << BIT2) & M_LFRX_ENABLE_MODE) | ((lfrx_agc_clkgate_dis_val << BIT1) & M_LFRX_AGC_CLKGATE_DIS) | ((lfrx_agc_start_sel_val << BIT0) & M_LFRX_AGC_START_SEL);
    
    //lfrx_cadet_th_h_cfg
    //bit[7:0]: lfrx_cadet_th_h 
    lfrx_cfg.lfrx_cadet_th_h_cfg = lfrx_cadet_th_h_val;
    
    //lfrx_cadet_th_l_cfg
    //bit[7:0]: lfrx_cadet_th_l  
    lfrx_cfg.lfrx_cadet_th_l_cfg = lfrx_cadet_th_l_val;
    
    //lfrx_signal_ok_clr_th_cfg
    //bit[7:0]: lfrx_signal_ok_clr_th 
    lfrx_cfg.lfrx_signal_ok_clr_th_cfg = lfrx_signal_ok_clr_th_val;
    
    //lfrx_data_length_cfg
    //bit[7:0]: lfrx_data_length 
    lfrx_cfg.lfrx_data_length_cfg = lfrx_data_length_val;
    
    lfrx_setup_config(&lfrx_cfg);									// config lfrx setup

    sys_set_hv_reg(CUS_SYSCTL18_ADDR, ((lfrx_dout_sel_val << BIT6) & M_LFRX_DOUT_SEL) | ((lfrx_wpint_sel_val << BIT4) & M_LFRX_WPINT_SEL) | ((pad_group2_en_val << BIT3) & M_PAD_GROUP2_EN) | ((pad_group1_en_val << BIT2) & M_PAD_GROUP1_EN), (M_LFRX_DOUT_SEL | M_LFRX_WPINT_SEL | M_PAD_GROUP2_EN | M_PAD_GROUP1_EN));
    sys_set_hv_reg(CUS_SYSCTL19_ADDR, ((lfrx_ext_clr_en_val << BIT5) & M_LFRX_EXT_CLR_EN) | ((lfrx_decode_err_out_en_val << BIT2) & M_LFRX_DECODE_ERR_OUT_EN) | ((lfrx_dclk_sel_val << BIT0) & M_LFRX_DCLK_SEL), (M_LFRX_EXT_CLR_EN | M_LFRX_DECODE_ERR_OUT_EN | M_LFRX_DCLK_SEL));
    sys_set_hv_reg(CUS_SYSCTL3_ADDR, ((lfrx_en_val << BIT2) & M_LFRX_EN), M_LFRX_EN);
}


void delay_1ms(void)
{
 sys_delay_us_count(250);
 sys_delay_us_count(250);
 sys_delay_us_count(250);
 sys_delay_us_count(250);
} 

void delay_10ms(void)
{
 byte ind;
 for(ind = 0; ind < 10; ind++)
	delay_1ms();
}

void delay_100ms(void)
{
 byte ind;
 for(ind = 0; ind < 10; ind++)
	delay_10ms();
}

void delay_1s(void)
{
 byte ind;
 for(ind = 0; ind < 10; ind++)
	delay_100ms();
}

                 
void main(void)   
{
 byte tmp;

 IEN0 = 0x00;
 IEN1 = 0x00;
 sys_clear_system_flag();
 
 //init port
 sys_set_hv_reg(CUS_PADCTL2_ADDR, (GPIO5_MODE_AS_DIG_OUTPUT|GPIO6_MODE_AS_DIG_OUTPUT|GPIO7_MODE_AS_DIG_OUTPUT), (M_GPIO5_MODE|M_GPIO6_MODE|M_GPIO7_MODE));
 sys_set_hv_reg(CUS_PADCTL4_ADDR, GPIO13_MODE_AS_DIG_OUTPUT, M_GPIO13_MODE);
 sys_set_hv_reg(CUS_PADCTL5_ADDR, (GPIO5_CNF_OUTPUT_PUSH_PULL|GPIO6_CNF_OUTPUT_PUSH_PULL|GPIO7_CNF_OUTPUT_PUSH_PULL), (M_GPIO5_CNF|M_GPIO6_CNF|M_GPIO7_CNF)); 	
 sys_set_hv_reg(CUS_PADCTL6_ADDR, GPIO13_CNF_OUTPUT_PUSH_PULL, M_GPIO13_CNF);	
 sys_set_hv_reg(CUS_PADCTL11_ADDR, (GPIO5_INPUT_FLOATING|GPIO6_INPUT_FLOATING|GPIO7_INPUT_FLOATING), (M_GPIO5_ODR|M_GPIO6_ODR|M_GPIO7_ODR));		
 sys_set_hv_reg(CUS_PADCTL12_ADDR, GPIO13_INPUT_FLOATING, M_GPIO13_ODR);
 
 
 sys_set_hv_reg(CUS_SYSCTL3_ADDR, M_S3S_DISABLE, M_S3S_DISABLE);						// disable S3S

 if(sys_is_first_power_up())
    {
    sys_enable_low_32khz_clock(0);														// lfrx need to enable 32khz clock
    delay_1ms();
	           
    sys_set_hv_reg(CUS_SYSCTL11_ADDR, M_LFRX_MANU_CLR, M_LFRX_MANU_CLR);				// set lfrx_manu_clr = 1
	
	system_set_lfrx_config();															// config lfrx setup 

	sys_set_hv_reg(CUS_SYSCTL3_ADDR, M_LFRX_DEBUG_EN, M_LFRX_DEBUG_EN);					// set 1 for 1-wire debug
    
	//sys_shutdown();
    } 

 while(1)
 	{
	delay_100ms();
	
	tmp = sys_get_lfrx_state();
	}

}
