#ifndef _CMT216XA_TYPES_H_
#define _CMT216XA_TYPES_H_

typedef unsigned char            BYTE;      // "b"
typedef unsigned int             WORD;      // "w"
typedef unsigned long int        LWORD;     // "l"
typedef signed char              CHAR;      // "c"

typedef unsigned char			 byte;		// "b"
typedef unsigned int			 word;		// "w"
typedef unsigned long int		 lword;		// "l"

typedef unsigned char            uint8_t;   // "b"
typedef unsigned int             uint16_t;  // "w"
typedef unsigned long int        uint32_t;  // "l"

typedef signed char              int8_t;    // "c"
typedef signed int               int16_t;   // "i"
typedef signed long int          int32_t;   // "j"

#endif