#ifndef _CMT216XA_SFR_H_
#define _CMT216XA_SFR_H_

#define BIT0                0
#define BIT1                1
#define BIT2                2
#define BIT3                3
#define BIT4                4
#define BIT5                5
#define BIT6                6
#define BIT7                7

/********* T8051XC3 core SFR **********/
/*************** Bank 0 ***************/

sfr B                    = 0xF0;
sfr IRCON1               = 0xF1;
sfr IPL1                 = 0xF6;
sfr ACC                  = 0xE0;
sfr IEN1                 = 0xE6;
sfr PSW                  = 0xD0;
sfr IPL0                 = 0xB8;
sfr IEN0                 = 0xA8;
sfr P2                   = 0xA0;
sfr PMOD                 = 0xA7;
sfr SCON0                = 0x98;
sfr SBUF0                = 0x99;
sfr TCON                 = 0x88;
sfr TMOD                 = 0x89;
sfr TL1                  = 0x8B;
sfr TH1                  = 0x8D;
sfr P0                   = 0x80;
sfr SP                   = 0x81;
sfr DPL                  = 0x82;
sfr DPH                  = 0x83;
sfr PCON                 = 0x87;

// PSW
sbit CY					 = PSW^BIT7;
sbit AC					 = PSW^BIT6;
sbit UGF0				 = PSW^BIT5;
sbit RS1				 = PSW^BIT4;
sbit RS0				 = PSW^BIT3;
sbit OV					 = PSW^BIT2;
sbit UGF1				 = PSW^BIT1;
sbit P					 = PSW^BIT0;

// IPL0
sbit IPL_ES0			 = IPL0^BIT4;
sbit IPL_ET1			 = IPL0^BIT3;
sbit IPL_EX1			 = IPL0^BIT2;
sbit IPL_EX0			 = IPL0^BIT0;

//  IE0
sbit EA   				 = IEN0^BIT7;
sbit ES   				 = IEN0^BIT4;
sbit ET1  				 = IEN0^BIT3;
sbit EX1  				 = IEN0^BIT2;
sbit EX0  				 = IEN0^BIT0;

// SCON0
sbit FE0                 = SCON0^BIT7;
sbit SM00                = SCON0^BIT7;
sbit SM10                = SCON0^BIT6;
sbit SM20                = SCON0^BIT5;
sbit REN0                = SCON0^BIT4;
sbit TB80                = SCON0^BIT3;
sbit RB80                = SCON0^BIT2;
sbit TI0                 = SCON0^BIT1;
sbit RI0                 = SCON0^BIT0;

// TCON
sbit TF1                 = TCON^BIT7;
sbit TR1                 = TCON^BIT6;
sbit IE1                 = TCON^BIT3;
sbit IT1                 = TCON^BIT2;
sbit IE0                 = TCON^BIT1;
sbit IT0                 = TCON^BIT0;

// P0
sbit P00                 = P0^BIT0;
sbit P01                 = P0^BIT1;
sbit P02                 = P0^BIT2;
sbit P03                 = P0^BIT3;
sbit P04                 = P0^BIT4;
sbit P05                 = P0^BIT5;
sbit P06                 = P0^BIT6;
sbit P07                 = P0^BIT7;

/*********** CMT216x SFR ****************/
/*********** bank 0 sfr *****************/
sfr CLK_SYS_DIV          = 0x8F;
sfr BOOT_DONE_FLAG       = 0x90;
sfr SPI_CTL1_H           = 0x91;
sfr SPI_CTL1_L           = 0x92;
sfr SPI_CTL2_H           = 0x93;

sfr SPI_DATA_H           = 0x95;
sfr SPI_DATA_L           = 0x96;
sfr UART_CTL             = 0x97;

sfr TACLK_DIV_H          = 0x9A;
sfr TACLK_DIV_L          = 0x9B;
sfr TACH                 = 0x9C;
sfr TACL                 = 0x9D;
sfr TARH                 = 0x9E;
sfr TARL                 = 0x9F;

sfr TACCR0H              = 0xA1;
sfr TACCR0L              = 0xA2;
sfr TACCTL0H             = 0xA3;
sfr TACCTL0L             = 0xA4;
sfr TACCR1H              = 0xA5;
sfr TACCR1L              = 0xA6;

sfr TACCTL1H             = 0xA9;
sfr TACCTL1L             = 0xAA;
sfr TACCR2H              = 0xAB;
sfr TACCR2L              = 0xAC;
sfr TACCTL2H             = 0xAD;
sfr TACCTL2L             = 0xAE;
sfr IRQ0_SEL             = 0xAF;
sfr IRQ1_SEL             = 0xB0;
sfr IRQ2_SEL             = 0xB1;
sfr IRQ3_SEL             = 0xB2;
sfr IRQ4_SEL             = 0xB3;
sfr IRQ5_SEL             = 0xB4;
sfr IRQ6_SEL             = 0xB5;
sfr IRQ7_SEL             = 0xB6;
sfr TIMER_IN_SEL         = 0xB7;

sfr CCI_SEL              = 0xB9;
sfr SPI_IN_SEL0          = 0xBA;
sfr SPI_IN_SEL1          = 0xBB;
sfr P0_IN_SEL0           = 0xBC;
sfr P0_IN_SEL1           = 0xBD;
sfr P0_IN_SEL2           = 0xBE;
sfr P0_IN_SEL3           = 0xBF;
sfr GPIO_IN_R_H          = 0xC0;
sfr GPIO_IN_R_L          = 0xC1;
sfr GPIO_OUT_R_H         = 0xC2;
sfr GPIO_OUT_R_L         = 0xC3;
sfr GPIO_OUT_SEL0        = 0xC4;
sfr GPIO_OUT_SEL1        = 0xC5;
sfr GPIO_OUT_SEL2        = 0xC6;
sfr GPIO_OUT_SEL3        = 0xC7;
sfr GPIO_OUT_SEL4        = 0xC8;
sfr GPIO_OUT_SEL5        = 0xC9;
sfr GPIO_OUT_SEL6        = 0xCA;
sfr GPIO_OUT_SEL7        = 0xCB;
sfr LED_CTL              = 0xCC;
sfr MAIN_STATE           = 0xCD;

sfr GPIO_IN_R_D1         = 0xDD;
sfr GPIO_OUT_R_D1        = 0xDE;

sfr SYS_CTL              = 0xFF;

/*********** CMT216x SFR ****************/
/*********** Bank 1 sfr *****************/
sfr PD_ANA				 = 0x8A; 
sfr PA_POWER_TH_9        = 0x8E;
sfr PA_POWER_TH_8        = 0x8F;
sfr PA_POWER_TH_7        = 0x90;
sfr PA_POWER_TH_6        = 0x91;
sfr PA_POWER_TH_5        = 0x92;
sfr PA_POWER_TH_4        = 0x93;
sfr PA_POWER_TH_3        = 0x94;
sfr PA_POWER_TH_2        = 0x95;
sfr PA_POWER_TH_1        = 0x96;
sfr PA_POWER_TH_0        = 0x97;

sfr CAL_PA_CAP_CODE		 = 0x9C;

sfr TX_SYM_GROUP         = 0xA9;
sfr TX_SYM_CTL           = 0xAA;
sfr TX_PKT_CTL           = 0xAB;
sfr SYMBOL_TIME_H        = 0xAC;
sfr SYMBOL_TIME_L        = 0xAD;
sfr FREQ_DEV_H           = 0xAE;
sfr FREQ_DEV_L           = 0xAF;
sfr RAMP_STEP_TIME_H     = 0xB0;
sfr RAMP_STEP_TIME_L     = 0xB1;
sfr	PA_POWER_CODE		 = 0xB2;
sfr PA_IDAC_CODE         = 0xB3;
sfr PA_CTL0              = 0xB4;
sfr PA_CTL1              = 0xB5;
sfr VCO_CTL0             = 0xB6;
sfr VCO_CTL1             = 0xB7;

sfr PLLN                 = 0xB9;
sfr PLLK_H               = 0xBA;
sfr PLLK_L               = 0xBB;
sfr	PLL_CTL0			 = 0xBC;
sfr PLL_CTL1			 = 0xBD;

sfr RNG_CTL              = 0xBE;
sfr RNG_SUM              = 0xBF;
sfr LBD_CTL              = 0xC0;
sfr LFRX_IF_TH_H         = 0xC1;

sfr LFRX_IF_TH_L         = 0xC3;


sfr TBCLK_DIV_H          = 0xD7;
sfr TBCLK_DIV_L          = 0xD8;
sfr TBCH                 = 0xD9;
sfr TBCL                 = 0xDA;
sfr TBCCR0H              = 0xDB;
sfr TBCCR0L              = 0xDC;
sfr TBCCTL0H             = 0xDD;
sfr TBCCTL0L             = 0xDE;
sfr TBCCR1H              = 0xDF;

sfr TBCCR1L              = 0xE1;
sfr TBCCTL1H             = 0xE2;
sfr TBCCTL1L             = 0xE3;
sfr TBCCR2H              = 0xE4;
sfr TBCCR2L              = 0xE5;

sfr TBCCTL2H             = 0xE7;
sfr TBCCTL2L             = 0xE8;
sfr TBCCI_SEL            = 0xE9;
sfr TBCNT_H              = 0xEA;
sfr TBCNT_L              = 0xEB;

/*************************** GPIO Direct Access ***************************/
/** Note: Before used, it should be make sure Bank Access point to Bank0 **/

#define A0_IN			(GPIO_IN_R_L & 0x01)
#define A1_IN          	(GPIO_IN_R_L & 0x02)
#define A2_IN          	(GPIO_IN_R_L & 0x04)
#define A3_IN          	(GPIO_IN_R_L & 0x08)
#define A4_IN          	(GPIO_IN_R_L & 0x10)
#define A5_IN           (GPIO_IN_R_L & 0x20)
#define A6_IN           (GPIO_IN_R_L & 0x40)
#define A7_IN           (GPIO_IN_R_L & 0x80)
#define B0_IN			(GPIO_IN_R_H & 0x01)
#define B1_IN          	(GPIO_IN_R_H & 0x02)
#define B2_IN          	(GPIO_IN_R_H & 0x04)
#define B3_IN          	(GPIO_IN_R_H & 0x08)
#define B4_IN          	(GPIO_IN_R_H & 0x10)
#define B5_IN           (GPIO_IN_R_H & 0x20)
#define B6_IN           (GPIO_IN_R_H & 0x40)
#define B7_IN           (GPIO_IN_R_H & 0x80)

#define D1_IN			(GPIO_IN_R_D1 & 0x01)
 
#define A0_OUT_H        GPIO_OUT_R_L = (GPIO_OUT_R_L | 0x01)
#define A0_OUT_L        GPIO_OUT_R_L = (GPIO_OUT_R_L & 0xFE)
#define A0_OUT_INV      GPIO_OUT_R_L = (GPIO_OUT_R_L ^ 0x01)
#define A1_OUT_H        GPIO_OUT_R_L = (GPIO_OUT_R_L | 0x02)
#define A1_OUT_L        GPIO_OUT_R_L = (GPIO_OUT_R_L & 0xFD)
#define A1_OUT_INV      GPIO_OUT_R_L = (GPIO_OUT_R_L ^ 0x02)
#define A2_OUT_H        GPIO_OUT_R_L = (GPIO_OUT_R_L | 0x04)
#define A2_OUT_L        GPIO_OUT_R_L = (GPIO_OUT_R_L & 0xFB)
#define A2_OUT_INV      GPIO_OUT_R_L = (GPIO_OUT_R_L ^ 0x04)
#define A3_OUT_H        GPIO_OUT_R_L = (GPIO_OUT_R_L | 0x08)
#define A3_OUT_L        GPIO_OUT_R_L = (GPIO_OUT_R_L & 0xF7)
#define A3_OUT_INV      GPIO_OUT_R_L = (GPIO_OUT_R_L ^ 0x08)
#define A4_OUT_H        GPIO_OUT_R_L = (GPIO_OUT_R_L | 0x10)
#define A4_OUT_L        GPIO_OUT_R_L = (GPIO_OUT_R_L & 0xEF)
#define A4_OUT_INV      GPIO_OUT_R_L = (GPIO_OUT_R_L ^ 0x10)
#define A5_OUT_H        GPIO_OUT_R_L = (GPIO_OUT_R_L | 0x20)
#define A5_OUT_L        GPIO_OUT_R_L = (GPIO_OUT_R_L & 0xDF)
#define A5_OUT_INV      GPIO_OUT_R_L = (GPIO_OUT_R_L ^ 0x20)
#define A6_OUT_H        GPIO_OUT_R_L = (GPIO_OUT_R_L | 0x40)
#define A6_OUT_L        GPIO_OUT_R_L = (GPIO_OUT_R_L & 0xBF)
#define A6_OUT_INV      GPIO_OUT_R_L = (GPIO_OUT_R_L ^ 0x40)
#define A7_OUT_H        GPIO_OUT_R_L = (GPIO_OUT_R_L | 0x80)
#define A7_OUT_L        GPIO_OUT_R_L = (GPIO_OUT_R_L & 0x7F)
#define A7_OUT_INV      GPIO_OUT_R_L = (GPIO_OUT_R_L ^ 0x80)

#define B0_OUT_H        GPIO_OUT_R_H = (GPIO_OUT_R_H | 0x01)
#define B0_OUT_L        GPIO_OUT_R_H = (GPIO_OUT_R_H & 0xFE)
#define B0_OUT_INV      GPIO_OUT_R_H = (GPIO_OUT_R_H ^ 0x01)
#define B1_OUT_H        GPIO_OUT_R_H = (GPIO_OUT_R_H | 0x02)
#define B1_OUT_L        GPIO_OUT_R_H = (GPIO_OUT_R_H & 0xFD)
#define B1_OUT_INV      GPIO_OUT_R_H = (GPIO_OUT_R_H ^ 0x02)
#define B2_OUT_H        GPIO_OUT_R_H = (GPIO_OUT_R_H | 0x04)
#define B2_OUT_L        GPIO_OUT_R_H = (GPIO_OUT_R_H & 0xFB)
#define B2_OUT_INV      GPIO_OUT_R_H = (GPIO_OUT_R_H ^ 0x04)
#define B3_OUT_H        GPIO_OUT_R_H = (GPIO_OUT_R_H | 0x08)
#define B3_OUT_L        GPIO_OUT_R_H = (GPIO_OUT_R_H & 0xF7)
#define B3_OUT_INV      GPIO_OUT_R_H = (GPIO_OUT_R_H ^ 0x08)
#define B4_OUT_H        GPIO_OUT_R_H = (GPIO_OUT_R_H | 0x10)
#define B4_OUT_L        GPIO_OUT_R_H = (GPIO_OUT_R_H & 0xEF)
#define B4_OUT_INV      GPIO_OUT_R_H = (GPIO_OUT_R_H ^ 0x10)
#define B5_OUT_H        GPIO_OUT_R_H = (GPIO_OUT_R_H | 0x20)
#define B5_OUT_L        GPIO_OUT_R_H = (GPIO_OUT_R_H & 0xDF)
#define B5_OUT_INV      GPIO_OUT_R_H = (GPIO_OUT_R_H ^ 0x20)
#define B6_OUT_H        GPIO_OUT_R_H = (GPIO_OUT_R_H | 0x40)
#define B6_OUT_L        GPIO_OUT_R_H = (GPIO_OUT_R_H & 0xBF)
#define B6_OUT_INV      GPIO_OUT_R_H = (GPIO_OUT_R_H ^ 0x40)
#define B7_OUT_H        GPIO_OUT_R_H = (GPIO_OUT_R_H | 0x80)
#define B7_OUT_L        GPIO_OUT_R_H = (GPIO_OUT_R_H & 0x7F)
#define B7_OUT_INV      GPIO_OUT_R_H = (GPIO_OUT_R_H ^ 0x80)

#define D1_OUT_H		GPIO_OUT_R_D1= (GPIO_OUT_R_D1 | 0x01)
#define D1_OUT_L		GPIO_OUT_R_D1= (GPIO_OUT_R_D1 & 0xFE)
#define D1_OUT_INV		GPIO_OUT_R_D1= (GPIO_OUT_R_D1 ^ 0x01)

#endif





















