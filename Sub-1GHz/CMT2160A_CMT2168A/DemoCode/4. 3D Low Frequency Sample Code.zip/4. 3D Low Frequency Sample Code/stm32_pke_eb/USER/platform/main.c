#include "typedefs.h"
#include <stdio.h>
#include <string.h>

#include "common.h"
#include "system.h"
#include "time_server.h"
#include "interrupt_server.h"
#include "key_server.h"

#include "gpio_defs.h"
#include "led.h"
#include "lcd12864.h"
#include "buzzer.h"
#include "pke.h"



void Mcu_Init(void)
{
    /* system init */
    SystemInit();
    GPIO_Config();
    NVIC_Config();
    SystemTimerDelay_Config();
    Timer4_Config();
    Timer5_Config();
    
    /* services init */
    time_server_init();
    IntSrv_Init();
    Key_Init();
    
    /* periph init */
    led_init();
    lcd12864_init();
    buzzer_init();
    
    lcd12864_led_on();
        
}



/* Main application entry point */
int main(void)
{

    Mcu_Init();
    
    pke_init();


    while(1)
    {
        pke_task_process();
    }
}

