#include <string.h>
#include "time_server.h"
#include "system.h"
#include "common.h"
#include "gpio_defs.h"
#include "stm32f10x_conf.h"
#include "interrupt_server.h"
#include "key_server.h"
#include "buzzer.h"
#include "led.h"
#include "pke.h"

#define 	LFRX_RELEASE       		1	 


#define 	CMD_LFRX    					0x01
#define 	CMD_KEY     					0x02

#define 	LFRX_SENT_DR    			4  // 1, 2, 4, 8 K

#define 	PKE_LFRX_BUF_SIZE    	32

#define 	PKE_RF_PACKET_DATA_SIZE    8

typedef __packed struct PKE_RF_PACKET_STRU {
    uint8_t  cmd;
    uint8_t  data_buf[PKE_RF_PACKET_DATA_SIZE];
    uint16_t crc;
} STRU_PKE_RF_PACKET;


#define PKE_RF_PACKET_SIZE    sizeof(STRU_PKE_RF_PACKET)
#define PKE_RF_TRANS_SYNC_ID  0x9D3C532B
#define PKE_RF_RECV_BUF_SIZE  PKE_RF_PACKET_SIZE

typedef __packed struct PKE_RF_TRANS_STRU {
    uint32_t sync_id;
    uint8_t  recv_size;
    uint8_t  recv_data[PKE_RF_RECV_BUF_SIZE];
}STRU_PKE_RF_TRANS; 

STRU_PKE_RF_TRANS  g_stru_pke_rf_trans_recving;
STRU_PKE_RF_PACKET g_stru_pke_rf_packet;

uint8_t g_pke_lfrx_buf[PKE_LFRX_BUF_SIZE];
uint8_t g_pke_lfrx_sent_cnt;
uint8_t g_pke_lfrx_sent_dr;

uint8_t g_square_wave_enable;
uint8_t g_rtc_4us_count;
uint8_t g_pke_lfrx_sent_start;
uint8_t g_pke_lfrx_125khz_single_wave;
uint8_t g_pke_lfrx_125khz_sending;

uint8_t g_pke_rf_trans_recv_done;
uint8_t g_pke_rf_trans_sync_id_recv_done;
uint8_t g_pke_rf_trans_timer_start;

volatile uint32_t g_pke_lfrx_sent_timeout = 0;
volatile uint32_t g_pke_lfrx_sent_time_cnt = 0;

void pke_set_lfrx_sent_timeout(uint32_t time_out)
{
    g_pke_lfrx_sent_timeout = time_out;
    get_system_timestamp(&g_pke_lfrx_sent_time_cnt);
}

uint8_t pke_is_lfrx_sent_timeout(void)
{
    return (get_system_relative_ms_count(&g_pke_lfrx_sent_time_cnt) >g_pke_lfrx_sent_timeout) ?1 :0;
}

void pke_assemble_lfrx_packet(void)
{
    uint8_t ind;
    
    ind = 0;
    g_pke_lfrx_buf[ind++] = 0xff;
    g_pke_lfrx_buf[ind++] = 0xff;
    g_pke_lfrx_buf[ind++] = 0xff;
    g_pke_lfrx_buf[ind++] = 0xff;
	
    g_pke_lfrx_buf[ind++] = 0x55;
    
    // sync = 0x999aa5a6(NRZ) = 0xabcd(MAN)
    g_pke_lfrx_buf[ind++] = 0x99;
    g_pke_lfrx_buf[ind++] = 0x9a;
    g_pke_lfrx_buf[ind++] = 0xa5;
    g_pke_lfrx_buf[ind++] = 0xa6;
    
    // wkid = 0xdcba(MAN)
    g_pke_lfrx_buf[ind++] = 0xa6; 				// 2'b10 = 1,  2'b01=0
    g_pke_lfrx_buf[ind++] = 0xa5;
    g_pke_lfrx_buf[ind++] = 0x9a;
    g_pke_lfrx_buf[ind++] = 0x99;
    
		// payload = 0x123456 
    g_pke_lfrx_buf[ind++] = 0x56;					// 0101 0110
    g_pke_lfrx_buf[ind++] = 0x59;					// 0101 1001
    g_pke_lfrx_buf[ind++] = 0x5a;					// 0101 1010
    g_pke_lfrx_buf[ind++] = 0x65;					// 0110 0101
    g_pke_lfrx_buf[ind++] = 0x66;					// 0110 0110
    g_pke_lfrx_buf[ind++] = 0x69;					// 0110 1001
    
    g_pke_lfrx_sent_cnt   = ind;
    g_pke_lfrx_sent_dr    = LFRX_SENT_DR;	// 2khz
}


void pke_rf_trans_init(void)
{
    SET_GPIO_IN(CMT_GPIO3_GPIO);
    
    g_pke_rf_trans_recv_done = 0;
    g_pke_rf_trans_sync_id_recv_done = 0;
    g_pke_rf_trans_timer_start = 0;
    
    g_stru_pke_rf_trans_recving.sync_id = PKE_RF_TRANS_SYNC_ID;
    g_stru_pke_rf_trans_recving.recv_size = PKE_RF_PACKET_SIZE;
}

uint8_t pke_rf_trans_data_in(void)
{
    return READ_GPIO_PIN(CMT_GPIO3_GPIO);
}

void pke_rf_trans_recving_rountine(void)
{
    static uint32_t sync_id = 0;
    static uint8_t bit_cnt = 0;
    static uint8_t recving_data = 0;
    static uint8_t recving_data_cnt = 0;
    
    if(g_pke_rf_trans_sync_id_recv_done == 0)
    {
        sync_id <<= 1;
        sync_id |= pke_rf_trans_data_in();
        if(sync_id == g_stru_pke_rf_trans_recving.sync_id)
        {
            g_pke_rf_trans_sync_id_recv_done = 1;
            bit_cnt = 0;
            recving_data = 0;
            recving_data_cnt = 0;
        }
    }
    else
    {
        recving_data <<= 1;
        recving_data |= pke_rf_trans_data_in();
        bit_cnt++;
        if(bit_cnt == 8)
        {
            g_stru_pke_rf_trans_recving.recv_data[recving_data_cnt++] = recving_data;
            bit_cnt = 0;
            recving_data = 0;
            
            if(recving_data_cnt == g_stru_pke_rf_trans_recving.recv_size)
            {
                memcpy((uint8_t*)&g_stru_pke_rf_packet.cmd, (uint8_t*)&g_stru_pke_rf_trans_recving.recv_data[0], PKE_RF_PACKET_SIZE);
                g_pke_rf_trans_sync_id_recv_done = 0;
                g_pke_rf_trans_recv_done = 1;
            }
        }
    }
    
}


void pke_rf_trans_init_timer(uint32_t data_rate)
{
    Timer6_Config(data_rate);
}

void pke_rf_trans_set_timer_half_count(void)
{
    TIM6->CNT = TIM6->ARR / 2;
}

void pke_rf_trans_start_timer(void)
{
    //TIM_Cmd(TIM6, DISABLE);
    //TIM_Cmd(TIM6, ENABLE);
    //TIM6->CR1 &= (uint16_t)(~((uint16_t)TIM_CR1_CEN));
    if(0==g_pke_rf_trans_timer_start) {
        g_pke_rf_trans_timer_start = 1;
        //TIM6->CR1 &= (uint16_t)(~((uint16_t)TIM_CR1_CEN));
        TIM6->CR1 |= TIM_CR1_CEN;
    }
}

void pke_rf_trans_stop_timer(void)
{
    //TIM_Cmd(TIM6, DISABLE);
    TIM6->CR1 &= (uint16_t)(~((uint16_t)TIM_CR1_CEN));
    g_pke_rf_trans_timer_start = 0;
}

void pke_rf_trans_gpio_interrupt_rountine(void)
{
    pke_rf_trans_start_timer();
    pke_rf_trans_set_timer_half_count();
}

void pke_init(void)
{
    SET_GPIO_L(LFRX_TRANS_DATA_GPIO);
    SET_GPIO_OUT(LFRX_TRANS_DATA_GPIO);
    SET_GPIO_L(LFRX_TRANS_DATA_GPIO);
    g_square_wave_enable = 0;
    g_pke_lfrx_sent_start = 0; 
    
    g_pke_lfrx_125khz_sending = 0;

    pke_assemble_lfrx_packet();
    
    pke_set_lfrx_sent_timeout(1000); // 1 s
    
    pke_rf_trans_init();
    pke_rf_trans_init_timer(10000); // 10khz data rate
    g_time_server_proc_run6 = pke_rf_trans_recving_rountine;
    
    // register gpio d0
    IntSrv_Register(CMT_GPIO3_GPIO, CMT_GPIO3_GPIO_PIN, EXTI_Trigger_Rising_Falling, pke_rf_trans_gpio_interrupt_rountine);
}

void pke_send_125khz_square_wave_rountine(void)
{
    if (g_square_wave_enable)
    {
        READ_OUTPUT_GPIO_PIN(LFRX_TRANS_DATA_GPIO) ? SET_GPIO_L(LFRX_TRANS_DATA_GPIO) : SET_GPIO_H(LFRX_TRANS_DATA_GPIO);        
    }
    else
    {
        SET_GPIO_L(LFRX_TRANS_DATA_GPIO);
    }
    
    g_rtc_4us_count++;
}


/* 1: 1khz, 2 : 2khz, 4: 4k, 8 : 8k  */
void pke_send_data(uint8_t data_buf[], uint8_t data_cnt, uint8_t dr_sel)
{
    uint8_t bit_cnt;
    uint8_t data_out;
    uint8_t ind;
    uint8_t delay_4us_cnt;
    
    /* calc delay time,1khz : 1ms = 250*4us, 2khz : 500us = 125*4us, 4khz : 250 = 63*4us, 8khz : 125us = 32*4us */   
    delay_4us_cnt = dr_sel==1 ? 250 : (dr_sel==2 ? 125 : (dr_sel==4 ? 63 : (dr_sel==8 ? 32 : 250)));
    g_rtc_4us_count = 0;
    
    /* enable TIM4 */
    g_time_server_proc_run4 = pke_send_125khz_square_wave_rountine;
    TIM_Cmd(TIM4, ENABLE);
    
    for(ind = 0; ind < data_cnt; ind++)
    {
        data_out = *data_buf++;
        
        for(bit_cnt = 0; bit_cnt < 8; bit_cnt++)
        {
            if(data_out & 0x80)
            {
                g_square_wave_enable = 1;
            }
            else
            {
                g_square_wave_enable = 0;
            }
            
            while(g_rtc_4us_count < delay_4us_cnt);
            g_rtc_4us_count = 0;
            
            data_out <<= 1;
        }
    }
    
    /* disable TIM4 */    
    TIM_Cmd(TIM4, DISABLE);
    g_time_server_proc_run4 = 0;
    SET_GPIO_L(LFRX_TRANS_DATA_GPIO);
}

void pke_parse_rf_packet(STRU_PKE_RF_PACKET * pke_rf_packet)
{
    if(pke_rf_packet->crc != crc16_ccitt_calc((uint8_t*)&pke_rf_packet->cmd, PKE_RF_PACKET_SIZE-2))
    {
        // pke rf packet error LED_INDEX4 flash 300ms
        led_onAutoOff(LED_INDEX4, 300);
    }
    else
    {
        switch(pke_rf_packet->cmd)
        {
            case CMD_LFRX:
            led_onAutoOff(LED_INDEX2, 300);
            //buzzer_onAutoOff(300);
            break;
            
            case CMD_KEY:
            led_onAutoOff(LED_INDEX3, 300); 
            break;
        }
    }
}

void pke_scan_keys_status(void)
{
    if(Key_IsDown(&g_key1) || Key_IsDown(&g_key2) || Key_IsDown(&g_key3) || Key_IsDown(&g_key4) || Key_IsDown(&g_key5))
    {
        g_pke_lfrx_sent_start = g_pke_lfrx_sent_start ? 0 : 1;
    }
}

#if (LFRX_RELEASE==0)
void pke_assemble_lfrx_packet_test(void)
{
    uint8_t ind;
    
    ind = 0;
    g_pke_lfrx_buf[ind++] = 0xff;
    g_pke_lfrx_buf[ind++] = 0xff;
    g_pke_lfrx_buf[ind++] = 0xaa;
    g_pke_lfrx_buf[ind++] = 0xaa;
    
    g_pke_lfrx_buf[ind++] = 0x96;
    
    // 0xabcd
    g_pke_lfrx_buf[ind++] = 0x99;
    g_pke_lfrx_buf[ind++] = 0x9a;
    g_pke_lfrx_buf[ind++] = 0xa5;
    g_pke_lfrx_buf[ind++] = 0xa6;
    
    // 0xdcba
    g_pke_lfrx_buf[ind++] = 0xa6;
    g_pke_lfrx_buf[ind++] = 0xa5;
    g_pke_lfrx_buf[ind++] = 0x9a;
    g_pke_lfrx_buf[ind++] = 0x99;
    
    g_pke_lfrx_buf[ind++] = 0x55;
    g_pke_lfrx_buf[ind++] = 0x55;
    g_pke_lfrx_buf[ind++] = 0x55;
    g_pke_lfrx_buf[ind++] = 0x55;
    g_pke_lfrx_buf[ind++] = 0x55;
    g_pke_lfrx_buf[ind++] = 0x55;
    
    
    g_pke_lfrx_sent_cnt = ind;
    //g_pke_lfrx_sent_dr = LFRX_SENT_DR; // 2khz
}

void pke_scan_keys_status_single(void)
{
    if(Key_IsDown(&g_key1))
    {
        g_pke_lfrx_sent_start = g_pke_lfrx_sent_start ? 0 : 1;
        g_pke_lfrx_sent_dr = 1;
    }
    
    if(Key_IsDown(&g_key2))
    {
        g_pke_lfrx_sent_start = g_pke_lfrx_sent_start ? 0 : 1;
        g_pke_lfrx_sent_dr = 2;
    }
    
    if(Key_IsDown(&g_key3))
    {
        g_pke_lfrx_sent_start = g_pke_lfrx_sent_start ? 0 : 1;
        g_pke_lfrx_sent_dr = 4;
    }
    
    if(Key_IsDown(&g_key4))
    {
        g_pke_lfrx_sent_start = g_pke_lfrx_sent_start ? 0 : 1;
        g_pke_lfrx_sent_dr = 8;
    }
    
    if(g_pke_lfrx_sent_start)
    {
        if(g_pke_lfrx_125khz_sending)
        {
            TIM_Cmd(TIM4, DISABLE);
            g_time_server_proc_run4 = 0;
            SET_GPIO_L(LFRX_TRANS_DATA_GPIO);
            g_pke_lfrx_125khz_sending = 0;
            g_square_wave_enable = 0;
            
            g_pke_lfrx_sent_start = 0;
        }
        
        g_pke_lfrx_125khz_single_wave = 0;
    }
    
    if(Key_IsDown(&g_key5))
    {
        if(g_pke_lfrx_sent_start)
        {            
            g_pke_lfrx_sent_start = 0;
        }
        else
        {
            g_pke_lfrx_125khz_single_wave = g_pke_lfrx_125khz_single_wave ? 0 : 1;
        }
    }
    
    if(g_pke_lfrx_125khz_single_wave)
    {
        g_pke_lfrx_sent_start = 0;
        
        if(g_pke_lfrx_125khz_sending==0)
        {
            g_square_wave_enable = 1;
            g_time_server_proc_run4 = pke_send_125khz_square_wave_rountine;
            TIM_Cmd(TIM4, ENABLE);
            g_pke_lfrx_125khz_sending = 1;
        }
        
        if(pke_is_lfrx_sent_timeout())
        {
            led_onAutoOff(LED_INDEX1, 300);
            
            pke_set_lfrx_sent_timeout(500); // 1s
        }
    }
    else
    {
        if(g_pke_lfrx_125khz_sending)
        {
            TIM_Cmd(TIM4, DISABLE);
            g_time_server_proc_run4 = 0;
            SET_GPIO_L(LFRX_TRANS_DATA_GPIO);
            g_pke_lfrx_125khz_sending = 0;
            g_square_wave_enable = 0;
        }
    }
    
    pke_assemble_lfrx_packet_test();
}

#endif


void pke_task_process(void)
{
    if(g_pke_rf_trans_recv_done)
    {
        pke_parse_rf_packet(&g_stru_pke_rf_packet);
        g_pke_rf_trans_recv_done = 0;
    }

#if LFRX_RELEASE    
    pke_scan_keys_status();
#else
    pke_scan_keys_status_single();
#endif
    if(g_pke_lfrx_sent_start)
    {
        if(pke_is_lfrx_sent_timeout())
        {
            led_onAutoOff(LED_INDEX1, 300);
            pke_send_data(g_pke_lfrx_buf, g_pke_lfrx_sent_cnt, g_pke_lfrx_sent_dr);
            
            pke_set_lfrx_sent_timeout(1000); // 1s
        }
    }
}





















