#include "common.h"
#include <string.h>

#include "gpio_defs.h"
#include "lcd12864.h"

void no_optimize(const void* p_param)
{
}

void Common_Init(void)
{
}

void GPIO_Config(void)
{ 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
    
    SET_GPIO_IN(KEY1_GPIO);
    SET_GPIO_IN(KEY2_GPIO);
    SET_GPIO_IN(KEY3_GPIO);
    SET_GPIO_IN(KEY4_GPIO);
    SET_GPIO_IN(KEY5_GPIO);
    
    SET_GPIO_IN(CMT_GPIO1_GPIO);
    SET_GPIO_IN(CMT_GPIO2_GPIO);
    SET_GPIO_IN(CMT_GPIO3_GPIO);
    SET_GPIO_IN(CMT_GPIO4_GPIO);
}

void GPIO_Pin_Setting(GPIO_TypeDef *gpio, uint16_t nPin, GPIOSpeed_TypeDef speed, GPIOMode_TypeDef mode)
{
#if 0
    GPIO_InitTypeDef GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Pin = nPin;
    GPIO_InitStructure.GPIO_Speed = speed;
    GPIO_InitStructure.GPIO_Mode = mode;
    GPIO_Init(gpio, &GPIO_InitStructure);
#else
    u16 i;
    u32 nCfg, nMask = 0x0F;
    
    nCfg  = (mode&0x10) ?speed :0;
    nCfg |= mode & 0x0C;
    
    if(nPin == 0)
        return;
    
    if(nPin < 0x0100)
    {
        for(i=nPin; (0x01&i)==0; i >>= 1) {
            nCfg <<= 4;
            nMask <<= 4;
        }
        
        gpio->CRL &= ~nMask;
        gpio->CRL |= nCfg;
    }
    else
    {
        for(i=(nPin>>8); (0x01&i)==0; i >>= 1) {
            nCfg <<= 4;
            nMask <<= 4;
        }
        
        gpio->CRH &= ~nMask;
        gpio->CRH |= nCfg;
    }
    
    if(GPIO_Mode_IPD==mode)
        gpio->BRR = nPin;
    
    else if(GPIO_Mode_IPU==mode)
        gpio->BSRR = nPin;
    
#endif
}

void set_u16_to_buf(u8 buf[], u16 dat16)
{
    buf[0] = (u8)dat16;
    buf[1] = (u8)(dat16 >> 8);
}

u16 get_u16_from_buf(const u8 buf[])
{
    u16 dat16 = 0;
    dat16  = buf[0];
    dat16 |= ((u16)buf[1]) << 8;
    return dat16;
}

void set_u32_to_buf(u8 buf[], u32 dat32)
{
    buf[0] = (u8)dat32;
    buf[1] = (u8)(dat32 >> 8);
    buf[2] = (u8)(dat32 >> 16);
    buf[3] = (u8)(dat32 >> 24);
}

u32 get_u32_from_buf(const u8 buf[])
{
    u32 dat32 = 0;
    dat32  = buf[0];
    dat32 |= ((u32)buf[1]) << 8;
    dat32 |= ((u32)buf[2]) << 16;
    dat32 |= ((u32)buf[3]) << 24;
    return dat32;
}

void views_print_line(u8 nLine, const char* str)
{
    static u8 buf[32];
    
    memset(buf, ' ', sizeof(buf));
    memcpy(buf, str, strlen(str));
    buf[21] = 0;

    lcd12864_update_data(0);
    lcd12864_display_string_6x8(nLine, 0, buf);
    lcd12864_update_data(1);
}


void manchester_encode(uint8_t raw_buf[],uint8_t enc_buf[], uint8_t data_cnt)
{
    uint16_t enc_data;
    uint8_t bit_cnt;
    uint8_t ind;
    uint8_t raw_data;
    
    for(ind = 0; ind < data_cnt; ind++)
    {
        enc_data = 0;
        raw_data = raw_buf[ind];
        for(bit_cnt = 0; bit_cnt < 8; bit_cnt++)
        {
            enc_data <<= 2;
            if(raw_data & 0x80)
            {
                enc_data |= 0x02; // 1 -> 10
            }
            else
            {
                enc_data |= 0x01; // 0 -> 01
            }
            
            raw_data <<= 1;
        }
        
        enc_buf[2*ind + 0]= enc_data >> 8;
        enc_buf[2*ind + 1] = enc_data;
    }
    
}

uint16_t crc16_ccitt_calc(const uint8_t buf[], uint16_t len)
{
    uint16_t i;
    uint16_t crc = 0x0000;

    for (; len > 0; len--)              /* Step through bytes in memory */
    {  
        crc = crc ^ (*buf++ << 8);     /* Fetch byte from memory, XOR into CRC top byte*/  
        for (i = 0; i < 8; i++)             /* Prepare to rotate 8 bits */  
        {  
            if (crc & 0x8000)            /* b15 is set... */  
                crc = (crc << 1) ^ 0x1021;    /* rotate and XOR with polynomic */  
            else                          /* b15 is clear... */  
                crc <<= 1;                  /* just rotate */  
        }                             /* Loop for 8 bits */  
        crc &= 0xFFFF;                  /* Ensure CRC remains 16-bit value */  
    }                               /* Loop until len=0 */  

    return crc;//(crc ^ 0xFFFF);
}








