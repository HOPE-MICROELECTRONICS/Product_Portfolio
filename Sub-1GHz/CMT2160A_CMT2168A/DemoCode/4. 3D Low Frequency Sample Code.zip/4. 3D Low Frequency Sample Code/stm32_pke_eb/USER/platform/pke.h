#ifndef __PKE_H__
#define __PKE_H__

void pke_init(void);

void pke_send_data(uint8_t data_buf[], uint8_t data_cnt, uint8_t dr_sel);

void pke_task_process(void);

#endif
