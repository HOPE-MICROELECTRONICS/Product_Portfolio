#include "cmt218x.h"
    
/******************************* TX Config ****************************************          
   tx_modu                   0                  ;0: OOK                  
   tx_freq_MHz               433.92                                                  
   tx_power_dBm              13                                                 
   tx_dr_kbps                10                                                      
   tx_ramp_en                1                  ;0: disable, 1:enable               
   tx_ramp_symbol_num_sel    0                  ;0: auto sel, 1:manual sel
   tx_ramp_symbol_num        0.2                                              
   tx_guass_on               0                  ;0: disable, 1:enable              
***************************************************************************************/     
void tx_config(void)
{
    xdata tx_modu_setup_entry_t modu_cfg;
    
    /* ana_ctl_1:
        bit[7:5]: reserved
        bit[4]  : dsm_dither_sel
        bit[3]  : dsm_dither_dis
        bit[2:0]: afc_refn_code
    */
    modu_cfg.ana_ctl_1 = 0x05;
    
    /* ana_ctl_2:
        bit[7]  : vco_hband -- pll hband
        bit[6]  : pdcplf_cpbias_code -- charge pump bias current control
        bit[5]  : reserved
        bit[4:2]: vco_gain_code -- vco gain code
        bit[1:0]: pll_bw_sel -- pll bandwidth control: 0-300khz, 1-210khz
    */
    modu_cfg.ana_ctl_2 = 0x0C;
    
    /* ana_ctl_3:
        bit[7:6]: reserved
        bit[5:4]: divx_code -- pll divider1(/1/2/3)
        bit[3]  : pa_rcramp_selb -- pa ramp rc filter select (1: rc filter is not selected, 0: rc filter is selected)
        bit[2:0]: pa_ramp_rsel -- select rc filter conrner of pa ramp control (0:640khz, 1:320khz, 2:160khz, 3:80khz,
                                                                               4:40khz, 5:20khz, 6:10khz, 7:5khz)
    */
    modu_cfg.ana_ctl_3 = 0x20;
    
    /* pll n value config */
    modu_cfg.plln = 0x21;
    
    /* pll k value[23:16] */
    modu_cfg.pllk_h =  0x06;
    
   /* pll k value[15:8] */
    modu_cfg.pllk_m =  0x0E;
    
   /* pll k value[7:0] */
    modu_cfg.pllk_l =  0x30;
    
    /* tx_brx16_word[23:16] */
    modu_cfg.tx_dr_0 =  0x03;
    
    /* tx_brx16_word[15:8] */
    modu_cfg.tx_dr_1 =  0x26;
    
    /* tx_brx16_word[7:0] */
    modu_cfg.tx_dr_2 =  0x99;
    
    /* tx_pkt_ctl 
        bit[7:4]: reserved
        bit[3]  : ramp_en -- 0: ramp off, 1: ramp on
        bit[0]  : guass_on -- 0:guass off, 1:guass on
    */
    modu_cfg.tx_pkt_ctl =  0x08;
    
    /* freq_dev[23:16] */
    modu_cfg.freq_dev_h =  0x00;
    
    /* freq_dev[15:8] */
    modu_cfg.freq_dev_m =  0x00;
    
    /* freq_dev[7:0] */
    modu_cfg.freq_dev_l =  0x00;
    
    /* ramp_step_h
        bit[7]  : reserved
        bit[6:0]: ram_step_time[14:8]
    */
    modu_cfg.ramp_step_h =  0x00;
    
    /* ram_step_time[7:0] */
    modu_cfg.ramp_step_l =  0x03;
    
    /* pa_idac_code
        bit[7:6]: reserved
        bit[5:0]: pa_idac_code -- pa current control bits for power control
    */
    modu_cfg.pa_idac_code =  0x3F;
    
    
    /* pa_power_th_9[6:0] */
    modu_cfg.pa_power_th_9 =  0x20;
    
    /* pa_power_th_8[6:0] */
    modu_cfg.pa_power_th_8 =  0x26;
    
    /* pa_power_th_7[6:0] */
    modu_cfg.pa_power_th_7 =  0x2D;
    
    /* pa_power_th_6[6:0] */
    modu_cfg.pa_power_th_6 =  0x38;
    
    /* pa_power_th_5[6:0] */
    modu_cfg.pa_power_th_5 =  0x49;
    
    /* pa_power_th_4[6:0] */
    modu_cfg.pa_power_th_4 =  0x5E;
    
    /* pa_power_th_3[6:0] */
    modu_cfg.pa_power_th_3 =  0x73;
    
    /* pa_power_th_2[6:0] */
    modu_cfg.pa_power_th_2 =  0x7F;
    
    /* pa_power_th_1[6:0] */
    modu_cfg.pa_power_th_1 =  0x7F;
    
    /* pa_power_th_0[6:0] */
    modu_cfg.pa_power_th_0 =  0x7F;
    
    tx_modu_config(&modu_cfg);
    
    
}
