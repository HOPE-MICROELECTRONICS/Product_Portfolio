//#include "intrins.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"

/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* this is a sample code for eb develop kit
* key1 -> d0 pin, key2 -> d6 pin, key3 -> d7 pin, key4 -> d11 pin
* when key is pressed, will transmit a packet data
* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

uint8_t g_scan_key;
uint8_t g_key_pressed;
uint16_t g_ms_cnt;
uint8_t g_key_first;
uint8_t g_key_second;
uint8_t g_key_cur;
uint8_t g_key_final;

void sys_scan_debounce_key(void)
{
    /* get gpio status and check key pressed(0: pressed, 1: no pressed) */
    g_key_cur = 0;
    g_key_final = 0;

    /* if was pressed three times continuously, so there are keys pressed */
    if((P0 & VAL_BIT0) == 0) /* key1 status */
    {
        if((g_key_first & 0x01) && (g_key_second & 0x01))
        {
            g_key_final |= 0x01;
        }
        else
        {
            g_key_cur |= 0x01;
        }
    }

    if((P0 & VAL_BIT6) == 0) /* key2 status */
    {
        if((g_key_first & 0x02) && (g_key_second & 0x02))
        {
            g_key_final |= 0x02;
        }
        else
        {
            g_key_cur |= 0x02;
        }
    }
    if((P0 & VAL_BIT7) == 0) /* key3 status */
    {
        if((g_key_first & 0x04) && (g_key_second & 0x04))
        {
            g_key_final |= 0x04;
        }
        else
        {
            g_key_cur |= 0x04;
        }
    }

    if((P1 & VAL_BIT3) == 0) /* key4 status */
    {
        if((g_key_first & 0x08) && (g_key_second & 0x08))
        {
            g_key_final |= 0x08;
        }
        else
        {
            g_key_cur |= 0x08;
        }
    }

    /* record gpio status */
    g_key_first = g_key_second;
    g_key_second = g_key_cur;

}

/**********************************************************************************************************
*@name:    tx_modu_config
*@desc:    implement setup tx modu config
*@param:
*    ptr_modu_cfg: pointer modulation cofig
*@return: none
***********************************************************************************************************/
void tx_modu_config(tx_modu_setup_entry_t xdata *ptr_modu_cfg)
{
    uint8_t cfg_val;

    /* ana_ctl_1:
        bit[7:5]: reserved
        bit[4]  : dsm_dither_sel
        bit[3]  : dsm_dither_dis
        bit[2:0]: afc_refn_code
    */
    cfg_val = ANA_CTL_1 & (~(M_DSM_DITHER_SEL | M_DSM_DITHER_DIS | M_AFC_REFN_CODE));
    ANA_CTL_1 = ptr_modu_cfg->ana_ctl_1 | cfg_val;

    /* ana_ctl_2:
        bit[7]  : vco_hband -- pll hband
        bit[6]  : pdcplf_cpbias_code -- charge pump bias current control
        bit[5]  : reserved
        bit[4:2]: vco_gain_code -- vco gain code
        bit[1:0]: pll_bw_sel -- pll bandwidth control: 0-300khz, 1-210khz
    */
    cfg_val = ANA_CTL_2 & (~(M_VCO_HBAND | M_PDCPLF_CPBIAS_CODE | M_VCO_GAIN_CODE | M_PLL_BW_SEL));
    ANA_CTL_2 = ptr_modu_cfg->ana_ctl_2 | cfg_val;

    /* ana_ctl_3
        bit[7:6]: reserved
        bit[5:4]: divx_code -- pll divider1(/1/2/3)
        bit[3]  : pa_rcramp_selb -- pa ramp rc filter select (1: rc filter is not selected, 0: rc filter is selected)
        bit[2:0]: pa_ramp_rsel -- select rc filter conrner of pa ramp control (0:640khz, 1:320khz, 2:160khz, 3:80khz,
                                                                               4:40khz, 5:20khz, 6:10khz, 7:5khz)
    */
    cfg_val = ANA_CTL_3 & (~(M_DIVX_CODE | M_PA_RCRAMP_SELB | M_PA_RAMP_RSEL));
    ANA_CTL_3 = ptr_modu_cfg->ana_ctl_3 | cfg_val;

    /* pll n value config */
    PLLN = ptr_modu_cfg->plln;

    /* pll k value[23:16] */
    PLLK_H = ptr_modu_cfg->pllk_h;

    /* pll k value[15:8] */
    PLLK_M = ptr_modu_cfg->pllk_m;

    /* pll k value[7:0] */
    PLLK_L = ptr_modu_cfg->pllk_l;

    /* tx_brx16_word[23:16] */
    TX_DR_0 = ptr_modu_cfg->tx_dr_0;

    /* tx_brx16_word[15:8] */
    TX_DR_1 = ptr_modu_cfg->tx_dr_1;

    /* tx_brx16_word[7:0] */
    TX_DR_2 = ptr_modu_cfg->tx_dr_2;

    /* tx_pkt_ctl
        bit[7:4]: reserved
        bit[3]  : ramp_en -- 0: ramp off, 1: ramp on
        bit[2]  : tx_modu -- 0: ook, 1: fsk
        bit[1]  : freq_dev_inv -- freq deviation control (0:(+f:1,-f:0), 1:(+f:0,-f:1)
        bit[0]  : guass_on -- 0:guass off, 1:guass on
    */
    cfg_val = TX_PKT_CTL & (~(M_RAMP_EN | M_TX_MODU | M_FREQ_DEV_INV | M_GUASS_ON));
    TX_PKT_CTL = ptr_modu_cfg->tx_pkt_ctl | cfg_val;

    /* freq_dev[23:16] */
    FREQ_DEV_H = ptr_modu_cfg->freq_dev_h;

    /* freq_dev[15:8] */
    FREQ_DEV_M = ptr_modu_cfg->freq_dev_m;

    /* freq_dev[7:0] */
    FREQ_DEV_L = ptr_modu_cfg->freq_dev_l;

    /* ramp_step_h
        bit[7]  : reserved
        bit[6:0]: ram_step_time[14:8]
    */
    cfg_val = RAMP_STEP_H & (~M_RAM_STEP_TIME_14_8);
    RAMP_STEP_H = ptr_modu_cfg->ramp_step_h | cfg_val;

    /* ram_step_time[7:0] */
    RAMP_STEP_L = ptr_modu_cfg->ramp_step_l;

    /* pa_idac_code
        bit[7:6]: reserved
        bit[5:0]: pa_idac_code -- pa current control bits for power control
    */
    cfg_val = PA_IDAC_CODE & (~M_PA_IDAC_CODE_CFG);
    PA_IDAC_CODE = ptr_modu_cfg->pa_idac_code | cfg_val;

    /* lbd_ctl_0
        bit[7:4]: reserved
        bit[3:0]: lbd_th[3:0](V) -- 0: 1.45, 1: 1.64, 2: 1.85, 3: 2.03, 4: 2.26, 5: 2.45, 6: 2.67, 7: 2.86,
                                    8: 3.08, 9: 3.24, 10: 3.43, 11: 3.64, 12: 3.87, 13: 4.00, 14: 4.29, 15: 4.44 (V)
    */
    cfg_val = LBD_CTL_0 & (~M_LBD_TH);
    LBD_CTL_0 = ptr_modu_cfg->lbd_ctl_0 | cfg_val;

    /* select sfr page 1 */
    SFR_PAGE |= M_SFR_PAGE_SEL;

    /* pa_power_th_9[6:0] */
    PA_POWER_TH_9 = ptr_modu_cfg->pa_power_th_9;

    /* pa_power_th_8[6:0] */
    PA_POWER_TH_8 = ptr_modu_cfg->pa_power_th_8;

    /* pa_power_th_7[6:0] */
    PA_POWER_TH_7 = ptr_modu_cfg->pa_power_th_7;

    /* pa_power_th_6[6:0] */
    PA_POWER_TH_6 = ptr_modu_cfg->pa_power_th_6;

    /* pa_power_th_5[6:0] */
    PA_POWER_TH_5 = ptr_modu_cfg->pa_power_th_5;

    /* pa_power_th_4[6:0] */
    PA_POWER_TH_4 = ptr_modu_cfg->pa_power_th_4;

    /* pa_power_th_3[6:0] */
    PA_POWER_TH_3 = ptr_modu_cfg->pa_power_th_3;

    /* pa_power_th_2[6:0] */
    PA_POWER_TH_2 = ptr_modu_cfg->pa_power_th_2;

    /* pa_power_th_1[6:0] */
    PA_POWER_TH_1 = ptr_modu_cfg->pa_power_th_1;

    /* pa_power_th_0[6:0] */
    PA_POWER_TH_0 = ptr_modu_cfg->pa_power_th_0;

    /* select sfr page 0 */
    SFR_PAGE &= ~M_SFR_PAGE_SEL;

}

/**********************************************************************************************************
*@name:    tx_sym_setup_config
*@desc:    implement setup tx sym config
*@param:
*    tx_sym_setup:
*        bit[7]  :    reserved
*        bit[6]  :    tx_direct_en  0:disable tx direct mode, 1: enable tx direct mode(the tx data come from
*                     tx_direct_data, and don't care tx_group_with, endian, tx_sym_ctrl)
*        bit[5:3]:    tx group with -- tx bits of tx_sym_byte; 0~7: 1~8 bits
*        bit[2]  :    endian(0-small endian, 1-big endian)
*        bit[1:0]:    tx_sym_ctrl
*               00:    shundown transmission after last bit
*               01:    reuse tha last symbol group for transmission
*               10:    all 0s data
*               11:    all 1s data
*@return: none
***********************************************************************************************************/
void tx_sym_setup_config(uint8_t tx_sym_setup)
{
    /* write tx_sym_setup[6:0] to TX_SYM_CTRL */
    TX_SYM_CTL = tx_sym_setup;
}

/**********************************************************************************************************
*@name:    tx_sym_open_front
*@desc:    open rf front
*@param:   none
*@return: none
***********************************************************************************************************/
void tx_sym_open_front(void)
{
    /* pd_pd_cplf = 0 */
    ANA_CTL_0 &= ~ M_PD_PDCPLF;

    /* delay 12 us */
    sys_delay_us(12);

    /* set fbdiv_set = 1 */
    ANA_CTL_2 |= M_FBDIV_SET;

    /* start afc */
    ANA_CTL_1 |= M_AFC_START;

    /* wait afc_done */
    while(!(ANA_CTL_1 & M_AFC_DONE));

    /* clear afc_done, afc_start  */
    ANA_CTL_1 &= ~(M_AFC_DONE | M_AFC_START);

    /* set fbdiv_set = 0 */
    ANA_CTL_2 &= ~M_FBDIV_SET;

    /* set fw_dsm_rstn = 1, start doing dsm */
    ANA_CTL_1 |= M_FW_DSM_RSTN;

    /* set pd_lbd_preload = 0, prepare lbd */
    ANA_CTL_0 &= ~M_PD_LBD_PRELOAD;

    /* start lbd */
    LBD_CTL_1 |= M_LBD_START;

    /* wait lbd done */
    while(!(LBD_CTL_1 & M_LBD_DONE));

    /* clear lbd_done, lbd_start */
    LBD_CTL_1 &= ~(M_LBD_DONE | M_LBD_START);

    /* set pd_lbd_preload = 1 */
    ANA_CTL_0 |= M_PD_LBD_PRELOAD;

    /* optionally wait 50 us for dsm done */
    sys_delay_us(50);

}


/**********************************************************************************************************
*@name:    tx_sym_close_front
*@desc:    close rf front
*@param:   none
*@return: none
***********************************************************************************************************/
void tx_sym_close_front(void)
{
    /* clear fw_dsm_rstn */
    ANA_CTL_1 &= ~M_FW_DSM_RSTN;

    /* set fbdiv_set = 1 */
    ANA_CTL_2 |= M_FBDIV_SET;

    /*  pd_pd_cplf = 1 */
    ANA_CTL_0 |= M_PD_PDCPLF;
}
/**********************************************************************************************************
*@name:    tx_sym_packet_transmit
*@desc:    implement transmit data from data_buf
*@param:
*    data_buf: (uint8_t pointer in xdata)pointer to data which will be transmitted
*    data_len:     the bytes of data  which will be transmitted
*@return: none
***********************************************************************************************************/
void tx_sym_packet_transmit(uint8_t data_buf[], uint8_t data_len)
{
    uint8_t *pbuf;
	EA = 0;
    pbuf = data_buf;

    /*set pd_pa = 0, enable tx transmit */
    ANA_CTL_0 &= ~M_PD_PA;

    /* delay 12 us */
    sys_delay_us(12);

    /* clear tx_pkt_done */
    TX_PKT_CTL &= ~M_TX_PKT_DONE;

    /* write data to tx_sym_byte first */
    TX_SYM_BYTE = *pbuf++;

    data_len--;

    /* start transmit */
    TX_PKT_CTL |= M_TX_START;

    while(data_len--)
    {
        /* wait tx sym empty */
        while(!(TX_PKT_CTL & M_TX_SYM_EMPTY));

        /* write data to tx_sym_byte next */
        TX_SYM_BYTE = *pbuf++;

    }


    /* wait tx no data */
    while(!(TX_SYM_CTL & M_TX_NODATA));

    /* stop transmit */
    TX_PKT_CTL |= M_TX_STOP_EN;

    /* wait tx stop done */
    while(!(RAMP_STEP_H & M_TX_STOP_DONE));

    /* clear tx stop done */
    RAMP_STEP_H &= ~M_TX_STOP_DONE;

    /* set pd_pa = 1, disable pa */
    ANA_CTL_0 |= M_PD_PA;

    /* clear tx_stop_en, tx_start, tx_pkt_done */
    TX_PKT_CTL &= ~(M_TX_STOP_EN | M_TX_START | M_TX_PKT_DONE);

}

#define PREAMBLE_LEN 	8
#define SYNC_LEN		3
#define DATA_LEN 		10

#define	PKT_LEN			(PREAMBLE_LEN+SYNC_LEN+DATA_LEN)

uint8_t code g_sync_buf[SYNC_LEN] = {0x2D, 0xD4, 0xD5};
uint8_t xdata g_data_buf[PKT_LEN];

void sys_tx_data_init(void)
{
	uint8_t idx;

	/* preamble */
	for(idx=0; idx<PREAMBLE_LEN; idx++)
	    g_data_buf[idx] = 0xAA;

    /* sync id */
	for( ; idx<(PREAMBLE_LEN+SYNC_LEN); idx++)
		g_data_buf[idx] = g_sync_buf[idx-PREAMBLE_LEN];

	for( ; idx<(PKT_LEN); idx++)
		g_data_buf[idx] = idx-PREAMBLE_LEN-SYNC_LEN;
}

void main(void)
{
    uint8_t dxx_polar;

    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;
    EA = 0;

    /* disable all clock */
    sys_disable_all_clk();

    /* enable clock */
    CLK_GATE_1 |= M_INTIO_CLK_EN;
    CLK_GATE_2 |= (M_PORT1_CLK_EN | M_PORT0_CLK_EN | M_TIMER1_CLK_EN);

    /* rst_in_en = 0 => set d0 as gpio */
    sys_set_reg_bit(AON_REG_07, 0, M_RST_IN_EN);

    /* enable d11,d7, d6, d0 pullup */
    sys_set_reg_bit(AON_REG_15, 0x00, (M_D7_PD_PULLUP | M_D6_PD_PULLUP | M_D0_PD_PULLUP));
    sys_set_reg_bit(AON_REG_16, 0x00, M_D11_PD_PULLUP);

    /* disable d11,d7, d6, d0 pulldown */
    sys_set_reg_bit(AON_REG_17, (M_D7_PD_PULLDOWN | M_D6_PD_PULLDOWN | M_D0_PD_PULLDOWN), (M_D7_PD_PULLDOWN | M_D6_PD_PULLDOWN | M_D0_PD_PULLDOWN));
    sys_set_reg_bit(AON_REG_18, M_D11_PD_PULLDOWN, M_D11_PD_PULLDOWN);

    /* d11,d7, d6, d0 dxx_idrv_en = 1 */
    sys_set_reg_bit(AON_REG_13, (M_D7_IDRV_EN | M_D6_IDRV_EN | M_D0_IDRV_EN), (M_D7_IDRV_EN | M_D6_IDRV_EN | M_D0_IDRV_EN));
	sys_set_reg_bit(AON_REG_14, M_D11_IDRV_EN, M_D11_IDRV_EN);

    /* d11,d7, d6, d0 dxx_det_en = 1, when io changing, will triger external interrupt 0*/
    sys_set_reg_bit(AON_REG_1B, (M_D7_DET_EN | M_D6_DET_EN | M_D0_DET_EN), (M_D7_DET_EN | M_D6_DET_EN | M_D0_DET_EN));
    sys_set_reg_bit(AON_REG_1C, M_D11_DET_EN, M_D11_DET_EN);

    /* d11,d7, d6, d0 dxx_polar = 1  0: rising edge triger int0, 1: falling edge triger int0 */
    sys_set_reg_bit(AON_REG_1D, (M_D7_POLAR | M_D6_POLAR | M_D0_POLAR), (M_D7_POLAR | M_D6_POLAR | M_D0_POLAR));
    sys_set_reg_bit(AON_REG_1E, M_D11_POLAR, M_D11_POLAR);

    TCON &= ~(M_TR1 | M_TF1);
    TMOD = (TMOD & (~M_M1)) | (T1_MODE_1); // t1 mode 1
    TH1 = 0xf8; // t = 1000us = (0x10000 - x)/(24mhz/12) => x = 0x10000 -(2mhz * 1000us)  = 0x10000 - 2000 = 0xf830
    TL1 = 0x30;

    /* enable timer1 interrupt */
    ET1 = 1;

    /* enable external interrupt 0 */
    EX0 = 1;

    EA = 1;

    g_key_pressed = 1;
    g_scan_key = 0;
    g_ms_cnt = 0;

    sys_tx_data_init();

    while(1)
    {
        if(g_key_pressed)
        {
            g_key_pressed = 0;
            TH1 = 0xf8; // t = 1000us = (0x10000 - x)/(24mhz/12) => x = 0x10000 -(2mhz * 1000us)  = 0x10000 - 2000 = 0xf830
            TL1 = 0x30;
            TCON |= M_TR1; // start t1
            g_ms_cnt = 0;
            g_scan_key = 1;
            g_key_first = 0;
            g_key_second = 0;
        }

        if(g_scan_key)
        {
            g_scan_key = 0;
            sys_scan_debounce_key();
            if(g_key_final != 0) // key pressed is valid
            {
                /* do something here */
                g_data_buf[PREAMBLE_LEN+SYNC_LEN] = g_key_final; /* update key value */

                /* xo_istart_bit4_sel = 0, xo_istart_bit3_sel = 0, xo_istart from mtp */
                sys_set_reg_bit(AON_REG_07, 0x00, 0x06);

                /* open xo crstal for tx */
                sys_set_reg_bit(AON_REG_04, 0, M_MANU_PD_XO);

                /* wait 400 us for xo crystal stable */
                sys_delay_100us(4);
						 /* xo_istart_bit4_sel = 1, xo_istart_bit3_sel = 1, xo_istart from latch */
                sys_set_reg_bit(AON_REG_07, 0x06, 0x06);

                /* enable ana lbd tx clock (must wait xo crystal stable) */
                CLK_GATE_0 |= (M_ANA_CLK_EN | M_LBD_CLK_EN);
                CLK_GATE_1 |= M_TX_CLK_EN;

                /* config tx_modu and tx_sym */
                tx_config();

                tx_sym_setup_config(0x3c);			//msb

                /* open vco_ldo */
                sys_set_reg_bit(AON_REG_06, 0, M_PD_VCO_LDO);
                sys_delay_us(5);

                /* open tx rf front */
                tx_sym_open_front();

                /* check afc lock and lower voltage or not */
                if((!(PA_IDAC_CODE & M_LD_OUT)) || (!(LBD_CTL_1 & M_LBD_STATUS)))
                {
                    /* if afc no lock or lower voltage, can stop transmiting here*/
                }

                /* transmit data over air */
                tx_sym_packet_transmit(g_data_buf, PKT_LEN);

                /* close tx rf front */
                tx_sym_close_front();

                /* close vco_ldo */
                sys_set_reg_bit(AON_REG_06, M_PD_VCO_LDO, M_PD_VCO_LDO);

                /* disable ana lbd tx clock  */
                CLK_GATE_0 &= ~(M_ANA_CLK_EN | M_LBD_CLK_EN);
                CLK_GATE_1 &= ~M_TX_CLK_EN;

                /* close xo crystal when no need */
                sys_set_reg_bit(AON_REG_04, M_MANU_PD_XO, M_MANU_PD_XO);

                g_key_first = 0;
                g_key_second = 0;
            }
        }

        /* no key pressed or long key pressed */
        if((g_key_first == 0 && g_key_cur == 0 && g_key_final == 0) || (g_ms_cnt > 10000))
        {
            TCON &= ~(M_TR1 | M_TF1); // stop t1

            /* change dxx_polar by gpio value */
            dxx_polar = P0;
            sys_write_reg(AON_REG_1D, dxx_polar);
            dxx_polar = P1;
            sys_write_reg(AON_REG_1E, dxx_polar);

            sys_shutdown();
        }
    }

}

void sys_external_interrupt0_routine(void)
{
    /* when wakeup by io event, must clear io_event_rst_n and state_is_sleep */
    WKINT_STA &= ~M_IO_EVENT_RST_N;
    sys_set_reg_bit(AON_REG_03, 0, M_STATE_IS_SLEEP);

    g_key_pressed = 1;
}

void sys_timer1_interrupt_routine(void)
{
    TCON &= ~ M_TF1;
    TH1 = 0xf8; // t = 1000us = (0x10000 - x)/(24mhz/12) => x = 0x10000 -(2mhz * 1000us)  = 0x10000 - 2000 = 0xf830
    TL1 = 0x30;
    g_ms_cnt++;
    if((g_ms_cnt % 7) == 0)
    {
        /* scan key every 7 ms */
        g_scan_key = 1;
    }
}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_external_interrupt0_routine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_timer1_interrupt_routine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
