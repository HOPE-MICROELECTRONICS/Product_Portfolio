//#include "intrins.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"

uint8_t g_scan_key;
uint8_t g_key_pressed;
uint16_t g_ms_cnt;
uint16_t g_key_first;
uint16_t g_key_second;
uint16_t g_key_cur;
uint16_t g_key_final;

void sys_scan_debounce_key(void)
{
    /* get gpio status and check key pressed(0: pressed, 1: no pressed) */
    g_key_cur = 0;
    g_key_final = 0;

    /* if was pressed three times continuously, so there are keys pressed */
    if((P0 & VAL_BIT0) == 0)
    {
        if((g_key_first & 0x01) && (g_key_second & 0x01))
        {
            g_key_final |= 0x01; 
        }
        else 
        {
            g_key_cur |= 0x01;
        }
    }
    if((P0 & VAL_BIT1) == 0)
    {
        if((g_key_first & 0x02) && (g_key_second & 0x02))
        {
            g_key_final |= 0x02;
        }
        else 
        {
            g_key_cur |= 0x02;
        }
    }
    if((P0 & VAL_BIT2) == 0)
    {
        if((g_key_first & 0x04) && (g_key_second & 0x04))
        {
            g_key_final |= 0x04;
        }
        else 
        {
            g_key_cur |= 0x04;
        }
    }
    if((P0 & VAL_BIT3) == 0)
    {
        if((g_key_first & 0x08) && (g_key_second & 0x08))
        {
            g_key_final |= 0x08;
        }
        else 
        {
            g_key_cur |= 0x08;
        }
    }
    if((P0 & VAL_BIT4) == 0)
    {
        if((g_key_first & 0x10) && (g_key_second & 0x10))
        {
            g_key_final |= 0x10;
        }
        else 
        {
            g_key_cur |= 0x10;
        }
    }
    if((P0 & VAL_BIT5) == 0)
    {
        if((g_key_first & 0x20) && (g_key_second & 0x20))
        {
            g_key_final |= 0x20;
        }
        else 
        {
            g_key_cur |= 0x20;
        }
    }
    if((P0 & VAL_BIT6) == 0)
    {
        if((g_key_first & 0x40) && (g_key_second & 0x40))
        {
            g_key_final |= 0x40;
        }
        else 
        {
            g_key_cur |= 0x40;
        }
    }
    if((P0 & VAL_BIT7) == 0)
    {
        if((g_key_first & 0x80) && (g_key_second & 0x80))
        {
            g_key_final |= 0x80;
        }
        else 
        {
            g_key_cur |= 0x80;
        }
    }
    if((P1 & VAL_BIT0) == 0)
    {
        if((g_key_first & 0x100) && (g_key_second & 0x100))
        {
            g_key_final |= 0x100;
        }
        else 
        {
            g_key_cur |= 0x100;
        }
    }
    if((P1 & VAL_BIT1) == 0)
    {
        //g_key_cur |= 0x200;
        if((g_key_first & 0x200) && (g_key_second & 0x200))
        {
            g_key_final |= 0x200;
        }
        else 
        {
            g_key_cur |= 0x200;
        }
    }
    if((P1 & VAL_BIT2) == 0)
    {
        if((g_key_first & 0x400) && (g_key_second & 0x400))
        {
            g_key_final |= 0x400;
        }
        else 
        {
            g_key_cur |= 0x400;
        }
    }
    if((P1 & VAL_BIT3) == 0)
    {
        if((g_key_first & 0x800) && (g_key_second & 0x800))
        {
            g_key_final |= 0x800;
        }
        else 
        {
            g_key_cur |= 0x800;
        }
    }
    
    /* record gpio status */
    g_key_first = g_key_second;
    g_key_second = g_key_cur;
    
}

void main(void)
{
    uint8_t dxx_polar;

    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;
    EA = 0;

    /* disable all clock */
    sys_disable_all_clk();

    /* enable clock */
    CLK_GATE_1 |= M_INTIO_CLK_EN;
    CLK_GATE_2 |= (M_PORT1_CLK_EN | M_PORT0_CLK_EN | M_TIMER1_CLK_EN);
    
    /* rst_in_en = 0 => set d0 as gpio */
    sys_set_reg_bit(AON_REG_07, 0, M_RST_IN_EN);
    
    /* enable d11~d0 pullup */
    sys_write_reg(AON_REG_15, 0x00);
    sys_write_reg(AON_REG_16, 0x00);
    
    /* disable d11-d0 pulldown */
    sys_write_reg(AON_REG_17, 0xff);
    sys_write_reg(AON_REG_18, 0x0f);
    
    /* dxx_idrv_en = 1 */
    sys_write_reg(AON_REG_13, 0xff);
    sys_write_reg(AON_REG_14, 0x0f); 
    
    /* dxx_det_en = 1, when io changing, will triger external interrupt 0*/
    sys_write_reg(AON_REG_1B, 0xff);
    sys_write_reg(AON_REG_1C, 0x0b); // disable d10 in simulation
    
    /* dxx_polar = 1  0: rising edge triger int0, 1: falling edge triger int0 */
    sys_write_reg(AON_REG_1D, 0xff);
    sys_write_reg(AON_REG_1E, 0x0f);
    
    TCON &= ~(M_TR1 | M_TF1);
    TMOD = (TMOD & (~M_M1)) | (T1_MODE_1); // t1 mode 1
    TH1 = 0xf8; // t = 1000us = (0x10000 - x)/(24mhz/12) => x = 0x10000 -(2mhz * 1000us)  = 0x10000 - 2000 = 0xf830
    TL1 = 0x30;
    
    /* enable timer1 interrupt */
    ET1 = 1;
    
    /* enable external interrupt 0 */
    EX0 = 1;
    
    EA = 1;

    g_key_pressed = 1;
    g_scan_key = 0;
    g_ms_cnt = 0;
    
    while(1)
    {
        if(g_key_pressed)
        {
            g_key_pressed = 0;
            TH1 = 0xf8; // t = 1000us = (0x10000 - x)/(24mhz/12) => x = 0x10000 -(2mhz * 1000us)  = 0x10000 - 2000 = 0xf830
            TL1 = 0x30;
            TCON |= M_TR1; // start t1
            g_ms_cnt = 0;
            g_scan_key = 1;
            g_key_first = 0;
            g_key_second = 0;
        }
        
        if(g_scan_key)
        {
            g_scan_key = 0;
            sys_scan_debounce_key();
            
            if(g_key_final != 0) // key pressed is valid
            {
                /* do something here */
                
                g_key_first = 0;
                g_key_second = 0;
            }
        }

        /* no key pressed or long key pressed */
        if((g_key_first == 0 && g_key_cur == 0 && g_key_final == 0) || (g_ms_cnt > 2000))
        {
            TCON &= ~(M_TR1 | M_TF1); // stop t1
            
            /* change dxx_polar by gpio value */
            dxx_polar = P0;
            sys_write_reg(AON_REG_1D, dxx_polar);
            dxx_polar = P1;
            sys_write_reg(AON_REG_1E, dxx_polar);

            sys_shutdown();
        }
    } 
    
}

void sys_external_interrupt0_routine(void)
{
    /* when wakeup by io event, must clear io_event_rst_n and state_is_sleep */
    WKINT_STA &= ~M_IO_EVENT_RST_N;
    sys_set_reg_bit(AON_REG_03, 0, M_STATE_IS_SLEEP);
    
    g_key_pressed = 1;
}

void sys_timer1_interrupt_routine(void)
{
    TCON &= ~ M_TF1;
    TH1 = 0xf8; // t = 1000us = (0x10000 - x)/(24mhz/12) => x = 0x10000 -(2mhz * 1000us)  = 0x10000 - 2000 = 0xf830
    TL1 = 0x30;
    g_ms_cnt++;
    if((g_ms_cnt % 7) == 0)
    {
        /* scan key every 7 ms */
        g_scan_key = 1;
    }
}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_external_interrupt0_routine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_timer1_interrupt_routine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
