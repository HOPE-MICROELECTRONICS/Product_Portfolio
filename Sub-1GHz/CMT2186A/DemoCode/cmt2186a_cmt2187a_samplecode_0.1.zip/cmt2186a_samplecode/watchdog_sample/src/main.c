// #include "intrins.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"

uint8_t g_ms_cnt = 0;

void main(void)
{
	uint8_t cnt;
    uint8_t led_on;
    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;
    EA = 0;

    /* disable all clock */
    sys_disable_all_clk();

    /* enable clock */
    CLK_GATE_1 |= M_INTIO_CLK_EN;
    CLK_GATE_2 |= M_TIMER1_CLK_EN;

    /* set d8 as led output pin */
    sys_set_reg_bit(AON_REG_16, 0, M_D8_PD_PULLUP);
    sys_set_reg_bit(AON_REG_12, M_D8_ODRV_EN, M_D8_ODRV_EN);
    sys_set_reg_bit(AON_REG_1A, 0, M_D8_OPEN_DRAIN);

    /* gpio8_out_sel = 0, output value from gpio_out_sfr[8] */
    GPIO_OUTE_SEL &= ~M_GPIO8_OUT_SEL;

    TCON &= ~(M_TR1 | M_TF1);
    TMOD = (TMOD & (~M_M1)) | (T1_MODE_1); // t1 mode 1
    TH1 = 0xf8;                            // t = 1000us = (0x10000 - x)/(24mhz/12) => x = 0x10000 -(2mhz * 1000us)  = 0x10000 - 2000 = 0xf830
    TL1 = 0x30;

    /* enable timer1 interrupt */
    ET1 = 1;

    EA = 1;

    /* open lfosc clock */
    sys_set_reg_bit(AON_REG_04, 0, M_PD_LFOSC);

    /* wait lfosc clock ready */
    while (!(sys_read_reg(AON_REG_07) & M_LFOSC_FLAG_R))
        ;

    /* set wdt_reset_th = 1 (0: 32ms, 1: 64ms, 2: 128ms, 3: 256ms, 4: 512ms, 5: 1s, 6: 2s, 7: 4s) */
    sys_set_reg_bit(AON_REG_03, WDT_RESET_TH_2S, M_WDT_RESET_TH);

    /* start watchdog */
    sys_set_reg_bit(AON_REG_03, M_WDT_EN_SOFT, (M_WDT_EN_SOFT | M_WDT_FORCE_HARD));

    /* enable timer1 */
    TCON |= M_TR1;

	for(cnt=0; cnt<20; cnt++)
	{
       if (led_on)
        {
            GPIO_OUT_1 |= 0x01; /* gpio_out_sfr[8] = 1 */
            led_on = 0;
        }
        else
        {
            GPIO_OUT_1 &= ~0x01; /* gpio_out_sfr[8] = 0 */
            led_on = 1;
        }

        sys_delay_ms(200);
 	}

    /* disble timer1 */
    TCON &= (~M_TR1);
    
	//wait for reset
	while (1)
    {
        if (led_on)
        {
            GPIO_OUT_1 |= 0x01; /* gpio_out_sfr[8] = 1 */
            led_on = 0;
        }
        else
        {
            GPIO_OUT_1 &= ~0x01; /* gpio_out_sfr[8] = 0 */
            led_on = 1;
        }

        sys_delay_ms(50);
    }
}

void sys_timer1_interrupt_routine(void)
{
    TCON &= ~M_TF1;
    TH1 = 0xf8; // t = 1000us = (0x10000 - x)/(24mhz/12) => x = 0x10000 -(2mhz * 1000us)  = 0x10000 - 2000 = 0xf830
    TL1 = 0x30;
    g_ms_cnt++;
    if ((g_ms_cnt % 32) == 0)
    {
        /* refresh watchdog */
        sys_set_reg_bit(AON_REG_03, 0, M_WDT_REFRESH);
        sys_set_reg_bit(AON_REG_03, M_WDT_REFRESH, M_WDT_REFRESH);
    }
}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_timer1_interrupt_routine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
