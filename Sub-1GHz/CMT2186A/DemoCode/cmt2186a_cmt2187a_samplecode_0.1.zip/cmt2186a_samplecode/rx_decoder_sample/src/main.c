//#include "intrins.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"

#define DATA_LEN            12
#define SYNC_PASS           0x26453214
uint8_t g_recv_done;
uint8_t g_recv_buf[DATA_LEN];
void receive_rx_data_routine(void)
{
    static uint32_t sync_id = 0;
    static uint8_t sync_ok = 0;
    static uint8_t bit_cnt = 0;
    static uint8_t byte_cnt = 0;
    static uint8_t recv_data = 0;

    /* set sfr_page_sel = 0 */
    SFR_PAGE &= ~M_SFR_PAGE_SEL;

    if(sync_ok == 0)
    {
        /* +++++++++++++++++ detect sync id ++++++++++++++++++++++++++++++++++++++*/
        sync_id <<= 1;
        if(CDR_DR_2 & M_RX_DATA_OUT)
        {
            sync_id |= 0x01;
        }

        if(sync_id == SYNC_PASS)
        {
            /* stop detecting sync id and start to receive data */
            sync_ok = 1;
            bit_cnt = 0;
            byte_cnt = 0;
        }
    }
    else 
    {
        /* +++++++++++++++++++ receive data ++++++++++++++++++++++++++++++++++++++*/
        recv_data <<= 1;
        if(CDR_DR_2 & M_RX_DATA_OUT)
        {
            recv_data |= 0x01;
        }
        bit_cnt++;

        if(bit_cnt >= 8)
        {
            g_recv_buf[byte_cnt++] = recv_data;
            bit_cnt = 0;
        }

        if(byte_cnt >= DATA_LEN)
        {
            g_recv_done = 1;
            byte_cnt = 0;
            sync_ok = 0; /* re-detect sync id */
        }
    }
}

void main(void)
{
    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;
    EA = 0;

    /* disable all clock */
    sys_disable_all_clk();

    /* enable intio and dec clock */
    CLK_GATE_1 |= (M_INTIO_CLK_EN | M_DEC_CLK_EN);

    /* set d1 as pullup input pin */
    sys_set_reg_bit(AON_REG_13, M_D1_IDRV_EN, M_D1_IDRV_EN);
    sys_set_reg_bit(AON_REG_15, 0, M_D1_PD_PULLUP);
    sys_set_reg_bit(AON_REG_17, M_D1_PD_PULLDOWN, M_D1_PD_PULLDOWN);

    /* set rxdata input from d1 */
    GPIO_INE_SEL = (GPIO_INE_SEL & (~M_RXDATA_GPIO_SEL)) | (1 << BIT4);

    /* set rx_clk_out to external int2 */
    INTCTL_1 = (INTCTL_1 & (~M_INT2_SEL)) | (INT_SRC_RX_CLK_OUT << BIT0);
    INTCTL_0 &= ~VAL_BIT2; /* int2 polar = 0 */

    /* set rx data rate */
    CDR_DR_0 = 0x03; // rx_brx16_word = 0x369c
    CDR_DR_1 = 0x69;
    CDR_DR_2 = (CDR_DR_2 & (~0x0f)) | 0x0c;

    /* rx decode start */
    CDR_DR_2 |= M_RX_START;

    /* enable external interrupt 2 */
    IEN1 |= M_EX2;
    EA = 1;

    while (1)
    {
        if(g_recv_done)
        {
            g_recv_done = 0;

            /* do something here */

            sys_shutdown();
        }
    }
    

    sys_shutdown();

}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    receive_rx_data_routine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
