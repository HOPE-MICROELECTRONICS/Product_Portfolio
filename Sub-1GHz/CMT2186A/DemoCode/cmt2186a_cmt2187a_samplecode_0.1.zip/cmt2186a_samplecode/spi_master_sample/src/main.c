//#include "intrins.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"


/* struct spi_setup */
typedef struct SPI_SETUP_STRU{
    /* spi_cfg0 define
    bit[7]: spi_bidi_mode       0: 2-line unidir mode, 1: 1-line bidir mode
    bit[6]: spi_bidi_oe         0: bidir mode output disabled (rx-only), 1: bidir mode output enabled (tx-only)
    bit[5]: spi_rx_only         0: unidir mode full duplex (rx and tx), 1: unidir mode output disabled (rx-only)
    bit[4]: spi_8b16b_sel       0: 8-bit data frame, 1: 16-bit data frame
    bit[3]: spi_fifo_reg_sel    0: NSS output, 1: FCSB output
    bit[2]: spi_nss_oen         0: NSS output disabled in master mode, 1: NSS output enabled in master mode
    bit[1]: spi_snss_en         0: software control slave NSS disabed, 1: software control slave NSS enabled (NSS = SSI)
    bit[0]: spi_snss            used to replace NSS in software control slave NSS mode
    */
    uint8_t spi_cfg0;

    /* spi_cfg1 define
    bit[7]  : spi_lsbf          0: MSB transmitted first, 1: LSB transmitted first
    bit[6]  : reserved
    bit[3:5]: spi_mbr           SPI baud rate, clk_per divided by 0: 4, 1: 8, 2: 16, 3: 24, 4: 32, 5: 64, 6: 128, 7: 256
    bit[2]  : spi_ms_sel        0: slave mode, 1: master mode
    bit[1]  : spi_ckpol_sel     0: SCK is 0 when IDEL, 1: SCK is 1 when IDLE
    bit[0]  : spi_edge_sel      0: first SCK edge to capture first data bit, 1: second SCK edge to capture first data bit
    */
    uint8_t spi_cfg1;

} STRU_SPI_SETUP;




STRU_SPI_SETUP xdata g_spi_setup;

uint8_t xdata g_spi_bidi_mode;       /* 0: 2-line unidir mode, 1: 1-line bidir mode */
uint8_t xdata g_spi_bidi_oe;         /* 0: bidir mode output disabled (rx-only), 1: bidir mode output enabled (tx-only) */
uint8_t xdata g_spi_rx_only;         /* 0: unidir mode full duplex (rx and tx), 1: unidir mode output disabled (rx-only) */
uint8_t xdata g_spi_8b16b_sel;       /* 0: 8-bit data frame, 1: 16-bit data frame */
uint8_t xdata g_spi_fifo_reg_sel;    /* 0: NSS output, 1: FCSB output */
uint8_t xdata g_spi_nss_oen;         /* 0: NSS output disabled in master mode, 1: NSS output enabled in master mode */
uint8_t xdata g_spi_snss_en;         /* 0: software control slave NSS disabed, 1: software control slave NSS enabled (NSS = SSI) */
uint8_t xdata g_spi_snss;            /*    used to replace NSS in software control slave NSS mode */

uint8_t xdata g_spi_lsbf;            /*0: MSB transmitted first, 1: LSB transmitted first */
uint8_t xdata g_spi_mbr;             /*SPI baud rate, clk_per divided by 0: 4, 1: 8, 2: 16, 3: 24, 4: 32, 5: 64, 6: 128, 7: 256 */
uint8_t xdata g_spi_ms_sel;          /*0: slave mode, 1: master mode */
uint8_t xdata g_spi_ckpol_sel;       /*0: SCK is 0 when IDEL, 1: SCK is 1 when IDLE */
uint8_t xdata g_spi_edge_sel;        /*0: first SCK edge to capture first data bit, 1: second SCK edge to capture first data bit */

void system_spi_setup_config()
{
    /* spi_cfg0 define
    bit[7]: spi_bidi_mode       0: 2-line unidir mode, 1: 1-line bidir mode
    bit[6]: spi_bidi_oe         0: bidir mode output disabled (rx-only), 1: bidir mode output enabled (tx-only)
    bit[5]: spi_rx_only         0: unidir mode full duplex (rx and tx), 1: unidir mode output disabled (rx-only)
    bit[4]: spi_8b16b_sel       0: 8-bit data frame, 1: 16-bit data frame
    bit[3]: spi_fifo_reg_sel    0: NSS output, 1: FCSB output
    bit[2]: spi_nss_oen         0: NSS output disabled in master mode, 1: NSS output enabled in master mode
    bit[1]: spi_snss_en         0: software control slave NSS disabed, 1: software control slave NSS enabled (NSS = SSI)
    bit[0]: spi_snss            used to replace NSS in software control slave NSS mode
    */
    g_spi_setup.spi_cfg0 = (g_spi_bidi_mode << BIT7) | (g_spi_bidi_oe << BIT6)| (g_spi_rx_only << BIT5) | (g_spi_8b16b_sel << BIT4) | (g_spi_fifo_reg_sel << BIT3)| (g_spi_nss_oen << BIT2) | (g_spi_snss_en << BIT1) | (g_spi_snss << BIT0);

    /* spi_cfg1 define
    bit[7]  : spi_lsbf          0: MSB transmitted first, 1: LSB transmitted first
    bit[6]  : reserved
    bit[3:5]: spi_mbr           SPI baud rate, clk_per divided by 0: 4, 1: 8, 2: 16, 3: 24, 4: 32, 5: 64, 6: 128, 7: 256
    bit[2]  : spi_ms_sel        0: slave mode, 1: master mode
    bit[1]  : spi_ckpol_sel     0: SCK is 0 when IDEL, 1: SCK is 1 when IDLE
    bit[0]  : spi_edge_sel      0: first SCK edge to capture first data bit, 1: second SCK edge to capture first data bit
    */
    g_spi_setup.spi_cfg1 = (g_spi_lsbf << BIT7) | (g_spi_mbr << BIT3) | (g_spi_ms_sel << BIT2) | (g_spi_ckpol_sel << BIT1) | (g_spi_edge_sel << BIT0);

    SPI_CTL_0 = g_spi_setup.spi_cfg0;
    SPI_CTL_1 = g_spi_setup.spi_cfg1;

}


void spi_send_recv_data(uint8_t *snd_buf, uint8_t *recv_buf, uint8_t data_len)
{
    uint8_t idx;
     
    /* enable spi */
    SPI_CTL_1 |= M_SPI_ENABLE;

    for (idx = 0; idx < data_len; idx++)
    {
        /* upate spi tx fifo */
        SPI_DATA_L = snd_buf[idx];

        /* wait spi tx fifo empty */
        while(!(SPI_CTL_2 & M_SPI_TXMTY));

        /* wait spi rx ready */
        while(!(SPI_CTL_2 & M_SPI_RXNMTY));

        /* recv data */
        recv_buf[idx] = SPI_DATA_L;
    }

    /* wait spi no busy (transmit done) */
    while(SPI_CTL_2 & M_SPI_BUSY);

    /* disable spi */
    SPI_CTL_1 &= ~M_SPI_ENABLE;
}

#define DATA_LEN        16
uint8_t xdata g_send_buf[DATA_LEN];
uint8_t xdata g_recv_buf[DATA_LEN];
void main(void)
{
    uint8_t idx;

    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;



    // disable all clk
    sys_disable_all_clk();

    // Enable spi master clk
    CLK_GATE_1 |= M_SPIM_CLK_EN | M_SPIS_CLK_EN | M_INTIO_CLK_EN;

    /* spi gpio config
        gpio1(d1) -> sck_out
        gpio2(d2) -> miso_in
        gpio3(d3) -> mosi_out
        gpio4(d4) -> nss_out
    */

    /* set gpio1(d1) gpio3(d3) gpio4(d4) push-pull output select */
    sys_set_reg_bit(AON_REG_19, (M_D4_OPEN_DRAIN | M_D1_OPEN_DRAIN | M_D3_OPEN_DRAIN), (M_D4_OPEN_DRAIN | M_D1_OPEN_DRAIN | M_D3_OPEN_DRAIN));
    sys_set_reg_bit(AON_REG_11, (M_D4_ODRV_EN | M_D1_ODRV_EN | M_D3_ODRV_EN), (M_D4_ODRV_EN | M_D1_ODRV_EN | M_D3_ODRV_EN));
    /* set miso input from gpio2(d2) */
    sys_set_reg_bit(AON_REG_13,  M_D2_IDRV_EN,  M_D2_IDRV_EN);

    /* miso_in_gpio_sel = 2, miso in from d2 */
    GPIO_INB_SEL = (GPIO_INB_SEL &  M_MISO_IN_GPIO_SEL) | (GPIO_IN_SEL_D2 << BIT0);
    /* gpio1_out_sel = 6, output from sck_out */
    GPIO_OUTA_SEL = (GPIO_OUTA_SEL & M_GPIO1_OUT_SEL) | (6 << BIT4);
    /* gpio3_out_sel = 8, output from mosi_out */
    GPIO_OUTB_SEL = (GPIO_OUTB_SEL & M_GPIO3_OUT_SEL) | (8 << BIT4);
    /* gpio4_out_sel = 5, output from nss_out */
    GPIO_OUTC_SEL = (GPIO_OUTC_SEL & M_GPIO4_OUT_SEL) | (5 << BIT0);

    g_spi_bidi_mode     = 0;    /* 0: 2-line unidir mode, 1: 1-line bidir mode */
    g_spi_bidi_oe       = 0;    /* 0: bidir mode output disabled (rx-only), 1: bidir mode output enabled (tx-only) */
    g_spi_rx_only       = 0;    /* 0: unidir mode full duplex (rx and tx), 1: unidir mode output disabled (rx-only) */
    g_spi_8b16b_sel     = 0;    /* 0: 8-bit data frame, 1: 16-bit data frame */
    g_spi_fifo_reg_sel  = 0;    /* 0: NSS output, 1: FCSB output */
    g_spi_nss_oen       = 1;    /* 0: NSS output disabled in master mode, 1: NSS output enabled in master mode */
    g_spi_snss_en       = 0;    /* 0: software control slave NSS disabed, 1: software control slave NSS enabled (NSS = SSI) */
    g_spi_snss          = 1;    /*    used to replace NSS in software control slave NSS mode  */

    g_spi_lsbf          = 1;    /*0: MSB transmitted first, 1: LSB transmitted first */
    g_spi_mbr           = 0;    /*SPI baud rate, clk_per divided by 0: 4, 1: 8, 2: 16, 3: 24, 4: 32, 5: 64, 6: 128, 7: 256 */
    g_spi_ms_sel        = 1;    /*0: slave mode, 1: master mode */
    g_spi_ckpol_sel     = 0;    /*0: SCK is 0 when IDEL, 1: SCK is 1 when IDLE */
    g_spi_edge_sel      = 0;    /*0: first SCK edge to capture first data bit, 1: second SCK edge to capture first data bit */

    /* spi config */
    system_spi_setup_config();

	EA = 1;

    for(idx = 0; idx < DATA_LEN; idx++)
    {
        g_send_buf[idx] = 0xa0 + idx;
    }

    spi_send_recv_data(g_send_buf, g_recv_buf, DATA_LEN);

    sys_delay_us(50);

    sys_shutdown();

}


extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
