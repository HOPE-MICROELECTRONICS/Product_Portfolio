//#include "intrins.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"



void main(void)
{
    uint8_t led_on;

    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;
    EA = 0;

    /* disable all clock */
    sys_disable_all_clk();

    /* enable clock */
    CLK_GATE_1 |= M_INTIO_CLK_EN;


    /* set d8 as led output pin */
    sys_set_reg_bit(AON_REG_16, 0, M_D8_PD_PULLUP);
    sys_set_reg_bit(AON_REG_12, M_D8_ODRV_EN, M_D8_ODRV_EN);
    sys_set_reg_bit(AON_REG_1A, 0, M_D8_OPEN_DRAIN);
    /* gpio8_out_sel = 0, output value from gpio_out_sfr[8] */
    GPIO_OUTE_SEL &= ~M_GPIO8_OUT_SEL;


    /* enable external interrupt 1, sleep timer timeout fixed map to external interrupt 1 */
    EX1 = 1;

    EA = 1;

    led_on = 0;

    /* open lfosc clock */
    sys_set_reg_bit(AON_REG_04, 0, M_PD_LFOSC);

    /* wait lfosc clock ready */
    while(!(sys_read_reg(AON_REG_07) & M_LFOSC_FLAG_R));

    /* sleep  timer  1024 ms = m*2^(r+1)*31.25us -> m = 1024, r = 4 */
    sys_write_reg(AON_REG_01, 00);
    sys_set_reg_bit(AON_REG_02, 4, M_TIMER_M_SLEEP_10_8);
    sys_set_reg_bit(AON_REG_02, (4 << BIT3), M_TIMER_R_SLEEP);
    /* sleep timer mode -- 0: rtc mode(sleep timer works at shutdown and active state), 1:nornal mode(sleep timer only works at shutdown state) */
    sys_set_reg_bit(AON_REG_06, 0, M_SLEEP_TIMER_MODE);
    /* start sleep timer */
    sys_set_reg_bit(AON_REG_02, M_SLEEP_TIMER_EN, M_SLEEP_TIMER_EN);

    GPIO_OUT_1 &= ~0x01; 	/* gpio_out_sfr[8] = 0 */
    sys_delay_ms(150);
	GPIO_OUT_1 |= 0x01; 	/* gpio_out_sfr[8] = 1 */


	while(1)
		{
		sys_shutdown();

    	GPIO_OUT_1 &= ~0x01; 	/* gpio_out_sfr[8] = 0 */
    	sys_delay_ms(10);
	    GPIO_OUT_1 |= 0x01; 	/* gpio_out_sfr[8] = 1 */
		}
}

void sys_external_interrupt1_routine(void)
{
    /* clear state_is_sleep */
    sys_set_reg_bit(AON_REG_03, 0, M_STATE_IS_SLEEP);

    /* sleep timer is rtc mode, need clear tmo_mode0 flag */
    sys_set_reg_bit(AON_REG_06, M_TMO_MODE0_CLR, M_TMO_MODE0_CLR);
    sys_delay_10us(13);
    sys_set_reg_bit(AON_REG_06, 0, M_TMO_MODE0_CLR);

}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_external_interrupt1_routine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
