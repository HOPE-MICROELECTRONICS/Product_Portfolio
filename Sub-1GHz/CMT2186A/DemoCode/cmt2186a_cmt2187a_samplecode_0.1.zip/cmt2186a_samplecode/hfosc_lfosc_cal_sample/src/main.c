//#include "intrins.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"

void sys_hfosc_cal(void)
{
    /* open xo crystal */

    /* hfcal_clk_en = 1 */
    CLK_GATE_2 |= M_HFCAL_CLK_EN;

    /* hfosc_cal_en = 1 */
    sys_set_reg_bit(AON_REG_04, M_HFOSC_CAL_EN, M_HFOSC_CAL_EN);

    /* hfosc_div2_en = 1 */
    ANA_CTL_8 |= M_HFOSC_DIV2_EN;

    /* cal_hfosc_start = 1 */
    ANA_CTL_8 |= M_CAL_HFOSC_START;

    /* wait cal_hfosc_done */
    while(!(ANA_CTL_4 & M_CAL_HFOSC_DONE));

    /* clear cal_hfosc_done */
    ANA_CTL_4 &= ~M_CAL_HFOSC_DONE;

    /* cal_hfosc_start = 0 */
    ANA_CTL_8 &= ~M_CAL_HFOSC_START;

    /* hfosc_div2_en = 0 */
    ANA_CTL_8 &= ~M_HFOSC_DIV2_EN;

    /* hfosc_cal_en = 0 */
    sys_set_reg_bit(AON_REG_04, 0, M_HFOSC_CAL_EN);

    /* hfcal_clk_en = 0 */
    CLK_GATE_2 &= ~M_HFCAL_CLK_EN;

}

void sys_lfosc_cal(void)
{
    /* open xo crystal */

    /* lfcal_clk_en = 1 */
    CLK_GATE_2 |= M_LFCAL_CLK_EN;

    /* lfosc_cal_en = 1, pd_lfosc = 0 */
    sys_set_reg_bit(AON_REG_04, M_LFOSC_CAL_EN, (M_LFOSC_CAL_EN | M_PD_LFOSC));

    /* cal_lfosc_start = 1 */
    ANA_CTL_8 |= M_CAL_LFOSC_START;

    /* wait cal_lfosc_done */
    while(!(ANA_CTL_4 & M_CAL_LFOSC_DONE));

    /* clear cal_lfosc_done */
    ANA_CTL_4 &= ~M_CAL_LFOSC_DONE;

    /* cal_lfosc_start = 0 */
    ANA_CTL_8 &= ~M_CAL_LFOSC_START;

    /* lfosc_cal_en = 0 */
    sys_set_reg_bit(AON_REG_04, 0, M_LFOSC_CAL_EN);

    /* lfcal_clk_en = 0 */
    CLK_GATE_2 &= ~M_LFCAL_CLK_EN;
}


void main(void)
{
    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;
    EA = 0;

    /* disable all clock */
    sys_disable_all_clk();

    /* enable clock */
    CLK_GATE_0 |= M_ANA_CLK_EN;

    /* xo_istart_bit4_sel = 0, xo_istart_bit3_sel = 0, xo_istart from mtp */
    sys_set_reg_bit(AON_REG_07, 0x00, 0x06);

    /* open xo crystal for hfosc and lfosc calibration */
    sys_set_reg_bit(AON_REG_04, 0, M_MANU_PD_XO);

    /* wait 400 us for xo crystal stable */
    sys_delay_100us(4);

    /* xo_istart_bit4_sel = 1, xo_istart_bit3_sel = 1, xo_istart from latch */
    sys_set_reg_bit(AON_REG_07, 0x06, 0x06);

    /* do hfosc calibration */
    sys_hfosc_cal();

    /* do lfosc calibration */
    sys_lfosc_cal();

    /* close xo crystal if no need */
    sys_set_reg_bit(AON_REG_04, M_MANU_PD_XO,M_MANU_PD_XO);

    sys_shutdown();

}



extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
