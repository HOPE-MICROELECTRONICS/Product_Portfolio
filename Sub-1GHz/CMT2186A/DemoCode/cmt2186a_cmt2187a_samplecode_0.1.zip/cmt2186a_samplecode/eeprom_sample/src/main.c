//#include "intrins.h"
#include "string.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"


/*****************************************************************************************************************
 * @name: eeprom_write_words
 * @desc: write buffer data(in xdata) to eeprom(erase + program)
 * @param:
 *  start_addr  : write eeprom start addr, must be smaller than 0x20, or else will occur unexpected error
 *  wr_buf      : (pointer to BYTE in xdata) pointer to data buffer which will be write to eeprom(MSB)
 *  eeprom_size : write eeprom size(word), (start_addr + eeprom_size) must be not larger than 0x20, or else will
 *                  occur unexpected error
 * @return:
 *          0: write eeprom successfully
 *          1: erase eeprom failed
 *          2: program eeprom failed
 * ******************************************************************************************************************/
uint8_t eeprom_write_words(uint8_t start_addr, uint8_t xdata *wr_buf, uint8_t eeprom_size)
{
    uint8_t idx;
    uint8_t ret_val;
    uint8_t delay_cnt;
    uint8_t *ptr_buf;

    /* default return code = 0 */
    ret_val = 0;
    ptr_buf = wr_buf;

    /* set sfr_page_sel = 1 */
    SFR_PAGE |= M_SFR_PAGE_SEL;

    /* set pd_ee = 0 */
    EE_CTL &= ~M_PD_EE;

    /* wait 2 us */
    sys_delay_us(2);

    /* bulk process */
    for (idx = 0; idx < eeprom_size; idx++)
    {
        /*+++++++++++++ step 1: erase one word eeprom address +++++++++++++++++++++++++++++*/
        
        /* set EE_ADDR */
        EE_ADDR = start_addr++;

        /* write erase mode to ee_mode, and start erasing */
        EE_CTL = (EE_CTL & (~M_EE_OPMODE)) | (EE_ERASE_MODE | M_EE_START);

        delay_cnt = 0;

        /* wait for ee_erase_done */
        while (!(EE_CTL & M_EE_ERASE_DONE))
        {
            /* delay 1 ms */
            sys_delay_ms(1);

            delay_cnt++;
            if(delay_cnt > 14) /* wait > 8 ms */
            {
                /* erase eeprom address fail */
                ret_val = 1;
                
                /* exit bulk process */
                goto eeprom_write_exit;
            }
        }
        if(EE_STA & (M_TRR_ERASE_READY_ERR | M_TRR_PGM_READY_ERR | M_TRR_READ_READY_ERR | M_TRR_IP_EN_READY_ERR))
        {
            ret_val = 2;
            goto eeprom_write_exit;
        }

        /* erase eeprom address sucessfully and clear ee_erase done */
        EE_CTL &= ~(M_EE_START | M_EE_ERASE_DONE);

        /*++++++++++++++++ step 2: write data to eeprom address ++++++++++++++++++++++++++++*/

        /* write data to EE_WDATA_H, EE_WDATA_L */
        EE_WDATA_H = *ptr_buf++;
        EE_WDATA_L = *ptr_buf++;

        /* write program mode to ee_opmode, and start programming */
        EE_CTL = (EE_CTL & (~M_EE_OPMODE)) | (EE_PGM_MODE | M_EE_START);

        delay_cnt = 0;

        /* wait for ee_pgm_done */
        while(!(EE_CTL & M_EE_PGM_DONE))
        {
            /* delay 1 ms */
            sys_delay_ms(1);

            delay_cnt++;
            if(delay_cnt > 14) /* wait > 8 ms */
            {
                /* write data to address fail */
                ret_val = 3;

                /* exit bulk process */
                goto eeprom_write_exit;
            }
        }

        if(EE_STA & (M_TRR_ERASE_READY_ERR | M_TRR_PGM_READY_ERR | M_TRR_READ_READY_ERR | M_TRR_IP_EN_READY_ERR))
        {
            ret_val = 4;
            goto eeprom_write_exit;
        }

        /* program eeprom sucessfully and clear ee_pgm_done */
        EE_CTL &= ~(M_EE_START | M_EE_PGM_DONE);
    }

eeprom_write_exit:
    EE_CTL &= ~(M_EE_START | M_EE_PGM_DONE | M_EE_ERASE_DONE);

    EE_CTL |= M_PD_EE;

    /* set sfr_page_sel = 0 */
    SFR_PAGE &= ~M_SFR_PAGE_SEL;

    return ret_val;
}

/*****************************************************************************************************************
 * @name: eeprom_read_words
 * @desc: read eeprom data to buffer data(in xdata)
 * @param:
 *  start_addr  : read eeprom start addr, must be smaller than 0x20, or else will occur unexpected error
 *  rd_buf      : (pointer to BYTE in xdata) pointer to data buffer which will be read from eeprom(MSB first)
 *  eeprom_size : read eeprom size(word), (start_addr + eeprom_size) must be not larger than 0x20, or else will
 *                  occur unexpected error
 * @return:
 *          0: read eeprom successfully
 *          1: read eeprom failed
 * ******************************************************************************************************************/
uint8_t eeprom_read_words(uint8_t start_addr, uint8_t xdata *rd_buf, uint8_t eeprom_size)
{
    uint8_t idx;
    uint8_t ret_val;
    uint8_t delay_cnt;
    uint8_t *ptr_buf;

    /* default return code = 0 */
    ret_val = 0;
    ptr_buf = rd_buf;

    /* set sfr_page_sel = 1 */
    SFR_PAGE |= M_SFR_PAGE_SEL;

    /* set pd_ee = 0 */
    EE_CTL &= ~M_PD_EE;

    /* wait 2 us */
    sys_delay_us(1);

    /* bulk process */
    for (idx = 0; idx < eeprom_size; idx++)
    {
        /* set EE_ADDR */
        EE_ADDR = start_addr++;

        /* write read mode to ee_mode, and start reading */
        EE_CTL = (EE_CTL & (~M_EE_OPMODE)) | (EE_READ_MODE | M_EE_START);

        delay_cnt = 0;

        /* wait for ee_read_done or ee_timing_err */
        while (!(EE_CTL & M_EE_READ_DONE ))
        {
            /* delay 2 us */
            sys_delay_us(1);

            delay_cnt++;
            if(delay_cnt > 250) /* wait > 500 us */
            {
                /* read eeprom data fail */
                ret_val = 1;
                
                /* exit bulk process */
                goto eeprom_read_exit;
            }
        }

        /* ee_timing err , exit bulk process */
        if(EE_STA & (M_TRR_ERASE_READY_ERR | M_TRR_PGM_READY_ERR | M_TRR_READ_READY_ERR | M_TRR_IP_EN_READY_ERR))
        {
            ret_val = 2;
            goto eeprom_read_exit;
        }
       
        /* read eeprom data sucessfully and clear ee_read_done */
        EE_CTL &= ~(M_EE_START | M_EE_READ_DONE);

        /* read data from EE_RDATA_H, EE_RDATA_L */
        *ptr_buf++ = EE_RDATA_H;
        *ptr_buf++ = EE_RDATA_L;

    }

eeprom_read_exit:
    EE_CTL &= ~(M_EE_START | M_EE_READ_DONE | M_EE_TIMING_ERR);

    EE_CTL |= M_PD_EE;

    /* set sfr_page_sel = 0 */
    SFR_PAGE &= ~M_SFR_PAGE_SEL;

    return ret_val;
}

/*****************************************************************************************************************
 * @name: uart_init
 * @desc: uart interface initial
 * @param:  none
 * @return: none
 * ******************************************************************************************************************/
void uart_init(void)
{

    /* enable dec intio serial0 timer1 clk */
    CLK_GATE_1 |= M_DEC_CLK_EN | M_INTIO_CLK_EN;
    CLK_GATE_2 |= M_SERIAL0_CLK_EN | M_TIMER1_CLK_EN;

    /* ++++++++++ config gpio +++++++++++++++++++++++++++++

        d3 : rx
        d2 : tx
    * +++++++++++++++++++++++++++++++++++++++++++++++++++++*/
    /* set d3 as pullup input */
    sys_set_reg_bit(AON_REG_15, 0x00, M_D3_PD_PULLUP);
    sys_set_reg_bit(AON_REG_13, M_D3_IDRV_EN, M_D3_IDRV_EN);
    /* set d2 as push-pull output */
    sys_set_reg_bit(AON_REG_19, 0, M_D2_OPEN_DRAIN);
    sys_set_reg_bit(AON_REG_11, M_D2_ODRV_EN, M_D2_ODRV_EN);

    /* gpio2(d2)_out_sel = 10, d2 as tx out */
    GPIO_OUTB_SEL = (GPIO_OUTB_SEL & M_GPIO2_OUT_SEL) | (10 << BIT0);

    /* rxd0_gpio_sel = 3, rx input from d3 */
    GPIO_INE_SEL = (GPIO_INE_SEL & M_RXD0_GPIO_SEL) | (GPIO_IN_SEL_D3 << BIT0);

    /* +++++++++++++++++++++++++++++ usart config +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     * when usart_sel = 1, and set timer1 mode1, then baud_rate = 2^smod1 * fclk_periph / (32 *(65536 - (TH1*0x100 + TL1)))
     * when usart_sel = 0, and set timer1 mode2, then baud_rate = 2^smod1 * fclk_periph / (32 * 12 *(256 - TH1))
     * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

    /* -------------- serial mode 1(8-bit uart, timer1-driven) ----------------------- */
    PCON |= M_SMOD1; /* double baud rate bit */
    SCON0 &= ~(M_SM00 | M_SM10);
    SCON0 |= M_SM10;
    SCON0 |= M_REN0; /* enable rxd */

    /* usart_sel = 1, timer1 auto-reload TH1 TL1 */
    CDR_DR_2 |= M_USART_SEL;

    /* set timer1 to mode 1 (one 16-bit timer/counter) */
    TMOD = 0x10;

    /* baud_rate = 2^smod1 * fclk_periph / (32 *(65536 - (TH1*0x100 + TL1))) */
    /*
    default fclk_periph = 24mhz
    baud_rate          TH1          TL1
    2.4k               0xfd        0x8f
    4.8k               0xfe        0xc7
    9.6k               0xff        0x64
    14.4k              0xff        0x98
    19.2k              0xff        0xb2
    38.4k              0xff        0xd9
    56k                0xff        0xe5
    57.6k              0xff        0xe6
    115.2k             0xff        0xf3
    128k               0xff        0xf4
    256k               0xff        0xfa
    */
    TH1 = 0xff; // baud_rate = 115.2k;
    TL1 = 0xf3;

    /* start timer1 */
    TCON |= M_TR1;

    /* diable uart interrupt */
    // ES0 = 1;
}

void uart_send_byte(uint8_t tx_dat)
{
  	/* start tx */
    SBUF0 = tx_dat;
    while (!(SCON0 & M_TI0))
    	;
    TI0 = 0;
}

void uart_send_string(uint8_t code *tx_str)
{
	uint8_t i = 0;

	while(tx_str[i]!='\0')
		{
    	SBUF0 = tx_str[i];
		i++;
    	while (!(SCON0 & M_TI0))
    		;
    	TI0 = 0;
		}
}



uint8_t xdata g_wr_buf[64];
uint8_t xdata g_rd_buf[64];

uint8_t rd_val;
uint8_t wr_val;




void main(void)
{
    uint8_t idx;
    uint8_t eeprom_fail_flag;

    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;
    EA = 0;

    eeprom_fail_flag = 0;

    /* disable all clock */
    sys_disable_all_clk();

	/* uart initial */
	uart_init();

    /* enable eeprom clock */
    CLK_GATE_1 |= M_EE_CLK_EN;

	sys_delay_ms(100);

	uart_send_string("test for eerprom...\r\n");

    for (idx = 0; idx < 64; idx++)
    {
        g_wr_buf[idx] = idx + 1;
    }

    wr_val = eeprom_write_words(0x00, g_wr_buf, 0x20);
    rd_val = eeprom_read_words(0x00, g_rd_buf, 0x20);

    /* check eeprom read data */
    for (idx = 0; idx < 64; idx++)
    {
        if(g_wr_buf[idx] != g_rd_buf[idx])
        {
            eeprom_fail_flag = 1;
            break;
        }
    }
	
	if(eeprom_fail_flag==0)
		uart_send_string("pass!!!\r\n");
	else
		uart_send_string("faild!!!\r\n");

    sys_shutdown();

}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
