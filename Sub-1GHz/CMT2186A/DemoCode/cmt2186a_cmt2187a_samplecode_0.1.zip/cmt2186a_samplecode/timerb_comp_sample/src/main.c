// #include "intrins.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"

void set_tbcci3(uint8_t val)
{
    TBC_H &= ~M_TB_CCI3_IN_SFR;
    TBC_H |= M_TB_CCI3_IN_SFR & (val << BIT1);
}

void set_tbcci2(uint8_t val)
{
    TBC_H &= ~M_TB_CCI2_IN_SFR;
    TBC_H |= M_TB_CCI2_IN_SFR & (val << BIT0);
}

/*set timer g_count mode. 0: stop mode; 1:up mode; 2:continuous mode; 3:up and down mode*/
// set_tb_cnt_mode
void set_tb_cnt_mode(uint8_t val)
{
    TBC_L &= ~M_TB_CNT_MODE;
    TBC_L |= M_TB_CNT_MODE & (val << BIT3);
}

/*set 16bit tbccrx*/
// set_tbccr0
void set_tbccr0(uint16_t val)
{
    TBCCR0TH_L = val;
    TBCCR0TH_H = val >> 8;
}

// set_tbccr1
void set_tbccr1(uint16_t val)
{
    TBCCR1TH_L = val;
    TBCCR1TH_H = val >> 8;
}

// set_tbccr2
void set_tbccr2(uint16_t val)
{
    TBCCR2TH_L = val;
    TBCCR2TH_H = val >> 8;
}

/*0:compare; 1:capture*/

void set_ccr0_cap(uint8_t val)
{
    TBCCTL0_H &= ~M_TB_CCR0_FUNC_MODE;
    TBCCTL0_H |= M_TB_CCR0_FUNC_MODE & val;
}

void set_ccr1_cap(uint8_t val)
{
    TBCCTL1_H &= ~M_TB_CCR1_FUNC_MODE;
    TBCCTL1_H |= M_TB_CCR1_FUNC_MODE & val;
}

void set_ccr2_cap(uint8_t val)
{
    TBCCTL2H &= ~M_TB_CCR2_FUNC_MODE;
    TBCCTL2H |= M_TB_CCR2_FUNC_MODE & val;
}

uint16_t get_tbccr0(void)
{
    uint16_t ret_val;

    ret_val = TBCCR0TH_H * 256 + TBCCR0TH_L;

    return ret_val;
}

uint16_t get_tbccr1(void)
{
    uint16_t ret_val;

    ret_val = TBCCR1TH_H * 256 + TBCCR1TH_L;

    return ret_val;
}

uint16_t get_tbccr2(void)
{
    uint16_t ret_val;

    ret_val = TBCCR2TH_H * 256 + TBCCR2TH_L;

    return ret_val;
}

/*0: disable tmr_ifg;  1:enable tmr_ifg*/
// set_tmr_ie
void set_tmr_ie(uint8_t val)
{
    TBC_L &= ~M_TB_TMR_IE;
    TBC_L |= M_TB_TMR_IE & (val << BIT1);
}

/*0: disable ccrx_ifg; 1:enable ccrx_ifg*/
// set_ccr0_ie
void set_ccr0_ie(uint8_t val)
{
    TBCCTL0_L &= ~M_TB_CCR0_IE;
    TBCCTL0_L |= M_TB_CCR0_IE & (val << BIT3);
}

// set_ccr1_ie
void set_ccr1_ie(uint8_t val)
{
    TBCCTL1_L &= ~M_TB_CCR1_IE;
    TBCCTL1_L |= M_TB_CCR1_IE & (val << BIT3);
}

// set_ccr2_ie
void set_ccr2_ie(uint8_t val)
{
    TBCCTL2L &= ~M_TB_CCR2_IE;
    TBCCTL2L |= M_TB_CCR2_IE & (val << BIT3);
}

/*set ccr1_out default value*/
// set_ccr0_out
void set_ccr0_out(uint8_t val)
{
    TBCCTL0_L &= ~M_TB_CCR0_OUT_SFR;
    TBCCTL0_L |= M_TB_CCR0_OUT_SFR & (val << BIT2);
}

// set_ccr1_out
void set_ccr1_out(uint8_t val)
{
    TBCCTL1_L &= ~M_TB_CCR1_OUT_SFR;
    TBCCTL1_L |= M_TB_CCR1_OUT_SFR & (val << BIT2);
}

// set_ccr2_out
void set_ccr2_out(uint8_t val)
{
    TBCCTL2L &= ~M_TB_CCR2_OUT_SFR;
    TBCCTL2L |= M_TB_CCR2_OUT_SFR & (val << BIT2);
}

/*set ccrx_outmode. 0~7*/
// set_ccr0_outmode
void set_ccr0_out_mode(uint8_t val)
{
    TBCCTL0_L &= ~M_TB_CCR0_OUT_MODE;
    TBCCTL0_L |= M_TB_CCR0_OUT_MODE & (val << BIT4);
}

// set_ccr1_outmode
void set_ccr1_out_mode(uint8_t val)
{
    TBCCTL1_L &= ~M_TB_CCR1_OUT_MODE;
    TBCCTL1_L |= M_TB_CCR1_OUT_MODE & (val << BIT4);
}

// set_ccr2_outmode
void set_ccr2_out_mode(uint8_t val)
{
    TBCCTL2L &= ~M_TB_CCR2_OUT_MODE;
    TBCCTL2L |= M_TB_CCR2_OUT_MODE & (val << BIT4);
}

/*0~3:select tbcci0~tbcci3 as capture input*/
void set_ccr0_ccis(uint8_t val)
{
    TBCCTL0_H &= ~M_TB_CCR0_SRC_SEL;
    TBCCTL0_H |= M_TB_CCR0_SRC_SEL & (val << BIT1);
}

void set_ccr1_ccis(uint8_t val)
{
    TBCCTL1_H &= ~M_TB_CCR1_SRC_SEL;
    TBCCTL1_H |= M_TB_CCR1_SRC_SEL & (val << BIT1);
}

void set_ccr2_ccis(uint8_t val)
{
    TBCCTL2H &= ~M_TB_CCR2_SRC_SEL;
    TBCCTL2H |= M_TB_CCR2_SRC_SEL & (val << BIT1);
}

/*0:no capture; 1:capture posedge; 2:capture negedge; 3:capture both edge*/
void set_ccr0_cm(uint8_t val)
{
    TBCCTL0_H &= ~M_TB_CCR0_CAP_MODE;
    TBCCTL0_H |= M_TB_CCR0_CAP_MODE & (val << BIT3);
}

void set_ccr1_cm(uint8_t val)
{
    TBCCTL1_H &= ~M_TB_CCR1_CAP_MODE;
    TBCCTL1_H |= M_TB_CCR1_CAP_MODE & (val << BIT3);
}

void set_ccr2_cm(uint8_t val)
{
    TBCCTL2H &= ~M_TB_CCR2_CAP_MODE;
    TBCCTL2H |= M_TB_CCR2_CAP_MODE & (val << BIT3);
}

/*0:no sync capture output; 1:sync capture output*/
void set_ccr0_scs(uint8_t val)
{
    TBCCTL0_L &= ~M_TB_CCR0_OUT_MODE;
    TBCCTL0_L |= M_TB_CCR0_OUT_MODE & (val << BIT7);
}

void set_ccr1_scs(uint8_t val)
{
    TBCCTL1_L &= ~M_TB_CCR1_OUT_MODE;
    TBCCTL1_L |= M_TB_CCR1_OUT_MODE & (val << BIT7);
}

void set_ccr2_scs(uint8_t val)
{
    TBCCTL2L &= ~M_TB_CCR2_OUT_MODE;
    TBCCTL2L |= M_TB_CCR2_OUT_MODE & (val << BIT7);
}

void set_tb_clr(uint8_t val)
{
    TBC_L &= ~M_TB_CLR;
    TBC_L |= M_TB_CLR & (val << BIT2);
}

void set_tmr_ifg(uint8_t val)
{
    TBC_L &= ~M_TB_TMR_INT;
    TBC_L |= M_TB_TMR_INT & val;
}

void set_ccr0_cov(uint8_t val)
{
    TBCCTL0_L &= ~M_TB_CCR0_COV;
    TBCCTL0_L |= M_TB_CCR0_COV & (val << BIT1);
}

void set_ccr1_cov(uint8_t val)
{
    TBCCTL1_L &= ~M_TB_CCR1_COV;
    TBCCTL1_L |= M_TB_CCR1_COV & (val << BIT1);
}

void set_ccr2_cov(uint8_t val)
{
    TBCCTL2L &= ~M_TB_CCR2_COV;
    TBCCTL2L |= M_TB_CCR2_COV & (val << BIT1);
}

void set_ccr0_ifg(uint8_t val)
{
    TBCCTL0_L &= ~M_TB_CCR0_INT;
    TBCCTL0_L |= M_TB_CCR0_INT & val;
}

void set_ccr1_ifg(uint8_t val)
{
    TBCCTL1_L &= ~M_TB_CCR1_INT;
    TBCCTL1_L |= M_TB_CCR1_INT & val;
}

void set_ccr2_ifg(uint8_t val)
{
    TBCCTL2L &= ~M_TB_CCR2_INT;
    TBCCTL2L |= M_TB_CCR2_INT & val;
}

void set_TBC_Lk_div(uint16_t val)
{
    TBC_LK_DIV_L = val;
    TBC_LK_DIV_H = val >> 8;
}

void set_tb_start(uint8_t val)
{
    TBC_H &= ~(M_TB_START | M_TB_DIS);
    TBC_H |= (val << BIT2) & M_TB_START;
    TBC_H |= (!val << BIT3) & M_TB_DIS;
}

void sys_timer_b_interrupt_service_routine(void)
{
    /* clear tmr_ifg flag */
    set_tmr_ifg(0);
}

void sys_timer_b_ccr0_interrupt_service_routine(void)
{
    /* clear ccr0_ifg flag */
    set_ccr0_ifg(0);
}

void sys_timer_b_ccr1_interrupt_service_routine(void)
{
    /* clear ccr1_ifg flag */
    set_ccr1_ifg(0);
}

void sys_timer_b_ccr2_interrupt_service_routine(void)
{
    /* clear ccr2_ifg flag */
    set_ccr2_ifg(0);
}

void main(void)
{
    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;

    // disable all clk
    sys_disable_all_clk();

    TBC_H &= ~M_TB_DIS;

    CLK_GATE_1 |= M_TIMERB_CLK_EN | M_INTIO_CLK_EN;

    sys_set_reg_bit(AON_REG_11, (M_D2_ODRV_EN | M_D3_ODRV_EN | M_D4_ODRV_EN), (M_D2_ODRV_EN | M_D3_ODRV_EN | M_D4_ODRV_EN));

    /* config gpio
     tb_out0 -> a2, tb_out1 -> a3, tb_out2 -> a4,
    */
    GPIO_OUTB_SEL = 0x32;
    GPIO_OUTC_SEL = 0x04;

    /* ccr0_ifg -> ext 2 */
    /* ccr1_ifg -> ext 3 */
    /* ccr2_ifg -> ext 6 */
    /* tmr_ifg  -> ext 7 */
    INTCTL_1 = 0x98;
    INTCTL_3 = 0x7a;

    IEN1 = M_EX2 | M_EX3 | M_EX6 | M_EX7;

    EA = 1;
    set_tmr_ie(1);
    set_ccr0_ie(1);
    set_ccr1_ie(1);
    set_ccr2_ie(1);

    /* enable compare */
    set_ccr0_cap(0);
    set_ccr1_cap(0);
    set_ccr2_cap(0);

    set_ccr0_ccis(0); /* cci0 */
    set_ccr1_ccis(1); /* cci1 */
    set_ccr2_ccis(2); /* cci2 */

    set_tbccr0(0xC00);
    set_tbccr1(0x800);
    set_tbccr2(0x400);

    /* set timer g_count mode. 0: stop mode; 1:up mode; 2:continuous mode; 3:up and down mode */
    set_tb_cnt_mode(1);

    /* div 1.064 ms*/
    set_TBC_Lk_div(1);

    /* 0: output, 1: set, 2: toggle/reset, 3: set/reset,
    4: toggle, 5: reset, 6: toggle/set, 7: reset/set */
    set_ccr0_out_mode(4);
    set_ccr1_out_mode(4);
    set_ccr2_out_mode(4);

    set_tb_start(1);

    sys_delay_ms(2000);
    sys_delay_ms(2000);

    set_tb_start(0);
    set_tb_clr(1);

    sys_delay_ms(2);

    sys_shutdown();
}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();

    sys_timer_b_ccr0_interrupt_service_routine();

    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();

    sys_timer_b_ccr1_interrupt_service_routine();

    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();

    sys_timer_b_ccr2_interrupt_service_routine();

    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();

    sys_timer_b_interrupt_service_routine();

    sys_pop_context_from_stack();
}
