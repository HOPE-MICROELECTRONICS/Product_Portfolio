// #include "intrins.h"
#include "stdio.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"

/**********************************************************************************************************
 *@name:    tx_modu_config
 *@desc:    implement setup tx modu config
 *@param:
 *    ptr_modu_cfg: pointer modulation cofig
 *@return: none
 ***********************************************************************************************************/
void tx_modu_config(tx_modu_setup_entry_t xdata *ptr_modu_cfg)
{
    uint8_t cfg_val;

    /* ana_ctl_1:
        bit[7:5]: reserved
        bit[4]  : dsm_dither_sel
        bit[3]  : dsm_dither_dis
        bit[2:0]: afc_refn_code
    */
    cfg_val = ANA_CTL_1 & (~(M_DSM_DITHER_SEL | M_DSM_DITHER_DIS | M_AFC_REFN_CODE));
    ANA_CTL_1 = ptr_modu_cfg->ana_ctl_1 | cfg_val;

    /* ana_ctl_2:
        bit[7]  : vco_hband -- pll hband
        bit[6]  : pdcplf_cpbias_code -- charge pump bias current control
        bit[5]  : reserved
        bit[4:2]: vco_gain_code -- vco gain code
        bit[1:0]: pll_bw_sel -- pll bandwidth control: 0-300khz, 1-210khz
    */
    cfg_val = ANA_CTL_2 & (~(M_VCO_HBAND | M_PDCPLF_CPBIAS_CODE | M_VCO_GAIN_CODE | M_PLL_BW_SEL));
    ANA_CTL_2 = ptr_modu_cfg->ana_ctl_2 | cfg_val;

    /* ana_ctl_3
        bit[7:6]: reserved
        bit[5:4]: divx_code -- pll divider1(/1/2/3)
        bit[3]  : pa_rcramp_selb -- pa ramp rc filter select (1: rc filter is not selected, 0: rc filter is selected)
        bit[2:0]: pa_ramp_rsel -- select rc filter conrner of pa ramp control (0:640khz, 1:320khz, 2:160khz, 3:80khz,
                                                                               4:40khz, 5:20khz, 6:10khz, 7:5khz)
    */
    cfg_val = ANA_CTL_3 & (~(M_DIVX_CODE | M_PA_RCRAMP_SELB | M_PA_RAMP_RSEL));
    ANA_CTL_3 = ptr_modu_cfg->ana_ctl_3 | cfg_val;

    /* pll n value config */
    PLLN = ptr_modu_cfg->plln;

    /* pll k value[23:16] */
    PLLK_H = ptr_modu_cfg->pllk_h;

    /* pll k value[15:8] */
    PLLK_M = ptr_modu_cfg->pllk_m;

    /* pll k value[7:0] */
    PLLK_L = ptr_modu_cfg->pllk_l;

    /* tx_brx16_word[23:16] */
    TX_DR_0 = ptr_modu_cfg->tx_dr_0;

    /* tx_brx16_word[15:8] */
    TX_DR_1 = ptr_modu_cfg->tx_dr_1;

    /* tx_brx16_word[7:0] */
    TX_DR_2 = ptr_modu_cfg->tx_dr_2;

    /* tx_pkt_ctl
        bit[7:4]: reserved
        bit[3]  : ramp_en -- 0: ramp off, 1: ramp on
        bit[2]  : tx_modu -- 0: ook, 1: fsk
        bit[1]  : freq_dev_inv -- freq deviation control (0:(+f:1,-f:0), 1:(+f:0,-f:1)
        bit[0]  : guass_on -- 0:guass off, 1:guass on
    */
    cfg_val = TX_PKT_CTL & (~(M_RAMP_EN | M_TX_MODU | M_FREQ_DEV_INV | M_GUASS_ON));
    TX_PKT_CTL = ptr_modu_cfg->tx_pkt_ctl | cfg_val;

    /* freq_dev[23:16] */
    FREQ_DEV_H = ptr_modu_cfg->freq_dev_h;

    /* freq_dev[15:8] */
    FREQ_DEV_M = ptr_modu_cfg->freq_dev_m;

    /* freq_dev[7:0] */
    FREQ_DEV_L = ptr_modu_cfg->freq_dev_l;

    /* ramp_step_h
        bit[7]  : reserved
        bit[6:0]: ram_step_time[14:8]
    */
    cfg_val = RAMP_STEP_H & (~M_RAM_STEP_TIME_14_8);
    RAMP_STEP_H = ptr_modu_cfg->ramp_step_h | cfg_val;

    /* ram_step_time[7:0] */
    RAMP_STEP_L = ptr_modu_cfg->ramp_step_l;

    /* pa_idac_code
        bit[7:6]: reserved
        bit[5:0]: pa_idac_code -- pa current control bits for power control
    */
    cfg_val = PA_IDAC_CODE & (~M_PA_IDAC_CODE_CFG);
    PA_IDAC_CODE = ptr_modu_cfg->pa_idac_code | cfg_val;

    /* lbd_ctl_0
        bit[7:4]: reserved
        bit[3:0]: lbd_th[3:0](V) -- 0: 1.45, 1: 1.64, 2: 1.85, 3: 2.03, 4: 2.26, 5: 2.45, 6: 2.67, 7: 2.86,
                                    8: 3.08, 9: 3.24, 10: 3.43, 11: 3.64, 12: 3.87, 13: 4.00, 14: 4.29, 15: 4.44 (V)
    */
    cfg_val = LBD_CTL_0 & (~M_LBD_TH);
    LBD_CTL_0 = ptr_modu_cfg->lbd_ctl_0 | cfg_val;

    /* select sfr page 1 */
    SFR_PAGE |= M_SFR_PAGE_SEL;

    /* pa_power_th_9[6:0] */
    PA_POWER_TH_9 = ptr_modu_cfg->pa_power_th_9;

    /* pa_power_th_8[6:0] */
    PA_POWER_TH_8 = ptr_modu_cfg->pa_power_th_8;

    /* pa_power_th_7[6:0] */
    PA_POWER_TH_7 = ptr_modu_cfg->pa_power_th_7;

    /* pa_power_th_6[6:0] */
    PA_POWER_TH_6 = ptr_modu_cfg->pa_power_th_6;

    /* pa_power_th_5[6:0] */
    PA_POWER_TH_5 = ptr_modu_cfg->pa_power_th_5;

    /* pa_power_th_4[6:0] */
    PA_POWER_TH_4 = ptr_modu_cfg->pa_power_th_4;

    /* pa_power_th_3[6:0] */
    PA_POWER_TH_3 = ptr_modu_cfg->pa_power_th_3;

    /* pa_power_th_2[6:0] */
    PA_POWER_TH_2 = ptr_modu_cfg->pa_power_th_2;

    /* pa_power_th_1[6:0] */
    PA_POWER_TH_1 = ptr_modu_cfg->pa_power_th_1;

    /* pa_power_th_0[6:0] */
    PA_POWER_TH_0 = ptr_modu_cfg->pa_power_th_0;

    /* select sfr page 0 */
    SFR_PAGE &= ~M_SFR_PAGE_SEL;
}

/**********************************************************************************************************
 *@name:    tx_sym_setup_config
 *@desc:    implement setup tx sym config
 *@param:
 *    tx_sym_setup:
 *        bit[7]  :    reserved
 *        bit[6]  :    tx_direct_en  0:disable tx direct mode, 1: enable tx direct mode(the tx data come from
 *                     tx_direct_data, and don't care tx_group_with, endian, tx_sym_ctrl)
 *        bit[5:3]:    tx group with -- tx bits of tx_sym_byte; 0~7: 1~8 bits
 *        bit[2]  :    endian(0-small endian, 1-big endian)
 *        bit[1:0]:    tx_sym_ctrl
 *               00:    shundown transmission after last bit
 *               01:    reuse tha last symbol group for transmission
 *               10:    all 0s data
 *               11:    all 1s data
 *@return: none
 ***********************************************************************************************************/
void tx_sym_setup_config(uint8_t tx_sym_setup)
{
    /* write tx_sym_setup[6:0] to TX_SYM_CTRL */
    TX_SYM_CTL = tx_sym_setup;
}

/**********************************************************************************************************
 *@name:    tx_sym_open_front
 *@desc:    open rf front
 *@param:   none
 *@return: none
 ***********************************************************************************************************/
void tx_sym_open_front(void)
{
    /* pd_pd_cplf = 0 */
    ANA_CTL_0 &= ~M_PD_PDCPLF;

    /* delay 12 us */
    sys_delay_us(12);

    /* set fbdiv_set = 1 */
    ANA_CTL_2 |= M_FBDIV_SET;

    /* start afc */
    ANA_CTL_1 |= M_AFC_START;

    /* wait afc_done */
    while (!(ANA_CTL_1 & M_AFC_DONE))
        ;

    /* clear afc_done, afc_start  */
    ANA_CTL_1 &= ~(M_AFC_DONE | M_AFC_START);

    /* set fbdiv_set = 0 */
    ANA_CTL_2 &= ~M_FBDIV_SET;

    /* set fw_dsm_rstn = 1, start doing dsm */
    ANA_CTL_1 |= M_FW_DSM_RSTN;

    /* set pd_lbd_preload = 0, prepare lbd */
    ANA_CTL_0 &= ~M_PD_LBD_PRELOAD;

    /* start lbd */
    LBD_CTL_1 |= M_LBD_START;

    /* wait lbd done */
    while (!(LBD_CTL_1 & M_LBD_DONE))
        ;

    /* clear lbd_done, lbd_start */
    LBD_CTL_1 &= ~(M_LBD_DONE | M_LBD_START);

    /* set pd_lbd_preload = 1 */
    ANA_CTL_0 |= M_PD_LBD_PRELOAD;

    /* optionally wait 50 us for dsm done */
    sys_delay_us(50);
}

/**********************************************************************************************************
 *@name:    tx_sym_close_front
 *@desc:    close rf front
 *@param:   none
 *@return: none
 ***********************************************************************************************************/
void tx_sym_close_front(void)
{
    /* clear fw_dsm_rstn */
    ANA_CTL_1 &= ~M_FW_DSM_RSTN;

    /* set fbdiv_set = 1 */
    ANA_CTL_2 |= M_FBDIV_SET;

    /*  pd_pd_cplf = 1 */
    ANA_CTL_0 |= M_PD_PDCPLF;
}

/**********************************************************************************************************
 *@name:    tx_sym_start_direct_transmit
 *@desc:    start direct transmit
 *@param:   none
 *@return: none
 ***********************************************************************************************************/
void tx_sym_start_direct_transmit(void)
{

    /* set pd_pa = 0, enable pa module */
    ANA_CTL_0 &= ~M_PD_PA;

    /* delay 12 us */
    sys_delay_us(12);

    /* start transmit (TX_START = 1) */
    TX_PKT_CTL |= M_TX_START;
}

/**********************************************************************************************************
 *@name:    tx_sym_stop_direct_transmit
 *@desc:    stop direct transmit
 *@param:   none
 *@return: none
 ***********************************************************************************************************/
void tx_sym_stop_direct_transmit(void)
{
    /* stop transmit */
    TX_PKT_CTL |= M_TX_STOP_EN;

    /* wait tx stop done */
    while (!(RAMP_STEP_H & M_TX_STOP_DONE))
        ;

    /* clear tx stop done */
    RAMP_STEP_H &= ~M_TX_STOP_DONE;

    /* set pd_pa = 0, disable pa */
    ANA_CTL_0 |= M_PD_PA;

    /* clear TX_START */
    TX_PKT_CTL &= ~(M_TX_START | M_TX_STOP_EN);
}

#define DATA_LEN 12
uint8_t xdata g_data_buf[DATA_LEN];
uint8_t g_tx_done;
uint8_t g_tx_start;
uint8_t g_tx_data;
void sys_timer1_interrupt_rountine(void)
{
    static uint8_t bit_cnt = 0;
    static uint8_t byte_cnt = 0;

    TX_SYM_BYTE = g_tx_data;
    g_tx_data >>= 0x01;
    bit_cnt++;
    if (bit_cnt >= 8)
    {
        bit_cnt = 0;
        byte_cnt++;
        if (byte_cnt >= DATA_LEN)
        {
            g_tx_done = 1;
            byte_cnt = 0;
            /* tx done, stop timer1 */
            TCON &= ~M_TR1;
        }
        else
        {
            g_tx_data = g_data_buf[byte_cnt];
        }
    }

    /* data rate = 10kbps, t = 100us = (0x10000 - x) / (24mhz / 12) => x = 0x10000 - (2mhz *100us) =  0x10000 - 200 = 0xf830 */
    TH1 = 0xf8;
    TL1 = 0x30;

    /* clear tf1 */
    TCON &= ~M_TF1;
}

void main(void)
{
    uint8_t idx;

    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;
    EA = 0;

    /* disable all clock */
    sys_disable_all_clk();

    /* enable timer1 clock */
    CLK_GATE_2 |= M_TIMER1_CLK_EN;

    /* timer1 mode 1 */
    TMOD = (TMOD & (~M_M1)) | (T1_MODE_1 << BIT4);
    /* data rate = 10kbps, t = 100us = (0x10000 - x) / (24mhz / 12) => x = 0x10000 - (2mhz *100us) =  0x10000 - 2000 = 0xf830 */
    TH1 = 0xf8;
    TL1 = 0x30;

    /* enable timer1 interrupt and EA */
    ET1 = 1;
    EA = 1;

    for (idx = 0; idx < DATA_LEN; idx++)
    {
        if (idx < 4)
        {
            g_data_buf[idx] = 0x55;
        }
        else
        {
            g_data_buf[idx] = idx - 3;
        }
    }

    g_tx_start = 1;
    g_tx_done = 0;
    while (1)
    {
        if (g_tx_start)
        {
            g_tx_start = 0;

            /* xo_istart_bit4_sel = 0, xo_istart_bit3_sel = 0, xo_istart from mtp */
            sys_set_reg_bit(AON_REG_07, 0x00, 0x06);

            /* open xo crstal for tx */
            sys_set_reg_bit(AON_REG_04, 0, M_MANU_PD_XO);

            /* wait 400 us for xo crystal stable */
            sys_delay_100us(4);

            /* xo_istart_bit4_sel = 1, xo_istart_bit3_sel = 1, xo_istart from latch */
            sys_set_reg_bit(AON_REG_07, 0x06, 0x06);

            /* enable ana lbd tx clock (must wait xo crystal stable) */
            CLK_GATE_0 |= (M_ANA_CLK_EN | M_LBD_CLK_EN);
            CLK_GATE_1 |= M_TX_CLK_EN;

            /* config tx_modu and tx_sym */
            tx_config();
            tx_sym_setup_config(0x40); /* tx direct mode */

            /* open vco_ldo */
            sys_set_reg_bit(AON_REG_06, 0, M_PD_VCO_LDO);
            sys_delay_us(5);

            /* open tx rf front */
            tx_sym_open_front();

            /* check afc lock and lower voltage or not */
            if ((!(PA_IDAC_CODE & M_LD_OUT)) || (!(LBD_CTL_1 & M_LBD_STATUS)))
            {
                /* if afc no lock or lower voltage, can stop transmiting  here*/
            }

            /* start direct transmit */
            tx_sym_start_direct_transmit();
            g_tx_data = g_data_buf[0];

            /* start t1, update data */
            TCON |= M_TR1;
        }

        if (g_tx_done)
        {
            g_tx_done = 0;

            /* stop direct transmit */
            tx_sym_stop_direct_transmit();

            /* close tx rf front */
            tx_sym_close_front();

            /* close vco_ldo */
            sys_set_reg_bit(AON_REG_06, M_PD_VCO_LDO, M_PD_VCO_LDO);

            /* disable ana lbd tx clock  */
            CLK_GATE_0 &= ~(M_ANA_CLK_EN | M_LBD_CLK_EN);
            CLK_GATE_1 &= ~M_TX_CLK_EN;

            /* close xo crystal when no need */
            sys_set_reg_bit(AON_REG_04, M_MANU_PD_XO, M_MANU_PD_XO);

            //sys_shutdown();
        }

    }
}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_timer1_interrupt_rountine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
