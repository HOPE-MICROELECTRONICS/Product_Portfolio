/*************************************************************
 *** @Author       : lining
 *** @Date         : 2023-06-29 10:29:03
 *** @LastEditTime : 2023-06-30 10:30:49
 *** @LastEditors  : lining
 *** @Description  :
 *** @FilePath     : \cmt218x_soft\timer0_mode0_test\main.c
 **************************************************************/
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"
#include "cmt218x.h"
#include "intrins.h"
#include "stdlib.h"
#include "system.h"

uint8_t cnt;
uint8_t g_test_result = 0;

void main(void)
{
    // disable all int
    IEN0 = 0x00;
    IEN1 = 0x00;

    // disable all clk
    sys_disable_all_clk();

    CLK_GATE_1 |= M_INTIO_CLK_EN;
    CLK_GATE_2 |= M_TIMER0_CLK_EN;

    /* enable timer1 interrupt */
    IEN0 |= M_ET0;
    EA = 1;

    /* config gpio3(d3) push-pull output */
    sys_set_reg_bit(AON_REG_11, M_D3_ODRV_EN , M_D3_ODRV_EN );
    sys_set_reg_bit(AON_REG_19, M_D3_OPEN_DRAIN, M_D3_OPEN_DRAIN);

    /* set d8 as led output pin */
    sys_set_reg_bit(AON_REG_16, 0, M_D8_PD_PULLUP);
    sys_set_reg_bit(AON_REG_12, M_D8_ODRV_EN, M_D8_ODRV_EN);
    sys_set_reg_bit(AON_REG_1A, 0, M_D8_OPEN_DRAIN);

    /* timer0 mode 1: 16-bit timer/counter */
    TMOD = 0x01;

    /* timer_ov_t = 12*(0x10000 -T_value)/sys_clk(default 24mhz), so timer_ov_t = 25ms, T_value =0x3cb0 */
    TL0 = 0xb0;
    TH0 = 0x3c;

    cnt = 0;
	  GPIO_OUT_0 = 0x02;
    /* enable timer0 */
    TCON |= M_TR0;

    // delay 2000ms
    sys_delay_ms(2000);

    /* disable timer0 */
    TCON &= ~M_TR0;

    sys_shutdown();
}

void sys_timer0_int_service_routine(void)
{
    TCON &= ~M_TF0;
    TL0 = 0xB0;
    TH0 = 0x3C;

    GPIO_OUT_0 ^= 0x08;
	GPIO_OUT_1 ^= 0x01;
}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0    // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

void system_timer0_interrupt(void) interrupt 1 using 0
{
    sys_push_context_to_stack();
    sys_timer0_int_service_routine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0  // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();

}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0  // 1B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0   // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0    // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();

}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0  // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0  // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0  // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0  // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

