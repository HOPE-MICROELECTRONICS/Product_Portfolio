/*************************************************************
 *** @Author       : lining
 *** @Date         : 2023-06-28 14:04:42
 *** @LastEditTime : 2023-07-05 11:08:03
 *** @LastEditors  : lining
 *** @Description  :
 *** @FilePath     : cmt218x_types.h
 **************************************************************/
#ifndef _CMT218X_TYPES_H_
#define _CMT218X_TYPES_H_

typedef unsigned char               BYTE;    // "b"
typedef unsigned int                WORD;    // "w"
typedef unsigned long int           LWORD;   // "l"
typedef signed char                 CHAR;    // "c"

typedef unsigned char               uint8_t;  // "b"
typedef unsigned int                uint16_t; // "w"
typedef unsigned long int           uint32_t; // "l"

typedef unsigned char               u8;  // "b"
typedef unsigned int                u16; // "w"
typedef unsigned long int           u32; // "l"

typedef signed char                 int8_t;   // "c"
typedef signed int                  int16_t;  // "i"
typedef signed long int             int32_t;  // "j"

#endif