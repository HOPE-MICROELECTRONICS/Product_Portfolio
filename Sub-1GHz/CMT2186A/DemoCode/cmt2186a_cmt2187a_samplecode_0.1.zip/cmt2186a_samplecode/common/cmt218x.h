#ifndef _CMT218X_H_
#define _CMT218X_H_

#include "cmt218x_types.h"

/*
*  structure for tx modulate setup
*/
typedef struct tx_modu_setup_entry{
    /* ana_ctl_1:
        bit[7:5]: reserved
        bit[4]  : dsm_dither_sel 
        bit[3]  : dsm_dither_dis
        bit[2:0]: afc_refn_code
    */
    uint8_t ana_ctl_1;
    
    /* ana_ctl_2:
        bit[7]  : vco_hband -- pll hband 
        bit[6]  : pdcplf_cpbias_code -- charge pump bias current control 
        bit[5]  : reserved
        bit[4:2]: vco_gain_code -- vco gain code 
        bit[1:0]: pll_bw_sel -- pll bandwidth control: 0-300khz, 1-210khz
    */
    uint8_t ana_ctl_2;
    
    /* ana_ctl_3
        bit[7:6]: reserved
        bit[5:4]: divx_code -- pll divider1(/1/2/3)
        bit[3]  : pa_rcramp_selb -- pa ramp rc filter select (1: rc filter is not selected, 0: rc filter is selected) 
        bit[2:0]: pa_ramp_rsel -- select rc filter conrner of pa ramp control (0:640khz, 1:320khz, 2:160khz, 3:80khz,
                                                                               4:40khz, 5:20khz, 6:10khz, 7:5khz)
    */
    uint8_t ana_ctl_3;
    
    /* pll n value config */
    uint8_t plln;
    
    /* pll k value[23:16] */
    uint8_t pllk_h;
    
    /* pll k value[15:8] */
    uint8_t pllk_m;
    
    /* pll k value[7:0] */
    uint8_t pllk_l;
     
    /* tx_brx16_word[23:16] */
    uint8_t tx_dr_0;
    
    /* tx_brx16_word[15:8] */
    uint8_t tx_dr_1;
    
    /* tx_brx16_word[7:0] */
    uint8_t tx_dr_2;
    
    /* tx_pkt_ctl 
        bit[7:4]: reserved
        bit[3]  : ramp_en -- 0: ramp off, 1: ramp on
        bit[2]  : tx_modu -- 0: ook, 1: fsk       
        bit[1]  : freq_dev_inv -- freq deviation control (0:(+f:1,-f:0), 1:(+f:0,-f:1)
        bit[0]  : guass_on -- 0:guass off, 1:guass on
    */
    uint8_t tx_pkt_ctl;
    
    /* freq_dev[23:16] */
    uint8_t freq_dev_h;
    
    /* freq_dev[15:8] */
    uint8_t freq_dev_m;
    
    /* freq_dev[7:0] */
    uint8_t freq_dev_l;
    
    /* ramp_step_h
        bit[7]  : reserved
        bit[6:0]: ram_step_time[14:8]
    */
    uint8_t ramp_step_h;
    
    /* ram_step_time[7:0] */
    uint8_t ramp_step_l;
    
    /* pa_idac_code
        bit[7:6]: reserved
        bit[5:0]: pa_idac_code -- pa current control bits for power control
    */
    uint8_t pa_idac_code;
    
    /* lbd_ctl_0
        bit[7:4]: reserved
        bit[3:0]: lbd_th[3:0](V) -- 0: 1.45, 1: 1.64, 2: 1.85, 3: 2.03, 4: 2.26, 5: 2.45, 6: 2.67, 7: 2.86,
                                    8: 3.08, 9: 3.24, 10: 3.43, 11: 3.64, 12: 3.87, 13: 4.00, 14: 4.29, 15: 4.44 (V)
    */
    uint8_t lbd_ctl_0;
    
    /* pa_power_th_9[6:0] */
    uint8_t pa_power_th_9;
    
    /* pa_power_th_8[6:0] */
    uint8_t pa_power_th_8;
    
    /* pa_power_th_7[6:0] */
    uint8_t pa_power_th_7;
    
    /* pa_power_th_6[6:0] */
    uint8_t pa_power_th_6;
    
    /* pa_power_th_5[6:0] */
    uint8_t pa_power_th_5;
    
    /* pa_power_th_4[6:0] */
    uint8_t pa_power_th_4;
    
    /* pa_power_th_3[6:0] */
    uint8_t pa_power_th_3;
    
    /* pa_power_th_2[6:0] */
    uint8_t pa_power_th_2;
    
    /* pa_power_th_1[6:0] */
    uint8_t pa_power_th_1;
    
    /* pa_power_th_0[6:0] */
    uint8_t pa_power_th_0;

}tx_modu_setup_entry_t;

void tx_modu_config(tx_modu_setup_entry_t xdata *ptr_modu_cfg);
void tx_config(void);

#endif






























