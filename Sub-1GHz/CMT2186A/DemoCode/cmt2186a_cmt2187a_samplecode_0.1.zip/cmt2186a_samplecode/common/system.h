/*************************************************************
 *** @Author       : lining
 *** @Date         : 2023-06-28 16:46:15
 *** @LastEditTime : 2023-06-28 17:02:00
 *** @LastEditors  : lining
 *** @Description  :
 *** @FilePath     : \cmt218x_soft\common\system.h
 **************************************************************/
#ifndef __SYSTEM_H__
#define __SYSTEM_H__
					
#include "cmt218x_types.h" 
#include "cmt218x_SFR.h"
#include "cmt218x_MACRO.h"
#include "cmt218x.h"
#include "intrins.h"

void sys_delay_us(uint16_t us);
void sys_delay_10us(uint16_t us);
void sys_delay_100us(uint16_t us);
void sys_delay_ms(uint32_t ms);

void sys_write_reg(uint8_t addr, uint8_t val);
void sys_set_reg_bit(uint8_t addr, uint8_t bits_val, uint8_t bits_mask);
void sys_set_reg_bit(uint8_t addr, uint8_t bits_val, uint8_t bits_mask);
uint8_t sys_read_reg(uint8_t addr);
void sys_disable_all_clk(void);
void sys_shutdown(void);

#endif
