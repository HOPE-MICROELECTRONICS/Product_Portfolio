#include "system.h"

/**
 * sys_write_reg.
 *
 * @author	lining
 * @since	v0.0.1
 * @version	v1.0.0	Friday, August 4th, 2023.
 * @global
 * @param	uint8_t	addr
 * @param	uint8_t	val
 * @return	void
 */
void sys_write_reg(uint8_t addr, uint8_t val)
{
    AON_ADDR = addr;
    AON_WDATA = val;
}

/**
 * sys_read_reg.
 *
 * @author	lining
 * @since	v0.0.1
 * @version	v1.0.0	Friday, August 4th, 2023.
 * @global
 * @param	uint8_t	addr
 * @return	mixed
 */
uint8_t sys_read_reg(uint8_t addr)
{
    AON_ADDR = addr;
    AON_RDATA = 0x03;
    return AON_RDATA;
}

/**
 * sys_set_reg_bit.
 *
 * @author	lining
 * @since	v0.0.1
 * @version	v1.0.0	Friday, August 4th, 2023.
 * @global
 * @param	uint8_t	addr
 * @param	uint8_t	bits_val
 * @param	uint8_t	bits_mask
 * @return	void
 */
void sys_set_reg_bit(uint8_t addr, uint8_t bits_val, uint8_t bits_mask)
{
    uint8_t reg_val;

    AON_ADDR = addr;
    AON_RDATA = 0x03;
    reg_val = AON_RDATA;

    reg_val = (reg_val & (~bits_mask)) | (bits_val & bits_mask);
    AON_ADDR = addr;
    AON_WDATA = reg_val;
}

/**
 * sys_delay_us.
 *
 * @author	lining
 * @since	v0.0.1
 * @version	v1.0.0	Friday, August 4th, 2023.
 * @global
 * @param	uint16_t	us
 * @return	void
 */
void sys_delay_us(uint16_t us)
{
    while(us--)
    {
        _nop_(); _nop_(); _nop_();_nop_();
        _nop_(); _nop_();// _nop_();//_nop_();
    }
}

/**
 * sys_delay_10us.
 *
 * @author	lining
 * @since	v0.0.1
 * @version	v1.0.0	Friday, August 4th, 2023.
 * @global
 * @param	uint16_t	us
 * @return	void
 */
void sys_delay_10us(uint16_t us)
{
    while(us--)
    {
        sys_delay_us(10);
    }
}

/**
 * sys_delay_100us.
 *
 * @author	lining
 * @since	v0.0.1
 * @version	v1.0.0	Friday, August 4th, 2023.
 * @global
 * @param	uint16_t	us
 * @return	void
 */
void sys_delay_100us(uint16_t us)
{
    while(us--)
    {
        sys_delay_us(100);
    }
}

/**
 * sys_delay_ms.
 *
 * @author	lining
 * @since	v0.0.1
 * @version	v1.0.0	Friday, August 4th, 2023.
 * @global
 * @param	int	ms
 * @return	void
 */
void sys_delay_ms(uint32_t ms)
{
	ms *= 10;
    while(ms--)
    {
        sys_delay_100us(1);
    }
}

/**
 * sys_disable_clk.
 *
 * @author	lining
 * @since	v0.0.1
 * @version	v1.0.0	Friday, August 4th, 2023.
 * @global
 * @param	mixed	void
 * @return	void
 */
void sys_disable_all_clk(void)
{
    CLK_GATE_0 &= ~(M_ANA_CLK_EN | M_LBD_CLK_EN | M_MEMCTL_CLK_EN | M_MTP_CLK_EN);
    CLK_GATE_1 &= ~(M_EE_CLK_EN | M_INTIO_CLK_EN | M_TX_CLK_EN | M_DEC_CLK_EN | M_SPIS_CLK_EN | M_SPIM_CLK_EN | M_TIMERB_CLK_EN | M_TIMERA_CLK_EN);
    CLK_GATE_2 &= ~(M_HFCAL_CLK_EN | M_LFCAL_CLK_EN | M_PORT1_CLK_EN | M_PORT0_CLK_EN | M_SERIAL0_CLK_EN | M_TIMER1_CLK_EN | M_TIMER0_CLK_EN);
}

/**
 * sys_shutdown.
 *
 * @author	lining
 * @since	v0.0.1
 * @version	v1.0.0	Friday, August 4th, 2023.
 * @global
 * @param	mixed	void
 * @return	void
 */
void sys_shutdown(void)
{
    sys_set_reg_bit(AON_REG_03, M_STATE_IS_SLEEP, M_STATE_IS_SLEEP);
    PCON |= M_STOP;
}


