// #include "intrins.h"
#include "stdio.h"
#include "string.h"
#include "intrins.h"
#include "system.h"
#include "cmt218x_types.h"
#include "cmt218x_sfr.h"
#include "cmt218x_macro.h"

#define RECV_DATA_LEN 16
xdata uint8_t g_recv_buf[RECV_DATA_LEN];
xdata uint8_t g_tx_buf[RECV_DATA_LEN];

uint8_t g_recv_ok;
uint8_t g_recv_cnt;

void uart_send_bytes(uint8_t xdata *ptr_buf, uint8_t tx_len)
{
    uint8_t idx;
    for (idx = 0; idx < tx_len; idx++)
    {
        /* start tx */
        SBUF0 = ptr_buf[idx];

        while (!(SCON0 & M_TI0))
            ;
        TI0 = 0;
    }
}

void main(void)
{

    /* disable all interrupt */
    IEN0 = 0x00;
    IEN1 = 0x00;

    EA = 0;

    // disable all clk
    sys_disable_all_clk();

    /* enable dec intio serial0 timer1 clk */
    CLK_GATE_1 |= M_DEC_CLK_EN | M_INTIO_CLK_EN;
    CLK_GATE_2 |= M_SERIAL0_CLK_EN | M_TIMER1_CLK_EN;

    /* ++++++++++ config gpio +++++++++++++++++++++++++++++

        d3 : rx
        d2 : tx
    * +++++++++++++++++++++++++++++++++++++++++++++++++++++*/
    /* set d3 as pullup input */
    sys_set_reg_bit(AON_REG_15, 0x00, M_D3_PD_PULLUP);
    sys_set_reg_bit(AON_REG_13, M_D3_IDRV_EN, M_D3_IDRV_EN);
    /* set d2 as push-pull output */
    sys_set_reg_bit(AON_REG_19, 0, M_D2_OPEN_DRAIN);
    sys_set_reg_bit(AON_REG_11, M_D2_ODRV_EN, M_D2_ODRV_EN);

    /* gpio2(d2)_out_sel = 10, d2 as tx out */
    GPIO_OUTB_SEL = (GPIO_OUTB_SEL & M_GPIO2_OUT_SEL) | (10 << BIT0);

    /* rxd0_gpio_sel = 3, rx input from d3 */
    GPIO_INE_SEL = (GPIO_INE_SEL & M_RXD0_GPIO_SEL) | (GPIO_IN_SEL_D3 << BIT0);

    /* +++++++++++++++++++++++++++++ usart config +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     * when usart_sel = 1, and set timer1 mode1, then baud_rate = 2^smod1 * fclk_periph / (32 *(65536 - (TH1*0x100 + TL1)))
     * when usart_sel = 0, and set timer1 mode2, then baud_rate = 2^smod1 * fclk_periph / (32 * 12 *(256 - TH1))
     * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

    /* -------------- serial mode 1(8-bit uart, timer1-driven) ----------------------- */
    PCON |= M_SMOD1; /* double baud rate bit */
    SCON0 &= ~(M_SM00 | M_SM10);
    SCON0 |= M_SM10;
    SCON0 |= M_REN0; /* enable rxd */

    /* usart_sel = 1, timer1 auto-reload TH1 TL1 */
    CDR_DR_2 |= M_USART_SEL;

    /* set timer1 to mode 1 (one 16-bit timer/counter) */
    TMOD = 0x10;

    /* baud_rate = 2^smod1 * fclk_periph / (32 *(65536 - (TH1*0x100 + TL1))) */
    /*
    default fclk_periph = 24mhz
    baud_rate          TH1          TL1
    2.4k               0xfd        0x8f
    4.8k               0xfe        0xc7
    9.6k               0xff        0x64
    14.4k              0xff        0x98
    19.2k              0xff        0xb2
    38.4k              0xff        0xd9
    56k                0xff        0xe5
    57.6k              0xff        0xe6
    115.2k             0xff        0xf3
    128k               0xff        0xf4
    256k               0xff        0xfa
    */
    TH1 = 0xff; // baud_rate = 115.2k;
    TL1 = 0xf3;

    /* start timer1 */
    TCON |= M_TR1;

    /* enable uart interrupt */
    ES0 = 1;

    /* enable all interrupt */
    EA = 1;

    g_recv_cnt = 0;
    g_recv_ok = 0;

    while (1)
    {
        if (g_recv_ok == 1)
        {
            g_recv_ok = 0;
            uart_send_bytes(g_tx_buf, RECV_DATA_LEN);
        }
    }

    sys_shutdown();
}

void serial_port0_interrupt_routine(void)
{
    if (SCON0 & M_RI0)
    {
        SCON0 &= ~M_RI0;

        g_recv_buf[g_recv_cnt++] = SBUF0;

        if (g_recv_cnt >= RECV_DATA_LEN)
        {
            g_recv_ok = 1;
            g_recv_cnt = 0;
            memcpy(g_tx_buf, g_recv_buf, RECV_DATA_LEN);
        }
    }
}

extern void sys_push_context_to_stack();
extern void sys_pop_context_from_stack();

// 8n+3
void system_external_interrupt0(void) interrupt 0 using 0 // 03
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt1(void) interrupt 2 using 0 // 13
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_timer1_interrupt(void) interrupt 3 using 0 // 1B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_serial_port0_interrupt(void) interrupt 4 using 0 // 23
{
    sys_push_context_to_stack();
    serial_port0_interrupt_routine();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt2(void) interrupt 9 using 0 // 4B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt3(void) interrupt 10 using 0 // 53
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt4(void) interrupt 11 using 0 // 5B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt5(void) interrupt 12 using 0 // 63
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt6(void) interrupt 13 using 0 // 6B
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}

// 8n+3
void system_external_interrupt7(void) interrupt 14 using 0 // 73
{
    sys_push_context_to_stack();
    sys_pop_context_from_stack();
}
