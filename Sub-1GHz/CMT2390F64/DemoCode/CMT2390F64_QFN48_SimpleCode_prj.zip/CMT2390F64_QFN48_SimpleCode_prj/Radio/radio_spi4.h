
#ifndef		__RADIO_SPI4_H__
	
	#define __RADIO_SPI4_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif

	#include "n32g031.h"
	#include "n32g031_conf.h"
	#include "n32g031_gpio.h"
	#include "dll.h"

	//***************************************************************************
	//GPIO                                                                       
	//mode:  2'b, 00(input), 01(output),  10(func),      11(analog)
	//type:  1'b, 0(push-pull),    1(open-drain)
	//sr:	 1'b, 0(quick toggle), 1(low speed)
	//pu/pd: 2'b, 00(none),  01(pull-up), 10(pull-down), 11(resv)
	//pod:   1'b, 0(output-high),  1(output-low)
	//pbsc:  1'b, 0(none),         1(set or clear)
	//af:    4'b,                                             
	//ds:    1'b, 0(high-drv), 	   1(low-drv)
	//***************************************************************************

	//----------------PORTA-------------------------mode-----type---sr---pu/pd---pod----af----ds      
	#define		RF_CSB			GPIO_PIN_8      //  01        0     0     00      0    0000   0  ** 
	
	//----------------PORTB-------------------------mode-----type---sr---pu/pd---pod----af----ds      
 	//#define					GPIO_PIN_0		//  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_1      //  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_2      //  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_3      //  00        0     0     00      0    0000   0
	#define		RF_GPIO5		GPIO_PIN_4      //  00        0     0     10      0    0000   0	
	//#define					GPIO_PIN_5      //  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_6      //  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_7      //  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_8      //  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_9      //  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_10     //  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_11     //  00        0     0     00      0    0000   0
	//#define					GPIO_PIN_12     //  00        0     0     00      0    0000   0
	#define		RF_SCK			GPIO_PIN_13     //  10        0     0     00      0    0000	  0   **   	
	#define		RF_MISO			GPIO_PIN_14     //  10        0     0     00      0    0000   0   **     
	#define		RF_MOSI			GPIO_PIN_15     //  10        0     0     00      0    0000   0   ** 	
	
	//----------------PORTC-------------------------mode-----type---sr---pu/pd---pod----af----ds  
	#define		RF_GPIO4		GPIO_PIN_13		//	00        0     0     10      0    0000   0


	#define		RADIO_PORTA_PMODE_VAL		0x00010000		
	#define		RADIO_PORTA_PMODE_MASK		0xFFFCFFFF	

	#define		RADIO_PORTA_POTYPE_VAL		0x00000000
	#define		RADIO_PORTA_POTYPE_MASK		0xFFFFFEFF

	#define		RADIO_PORTA_SR_VAL			0x00000000
	#define		RADIO_PORTA_SR_MASK			0xFFFFFEFF

	#define		RADIO_PORTA_PUPD_VAL		0x00000000
	#define		RADIO_PORTA_PUPD_MASK		0xFFFCFFFF

	#define		RADIO_PORTA_POD_VAL			0x00000000
	#define		RADIO_PORTA_POD_MASK		0xFFFFFEFF

	#define		RADIO_PORTA_AFL_VAL			0x00000000
	#define		RADIO_PORTA_AFL_MASK		0xFFFFFFFF

	#define		RADIO_PORTA_AFH_VAL			0x00000000
	#define		RADIO_PORTA_AFH_MASK		0xFFFFFFFF

	#define		RADIO_PORTA_DS_VAL			0x00000000
	#define		RADIO_PORTA_DS_MASK			0xFFFFFEFF


	#define		RADIO_PORTB_PMODE_VAL		0xA8000000		
	#define		RADIO_PORTB_PMODE_MASK		0x03FFFCFF		

	#define		RADIO_PORTB_POTYPE_VAL		0x00000000
	#define		RADIO_PORTB_POTYPE_MASK		0xFFFF1FEF

	#define		RADIO_PORTB_SR_VAL			0x00000000
	#define		RADIO_PORTB_SR_MASK			0xFFFF1FEF
	
	#define		RADIO_PORTB_PUPD_VAL		0x00000200
	#define		RADIO_PORTB_PUPD_MASK		0x03FFFCFF

	#define		RADIO_PORTB_DS_VAL			0x00000000
	#define		RADIO_PORTB_DS_MASK			0xFFFFFFFF

	#define		RADIO_PORTB_POD_VAL			0x00000000
	#define		RADIO_PORTB_POD_MASK		0xFFFF1FEF

	#define		RADIO_PORTB_AFL_VAL			0x00000000
	#define		RADIO_PORTB_AFL_MASK		0xFFFFFFFF

	#define		RADIO_PORTB_AFH_VAL			0x00000000
	#define		RADIO_PORTB_AFH_MASK		0x000FFFFF


	#define		RADIO_PORTC_PMODE_VAL		0x00000000		
	#define		RADIO_PORTC_PMODE_MASK		0xF3FFFFFF		

	#define		RADIO_PORTC_POTYPE_VAL		0x00000000
	#define		RADIO_PORTC_POTYPE_MASK		0xFFFFDFFF

	#define		RADIO_PORTC_SR_VAL			0x00000000
	#define		RADIO_PORTC_SR_MASK			0xFFFFDFFF

	#define		RADIO_PORTC_PUPD_VAL		0x08000000
	#define		RADIO_PORTC_PUPD_MASK		0xF3FFFFFF

	#define		RADIO_PORTC_DS_VAL			0x00000000
	#define		RADIO_PORTC_DS_MASK			0xFFFFDFFF
	
	
	#define		SET_RF_CSB()		(GPIOA->PBSC |= RF_CSB)
	#define		CLR_RF_CSB()		(GPIOA->PBC  |= RF_CSB)
	
	#define		RF_GPIO5_H()		((GPIOB->PID&RF_GPIO5)==RF_GPIO5)
	#define		RF_GPIO5_L()		((GPIOB->PID&RF_GPIO5)==0)

	#define		RF_GPIO4_H()		((GPIOC->PID&RF_GPIO4)==RF_GPIO4)
	#define		RF_GPIO4_L()		((GPIOC->PID&RF_GPIO4)==0)


	#define 	RF_GPIO4_Output()	(GPIOC->PMODE |= (0x04000000))
	#define		RF_GPIO4_Input()  	(GPIOC->PMODE &= (0xF3FFFFFF))

	#define 	RF_TX_DATA_Output()	(GPIOC->PMODE |= (0x04000000))
	#define		RF_TX_DATA_Input()  (GPIOC->PMODE &= (0xF3FFFFFF))

	#define		RF_TX_DAT_H()		(GPIOC->PBSC |= RF_GPIO4)  
	#define		RF_TX_DAT_L()		(GPIOC->PBC  |= RF_GPIO4)


	// API
	extern void vSpiMasterInit(void);
	extern unsigned char bSpiWriteByte(unsigned char spi_adr, unsigned char spi_dat);
	extern unsigned char bSpiReadByte(unsigned char spi_adr);
	extern void vSpiBurstWrite(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length);
	extern void vSpiBurstRead(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length);

	
	#ifdef	__cplusplus
		}
	#endif

#endif 		
