#include "radio_spi4.h"

#define		SPI_SPEED_SEL		1			// 0 --> 7

#define		SPI_DUMMY_VALUE		0xFF

/**********************************************************
**Name: 	vSpiInit
**Func: 	Init Spi-3 Config
**Note: 	
**********************************************************/
void vSpiMasterInit(void)
{
	unsigned int tmp;
	SPI_InitType SPI_InitStructure;	

	RCC_EnableAPB2PeriphClk((RCC_APB2_PERIPH_GPIOB|RCC_APB2_PERIPH_GPIOC|RCC_APB2_PERIPH_AFIO), ENABLE);	//enable gpioB & gpioC periph clk
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_SPI1, ENABLE);													//enable SPI1 periph clk
	
	//PortA
	//## ds
	tmp  = GPIOA->DS;
	tmp &= RADIO_PORTA_DS_MASK;
	tmp |= RADIO_PORTA_DS_VAL;
	GPIOA->DS   = tmp;
	
	//## pod
	tmp  = GPIOA->POD;
	tmp &= RADIO_PORTA_POD_MASK;
	tmp |= RADIO_PORTA_POD_VAL;
	GPIOA->POD   = tmp;
	
	//## pull-up or pull-down
	tmp  = GPIOA->PUPD;
	tmp &= RADIO_PORTA_PUPD_MASK;
	tmp |= RADIO_PORTA_PUPD_VAL;
	GPIOA->PUPD = tmp;

	//## sr 	
	tmp  = GPIOA->SR;
	tmp &= RADIO_PORTA_SR_MASK;
	tmp |= RADIO_PORTA_SR_VAL;
	GPIOA->SR  = tmp;

	//## push-pull output or open-drain 
	tmp  = GPIOA->POTYPE;
	tmp &= RADIO_PORTA_POTYPE_MASK;
	tmp |= RADIO_PORTA_POTYPE_VAL;
	GPIOA->POTYPE = tmp;

	//## AF
	tmp  = GPIOA->AFL;
	tmp &= RADIO_PORTA_AFL_MASK;
	tmp |= RADIO_PORTA_AFL_VAL;		
	GPIOA->AFL = tmp;
	
	tmp  = GPIOA->AFH;
	tmp &= RADIO_PORTA_AFH_MASK;
	tmp |= RADIO_PORTA_AFH_VAL;		
	GPIOA->AFH = tmp;
	
	//## mode		
	tmp  = GPIOA->PMODE;
	tmp &= RADIO_PORTA_PMODE_MASK;
	tmp |= RADIO_PORTA_PMODE_VAL;		
	GPIOA->PMODE = tmp;
	
	
	//PortB
	//## ds
	tmp  = GPIOB->DS;
	tmp &= RADIO_PORTB_DS_MASK;
	tmp |= RADIO_PORTB_DS_VAL;
	GPIOB->DS   = tmp;
	
	//## pod
	tmp  = GPIOB->POD;
	tmp &= RADIO_PORTB_POD_MASK;
	tmp |= RADIO_PORTB_POD_VAL;
	GPIOB->POD   = tmp;
	

	//## pull-up or pull-down
	tmp  = GPIOB->PUPD;
	tmp &= RADIO_PORTB_PUPD_MASK;
	tmp |= RADIO_PORTB_PUPD_VAL;
	GPIOB->PUPD = tmp;

	//## sr 	
	tmp  = GPIOB->SR;
	tmp &= RADIO_PORTB_SR_MASK;
	tmp |= RADIO_PORTB_SR_VAL;
	GPIOB->SR  = tmp;

	//## push-pull output or open-drain 
	tmp  = GPIOB->POTYPE;
	tmp &= RADIO_PORTB_POTYPE_MASK;
	tmp |= RADIO_PORTB_POTYPE_VAL;
	GPIOB->POTYPE = tmp;

	//## AF
	tmp  = GPIOB->AFL;
	tmp &= RADIO_PORTB_AFL_MASK;
	tmp |= RADIO_PORTB_AFL_VAL;		
	GPIOB->AFL = tmp;
	
	tmp  = GPIOB->AFH;
	tmp &= RADIO_PORTB_AFH_MASK;
	tmp |= RADIO_PORTB_AFH_VAL;		
	GPIOB->AFH = tmp;

	//## mode		
	tmp  = GPIOB->PMODE;
	tmp &= RADIO_PORTB_PMODE_MASK;
	tmp |= RADIO_PORTB_PMODE_VAL;		
	GPIOB->PMODE = tmp;

	//PortC
	//## ds
	tmp  = GPIOC->DS;
	tmp &= RADIO_PORTC_DS_MASK;
	tmp |= RADIO_PORTC_DS_VAL;
	GPIOC->DS   = tmp;

	//## pull-up or pull-down
	tmp  = GPIOC->PUPD;
	tmp &= RADIO_PORTC_PUPD_MASK;
	tmp |= RADIO_PORTC_PUPD_VAL;
	GPIOC->PUPD = tmp;

	//## sr 	
	tmp  = GPIOC->SR;
	tmp &= RADIO_PORTC_SR_MASK;
	tmp |= RADIO_PORTC_SR_VAL;
	GPIOC->SR  = tmp;

	//## push-pull output or open-drain 
	tmp  = GPIOC->POTYPE;
	tmp &= RADIO_PORTC_POTYPE_MASK;
	tmp |= RADIO_PORTC_POTYPE_VAL;
	GPIOC->POTYPE = tmp;

	//## mode		
	tmp  = GPIOC->PMODE;
	tmp &= RADIO_PORTC_PMODE_MASK;
	tmp |= RADIO_PORTC_PMODE_VAL;		
	GPIOC->PMODE = tmp;

	SET_RF_CSB();

    SPI_Enable(SPI1, DISABLE);
	
    SPI_InitStructure.DataDirection = SPI_DIR_DOUBLELINE_FULLDUPLEX;
    SPI_InitStructure.SpiMode       = SPI_MODE_MASTER;
    SPI_InitStructure.DataLen       = SPI_DATA_SIZE_8BITS;
    SPI_InitStructure.CLKPOL        = SPI_CLKPOL_LOW;
    SPI_InitStructure.CLKPHA        = SPI_CLKPHA_FIRST_EDGE;
    SPI_InitStructure.NSS           = SPI_NSS_SOFT;

	switch(SPI_SPEED_SEL)    													//   @8MHz   @12MHz   @24MHz   @32MHz   @40MHz
    	{																		//
    	case 0: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_2;   break;	//    4M       6M      12M      16M		 20M
    	case 1: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_4;   break;	//	  1M       3M      6M       8M       10M
    	case 2: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_8;   break;	//   500k      1.5M    3M       4M       5M
    	case 3: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_16;  break;	//   250k      750k    1.5M     2M       2.5M
    	case 4: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_32;  break;	//	 125k	   375k    750k     1M       1.25M
    	case 5: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_64;  break;	//   62.5k     187.5k  375k     500k     625k
    	case 6: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_128; break;	//   31.25k    93k     187.5k   250k     312.5k
    	case 7: SPI_InitStructure.BaudRatePres = SPI_BR_PRESCALER_256; break;	//	 16.625k   47k     93k      125k     156k
    	}
    SPI_InitStructure.FirstBit      = SPI_FB_MSB;
    SPI_InitStructure.CRCPoly       = 7;
    SPI_Init(SPI1, &SPI_InitStructure);	

    SPI_Enable(SPI1, ENABLE);
}

/**********************************************************
**Name:	 	bSpiWriteByte
**Func: 	SPI Write One word
**Input: 	Write word
**Output:	none
**********************************************************/
unsigned char bSpiWriteByte(unsigned char spi_adr, unsigned char spi_dat)
{
	unsigned char dout;
	
	CLR_RF_CSB();

	SPI1->DAT = (spi_adr&0x7F);   
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT;
	SPI1->DAT = spi_dat;	
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT;	

	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_BUSY_FLAG) == SET);		// Wait for SPI1 not busy
	SET_RF_CSB();	
	return(dout);	
}

/**********************************************************
**Name:	 	bSpiReadByte
**Func: 	SPI Read One byte
**Input: 	readout addresss
**Output:	readout byte
**********************************************************/
unsigned char bSpiReadByte(unsigned char spi_adr)
{
	unsigned char dout;
	
	CLR_RF_CSB();

	SPI1->DAT = (spi_adr|0x80);   
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT;
	SPI1->DAT = SPI_DUMMY_VALUE;	
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT;	

	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_BUSY_FLAG) == SET);		// Wait for SPI1 not busy
	SET_RF_CSB();	
	return(dout);	
}

/**********************************************************
**Name:	 	vSpiBurstWrite
**Func: 	burst wirte N byte
**Input: 	array length & head pointer
**Output:	none
**********************************************************/
void vSpiBurstWrite(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length)
{
 	unsigned char i;
	unsigned char dout;	
 	
 	spi_adr &= 0x7F;

	CLR_RF_CSB();
	SPI1->DAT = spi_adr;   
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	dout = (unsigned char)SPI1->DAT; 	
 	if(spi_length!=0x00)
	 	{
 		for(i=0; i<spi_length; i++)
			{
			SPI1->DAT = spi_dat[i];	
			while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
			dout = (unsigned char)SPI1->DAT;				
			}
 		}
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_BUSY_FLAG) == SET);		// Wait for SPI1 not busy
	SET_RF_CSB();	 		
 	return;
}

/**********************************************************
**Name:	 	vSpiBurstRead
**Func: 	burst wirte N byte
**Input: 	array length  & head pointer
**Output:	none
**********************************************************/
void vSpiBurstRead(unsigned char spi_adr, unsigned char spi_dat[], unsigned char spi_length)
{
	unsigned char i;
	
	spi_adr |= 0x80;
	
	CLR_RF_CSB();
	SPI1->DAT = spi_adr;   
	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
	i = (unsigned char)SPI1->DAT; 	
 	if(spi_length!=0)
 		{
 		for(i=0; i<spi_length; i++)
 			{
			SPI1->DAT = SPI_DUMMY_VALUE;	
			while (SPI_I2S_GetStatus(SPI1, SPI_I2S_RNE_FLAG) == RESET);
			spi_dat[i] = (unsigned char)SPI1->DAT;	 				
			}
 		}	

	while (SPI_I2S_GetStatus(SPI1, SPI_I2S_BUSY_FLAG) == SET);		// Wait for SPI1 not busy
	SET_RF_CSB();	 		
 	return;
}

