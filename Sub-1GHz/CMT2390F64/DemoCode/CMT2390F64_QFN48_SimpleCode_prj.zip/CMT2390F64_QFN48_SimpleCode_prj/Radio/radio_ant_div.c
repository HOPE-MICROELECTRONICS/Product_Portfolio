#include "radio_ant_div.h"


/******************************
**Name:  vRadioAntennaDiversityCfg
**Func:  antenna diversity enable or disable
**Input: FALSE: disable antenna diversity
*        TRUE:  enable antenna diversity
*Output: None
********************************/
void vRadioAntennaDiversityCfg(boolean_t on_off)
{
	vRadioRegPageSel(1);
	if(on_off)
		bRadioSetReg(CMT2310A_RX_ANTD_REG_00, CMT2310A_ANT_DIV_EN, CMT2310A_ANT_DIV_EN);
	else
		bRadioSetReg(CMT2310A_RX_ANTD_REG_00, 0, CMT2310A_ANT_DIV_EN);
	vRadioRegPageSel(0);	
}

/******************************
**Name:  vRadioAntennaDiversityCompareModeCfg
**Func:  antenna diversity Compare Mode
**Input: FALSE: auto compare between ANT1 & ANT2
*        TRUE:  fixed TH(more than 16dB) for ANT1 or ANT2
*Output: None
********************************/
void vRadioAntennaDiversityCompareModeCfg(boolean_t on_off)
{
	vRadioRegPageSel(1);
	if(on_off)
		bRadioSetReg(CMT2310A_RX_ANTD_REG_00, CMT2310A_ANT_SW_DIS, CMT2310A_ANT_SW_DIS);
	else
		bRadioSetReg(CMT2310A_RX_ANTD_REG_00, 0, CMT2310A_ANT_SW_DIS);
	vRadioRegPageSel(0);	
}

/******************************
**Name:  vRadioAntennaDiversityDetWindowCfg
**Func:  antenna diversity detect window 
**Input: select value as below
         CMT2310A_ANT_WAIT_1_5_UNIT
         CMT2310A_ANT_WAIT_2_UNIT
         CMT2310A_ANT_WAIT_2_5_UNIT
         CMT2310A_ANT_WAIT_3_UNIT
*Output: None
********************************/
void vRadioAntennaDiversityDetWindowCfg(unsigned char cfg_value)
{
	vRadioRegPageSel(1);
	bRadioSetReg(CMT2310A_RX_ANTD_REG_00, cfg_value, CMT2310A_ANT_WAIT_PMB_MASK);
	vRadioRegPageSel(0);	
}


/******************************
**Name:  vRadioAntennaDiversityManualModeCfg
**Func:  antenna diversity manual mode
**Input: FALSE: antenna diversity work as automatic
		 TRUE:  antenna diversity work as manual
*Output: None
********************************/
void vRadioAntennaDiversityManualModeCfg(boolean_t on_off)
{
	vRadioRegPageSel(0);
	if(on_off)
		bRadioSetReg(CMT2310A_CTL_REG_02, CMT2310A_ANT_DIV_MANU, CMT2310A_ANT_DIV_MANU);
	else
		bRadioSetReg(CMT2310A_CTL_REG_02, 0, CMT2310A_ANT_DIV_MANU);
}

/******************************
**Name:  vRadioAntennaDiversitySelectAntenna
**Func:  select ant1 or ant2, in antenna diversity manual mode
**Input: FALSE: antenna1
		 TRUE:  antenna2
*Output: None
********************************/
void vRadioAntennaDiversitySelectAntenna(boolean_t on_off)
{
	vRadioRegPageSel(0);
	if(on_off)
		bRadioSetReg(CMT2310A_CTL_REG_02, CMT2310A_ANT_SELECT, CMT2310A_ANT_SELECT);
	else
		bRadioSetReg(CMT2310A_CTL_REG_02, 0, CMT2310A_ANT_SELECT);
}

/******************************
**Name:  vRadioAntennaDiversityLockClear
**Func:  clear antenna locked flag
**Input: None
*Output: None
********************************/
void vRadioAntennaDiversityLockClear(void)
{
	vRadioRegPageSel(0);
	bRadioSetReg(CMT2310A_CTL_REG_29, CMT2310A_ANT_LOCK_CLR, CMT2310A_ANT_LOCK_CLR);
}

/******************************
**Name:  vRadioAntennaDiversityLockIntEnable
**Func:  enable antenna locked interrupt
**Input: TRUE:  Enable
**		 FALSE: Disable
*Output: None
********************************/
void vRadioAntennaDiversityLockInterrupt(boolean_t on_off)
{
	vRadioRegPageSel(0);
	if(on_off)
		bRadioSetReg(CMT2310A_CTL_REG_22, CMT2310A_ANT_LOCK_EN, CMT2310A_ANT_LOCK_EN);
	else
		bRadioSetReg(CMT2310A_CTL_REG_22, 0, CMT2310A_ANT_LOCK_EN);
}

