

#ifndef __RADIO_ANT_DIV_H

	#define 	__RADIO_ANT_DIV_H
	
	#include "dll.h"
	#include "radio_spi4.h"	
	#include "radio_hal.h"
	#include "CMT2310A_def.h"
	#include "CMT2310A_reg.h"
	
	
	//api 
	
	extern void vRadioAntennaDiversityCfg(boolean_t on_off);
	extern void vRadioAntennaDiversityCompareModeCfg(boolean_t on_off);
	extern void vRadioAntennaDiversityDetWindowCfg(unsigned char cfg_value);
	extern void vRadioAntennaDiversityManualModeCfg(boolean_t on_off);
	extern void vRadioAntennaDiversitySelectAntenna(boolean_t on_off);
	extern void vRadioAntennaDiversityLockClear(void);
	extern void vRadioAntennaDiversityLockInterrupt(boolean_t on_off);

#endif	



