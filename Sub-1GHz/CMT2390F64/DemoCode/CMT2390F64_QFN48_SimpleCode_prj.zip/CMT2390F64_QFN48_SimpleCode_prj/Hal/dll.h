
#ifndef		__DLL_H__
	
	#define __DLL_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif

	#include "n32g031.h"

	/** logical datatype (only values are TRUE and FALSE) */
	typedef uint8_t      boolean_t;

	#ifndef TRUE
	  /** Value is true (boolean_t type) */
	  #define TRUE        ((boolean_t) 1u)
	#endif
	
	#ifndef FALSE
	  /** Value is false (boolean_t type) */
	  #define FALSE       ((boolean_t) 0u)
	#endif  

	typedef unsigned char 	byte;
	typedef	unsigned char 	BYTE;
	
	typedef unsigned short int	word;
	typedef	unsigned short int 	WORD;
	
	typedef unsigned int	lword;
	typedef	unsigned int	LWORD;
	

	typedef enum
		{
    	FAILED = 0,
    	PASSED = !FAILED
		}Status;
		

	extern void delay100ms(unsigned int u32Cnt);
	extern void delay10ms(unsigned int u32Cnt);
	extern void delay1ms(unsigned int u32Cnt);
	extern void delay100us(unsigned int u32Cnt);	
	extern void delay10us(unsigned int u32Cnt);


	#ifdef	__cplusplus
		}
	#endif

#endif 		








