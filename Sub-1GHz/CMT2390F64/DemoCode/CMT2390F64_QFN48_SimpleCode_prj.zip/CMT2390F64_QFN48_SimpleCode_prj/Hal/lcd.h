

#ifndef		__LCD_H__
	
	#define __LCD_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif

	#include "n32g031.h"
	#include "n32g031_gpio.h"
	#include "dll.h"
	
	#define		LcdSoftReset 		0xE2

    //------------PORTA-----------------------------mode-----type---sr---pu/pd---pod----af----ds
	#define		LCD_SDIO		GPIO_PIN_0	    //  00/01	  0     0     00      1    0000   0    
	#define		LCD_RS			GPIO_PIN_1      //  01        0     0     00      1    0000   0
	#define		LCD_CS			GPIO_PIN_2      //  01        0     0     00      1    0000   0 
 	#define		LCD_SCK			GPIO_PIN_3      //  01        0     0     00      1    0000	  0
 	#define		LCD_ROM_CS		GPIO_PIN_4      //  01        0     0     00      1    0000   0
	//#define					GPIO_PIN_5      //  00        0     0     00      0    0000   0
	#define		LCD_ROM_SDIO	GPIO_PIN_6      //  00        0     0     01      1    0000   0
	//#define					GPIO_PIN_7      //  00        0     0     00      0    0000   0

	#define		LCD_PMODE_VAL		0x00000155		
	#define		LCD_PMODE_MASK		0xFFFFCC00		
	
	#define		LCD_POTYPE_VAL		0x00000000
	#define		LCD_POTYPE_MASK		0xFFFFFFA0

	#define		LCD_SR_VAL			0x00000000
	#define		LCD_SR_MASK			0xFFFFFFA0

	#define		LCD_PUPD_VAL		0x00002000
	#define		LCD_PUPD_MASK		0xFFFFCC00


	#define		SET_LCD_SDIO()		(GPIOA->PBSC = LCD_SDIO)
	#define		CLR_LCD_SDIO()		(GPIOA->PBC  = LCD_SDIO)
	
	#define		SET_LCD_RS()		(GPIOA->PBSC = LCD_RS)
	#define		CLR_LCD_RS()		(GPIOA->PBC  = LCD_RS)

	#define		SET_LCD_CS()		(GPIOA->PBSC = LCD_CS)
	#define		CLR_LCD_CS()		(GPIOA->PBC  = LCD_CS)

	#define		SET_LCD_SCK()		(GPIOA->PBSC = LCD_SCK)
	#define		CLR_LCD_SCK()		(GPIOA->PBC  = LCD_SCK)

	#define		SET_LCD_ROM_CS()	(GPIOA->PBSC = LCD_ROM_CS)
	#define		CLR_LCD_ROM_CS()	(GPIOA->PBC  = LCD_ROM_CS)
	
	#define		SET_ROM_SDIO()		(GPIOA->PBSC = LCD_ROM_SDIO)
	#define		CLR_ROM_SDIO()		(GPIOA->PBC  = LCD_ROM_SDIO)
	
	#define		LCD_ROM_SDIO_H()	((GPIOA->PID&LCD_ROM_SDIO)==LCD_ROM_SDIO)
	#define		LCD_ROM_SDIO_L()	((GPIOA->PID&LCD_ROM_SDIO)==0)
	
	#define		LCD_SDIO_H()		((GPIOA->PID&LCD_SDIO)==LCD_SDIO)
	#define		LCD_SDIO_L()		((GPIOA->PID&LCD_SDIO)==0)


	// Display API
	extern void vDispInit(void);
	extern void vDispOn(void);
	extern void vDispOff(void);
	extern void vDispFull(void);
	extern void vDispClear(void);
	extern void vDispArduinoLogo(unsigned char positive);
	extern void vDispHopeRFLogo(unsigned char line, unsigned char positive);
	extern void vDispCmostekLogo(unsigned char line, unsigned char positive);
	extern void vDispGrap32x32(unsigned char page, unsigned char column, unsigned char *ptr);
	extern void vDispGrap16x16(unsigned char page, unsigned char column, unsigned char *ptr);
	extern void vDispGrap8x16(unsigned char page, unsigned char column, unsigned char *ptr);
	extern void vDispGrap8x8(unsigned char page, unsigned char column, unsigned char *ptr);
	extern void vDispClearGrap8x8(unsigned char page, unsigned char column);
	extern void vDispString8x8(unsigned char page, unsigned char column, unsigned char *text);
	extern void vDispSetDot(unsigned char x_axis, unsigned char y_axis);
	extern void vDispFillDot(unsigned char x_axis, unsigned char y_axis);
	extern void vDispClrYaxis(unsigned char x_axis);
	extern void vDispAscii(unsigned char page, unsigned char column, unsigned char ch);
	
	// LCD API
	extern void vLcdInit(void);								//## LCD Init	
	extern void vLcdEnable(void);							//## 
	extern void vLcdDisable(void);							//##
	extern void vLcdLocate(unsigned char page, unsigned char column);
	extern void vLcdClearScreen(void);						//## 
	extern void vLcdFullDisplay(void);						//## 
	extern void vLcdGetASCII8x8(unsigned char ascii_code, unsigned char *ptr);		//##

	extern void vLcdPrintCapital(unsigned char line, unsigned char col, unsigned char ind);
	extern void vLcdPrintLowercase(unsigned char line, unsigned char col, unsigned char ind);
	extern void vLcdPrintNumber(unsigned char line, unsigned char col, unsigned char ind);
	extern void vLcdPrintOther(unsigned char line, unsigned char col, unsigned char ind);
	extern void vLcdDrawDoubleLine(unsigned char line);
	extern void vLcdPrintString(byte line, const byte ch[]);
	extern void vLcdPrintCounter(unsigned char line, unsigned char num, unsigned short int counter);
	

	
	// LCD HAL 
	extern void vLcdSendCmd(unsigned char dat);										//## LCD Send Command 8bit 
	extern void vLcdSendDoubleByteCmd(unsigned char cmd, unsigned char value) ;		//## LCD Send Double Byte Command
	extern void vLcdSendData(unsigned char dat);									//## LCD Send Data
	extern void vLcdBurstSendData(unsigned char *ptr, unsigned char length);		//## LCD Burst Send Data 
	extern void vLcdLibSend(unsigned char dat);										//## LCD ROM Send	
	extern unsigned char bLcdLibRead(void);											//## LCD ROM Read
	
	extern void vLcdGpioInit(void);							
	extern void vLcdSdioOutput(void);
	
	#ifdef	__cplusplus
		}
	#endif

#endif 	



