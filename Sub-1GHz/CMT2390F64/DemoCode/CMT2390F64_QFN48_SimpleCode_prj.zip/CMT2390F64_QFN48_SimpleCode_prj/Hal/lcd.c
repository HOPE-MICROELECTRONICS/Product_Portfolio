#include "lcd.h"

// LCD Driver for JLX12864

//����ָ����ҪRS=0
#define		LCD_CMD_ON 			0xAF
#define		LCD_CMD_OFF			0xAE

#define		LCD_LINE_SET		0x40		//0x40|line, line��Χ��0x00-0x3F, ����0-63��

#define		LCD_ADDR_SET		0xB0		//0xB0|addr, addr��Χ��0xB0-0xB8, һ��1-9ҳ

#define		LCD_COL_H_SET		0x10		//0x10|col_h, col_h��Χ���е�ַ��4λ
#define		LCD_COL_L_SET		0x00		//0x00|col_l, col_l��Χ���е�ַ��4λ�����磺100�У���0x64����Ҫ��� col_h=0x06, col_l=0x04

#define		LCD_CMD_ADC_L2R		0xA0		//��ʾ�е�ַ����ߵ���
#define		LCD_CMD_ADC_R2L		0xA1		//��ʾ�е�ַ���ұߵ���

#define		LCD_CMD_DISP_NOR	0xA6		//��ʾΪ����ʾ
#define		LCD_CMD_DISP_INV	0xA7		//��ʾΪ����ʾ

#define		LCD_CMD_FULL_ON		0xA5		//����������ʾ
#define		LCD_CMD_FULL_OFF	0xA4		//������ʾ

#define		LCD_CMD_BIAS_1_9	0xA2		//ƫѹ��Ϊ1/9
#define		LCD_CMD_BIAS_1_7	0xA3		//ƫѹ��Ϊ1/7

#define		LCD_CMD_RESET		0xE2		//��λ

#define		LCD_COM_UP2DOWN		0xC0		//��ɨ��˳��Ϊ�ϵ���
#define		LCD_COM_DOWN2UP		0xC8		//��ɨ��˳��Ϊ�µ���

#define		LCD_RES_ADJ_SEL		0x20		//0x20|res, res��Χ��0-7�� ֵԽ��ԽŨ��ֵԽС��Խ��

#define		LCD_VOL_ADJ_SEL		0x81		//0x81 + val, �����ֽ�ָ�val��Χ��0-63, ֵԽ��ԽŨ��ֵԽС��Խ��

#define		LCD_STATIC_ON		0xAD		//��̬ͼ�꿪������ָ���ڽ��뼰�˳�˯��ģʽʱ������
#define		LCD_STATIC_OFF		0xAC		//��̬ͼ��رգ���ָ���ڽ��뼰�˳�˯��ģʽʱ������

#define		LCD_CMD_NOP			0xE3


unsigned char const g_hoperf_logo_grap[512] =  { 
0XFF,0XFF,0XFF,0X7F,0X7F,0X7F,0X7F,0X7F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0X7F,0X7F,0X7F,0X7F,0XFF,0XFF,0XFF,0XFF,0XFF,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,
0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0XFF,0XFF,0XFF,0XFF,0XFF,0X7F,0X7F,0X7F,
0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,
0X7F,0X7F,0X7F,0X7F,0XFF,0XFF,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,
0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X7F,0X7F,0X7F,
0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0X7F,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0X00,0X00,0X00,0X00,0X00,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,
0X1F,0X00,0X00,0X00,0X00,0XFF,0XFF,0XFF,0X01,0X00,0X00,0X00,0XF0,0XF8,0XFC,0XFC,
0XFC,0XFC,0XFC,0XFC,0XFC,0XF0,0X00,0X00,0X00,0X01,0XFF,0XFF,0XFF,0X00,0X00,0X00,
0X00,0X3C,0X3C,0X3C,0X3C,0X3C,0X3C,0X3C,0X3C,0X38,0X00,0X00,0X00,0X00,0X81,0XFF,
0XFF,0X07,0X00,0X00,0X00,0X00,0X18,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,
0X1C,0X1C,0X1C,0X1C,0XFF,0XFF,0X00,0X00,0X00,0X00,0X00,0X3C,0X3C,0X3C,0X3C,0X3C,
0X3C,0X3C,0X3C,0X18,0X00,0X00,0X00,0X00,0XC3,0XFF,0XFF,0X01,0X00,0X00,0X00,0X00,
0X18,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0X1C,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0X80,0X80,0X80,0X80,0X80,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0X80,0X80,0X80,0X80,0XFF,0XFF,0XFF,0XF0,0XC0,0XC0,0X80,0X81,0X87,0X87,0X87,
0X87,0X87,0X87,0X87,0X87,0X83,0X80,0XC0,0XC0,0XE0,0XFF,0XFF,0XFF,0X80,0X80,0X80,
0X80,0XFE,0XFE,0XFE,0XFE,0XFE,0XFE,0XFE,0XFE,0XFE,0XFE,0XFE,0XFE,0XFF,0XFF,0XFF,
0XFF,0XF8,0XE0,0XC0,0X80,0X80,0X87,0X87,0X87,0X87,0X87,0X87,0X87,0X87,0X87,0X87,
0X87,0X87,0X87,0X87,0XFF,0XFF,0X80,0X80,0X80,0X80,0X80,0XFE,0XFE,0XFE,0XFC,0XF8,
0XF0,0XE0,0XC0,0X80,0X86,0X8E,0X9E,0XBF,0XFF,0XFF,0XFF,0X80,0X80,0X80,0X80,0X80,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X7F
};

unsigned char const g_cmostek_logo_grap[384] = { 							
0X00,0X80,0XE0,0XF0,0XF8,0XF8,0XFC,0XFC,0X7C,0X1E,0X1E,0X1E,0X1E,0X1E,0X1C,0X3C,
0X38,0X00,0X00,0X00,0XE0,0XFC,0XFC,0XFE,0XFE,0XFE,0XFE,0XF8,0XC0,0X00,0X00,0X00,
0X00,0XE0,0XF8,0XFC,0XFC,0XFE,0XFE,0XFE,0XFE,0XC0,0X00,0X00,0X80,0XE0,0XF0,0XF8,
0XFC,0XFC,0X3C,0X1E,0X0E,0X0E,0X1E,0X3E,0XFC,0XFC,0XF8,0XF8,0XF0,0XC0,0X00,0XE0,
0XF8,0XFC,0XFC,0XFC,0XFE,0X9E,0X0E,0X0E,0X0E,0X1E,0X1C,0X3C,0X38,0X00,0X1C,0X1C,
0X1E,0X1E,0XFE,0XFE,0XFE,0XFE,0XFE,0XFE,0X1E,0X1E,0X1E,0X1E,0X00,0X00,0XF8,0XFC,
0XFE,0XFE,0XFE,0XFE,0X1E,0X1E,0X1E,0X1E,0X1E,0X1E,0X1E,0X00,0X00,0XF8,0XFC,0XFC,

0XFE,0XFE,0XFE,0X00,0X80,0XE0,0XF0,0XFC,0XFC,0X7E,0X3E,0X1E,0X0E,0X02,0X00,0X00,
0X00,0X3F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XC0,0X80,0X00,0X00,0X00,0X00,0X00,0X80,
0XC0,0X00,0X00,0XC0,0XFF,0XFF,0XFF,0XFF,0XFF,0X07,0X3F,0XFF,0XFF,0XFF,0XF8,0XF8,
0XFF,0XFF,0XFF,0X3F,0X07,0XFF,0XFF,0XFF,0XFF,0XFF,0X80,0X00,0X7F,0XFF,0XFF,0XFF,
0XFF,0XFF,0XC0,0X00,0X00,0X00,0X00,0X80,0XFF,0XFF,0XFF,0XFF,0XFF,0X7F,0X04,0X00,
0X81,0X83,0X07,0X07,0X0F,0X0F,0X1F,0XBF,0XFE,0XFE,0XFC,0XF8,0XF8,0XE0,0X00,0X00,
0X00,0X00,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X00,0X00,0X00,0X00,0X00,0X00,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0X0E,0X0E,0X0E,0X0E,0X0E,0X0E,0X0E,0X00,0X00,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0X0F,0X3F,0X7F,0XFF,0XFF,0XF0,0XE0,0XC0,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X01,0X03,0X03,0X07,0X07,0X07,0X0F,0X0F,0X0F,0X0F,0X07,0X07,0X07,
0X03,0X00,0X00,0X07,0X07,0X07,0X07,0X07,0X07,0X00,0X00,0X01,0X07,0X07,0X07,0X07,
0X07,0X07,0X01,0X00,0X00,0X07,0X07,0X07,0X07,0X07,0X07,0X00,0X00,0X00,0X01,0X03,
0X07,0X07,0X07,0X0F,0X0F,0X0F,0X0F,0X07,0X07,0X07,0X03,0X01,0X00,0X00,0X00,0X00,
0X03,0X07,0X07,0X07,0X0F,0X0F,0X0F,0X0F,0X0F,0X07,0X07,0X03,0X03,0X00,0X00,0X00,
0X00,0X00,0X07,0X07,0X07,0X07,0X07,0X07,0X00,0X00,0X00,0X00,0X00,0X00,0X07,0X07,
0X07,0X07,0X07,0X07,0X07,0X07,0X07,0X07,0X07,0X07,0X07,0X00,0X00,0X07,0X07,0X07,
0X07,0X07,0X07,0X00,0X00,0X00,0X01,0X03,0X07,0X07,0X07,0X07,0X07,0X04,0X00,0X00,
};

unsigned char const g_arduino_logo_grap[1024] = { 
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0X7F,0X7F,0X3F,0X3F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,
0X3F,0X3F,0X3F,0X7F,0X7F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X7F,0X7F,0X3F,0X3F,0X3F,0X1F,0X1F,0X1F,
0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X3F,0X3F,0X3F,0X7F,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X7F,0X1F,0X0F,0X07,0X03,0X01,0X00,0X00,
0X80,0XC0,0XE0,0XF0,0XF0,0XF8,0XF8,0XF8,0XF8,0XF8,0XF8,0XF8,0XF8,0XF8,0XF8,0XF0,
0XF0,0XE0,0XE0,0XC0,0X80,0X00,0X01,0X01,0X03,0X07,0X0F,0X1F,0X3F,0XFF,0XFF,0XFF,
0X7F,0X3F,0X0F,0X07,0X03,0X03,0X01,0X00,0X80,0XC0,0XE0,0XE0,0XF0,0XF0,0XF0,0XF8,
0XF8,0XF8,0XF8,0XF8,0XF8,0XF8,0XF8,0XF8,0XF0,0XF0,0XE0,0XE0,0XC0,0X80,0X00,0X01,
0X03,0X07,0X0F,0X1F,0X7F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X03,0X00,0X00,0X00,0X00,0X00,0XF8,0XFE,0XFF,
0XFF,0XFF,0XFF,0XFF,0X3F,0X3F,0X3F,0X3F,0X3F,0X3F,0X3F,0X3F,0X3F,0X3F,0X3F,0X3F,
0X3F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFE,0XFC,0XF8,0XE0,0XC0,0X00,0X00,0X00,0X01,0X00,
0X00,0X00,0X00,0XE0,0XF0,0XFC,0XFE,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X1F,0X1F,0X1F,
0X1F,0X03,0X03,0X03,0X1F,0X1F,0X1F,0X1F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFC,
0XE0,0X00,0X00,0X00,0X00,0X01,0X1F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XE0,0X00,0X00,0X00,0X00,0X00,0X0F,0X3F,0X7F,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0X7F,0X3F,0X1F,0X07,0X03,0X00,0X00,0X00,0X80,0XC0,0X80,
0X00,0X00,0X00,0X03,0X07,0X1F,0X3F,0X7F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XF0,0XF0,0XF0,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X3F,0X3F,
0X01,0X00,0X00,0X00,0X00,0XC0,0XFC,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFE,0XF8,0XF0,0XE0,0XC0,0X80,0X80,
0X00,0X01,0X03,0X07,0X07,0X07,0X0F,0X0F,0X0F,0X0F,0X0F,0X0F,0X0F,0X0F,0X0F,0X07,
0X07,0X07,0X03,0X01,0X00,0X80,0XC0,0XC0,0XE0,0XF0,0XF8,0XFC,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFE,0XFC,0XF0,0XE0,0XE0,0XC0,0X80,0X00,0X01,0X03,0X03,0X07,0X07,0X0F,0X0F,
0X0F,0X0F,0X0F,0X0F,0X0F,0X0F,0X0F,0X0F,0X07,0X07,0X03,0X01,0X01,0X80,0X80,0XC0,
0XE0,0XF0,0XF8,0XFC,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X3F,0X3F,0X3F,0X7F,0XFF,
0XFF,0XFF,0XFE,0XFE,0X3E,0X3C,0X3C,0X3C,0X3C,0X3C,0X7C,0X7C,0XFC,0XFC,0XFC,0X3C,
0X3C,0X3E,0X3E,0X3F,0X3F,0X7F,0X7F,0XFF,0XFF,0XFF,0XFF,0X3F,0X3F,0XFF,0XFF,0XFF,
0XFF,0XFF,0X3F,0X3F,0XFF,0XFF,0XFF,0X3F,0X3F,0X3F,0X3E,0X3E,0X3E,0X3C,0X3C,0XFC,
0XFC,0XFC,0X3C,0X3C,0X7C,0XFC,0XFC,0XFC,0XFC,0X3E,0X3E,0XFE,0XFF,0XFF,0X7F,0X7F,
0X3F,0X3F,0X3F,0X3F,0X7F,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X0F,0X01,0X60,0X7E,0X7C,0X20,0X01,
0X1F,0XFF,0XFF,0XFF,0X00,0X00,0XCF,0XCF,0XCF,0X07,0X20,0X70,0XFF,0XFF,0XFF,0X00,
0X00,0XFF,0XFF,0XFF,0XFF,0XFE,0X18,0X00,0X83,0XFF,0XFF,0X00,0X00,0XFF,0XFF,0XFF,
0XFF,0XFF,0X00,0X00,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X00,0X00,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0X00,0X00,0XF8,0XE1,0X87,0X1F,0X3F,0X00,0X00,0XFF,0XFF,0X00,0X00,0XFE,
0XFF,0XFF,0XFF,0XFE,0X38,0X00,0X83,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,

0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XF8,0XF8,0XFE,0XFF,0XFF,0XFF,0XFF,0XFE,
0XF8,0XF8,0XFF,0XFF,0XF8,0XF8,0XFF,0XFF,0XFF,0XFF,0XFC,0XF8,0XF9,0XFF,0XFF,0XF8,
0XF8,0XF9,0XF9,0XF9,0XF9,0XFC,0XFC,0XFE,0XFF,0XFF,0XFF,0XFC,0XFC,0XF9,0XF9,0XF9,
0XF9,0XF8,0XFC,0XFE,0XFF,0XFF,0XFF,0XF9,0XF9,0XF9,0XF8,0XF8,0XF9,0XF9,0XF9,0XFF,
0XFF,0XFF,0XF8,0XF8,0XFF,0XFF,0XFF,0XFE,0XF8,0XF8,0XF8,0XFF,0XFF,0XFE,0XFC,0XF8,
0XF9,0XF9,0XF9,0XF8,0XFC,0XFE,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0X7F,
};

unsigned char const g_ascii_number_7x8[10][7] = {
	      {0x00, 0x3e, 0x51, 0x49, 0x45, 0x3e, 0x00}, //-0-
	      {0x00, 0x00, 0x42, 0x7f, 0x40, 0x00, 0x00}, //-1-
	      {0x00, 0x42, 0x61, 0x51, 0x49, 0x46, 0x00}, //-2-
	      {0x00, 0x21, 0x41, 0x45, 0x4b, 0x31, 0x00}, //-3-
	      {0x00, 0x18, 0x14, 0x12, 0x7f, 0x10, 0x00}, //-4-
	      {0x00, 0x27, 0x45, 0x45, 0x45, 0x39, 0x00}, //-5-
	      {0x00, 0x3c, 0x4a, 0x49, 0x49, 0x30, 0x00}, //-6-
	      {0x00, 0x01, 0x71, 0x09, 0x05, 0x03, 0x00}, //-7-
	      {0x00, 0x36, 0x49, 0x49, 0x49, 0x36, 0x00}, //-8-
	      {0x00, 0x06, 0x49, 0x49, 0x29, 0x1e, 0x00}, //-9-
                                       };

unsigned char const g_ascii_capital_7x8[26][7] = {
    	  {0x00, 0x7e, 0x11, 0x11, 0x11, 0x7e, 0x00}, //-A-
		  {0x00, 0x7f, 0x49, 0x49, 0x49, 0x36, 0x00}, //-B-
		  {0x00, 0x3e, 0x41, 0x41, 0x41, 0x22, 0x00}, //-C-
		  {0x00, 0x7f, 0x41, 0x41, 0x22, 0x1c, 0x00}, //-D-
		  {0x00, 0x7f, 0x49, 0x49, 0x49, 0x41, 0x00}, //-E-
		  {0x00, 0x7f, 0x09, 0x09, 0x09, 0x01, 0x00}, //-F-
		  {0x00, 0x3e, 0x41, 0x49, 0x49, 0x7a, 0x00}, //-G-
		  {0x00, 0x7f, 0x08, 0x08, 0x08, 0x7f, 0x00}, //-H-
		  {0x00, 0x00, 0x41, 0x7f, 0x41, 0x00, 0x00}, //-I-
		  {0x00, 0x20, 0x40, 0x41, 0x3f, 0x01, 0x00}, //-J-
		  {0x00, 0x7f, 0x08, 0x14, 0x22, 0x41, 0x00}, //-K-
		  {0x00, 0x7f, 0x40, 0x40, 0x40, 0x40, 0x00}, //-L-
		  {0x00, 0x7f, 0x02, 0x0c, 0x02, 0x7f, 0x00}, //-M-
		  {0x00, 0x7f, 0x04, 0x08, 0x10, 0x7f, 0x00}, //-N-
		  {0x00, 0x3e, 0x41, 0x41, 0x41, 0x3e, 0x00}, //-O-
		  {0x00, 0x7f, 0x09, 0x09, 0x09, 0x06, 0x00}, //-P-
		  {0x00, 0x3e, 0x41, 0x51, 0x21, 0x5e, 0x00}, //-Q-
		  {0x00, 0x7f, 0x09, 0x19, 0x29, 0x46, 0x00}, //-R-
		  {0x00, 0x46, 0x49, 0x49, 0x49, 0x31, 0x00}, //-S-
		  {0x00, 0x01, 0x01, 0x7f, 0x01, 0x01, 0x00}, //-T-
		  {0x00, 0x3f, 0x40, 0x40, 0x40, 0x3f, 0x00}, //-U-
		  {0x00, 0x1f, 0x20, 0x40, 0x20, 0x1f, 0x00}, //-V-
		  {0x00, 0x3f, 0x40, 0x38, 0x40, 0x3f, 0x00}, //-W-
		  {0x00, 0x63, 0x14, 0x08, 0x14, 0x63, 0x00}, //-X-
		  {0x00, 0x07, 0x08, 0x70, 0x08, 0x07, 0x00}, //-Y-
		  {0x00, 0x61, 0x51, 0x49, 0x45, 0x43, 0x00}, //-Z-                                   
                                        };									   
									   
unsigned char const g_ascii_lowercase_7x8[26][7] = {
	      {0x00, 0x20, 0x54, 0x54, 0x54, 0x78, 0x00}, //-a-
	      {0x00, 0x7f, 0x48, 0x48, 0x48, 0x30, 0x00}, //-b-
	      {0x00, 0x38, 0x44, 0x44, 0x44, 0x44, 0x00}, //-c-
	      {0x00, 0x30, 0x48, 0x48, 0x48, 0x7f, 0x00}, //-d-
	      {0x00, 0x38, 0x54, 0x54, 0x54, 0x58, 0x00}, //-e-
	      {0x00, 0x00, 0x08, 0x7e, 0x09, 0x02, 0x00}, //-f-
	      {0x00, 0x48, 0x54, 0x54, 0x54, 0x3c, 0x00}, //-g-
	      {0x00, 0x7f, 0x08, 0x08, 0x08, 0x70, 0x00}, //-h-
	      {0x00, 0x00, 0x00, 0x7a, 0x00, 0x00, 0x00}, //-i-
	      {0x00, 0x20, 0x40, 0x40, 0x3d, 0x00, 0x00}, //-j-
	      {0x00, 0x7f, 0x20, 0x28, 0x44, 0x00, 0x00}, //-k-
	      {0x00, 0x00, 0x41, 0x7f, 0x40, 0x00, 0x00}, //-l-
	      {0x00, 0x7c, 0x04, 0x38, 0x04, 0x7c, 0x00}, //-m-
	      {0x00, 0x7c, 0x08, 0x04, 0x04, 0x78, 0x00}, //-n-
	      {0x00, 0x38, 0x44, 0x44, 0x44, 0x38, 0x00}, //-o-
	      {0x00, 0x7c, 0x14, 0x14, 0x14, 0x08, 0x00}, //-p-
	      {0x00, 0x08, 0x14, 0x14, 0x14, 0x7c, 0x00}, //-q-
	      {0x00, 0x7c, 0x08, 0x04, 0x04, 0x08, 0x00}, //-r-
	      {0x00, 0x48, 0x54, 0x54, 0x54, 0x24, 0x00}, //-s-
	      {0x00, 0x04, 0x04, 0x3f, 0x44, 0x24, 0x00}, //-t-
	      {0x00, 0x3c, 0x40, 0x40, 0x40, 0x3c, 0x00}, //-u-
	      {0x00, 0x1c, 0x20, 0x40, 0x20, 0x1c, 0x00}, //-v-
	      {0x00, 0x3c, 0x40, 0x30, 0x40, 0x3c, 0x00}, //-w-
	      {0x00, 0x44, 0x28, 0x10, 0x28, 0x44, 0x00}, //-x-
	      {0x00, 0x04, 0x48, 0x30, 0x08, 0x04, 0x00}, //-y-
	      {0x00, 0x44, 0x64, 0x54, 0x4c, 0x44, 0x00}, //-z-	
                                        };

unsigned char const g_ascii_other_7x8[39][7] = {
	      {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, //space  -0
	      {0x00, 0x00, 0x00, 0x4f, 0x00, 0x00, 0x00}, //-!-    -1 
	      {0x00, 0x00, 0x07, 0x00, 0x07, 0x00, 0x00}, //-"-    -2
	      {0x00, 0x14, 0x7f, 0x14, 0x7f, 0x14, 0x00}, //-#-    -3
	      {0x00, 0x24, 0x2a, 0x7f, 0x2a, 0x12, 0x00}, //-$-    -4
	      {0x00, 0x23, 0x13, 0x08, 0x64, 0x62, 0x00}, //-%-    -5
	      {0x00, 0x36, 0x49, 0x55, 0x22, 0x50, 0x00}, //-&-    -6
	      {0x00, 0x00, 0x05, 0x07, 0x00, 0x00, 0x00}, //-'-    -7
	      {0x00, 0x00, 0x1c, 0x22, 0x41, 0x00, 0x00}, //-(-    -8
	      {0x00, 0x00, 0x41, 0x22, 0x1c, 0x00, 0x00}, //-)-    -9
	      {0x00, 0x14, 0x08, 0x3e, 0x08, 0x14, 0x00}, //-*-    -10
	      {0x00, 0x08, 0x08, 0x3e, 0x08, 0x08, 0x00}, //-+-    -11
	      {0x00, 0x00, 0x50, 0x30, 0x00, 0x00, 0x00}, //-,-    -12
	      {0x00, 0x08, 0x08, 0x08, 0x08, 0x08, 0x00}, //---    -13
	      {0x00, 0x00, 0x60, 0x60, 0x00, 0x00, 0x00}, //-.-    -14
	      {0x00, 0x20, 0x10, 0x08, 0x04, 0x02, 0x00}, //-/-    -15
	      {0x00, 0x00, 0x36, 0x36, 0x00, 0x00, 0x00}, //-:-    -16
	      {0x00, 0x00, 0x56, 0x36, 0x00, 0x00, 0x00}, //-;-    -17
	      {0x00, 0x08, 0x14, 0x22, 0x41, 0x00, 0x00}, //-<-    -18
	      {0x00, 0x14, 0x14, 0x14, 0x14, 0x14, 0x00}, //-=-    -19
	      {0x00, 0x00, 0x41, 0x22, 0x14, 0x08, 0x00}, //->-    -20
	      {0x00, 0x02, 0x01, 0x51, 0x09, 0x06, 0x00}, //-?-    -21
	      {0x00, 0x32, 0x49, 0x79, 0x41, 0x3e, 0x00}, //-@-    -22
	      {0x00, 0x00, 0x7f, 0x41, 0x41, 0x00, 0x00}, //-[-    -23
	      {0x00, 0x02, 0x04, 0x08, 0x10, 0x20, 0x00}, //-\-    -24
	      {0x00, 0x00, 0x41, 0x41, 0x7f, 0x00, 0x00}, //-]-    -25
	      {0x00, 0x04, 0x02, 0x01, 0x02, 0x04, 0x00}, //-^-    -26
	      {0x00, 0x40, 0x40, 0x40, 0x40, 0x40, 0x00}, //-_-    -27
	      {0x00, 0x01, 0x02, 0x04, 0x00, 0x00, 0x00}, //-`-    -28
	      {0x00, 0x08, 0x36, 0x41, 0x41, 0x00, 0x00}, //-{-    -29
	      {0x00, 0x00, 0x00, 0x77, 0x00, 0x00, 0x00}, //-|-    -30
	      {0x00, 0x00, 0x41, 0x41, 0x36, 0x08, 0x00}, //-}-    -31
	      {0x00, 0x04, 0x02, 0x02, 0x02, 0x01, 0x00}, //-~-    -32
		  {0x3C, 0x42, 0x42, 0x42, 0x42, 0x3C, 0x00}, //       -33   go
		  {0x20, 0x72, 0xAA, 0x22, 0x22, 0x22, 0x1C}, //       -34   ����
		  {0x00, 0x20, 0x40, 0xFF, 0x40, 0x20, 0x00}, //       -35   �¼�ͷ
	      {0x00, 0x04, 0x02, 0xFF, 0x02, 0x04, 0x00}, //       -36   �ϼ�ͷ
		  {0x10, 0x38, 0x54, 0x10, 0x10, 0x10, 0x1E}, //       -37   �س�
 		  {0x3C, 0x66, 0x5A, 0x5A, 0x5A, 0x66, 0x3C}, //       -38   �س�
			};   



void vDispInit(void)
{
 	vLcdInit();
}

void vDispOn(void)
{
 	vLcdEnable();
}

void vDispOff(void)
{
 	vLcdDisable();
}

void vDispFull(void)
{
 	vLcdFullDisplay();
}

void vDispClear(void)
{
 	vLcdClearScreen();
}

/**********************************************************
**Name:     vDispArduinoLogo
**Function: Show Arduino Logo
**Input:    positive for show positive or inverse
**Output:   none
**********************************************************/
void vDispArduinoLogo(unsigned char positive)
{
	unsigned char i, j;
	
	for(i=1; i<9; i++)
		{
		vLcdLocate(i, 1);
		for(j=0; j<128; j++)
 			{
 			if(positive!=0)
 				vLcdSendData((unsigned char)g_arduino_logo_grap[(((unsigned short int)(i-1))<<7)+j]^0xFF);	
 			else	
 				vLcdSendData((unsigned char)g_arduino_logo_grap[(((unsigned short int)(i-1))<<7)+j]);
 			}
		SET_LCD_CS();
		}
}

/**********************************************************
**Name:     vDispHopeRFLogo
**Function: Show HopeRF Logo
**Input:    line for start address(1-8), 
            positive for show positive or inverse
**Output:   none
**********************************************************/
void vDispHopeRFLogo(unsigned char line, unsigned char positive)
{
	unsigned char i, j;
	
	if((line==0)||(line>=9))
		line = 1;
	
	for(i=line; i<(line+4); i++)
		{
		vLcdLocate(i, 1);
		for(j=0; j<128; j++)
 			{
 			if(positive!=0)
 				vLcdSendData((unsigned char)g_hoperf_logo_grap[(((unsigned short int)(i-line))<<7)+j]^0xFF);	
 			else	
 				vLcdSendData((unsigned char)g_hoperf_logo_grap[(((unsigned short int)(i-line))<<7)+j]);
 			}
		SET_LCD_CS();
		}
}	

/**********************************************************
**Name:     vDispCmostekLogo
**Function: Show CMOSTEK Logo
**Input:    line for start address(1-8), 
            positive for show positive or inverse
**Output:   none
**********************************************************/
void vDispCmostekLogo(unsigned char line, unsigned char positive)
{
	unsigned char i, j;
	
	if((line==0)||(line>=9))
		line = 1;
	
	for(i=line; i<(line+3); i++)
		{
		vLcdLocate(i, 1);
		for(j=0;j<128;j++)
 			{
 			if(positive)
 				vLcdSendData((unsigned char)g_cmostek_logo_grap[(((unsigned short int)(i-line))<<7)+j]^0xFF);	
 			else	
 				vLcdSendData((unsigned char)g_cmostek_logo_grap[(((unsigned short int)(i-line))<<7)+j]);
 			}
		SET_LCD_CS();
		}
}	

	
/**********************************************************
**Name:     vDispGrap32x32
**Function: Show 32*32 grap.
**Input:    page, column, ptr
**Output:   none
**********************************************************/
void vDispGrap32x32(unsigned char page, unsigned char column, unsigned char *ptr)		
{
	unsigned char j;
	
	for(j=0; j<4; j++)
		{
		vLcdLocate(page+j, column);
		vLcdBurstSendData(ptr, 32);
		}
}

/**********************************************************
**Name:     vDispGrap16x16
**Function: Show 16*16 grap.
**Input:    page, column, ptr
**Output:   none
**********************************************************/
void vDispGrap16x16(unsigned char page, unsigned char column, unsigned char *ptr)		
{
	unsigned char j;
	
	for(j=0; j<2; j++)
		{
		vLcdLocate(page+j, column);
		vLcdBurstSendData(ptr, 16);
		}

}

/**********************************************************
**Name:     vDispGrap8x16
**Function: Show 8*16 grap.
**Input:    page, column, ptr
**Output:   none
**********************************************************/
void vDispGrap8x16(unsigned char page, unsigned char column, unsigned char *ptr)		
{
	unsigned char j;
	
	for(j=0; j<2; j++)
		{
		vLcdLocate(page+j, column);
		vLcdBurstSendData(ptr, 8);
		}
}

/**********************************************************
**Name:     vDispGrap8x8
**Function: Show 8*8 grap.
**Input:    page, column, ptr
**Output:   none
**********************************************************/
void vDispGrap8x8(unsigned char page, unsigned char column, unsigned char *ptr)		
{
 	vLcdLocate(page, column);
	vLcdBurstSendData(ptr, 8);
}

void vDispClearGrap8x8(unsigned char page, unsigned char column)		
{
	unsigned char ptr[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
 	vLcdLocate(page, column);
	vLcdBurstSendData(ptr, 8);
}

/**********************************************************
**Name:     vDispString8x8
**Function: Show 8*8 grap.
**Input:    page, column, text for string
**Output:   none
**********************************************************/
void vDispString8x8(unsigned char page, unsigned char column, unsigned char *text) 
{ 
 	unsigned char i;
 	unsigned char sptr[8];
 	i = 0;
 	
 	while(text[i]!='\0')				
 		{
 		vLcdGetASCII8x8(text[i], sptr);
 		vDispGrap8x8(page, column, sptr);
 		i++;
 		column += 8;
 		}
} 	

void vDispAscii(unsigned char page, unsigned char column, unsigned char ch)
{
	unsigned char sptr[8];
	vLcdGetASCII8x8(ch, sptr);
 	vDispGrap8x8(page, column*8, sptr);
}

/**********************************************************
**Name:     vDispSetDot
**Function: 
**Input:    
**Output:   none
**********************************************************/
void vDispSetDot(unsigned char x_axis, unsigned char y_axis)
{
 unsigned char  i, j;
 
 i = y_axis&0x07;
 
 for(j=0x01; i!=0; i--)
 	j <<= 1;
 	
 i = (y_axis>>3)+1;
 
 vLcdLocate(i, x_axis);
 vLcdSendData(j);
 SET_LCD_CS();	
}

void vDispFillDot(unsigned char x_axis, unsigned char y_axis)
{
 unsigned char i, j;
 
 i = y_axis&0x07;
 
 switch(i)
 	{
 	case 1: j = 0xFE; break;
 	case 2: j = 0xFC; break;
 	case 3: j = 0xF8; break;			
 	case 4: j = 0xF0; break;
 	case 5: j = 0xE0; break;
 	case 6: j = 0xC0; break;
 	case 7: j = 0x80; break;	
 	case 0:
 	default:j = 0x00; break;
 	}
 i = (y_axis>>3)+1;	
 
 vLcdLocate(i, x_axis);
 vLcdSendData(j);
 SET_LCD_CS();	
 
 i++;
 for( ; i<9; i++)
 	{
 	vLcdLocate(i, x_axis);
 	vLcdSendData(0xFF);
 	SET_LCD_CS();	
 	}
}

/**********************************************************
**Name:     vDispClrYaxis
**Function: 
**Input:    
**Output:   none
**********************************************************/
void vDispClrYaxis(unsigned char x_axis)
{
 unsigned char i;
 
 for(i=1; i<9; i++)
 	{	
 	vLcdLocate(i, x_axis);
 	vLcdSendData(0);
 	SET_LCD_CS();
	}
}
	


//***********************************************************************************************************************

/**********************************************************
**Name:     vLcdInit
**Function: Init. for JLX12864
**Input:    none
**Output:   none
**********************************************************/ 
void vLcdInit(void) 
{ 	
	vLcdGpioInit();
	
 	//ClrLRST();						//Hardware Reset
 	//_delay_us(10);
 	//SetLRST();
 	//_delay_ms(10);
 
 	vLcdSendCmd(LcdSoftReset);			//SoftReset
 	delay1ms(5);
 	vLcdSendCmd(0x2C);					//Set Power Control 3step or only set 0x2F
 	delay10us(2);
 	vLcdSendCmd(0x2E);
 	delay10us(2);
 	vLcdSendCmd(0x2F);
 	delay10us(2);
 	vLcdSendCmd(0x23);					//Set Vlcd Resistor Ratio, range for 0x20~0x27
 	vLcdSendDoubleByteCmd(0x81, 40);	//Set Electronic volume, range for 0x00~0x3F
 	vLcdSendCmd(0xA2);					//1/9 bias
 	vLcdSendCmd(0xC8);					//Set COM Direction, from top to button
 	vLcdSendCmd(0xA0);					//Set SEG Direction, from left to right
 	vLcdSendCmd(0x40);					//Set Scroll Line, for No.1 Line
 	vLcdEnable();						//Set Display enable, for 0xAE Disable
}	

/**********************************************************
**Name:     vLcdSendCmd
**Function: send command to JLX12864
**Input:    dat for command value (8bits)
**Output:   none
**********************************************************/
void vLcdSendCmd(unsigned char dat) 
{ 
 	unsigned char i;	

	vLcdSdioOutput();
	SET_LCD_SCK();
 	SET_LCD_ROM_CS();	
 	CLR_LCD_CS();
 	CLR_LCD_RS();
	
 	for(i=0; i<8; i++)
 		{
		CLR_LCD_SCK();
 		if(dat&0x80)
 			SET_LCD_SDIO();
 		else
 			CLR_LCD_SDIO();
		SET_LCD_SCK();
 		dat <<= 1;
 		}
 	
	SET_LCD_SCK();
 	SET_LCD_RS();
 	SET_LCD_CS();
 	SET_LCD_SDIO();
} 

/**********************************************************
**Name:     vLcdSendDoubleByteCmd
**Function: send double byte command to JLX12864
**Input:    cmd & value == 16bits command
**Output:   none
**********************************************************/
void vLcdSendDoubleByteCmd(unsigned char cmd, unsigned char value) 
{
	unsigned char  i;	
	unsigned short int dat;
		
	dat = (((unsigned short )cmd<<8)|value);
 	
	vLcdSdioOutput();
	SET_LCD_SCK();
 	SET_LCD_ROM_CS();	
 	CLR_LCD_CS();
 	CLR_LCD_RS();
 	
 	for(i=0; i<16; i++)
 		{
		CLR_LCD_SCK();
 		if(dat&0x8000)
 			SET_LCD_SDIO();
 		else
 			CLR_LCD_SDIO();
		SET_LCD_SCK();
 		dat <<= 1;
 		}
 	
	SET_LCD_SCK();
 	SET_LCD_RS();
 	SET_LCD_CS();
 	SET_LCD_SDIO();
}

/**********************************************************
**Name:     vLcdSendData
**Function: send data to JLX12864
**Input:    dat
**Output:   none
**********************************************************/
void vLcdSendData(unsigned char dat)
{
 	unsigned char i;
 	
	vLcdSdioOutput();
	SET_LCD_SCK();
 	SET_LCD_ROM_CS();	
 	CLR_LCD_CS();
 	SET_LCD_RS();

	for(i=0; i<8; i++)
 		{
 		CLR_LCD_SCK();
 		if(dat&0x80)
 			SET_LCD_SDIO();
 		else
 			CLR_LCD_SDIO();
		SET_LCD_SCK();
 		dat <<= 1;
 		}
	SET_LCD_SCK();
	SET_LCD_SDIO();
}	

/**********************************************************
**Name:     vLcdBurstSendData
**Function: continuous send data to JLX12864
**Input:    ptr & length
**Output:   none
**********************************************************/ 
void vLcdBurstSendData(unsigned char *ptr, unsigned char length)
{
	unsigned char i, j;	
 	unsigned char dat;
 	
 	if(length!=0)
 		{
		vLcdSdioOutput();
		SET_LCD_SCK();
 		
 		SET_LCD_ROM_CS();	
 	 	SET_LCD_RS();
 		CLR_LCD_CS();
		
		for(j=0; j<length; j++)
			{
			dat = ptr[j];
 			for(i=0; i<8; i++)
 				{
 				CLR_LCD_SCK();
 				if(dat&0x80)
 					SET_LCD_SDIO();
 				else
 					CLR_LCD_SDIO();
				SET_LCD_SCK();
 				dat <<= 1;
 				}
 			}	
		SET_LCD_SCK();
 		SET_LCD_CS();	
 		SET_LCD_SDIO();
		}
}

/**********************************************************
**Name:     vLcdEnable
**Function: turn on LCD
**Input:    none
**Output:   none
**********************************************************/  
void vLcdEnable(void) 
{
 	vLcdSendCmd(0xAF);
}

/**********************************************************
**Name:     vLcdDisable
**Function: turn off LCD
**Input:    none
**Output:   none
**********************************************************/   
void vLcdDisable(void)  
{
	vLcdSendCmd(0xAE);
}

/**********************************************************
**Name:     vLcdLocate
**Function: locate address for picture array
**Input:    page, column
**Output:   none
**********************************************************/   
void vLcdLocate(unsigned char page, unsigned char column)
{
	page -= 1;
	column -= 1;							//begin from 0
 	vLcdSendCmd(0xB0+page);					//full screen have 64lines, 8 pages, every page have 8lines
 	vLcdSendCmd(((column>>4)&0x0F)|0x10);	//set column address for MSB
 	vLcdSendCmd(column&0x0f);				//set column address for LSB
}

/**********************************************************
**Name:     vLcdClearScreen
**Function: clear screen
**Input:    none
**Output:   none
**********************************************************/   	
void vLcdClearScreen(void)
{
 	unsigned char i, j;
 	for(i=1; i<10; i++)	
 		{
 		vLcdLocate(i, 1);
 		for(j=0;j<132;j++)
 			vLcdSendData(0);
 		SET_LCD_CS();	
 		}
}

/**********************************************************
**Name:     vLcdFullDisplay
**Function: show full display
**Input:    none
**Output:   none
**********************************************************/ 
void vLcdFullDisplay(void)
{
	unsigned char i, j;
	for(i=1; i<9; i++)
		{
		vLcdLocate(i, 1);
		for(j=0;j<128;j++)
 			vLcdSendData(0xFF);
 		SET_LCD_CS();	
		}
}

/**********************************************************
**Name:     vLcdLibSend
**Function: send command to lib
**Input:    dat
**Output:   none
**********************************************************/ 
void vLcdLibSend(unsigned char dat)
{
 	unsigned char i;
 	
 	for(i=0; i<8; i++)
 		{
 		CLR_LCD_SCK();
 		if(dat&0x80)
 			SET_LCD_SDIO();
 		else
 			CLR_LCD_SDIO();
 		SET_LCD_SCK();
 		dat <<= 1;
 		}
}


/**********************************************************
**Name:     bLcdLibRead
**Function: read data from lib
**Input:    none
**Output:   data
**********************************************************/
unsigned char bLcdLibRead(void) 
{
	unsigned char i, dat;
	
	SET_LCD_SDIO();
	for(i=0; i<8; i++)
		{
		CLR_LCD_SCK();	
		dat <<= 1;	
		SET_LCD_SCK();		
		if(LCD_ROM_SDIO_H())
			dat |= 0x01;
		else
			dat |= 0x00;
		}
	return(dat);
}


/**********************************************************
**Name:     vLcdGetASCII8x8
**Function: read 8*8 ASCII array 
**Input:    none
**Output:   ptr
**********************************************************/
void vLcdGetASCII8x8(unsigned char ascii_code, unsigned char *ptr)				/*��ȡһ��ASCII�����飬7*8��ʽ*/
{
	unsigned short int addr;
	unsigned char i;	

	if((ascii_code>=0x20)&&(ascii_code<0x7F))
		{
		addr = ((unsigned short int)(ascii_code-0x20)<<3)+0x66C0;
		
  		vLcdSdioOutput();
 		SET_LCD_SCK();	
 		SET_LCD_CS();
 		SET_LCD_RS(); 	
 		CLR_LCD_ROM_CS();
 		
 		vLcdLibSend(0x0B);		//Fast Read
 		vLcdLibSend(0x00);
 		vLcdLibSend((unsigned char)(addr>>8));
 		vLcdLibSend((unsigned char)addr);
 		vLcdLibSend(0xAA);
 		
 		for(i=0; i<8; i++)
 			ptr[i] = bLcdLibRead();
 		
 		SET_LCD_SCK();
		SET_LCD_ROM_CS();
 		SET_LCD_SDIO();
		}	
}

/**********************************************************
**Name:     vLcdGpioInit
**Function: GPIO config init
**Input:    none
**Output:   none
**********************************************************/
void vLcdGpioInit(void)
{
	unsigned int tmp;

	
	//## pull-up or pull-down
	tmp  = GPIOA->PUPD;
	tmp &= LCD_PUPD_MASK;
	tmp |= LCD_PUPD_VAL;
	GPIOA->PUPD = tmp;

	//## sr 	
	tmp  = GPIOA->SR;
	tmp &= LCD_SR_MASK;
	tmp |= LCD_SR_VAL;
	GPIOA->SR  = tmp;

	//## push-pull output or open-drain 
	tmp  = GPIOA->POTYPE;
	tmp &= LCD_POTYPE_MASK;
	tmp |= LCD_POTYPE_VAL;
	GPIOA->POTYPE = tmp;

	//## mode		
	tmp  = GPIOA->PMODE;
	tmp &= LCD_PMODE_MASK;
	tmp |= LCD_PMODE_VAL;		
	GPIOA->PMODE = tmp;
}

void vLcdSdioOutput(void)
{
 	unsigned int tmp;
 	
	//## LCD_SDIO switch to Output mode
	tmp  = GPIOA->PMODE;
	tmp &= 0xFFFFFFFC;
	tmp |= 0x00000001;
	GPIOA->PMODE = tmp;  		
}

/**********************************************************
**Name:     vLcdPrintCapital
**Function: ��ӡ��д��ĸ
**Input:    line = 1-8ҳ������Ӧ����1-8��
**          col  = ��7x8�ַ�����ÿ�зֳ�18��������
**          cap  = ��ĸ���
**Output:   none
**********************************************************/ 
void vLcdPrintCapital(unsigned char line, unsigned char col, unsigned char ind)			//ָ��λ�ô�ӡһ����д�ַ�             //ÿ���ַ���ʱ0.25ms
{
	col  = (col*7+1);
	vLcdLocate(line, col);					
	vLcdBurstSendData((unsigned char*)g_ascii_capital_7x8[ind], 7);
}

void vLcdPrintLowercase(unsigned char line, unsigned char col, unsigned char ind)		//ָ��λ�ô�ӡһ��Сд�ַ� 
{
	col  = (col*7+1);
	vLcdLocate(line, col);					
	vLcdBurstSendData((unsigned char*)g_ascii_lowercase_7x8[ind], 7);
}

void vLcdPrintNumber(unsigned char line, unsigned char col, unsigned char ind)			//ָ��λ�ô�ӡһ������������
{
	col  = (col*7+1);
	vLcdLocate(line, col);					
	vLcdBurstSendData((unsigned char*)g_ascii_number_7x8[ind], 7);
}

void vLcdPrintOther(unsigned char line, unsigned char col, unsigned char ind)			//ָ��λ�ô�ӡһ���ض��ַ�
{
	col  = (col*7+1);
	vLcdLocate(line, col);					
	vLcdBurstSendData((unsigned char*)g_ascii_other_7x8[ind], 7);
}

void vLcdDrawDoubleLine(unsigned char line)												//ָ���л�һ��˫����
{
	unsigned char i;
	vLcdLocate(line, 1);
	for(i=0; i<128; i++)	
		vLcdSendData(0x14);
	SET_LCD_CS();
}	

void vLcdPrintString(byte line, const byte ch[])				//ָ���д�ӡһ���ַ�����ע��ÿ��֧��18���ַ�
{
	byte i;	
	byte cht;
 
	for(i=0; ch[i]!='\0'; i++)
		{
		cht = ch[i]; 	
		if((cht>='a')&&(cht<='z'))
			vLcdPrintLowercase(line, i, (cht-'a'));
		else if((cht>='A')&&(cht<='Z'))
			vLcdPrintCapital(line, i, (cht-'A'));
		else if((cht>='0')&&(cht<='9'))
			vLcdPrintNumber(line, i, (cht-'0'));
		else
			{}
		}
}

void vLcdPrintCounter(unsigned char line, unsigned char num, unsigned short int counter)
{
	unsigned char i;
	unsigned short int j;
	
	for(j=10000; j!=0; j/=10)
		{
		i = counter/j;
		counter %= j;
		vLcdPrintNumber(line, num++, i);
		}
}	



