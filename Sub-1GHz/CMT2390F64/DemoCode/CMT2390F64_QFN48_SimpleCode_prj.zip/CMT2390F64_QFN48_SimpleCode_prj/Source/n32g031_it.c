/**
 * @file 	n32g031_it.c
 * @author 	QY.Ruan
 * @version v1.0.0
 *
 * @copyright Copyright (c) 2021, CMOSTEK Microelectronics Co., Ltd. All rights are reserved.
 */
#include "n32g031_it.h"
#include "cmt2390f64_eb.h"

/** @addtogroup N32G031_StdPeriph_Template
 * @{
 */

/******************************************************************************/
/*            Cortex-M0 Processor Exceptions Handlers                         */
/******************************************************************************/

extern __IO uint32_t IsrStack;

/**
 * @brief  This function handles NMI exception.
 */
void NMI_Handler(void)
{
}

/**
 * @brief  This function handles Hard Fault exception.
 */
void HardFault_Handler(void)
{
    /* Go to infinite loop when Hard Fault exception occurs */
    while(1);
}

/**
 * @brief  This function handles SVCall exception.
 */
void SVC_Handler(void)
{
}

/**
 * @brief  This function handles PendSV_Handler exception.
 */
void PendSV_Handler(void)
{
}

/**
 * @brief  This function handles RCC interrupt request.
 */
void RCC_IRQHandler(void)
{
    if (RCC_GetIntStatus(RCC_INT_PLLRDIF) != RESET)
		{
        RCC_ClrIntPendingBit(RCC_CLR_PLLRDIF);						// Clear PLLRDY interrupt pending bit
        if (RCC_GetFlagStatus(RCC_CTRL_FLAG_PLLRDF) != RESET)		// Check if the PLL is still locked
            RCC_ConfigSysclk(RCC_SYSCLK_SRC_PLLCLK);		        // Select PLL as system clock source
    }
}

/**
 * @brief  This function handles the PVD Output interrupt request defined in main.h .
 */

void EXTI4_15_IRQHandler(void)
{
    if (EXTI_GetITStatus(EXTI_LINE6) != RESET)
        EXTI_ClrITPendBit(EXTI_LINE6);		// Clear the Key Button EXTI line pending bit
    if (EXTI_GetITStatus(EXTI_LINE7) != RESET)
		EXTI_ClrITPendBit(EXTI_LINE7);
}

/******************************************************************************/
/*                 N32G031 Peripherals Interrupt Handlers                     */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_n32g031.s).                                                 */
/******************************************************************************/

/**
 * @brief  This function handles TIM3 global interrupt request.
 */
void TIM3_IRQHandler(void)
{
    if (TIM_GetIntStatus(TIM3, TIM_INT_UPDATE) != RESET)
		{
        TIM_ClrIntPendingBit(TIM3, TIM_INT_UPDATE);
		g_systimer++;
		g_keytimer++;
		}
}


/**
 * @brief  This function handles PPP interrupt request.
 */
/*void PPP_IRQHandler(void)
{
}*/

/**
 * @}
 */
