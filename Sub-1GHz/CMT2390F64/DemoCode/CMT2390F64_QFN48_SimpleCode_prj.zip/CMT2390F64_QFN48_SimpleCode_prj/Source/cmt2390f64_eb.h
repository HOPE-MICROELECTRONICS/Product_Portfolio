
#ifndef		__CMT2380F64_EB_H__
	
	#define __CMT2380F64_EB_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif

	#include "n32g031.h"
	#include "n32g031_gpio.h"
	#include "lcd.h"
	#include "hal.h"
	#include "dll.h"
	#include "radio.h"

	#include <stdio.h>

	#define		CLOCK_MODE			0		//0=HSI,  8MHz, 
											//1=HSE, 12MHz, (!! 2390F64 not support)
											//2=PLL(base on HSI), 24MHz	
											//3=PLL(base on HSI), 32MHz
											//4=PLL(base on HSI), 48MHz
											//5=PLL(base on HSE), 24MHz (!! 2390F64 not support)
											//6=PLL(base on HSE), 36MHz (!! 2390F64 not support) 
											//7=PLL(base on HSE), 48MHz	(!! 2390F64 not support)		

	#define		ANT_DIVERSITY_MODE
	
	#define		UHF_LEN				10
	
	#define		LIMIT_TIMER_TX_CNT	100

	//***************************************************************************
	// vars
	//***************************************************************************
	extern word 		g_systimer;
	extern word 		g_keytimer;	
	extern byte			g_key_value;
	extern boolean_t	g_key_press_F;


	extern byte   	 	radio_rx_buf[UHF_LEN];
	extern byte 		radio_tx_buf[UHF_LEN];
	extern word 		g_rx_count;
	extern word 		g_tx_count;


	//***************************************************************************
	// functions
	//***************************************************************************
	//main.c
	extern void vNvicConfiguration(void);
	extern void vBeep(void);
	extern void vGetTxBuf(void);
	extern void vMcuInit(void);
	extern byte bReadKey(void);
	extern byte bKeyscan(void);
	


	#ifdef	__cplusplus
		}
	#endif

#endif 






