/**
 * @file   	main.c
 * @author 	QY.Ruan
 * @version v1.0.0
 *
 * @copyright Copyright (c) 2021, CMOSTEK Microelectronics Co., Ltd. All rights are reserved.
 */
#include "cmt2390f64_eb.h"


word 		g_systimer;
word 		g_keytimer;				//����ʶ��ʱ��
byte		g_key_value;
boolean_t	g_key_press_F;

byte   	 	radio_rx_buf[UHF_LEN];
byte 		radio_tx_buf[UHF_LEN];
word 		g_rx_count;
word 		g_tx_count;

boolean_t	g_ant_1st_lock_F;


#define		WORK_MODE		1		// 3 = transmit zero
									// 2 = receive mode for sensisity test
									// 1 = transmit packet test
									// 0 = receive packet test		

int main(void)
{
	byte i;
	
	vMcuInit();

	delay1ms(1000);
	vBeep();
	
	
	vSpiMasterInit();
	
	g_ant_1st_lock_F = FALSE;
	
 #if (WORK_MODE==3)										//test cw tx	
	vRadioInit();
	
	#ifdef	ANT_DIVERSITY_MODE	
		vRadioAntennaDiversityManualModeCfg(TRUE);		//select manual antenna diversity
		vRadioAntennaDiversityCompareModeCfg(FALSE);	//whatever
		vRadioAntennaDiversityDetWindowCfg(CMT2310A_ANT_WAIT_3_UNIT);
		vRadioAntennaDiversitySelectAntenna(FALSE);		//select antenna1
		vRadioAntennaDiversityCfg(TRUE);
	#endif		

	vRadioClearInterrupt(); 
	vCWTransmitInit();
	while(1);
 #endif	


 #if (WORK_MODE==2)		   								//test base rx mode
	vRadioInit();

	#ifdef	ANT_DIVERSITY_MODE	
		vRadioAntennaDiversityManualModeCfg(TRUE);		//select auto antenna diversity
		vRadioAntennaDiversityCompareModeCfg(FALSE);	//compare between ant1 & ant2
		vRadioAntennaDiversityDetWindowCfg(CMT2310A_ANT_WAIT_3_UNIT);
		vRadioAntennaDiversitySelectAntenna(FALSE);		//whatever
		vRadioAntennaDiversityCfg(TRUE);
	#endif		

	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_WBYTE);
	bRadioGoRx();
	SET_LED1();
	SET_LED2();
	while(1)
		{
		if(RF_GPIO4_H())
			{
			CLR_LED2();	
			vRadioClearRxFifo();	
			vRadioClearInterrupt(); 
			bRadioGoRx();
			}
		}
 #endif

 #if (WORK_MODE==1)										//test transmit packet mode
	vRadioInit();

	#ifdef	ANT_DIVERSITY_MODE	
		vRadioAntennaDiversityManualModeCfg(TRUE);		//select manual antenna diversity
		vRadioAntennaDiversityCompareModeCfg(FALSE);	//whatever
		vRadioAntennaDiversityDetWindowCfg(CMT2310A_ANT_WAIT_3_UNIT);
		vRadioAntennaDiversitySelectAntenna(FALSE);		//select antenna1
		vRadioAntennaDiversityCfg(TRUE);
	#endif

	while(1)
		{
		CLR_LED1();
		vRadioSetInt1Sel(CMT2310A_INT_TX_DONE);
		vRadioSetInt2Sel(CMT2310A_INT_TX_FIFO_NMTY);	
		g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
		vRadioSetPayloadLength(&g_radio.frame_cfg);
		vGetTxBuf();
		vRadioWriteFifo(radio_tx_buf, UHF_LEN);
		bRadioGoTx();
		for(g_systimer=0; g_systimer<LIMIT_TIMER_TX_CNT; )
			{
			if(RF_GPIO4_H())
				{
				bRadioGoStandby();
				vRadioClearTxFifo();
				vRadioClearInterrupt();
				g_tx_count++;
				break;
				}
			}
		if(g_systimer>=LIMIT_TIMER_TX_CNT)
			bRadioGoStandby();
		SET_LED1();
//		for(g_systimer=0; g_systimer<25; )
//			{
//			if(bKeyscan())
//				g_tx_count = 0;
//			}
		}
 #endif


 #if (WORK_MODE==0)										//test receive packet mode
	vRadioInit();

	#ifdef	ANT_DIVERSITY_MODE	
		vRadioAntennaDiversityManualModeCfg(FALSE);		//select auto antenna diversity
		vRadioAntennaDiversityCompareModeCfg(FALSE);	//compare between ant1 & ant2
		vRadioAntennaDiversityDetWindowCfg(CMT2310A_ANT_WAIT_3_UNIT);
		vRadioAntennaDiversitySelectAntenna(FALSE);		//whatever
		vRadioAntennaDiversityLockInterrupt(TRUE);
		vRadioAntennaDiversityCfg(TRUE);
	#endif		
	
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
	
	#ifdef	ANT_DIVERSITY_MODE
		vRadioSetInt2Sel(CMT2310A_INT_ANT_LOCK);
	#else
		vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_WBYTE);
	#endif
	
	bRadioGoRx();	
	while(1)
		{
	#ifdef	ANT_DIVERSITY_MODE		
		if(RF_GPIO5_H())
			{
			if(!g_ant_1st_lock_F)
				{
				g_systimer = 0;
				g_ant_1st_lock_F = TRUE;
				}
			if(g_systimer>=100)
				{
				bRadioGoStandby();
				vRadioClearInterrupt();				//include AntLockClear				
				//vRadioAntennaDiversityLockClear();
				g_ant_1st_lock_F = FALSE;
				bRadioGoRx();	
				}
			}
	#endif
			
		if(RF_GPIO4_H())
			{
			if(g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_EN==1)
				{
				vRadioInterruptSoucreFlag(&g_radio.int_src_flag);
				if(g_radio.int_src_flag._BITS.CRC_PASS_FLG==1)
					{
					CLR_LED2();
					g_rx_count++;
					}
				}
			else
				g_rx_count++;
			vRadioReadFifo(radio_rx_buf, UHF_LEN);
			vRadioClearRxFifo();	
			vRadioClearInterrupt(); 
			delay1ms(50);
			g_ant_1st_lock_F = FALSE;
			bRadioGoRx();	
			SET_LED2();
			}
		if(bKeyscan())
			{
			g_rx_count = 0;
			}
		}

 #endif
}

void vNvicConfiguration(void)
{
    NVIC_InitType NVIC_InitStructure;

    /* Enable and configure RCC global IRQ channel */
    NVIC_InitStructure.NVIC_IRQChannel         = RCC_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd      = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void vBeep(void)
{
	SET_BUZZ();
	for(g_systimer=0; g_systimer<10; )
		delay1ms(1);
	CLR_BUZZ();
}

void vGetTxBuf(void)										//��ȡ�����
{
	word i;

	for(i=0; i<UHF_LEN; i++)
		radio_tx_buf[i] = (byte)i;

}	

/********************************
**Name: vMcuInit
**Func: Initial uC Control
*Input: None
Output: None
********************************/
void vMcuInit(void)
{
	RCC_ClocksType RCC_temp;

	vGpioInit();

	vSetSysClockToHSI();
	RCC_GetClocksFreqValue(&RCC_temp);	
	SystemCoreClock = 8000000;	
	delay1ms(100);
	
	vGpioInit();	
	
	switch(CLOCK_MODE)
		{
		case 7:
			vSetSysClockToPLL(48000000, SYSCLK_USE_HSE);
			RCC_GetClocksFreqValue(&RCC_temp);	
			SystemCoreClock = 48000000;	
			break;
		case 6:
			vSetSysClockToPLL(36000000, SYSCLK_USE_HSE);
			RCC_GetClocksFreqValue(&RCC_temp);	
			SystemCoreClock = 36000000;	
			break;
		case 5:
			vSetSysClockToPLL(24000000, SYSCLK_USE_HSE);
			RCC_GetClocksFreqValue(&RCC_temp);	
			SystemCoreClock = 24000000;	
			break;
		case 4:
			vSetSysClockToPLL(48000000, SYSCLK_USE_HSI);
			RCC_GetClocksFreqValue(&RCC_temp);	
			SystemCoreClock = 48000000;	
			break;
		case 3:
			vSetSysClockToPLL(32000000, SYSCLK_USE_HSI);
			RCC_GetClocksFreqValue(&RCC_temp);	
			SystemCoreClock = 32000000;	
			break;
		case 2:
			vSetSysClockToPLL(24000000, SYSCLK_USE_HSI);
			RCC_GetClocksFreqValue(&RCC_temp);	
			SystemCoreClock = 24000000;	
			break;
		case 1:
			vSetSysClockToHSE();
			RCC_GetClocksFreqValue(&RCC_temp);	
			SystemCoreClock = 12000000;	
			break;
		case 0:
		default: break;
		}	
	
	vNvicConfiguration();
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_PWR, ENABLE);
    //DBG_ConfigPeriph(DBG_STOP, ENABLE);				//## Enable the DBG_STOP to keep debug in low power

	vTimer3Configuration();
}	

//*************************************************************************************************
//keyborad interface
//*************************************************************************************************
byte bReadKey(void)
{
	byte key = 0;
	
	if(KEY1_L())
		key |= 0x01;
	if(KEY2_L())
		key |= 0x02;
	if(KEY3_L())
		key |= 0x04;
	if(KEY4_L())
		key |= 0x08;
	
	return(key);
}

byte bKeyscan(void)								//return: 1-short press, 2-2s-press, 3-press & hold,  0-none
{
	byte key = 0;
	
	key = bReadKey();
	 
	if(key!=0)
		{
		if(g_key_press_F==0)					//1st trigger
			{
			g_keytimer = 0;
			do
				{
				if(bReadKey()==0)
					break;
				delay1ms(5);
				}while(g_keytimer<5);
			if(g_keytimer>=5)
				{
				g_key_press_F = 1;
				g_key_value = bReadKey();
				return(1);						//trigger active
				}	
			else
				{
				g_key_press_F = 0;	
				return(0);
				}
			}
		else									//hold
			{
			if(key==g_key_value)				//keep on
				{
				if(g_keytimer>=200)
					{
					g_keytimer = 200;	
					return(3);					//hold for 2s
					}
				else
					return(2);				
				}
			else								//press change
				{	
				g_keytimer = 0;							
				g_key_value = key;
				return(1);	
				}
			}
		}
	else										//none
		{
		g_key_press_F = 0;
		return(0);	
		}
}
