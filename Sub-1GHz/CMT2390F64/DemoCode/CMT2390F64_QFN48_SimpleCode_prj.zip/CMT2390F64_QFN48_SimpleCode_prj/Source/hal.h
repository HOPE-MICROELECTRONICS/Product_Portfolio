


#ifndef		__HAL_H__
	
	#define __HAL_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif

	#include "n32g031.h"
	#include "n32g031_gpio.h"
	#include "n32g031_tim.h"
	
	
	#define 	SYSCLK_USE_HSI     	0
	#define 	SYSCLK_USE_HSE     	1
	#define 	SYSCLK_USE_HSI_PLL 	2
	#define 	SYSCLK_USE_HSE_PLL 	3
	#define 	SYSCLK_USE_LSE     	4
	#define 	SYSCLK_USE_LSI     	5	


	//***************************************************************************
	//GPIO                                                                       
	//mode:  2'b, 00(input), 01(output),  10(func),      11(analog)
	//type:  1'b, 0(push-pull),    1(open-drain)
	//sr:	 1'b, 0(quick toggle), 1(low speed)
	//pu/pd: 2'b, 00(none),  01(pull-up), 10(pull-down), 11(resv)
	//pod:   1'b, 0(output-high),  1(output-low)
	//pbsc:  1'b, 0(none),         1(set or clear)
	//af:    4'b,                                             
	//ds:    1'b, 0(high-drv), 	   1(low-drv)
	//***************************************************************************
	
	//----------------PORTA-------------------------mode-----type---sr---pu/pd---pod----af----ds
	//#define	PA0				GPIO_PIN_0	    //  01	      0     0     00      0    0000   0    
	//#define	PA1				GPIO_PIN_1      //  01        0     0     00      0    0000   0
	//#define	PA2				GPIO_PIN_2      //  01        0     0     00      0    0000   0 
 	//#define	PA3				GPIO_PIN_3      //  01        0     0     00      0    0000	  0
 	//#define	PA4				GPIO_PIN_4      //  01        0     0     00      0    0000   0
	//#define	PA5				GPIO_PIN_5      //  01        0     0     00      0    0000   0
	//#define	PA6				GPIO_PIN_6      //  01        0     0     00      0    0000   0
	//#define	PA7				GPIO_PIN_7      //  01        0     0     00      0    0000   0
	//#define	RF_CSB			GPIO_PIN_8      //  00        0     0     00      0    0000   0		**
	#define		UART_RxD		GPIO_PIN_9      //  10        0     0     00      1    0100   0     **
	#define		UART_TxD		GPIO_PIN_10     //  10        0     0     00      1    0100   0     **
	//#define	PA11			GPIO_PIN_11     //  01        0     0     00      0    0000   0
	//#define	PA12			GPIO_PIN_12     //  01        0     0     00      0    0000   0
	//#define	SWD_SWDIO		GPIO_PIN_13     //  10        0     0     01      0    0000   0     **
	//#define	SWD_SWCLK		GPIO_PIN_14     //  10        0     0     10      0    0000   0     **
	//#define	PA15			GPIO_PIN_15     //  01        0     0     00      0    0000   0   

	#define		LED1			GPIO_PIN_9		//  01		  0     0     00      1    0000   0 
	#define		LED2			GPIO_PIN_10		//  01        0     0     00      1    0000   0
	#define		LCD_LED			GPIO_PIN_14     //  01        0     0     00      0    0000   0��
	
	//----------------PORTB-------------------------mode-----type---sr---pu/pd---pod----af----ds      
 	//#define					GPIO_PIN_0		//  01        0     0     00      0    0000   0
	//#define					GPIO_PIN_1      //  01        0     0     00      0    0000   0
	//#define					GPIO_PIN_2      //  01        0     0     00      0    0000   0
	#define		KEY3			GPIO_PIN_3      //  00        0     0     01      0    0000	  0     
	//#define	RF_GPIO5		GPIO_PIN_4      //  00        0     0     10      0    0000   0     
	#define		BUZZ			GPIO_PIN_5      //  01        0     0     00      0    0000   0
	#define		KEY2			GPIO_PIN_6      //  00        0     0     01      0    0000   0
	#define		KEY1			GPIO_PIN_7      //  00        0     0     01      0    0000   0
	//#define	PB8				GPIO_PIN_8      //  01        0     0     00      0    0000   0
	//#define	PB9				GPIO_PIN_9      //  01        0     0     00      0    0000   0
	//#define	PB10			GPIO_PIN_10     //  01        0     0     00      0    0000   0
	//#define	PB11			GPIO_PIN_11     //  01        0     0     00      0    0000   0
	#define		KEY4			GPIO_PIN_12     //  00        0     0     01      0    0000   0
	//#define	RF_SCK			GPIO_PIN_13     //  00        0     0     00      0    0000   0
	//#define	RF_MISO			GPIO_PIN_14     //  00        0     0     00      0    0000   0
	//#define	RF_MOSI			GPIO_PIN_15     //  00        0     0     00      0    0000   0      

	//----------------PORTC-------------------------mode-----type---sr---pu/pd---pod----af----ds  
	//#define	RF_GPIO4		GPIO_PIN_13		//	00        0     0     10      0    0000   0
	//#define	LSE_XI			GPIO_PIN_14     //	01        0     0     00      0    0000   0
	//#define	LSE_XO			GPIO_PIN_15     //	01        0     0     00      0    0000   0
	
	//----------------PORTF-------------------------mode-----type---sr---pu/pd---pod----af----ds  
	//#define	PF0				GPIO_PIN_0		//	01        0     0     00      0    0000   0
	//#define	PF1				GPIO_PIN_1		//	01        0     0     00      0    0000   0	
	//#define					GPIO_PIN_6		//	00        0     0     00      0    0000   0
	//#define					GPIO_PIN_7		//	00        0     0     00      0    0000   0	

	#define		GPIOA_PMODE_VAL1	0x69685555		//PA9/PA10 for UART1
	#define		GPIOA_PMODE_VAL2	0x69545555		//PA9/PA10 for LED
	#define		GPIOB_PMODE_VAL		0x00550415
	#define		GPIOC_PMODE_VAL		0x50000000
	#define		GPIOF_PMODE_VAL		0x00000005

	#define		GPIOA_PMODE_MASK	0x3C000000		//for swd

	#define		GPIOA_POTYPE_VAL	0x00000000
	#define		GPIOB_POTYPE_VAL	0x00000000
	#define		GPIOC_POTYPE_VAL	0x00000000
	#define		GPIOF_POTYPE_VAL	0x00000000
	
	#define		GPIOA_SR_VAL		0x00000000
	#define		GPIOB_SR_VAL		0x00000000
	#define		GPIOC_SR_VAL		0x00000000
	#define		GPIOF_SR_VAL		0x00000000

	#define		GPIOA_PUPD_VAL		0x24000000
	#define		GPIOB_PUPD_VAL		0x01005240
	#define		GPIOC_PUPD_VAL		0x08000000
	#define		GPIOF_PUPD_VAL		0x00000000
	
	#define		GPIOA_POD_VAL		0x00000600
	#define		GPIOB_POD_VAL		0x00000000
	#define		GPIOC_POD_VAL		0x00000000
	#define		GPIOF_POD_VAL		0x00000000
	
	#define		GPIOA_DS_VAL		0x00000000
	#define		GPIOB_DS_VAL		0x00000000
	#define		GPIOC_DS_VAL		0x00000000
	#define		GPIOF_DS_VAL		0x00000000

	#define		GPIOA_AFL_VAL		0xFFFFFFFF
	#define		GPIOA_AFH_VAL		0xF00FFFFF
	#define		GPIOB_AFL_VAL		0xFFFFFFFF
	#define		GPIOB_AFH_VAL		0xFFFFFFFF
	#define		GPIOF_AFL_VAL		0xFFFFFFFF	
	#define		GPIOF_AFH_VAL		0x00000000

	//output	
	#define		SET_LED1()		(GPIOA->PBSC=LED1)
	#define		CLR_LED1()		(GPIOA->PBC=LED1)
	
	#define		SET_LED2()		(GPIOA->PBSC=LED2)
	#define		CLR_LED2()		(GPIOA->PBC=LED2)
	
	#define		SET_BUZZ()		(GPIOB->PBSC=BUZZ)
	#define		CLR_BUZZ()		(GPIOB->PBC=BUZZ)
	
	//input
	#define		KEY1_H()		((GPIOB->PID&KEY1)==KEY1)
	#define		KEY1_L()		((GPIOB->PID&KEY1)==0)
	
	#define		KEY2_H()		((GPIOB->PID&KEY2)==KEY2)
	#define		KEY2_L()		((GPIOB->PID&KEY2)==0)	

	#define		KEY3_H()		((GPIOB->PID&KEY3)==KEY3)
	#define		KEY3_L()		((GPIOB->PID&KEY3)==0)	

	#define		KEY4_H()		((GPIOB->PID&KEY4)==KEY4)
	#define		KEY4_L()		((GPIOB->PID&KEY4)==0)	

	
	// vars
	extern RCC_ClocksType 	RCC_ClockFreq;
	extern ErrorStatus 	HSEStartUpStatus;
	extern ErrorStatus 	HSIStartUpStatus;
	
	
	// apis
	extern void vGpioInit(void);
	extern void vKeyInputExtiInit(FunctionalState cmd);
	extern void vTimer3Configuration(void);

	extern void vSetSysClockToHSI(void);
	extern void vSetSysClockToHSE(void);
	extern void vSetSysClockToPLL(uint32_t freq, uint8_t src);
	extern void vSetSysClock_LSI(void);
	extern void vSetSysClock_LSE(void);	
	

	#ifdef	__cplusplus
		}
	#endif

#endif 
	
