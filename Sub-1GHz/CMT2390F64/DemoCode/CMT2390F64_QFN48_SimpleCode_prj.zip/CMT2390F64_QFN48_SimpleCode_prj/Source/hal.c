#include "hal.h"

RCC_ClocksType 	RCC_ClockFreq;
ErrorStatus 	HSEStartUpStatus;
ErrorStatus 	HSIStartUpStatus;

void vGpioInit(void)
{
	uint32_t tmp;

	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOF, ENABLE);	
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO,  ENABLE);	
	
	
	//## ds
	GPIOA->DS   = GPIOA_DS_VAL;
	GPIOB->DS   = GPIOB_DS_VAL;
	GPIOC->DS   = GPIOC_DS_VAL;
	GPIOF->DS   = GPIOF_DS_VAL;

	//## output value
	GPIOA->POD  = GPIOA_POD_VAL;
	GPIOB->POD  = GPIOB_POD_VAL;
	GPIOC->POD  = GPIOC_POD_VAL;
	GPIOF->POD  = GPIOF_POD_VAL;
	
	//## pull-up or pull-down
	GPIOA->PUPD = GPIOA_PUPD_VAL;
	GPIOB->PUPD = GPIOB_PUPD_VAL;	
	GPIOC->PUPD = GPIOC_PUPD_VAL;
	GPIOF->PUPD = GPIOF_PUPD_VAL;

	//## push-pull output or open-drain 
	GPIOA->POTYPE = GPIOA_POTYPE_VAL;
	GPIOB->POTYPE = GPIOB_POTYPE_VAL;
	GPIOC->POTYPE = GPIOC_POTYPE_VAL;
	GPIOF->POTYPE = GPIOF_POTYPE_VAL;

	//## sr 	
	GPIOA->SR  = GPIOA_SR_VAL;
	GPIOB->SR  = GPIOB_SR_VAL;
	GPIOC->SR  = GPIOC_SR_VAL;
	GPIOF->SR  = GPIOF_SR_VAL;

	//## af
	GPIOA->AFL = GPIOA_AFL_VAL;
	GPIOA->AFH = GPIOA_AFH_VAL;
	GPIOB->AFL = GPIOB_AFL_VAL;
	GPIOB->AFH = GPIOB_AFH_VAL;
	GPIOF->AFL = GPIOF_AFL_VAL;
	GPIOF->AFH = GPIOF_AFH_VAL;
	
	//## mode		
	tmp  = GPIOA->PMODE;
	tmp &= GPIOA_PMODE_MASK;
	tmp |= GPIOA_PMODE_VAL2;			//for LED
	GPIOA->PMODE = tmp;

	GPIOB->PMODE  = GPIOB_PMODE_VAL;
	GPIOC->PMODE  = GPIOC_PMODE_VAL;
	GPIOF->PMODE  = GPIOF_PMODE_VAL;
}

/**
 * @brief  Configures key GPIO.
 * @param key Specifies the Led to be configured.
 *   This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void vKeyInputExtiInit(FunctionalState cmd)
{
    EXTI_InitType EXTI_InitStructure;
    NVIC_InitType NVIC_InitStructure;

    /*Configure key EXTI Line to key input  Pin*/
	GPIO_ConfigEXTILine(GPIOB_PORT_SOURCE, GPIO_PIN_SOURCE6);
    GPIO_ConfigEXTILine(GPIOB_PORT_SOURCE, GPIO_PIN_SOURCE7);

    /*Configure key EXTI line*/
    EXTI_InitStructure.EXTI_Line = (EXTI_LINE6+EXTI_LINE7);
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;

    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;

	if(cmd != DISABLE)	
		EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	else
		EXTI_InitStructure.EXTI_LineCmd = DISABLE;
    EXTI_InitPeripheral(&EXTI_InitStructure);

    /*Set key input interrupt priority*/
    NVIC_InitStructure.NVIC_IRQChannel         = EXTI4_15_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 2;
	if(cmd != DISABLE)	
		NVIC_InitStructure.NVIC_IRQChannelCmd  = ENABLE;
	else
		NVIC_InitStructure.NVIC_IRQChannelCmd  = DISABLE;
	
    NVIC_Init(&NVIC_InitStructure);
}


/**
 * @brief  Configures tim3 clocks.
 */
void vTimer3Configuration(void)
{
	TIM_TimeBaseInitType TIM_TimeBaseStructure;
    NVIC_InitType NVIC_InitStructure;

	uint16_t PrescalerValue = 0;	

	RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM3, ENABLE);
    
    PrescalerValue = (uint16_t) (SystemCoreClock / 1000000);	//target 1MHz Clock

    /* Time base configuration */
    TIM_TimeBaseStructure.Period    = 10000;					//target 10ms
    TIM_TimeBaseStructure.Prescaler = 0;
    TIM_TimeBaseStructure.ClkDiv    = 0;
    TIM_TimeBaseStructure.CntMode   = TIM_CNT_MODE_UP;

    TIM_InitTimeBase(TIM3, &TIM_TimeBaseStructure);
    TIM_ConfigPrescaler(TIM3, PrescalerValue, TIM_PSC_RELOAD_MODE_IMMEDIATE);		// Prescaler configuration
    TIM_ConfigInt(TIM3, TIM_INT_UPDATE, ENABLE);	// TIM3 enable update irq
    TIM_Enable(TIM3, ENABLE);						// TIM3 enable counter 

    /* Enable the TIM3 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel         = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd      = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
	

}



/**
 * @brief  Selects HSI as System clock source and configure HCLK, PCLK2
 *         and PCLK1 prescalers.
 */
void vSetSysClockToHSI(void)
{
    RCC_DeInit();
    RCC_EnableHsi(ENABLE);
    HSIStartUpStatus = RCC_WaitHsiStable();			    	// Wait till HSI is ready

    if(HSIStartUpStatus == SUCCESS)
		{
        FLASH_PrefetchBufSet(FLASH_PrefetchBuf_EN);			// Enable Prefetch Buffer 
        FLASH_SetLatency(FLASH_LATENCY_0);					// Flash 0 wait state
        RCC_ConfigHclk(RCC_SYSCLK_DIV1);					// HCLK = SYSCLK 
        RCC_ConfigPclk2(RCC_HCLK_DIV1);						// PCLK2 = HCLK
        RCC_ConfigPclk1(RCC_HCLK_DIV1);						// PCLK1 = HCLK
        RCC_ConfigSysclk(RCC_SYSCLK_SRC_HSI);		  		// Select HSI as system clock source
        while(RCC_GetSysclkSrc() != RCC_CFG_SCLKSTS_HSI);	// Wait till HSI is used as system clock source */	
		}
    else
		{
        /* If HSI fails to start-up, the application will have wrong clock
           configuration. User can add here some code to deal with this error */
        while (1);
		}
}

/**
 * @brief  Selects HSE as System clock source and configure HCLK, PCLK2
 *         and PCLK1 prescalers.
 */
void vSetSysClockToHSE(void)
{
    RCC_DeInit();
    RCC_ConfigHse(RCC_HSE_ENABLE);			    			// Enable HSE
    HSEStartUpStatus = RCC_WaitHseStable();			    	// Wait till HSE is ready

    if(HSEStartUpStatus == SUCCESS)
		{
        FLASH_PrefetchBufSet(FLASH_PrefetchBuf_EN);			// Enable Prefetch Buffer

		if (HSE_Value <= 18000000)
            FLASH_SetLatency(FLASH_LATENCY_0);				// Flash 0 wait state
        else
            FLASH_SetLatency(FLASH_LATENCY_1);			    // Flash 1 wait state

        RCC_ConfigHclk(RCC_SYSCLK_DIV1);			        // HCLK = SYSCLK
        RCC_ConfigPclk2(RCC_HCLK_DIV1);						// PCLK2 = HCLK
        RCC_ConfigPclk1(RCC_HCLK_DIV1);						// PCLK1 = HCLK
        RCC_ConfigSysclk(RCC_SYSCLK_SRC_HSE);	        	// Select HSE as system clock source
        while(RCC_GetSysclkSrc() != RCC_CFG_SCLKSTS_HSE);	// Wait till HSE is used as system clock source
		}
    else
		{
        /* If HSE fails to start-up, the application will have wrong clock
           configuration. User can add here some code to deal with this error */
        while (1);
		}
}

/**
 * @brief  Selects PLL clock as System clock source and configure HCLK, PCLK2
 *         and PCLK1 prescalers.
 */
void vSetSysClockToPLL(uint32_t freq, uint8_t src)
{
    uint32_t pllmul;
    uint32_t plldiv = RCC_PLLOUT_DIV_1;
    uint32_t latency;
    uint32_t pclk1div, pclk2div;
    uint32_t pllprediv;
	
    if (HSE_VALUE != 8000000)
		{
        /* HSE_VALUE == 8000000 is needed in this project! */
        while (1);
		}


    RCC_DeInit();

    if(src == SYSCLK_USE_HSI) 
		{
        RCC_ConfigHsi(RCC_HSI_ENABLE);		      		// Enable HSI 
        HSIStartUpStatus = RCC_WaitHsiStable();			// Wait till HSI is ready
        if(HSIStartUpStatus != SUCCESS)
			{
            /* If HSI fails to start-up, the application will have wrong clock
               configuration. User can add here some code to deal with this
               error */
            while (1);
			}

		}
    else if(src == SYSCLK_USE_HSE) 
		{
        RCC_ConfigHse(RCC_HSE_ENABLE);					// Enable HSE
        HSEStartUpStatus = RCC_WaitHseStable();			// Wait till HSE is ready
        if(HSEStartUpStatus != SUCCESS)
			{
            /* If HSE fails to start-up, the application will have wrong clock
               configuration. User can add here some code to deal with this
               error */
            while (1);
			}

		}

    switch (freq)
		{
		case 24000000:
            latency = FLASH_LATENCY_1;
            if(src == SYSCLK_USE_HSI)
                pllmul = RCC_PLL_MUL_6;
            else if(src == SYSCLK_USE_HSE)
                pllmul = RCC_PLL_MUL_4;
            pclk1div = RCC_HCLK_DIV1;
            pclk2div = RCC_HCLK_DIV1;			
			pllprediv= RCC_PLL_PRE_1;
			plldiv   = RCC_PLLOUT_DIV_2;
			break;
        case 32000000:
            latency = FLASH_LATENCY_1;
            if(src == SYSCLK_USE_HSI)
                pllmul = RCC_PLL_MUL_8;
            else if(src == SYSCLK_USE_HSE)
                pllmul = RCC_PLL_MUL_8;
            pclk1div = RCC_HCLK_DIV1;
            pclk2div = RCC_HCLK_DIV1;
			pllprediv= RCC_PLL_PRE_1;
			plldiv   = RCC_PLLOUT_DIV_2;			
            break;
		case 36000000:
            latency = FLASH_LATENCY_2;
            if(src == SYSCLK_USE_HSI)
                pllmul = RCC_PLL_MUL_9;
            else if(src == SYSCLK_USE_HSE)
                pllmul = RCC_PLL_MUL_6;
            pclk1div = RCC_HCLK_DIV1;
            pclk2div = RCC_HCLK_DIV1;
			pllprediv= RCC_PLL_PRE_1;
			plldiv   = RCC_PLLOUT_DIV_2;			
            break;
        case 48000000:
            latency  = FLASH_LATENCY_2;
            if(src == SYSCLK_USE_HSI)
              pllmul = RCC_PLL_MUL_12;
            else if(src == SYSCLK_USE_HSE)
               pllmul = RCC_PLL_MUL_8;
            pclk1div = RCC_HCLK_DIV1;
            pclk2div = RCC_HCLK_DIV1;
			pllprediv= RCC_PLL_PRE_2;
			plldiv   = RCC_PLLOUT_DIV_1;			
            break;
        default:
            while (1);
		}

    FLASH_SetLatency(latency);
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);		    		// HCLK = SYSCLK 
    RCC_ConfigPclk2(pclk2div);		    				// PCLK2 = HCLK
    RCC_ConfigPclk1(pclk1div);							// PCLK1 = HCLK 
    if(src == SYSCLK_USE_HSE)
        RCC_ConfigPll(RCC_PLL_SRC_HSE, pllmul, pllprediv, plldiv);
    else
        RCC_ConfigPll(RCC_PLL_SRC_HSI, pllmul, pllprediv, plldiv);

    RCC_EnablePll(ENABLE);					   			// Enable PLL
	// while (RCC_GetFlagStatus(RCC_CTRL_FLAG_PLLRDF) == RESET);
    while((RCC->CTRL & RCC_CTRL_PLLRDF) == 0);			// Wait till PLL is ready 
    RCC_ConfigSysclk(RCC_SYSCLK_SRC_PLLCLK);			// Select PLL as system clock source
    while(RCC_GetSysclkSrc() != RCC_CFG_SCLKSTS_PLL);	// Wait till PLL is used as system clock source
}


void vSetSysClock_LSI(void)
{
    RCC_DeInit();
    RCC_EnableLsi(ENABLE);
    while(RCC_GetFlagStatus(RCC_LSCTRL_FLAG_LSIRD) == RESET);

    RCC_ConfigHclk(RCC_SYSCLK_DIV1);					// HCLK = SYSCLK
    RCC_ConfigPclk2(RCC_HCLK_DIV1);						// PCLK2 = HCLK
    RCC_ConfigPclk1(RCC_HCLK_DIV1);						// PCLK1 = HCLK
	FLASH_SetLatency(FLASH_LATENCY_0);
    
	RCC_ConfigSysclk(RCC_SYSCLK_SRC_LSI);
    while(RCC_GetSysclkSrc() != RCC_CFG_SCLKSTS_LSI);
}


void vSetSysClock_LSE(void)
{
    RCC_DeInit();
    RCC_ConfigLse(RCC_LSE_ENABLE);
    while(RCC_GetFlagStatus(RCC_LSCTRL_FLAG_LSERD) == RESET);
    
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);					// HCLK = SYSCLK
    RCC_ConfigPclk2(RCC_HCLK_DIV1);						// PCLK2 = HCLK 
    RCC_ConfigPclk1(RCC_HCLK_DIV1);						// PCLK1 = HCLK 

    FLASH_SetLatency(FLASH_LATENCY_0);
    RCC_ConfigSysclk(RCC_SYSCLK_SRC_LSE);
    while (RCC_GetSysclkSrc() != RCC_CFG_SCLKSTS_LSE);
}



