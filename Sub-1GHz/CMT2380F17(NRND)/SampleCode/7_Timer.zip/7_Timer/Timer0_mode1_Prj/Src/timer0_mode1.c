#include "timer0_mode1.h"

unsigned char gTimer0Counter;

//*********************************************************
//														   
//*********************************************************
void vTimer0Mode1Init(void)
{
 TCON  = 0;
 TMOD  = 0x01;			//Timer0 as 16bit up load compare
 TH0   = 0x00;
 TL0   = 0x00;

 AUXR2 &= (~T0CKOE); 
 if(T0_CLK_OUT_EN!=0)
 	AUXR2 |= T0CKOE;  	 

 __DRV_SFR_PageIndex(0);
 switch(T0_CLOCK_SEL)
 	{
	case 1:				//sysclk 
		AUXR3 &= (~T0XL);	
		AUXR2 |= T0X12; 	
	   	TMOD  &= (~T0C_T);
		break;
	case 2:				//sysclk/48
		AUXR3 |= T0XL;	
		AUXR2 &= (~T0X12); 	
	   	TMOD  &= (~T0C_T);
		break;
	case 3:
  		AUXR3 |= T0XL;	
		AUXR2 |= T0X12; 	
	   	TMOD  &= (~T0C_T);
		break;
	case 0:				//sysclk/12
	default:			 
		AUXR3 &= (~T0XL);	
		AUXR2 &= (~T0X12); 	
	   	TMOD  &= (~T0C_T);
		break;
	}

 AUXR3 &= (~(T0PS1|T0PS0));	//select P3.4

 ET0 = 1;					//enable interrupt
 TR0 = 1;
}

void Timer0_TF0_ISR(void)   interrupt TIMER0_ISR_VECTOR 
{
 _push_(SFRPI);
 gTimer0Counter++;
 _pop_(SFRPI);
}