


#ifndef __TIMER0_MODE2_H
	#define __TIMER0_MODE2_H

	#include "CMT2380F17_CONFIG.h"


	#define		T0_CLOCK_SEL			3			// 0 = SYSCLK/12, default
													// 1 = SYSCLK
													// 2 = SYSCLK/48
													// 3 = SYSCLK/192

   	#define		T0_CLK_OUT_EN			1			// 0 = disable clk output(P3.4)
													//!0 = enable clk output

	#define		T0_INTERVAL_VALUE		100			//
	
	extern unsigned char gTimer0Counter;


	extern void vTimer0Mode2Init(void);


#endif