


#ifndef __TIMER0_ILRCO_H
	#define __TIMER0_ILRCO_H
	
	#include "CMT2380F17_CONFIG.h"


	#define		T0_MODE_SEL				0			// 0 = 8-bit up load mode��from 0 to overwise, allow to set init_value in ISR
													// 1 = 16-bit up load mode, from 0 to overwise, allow be set init_value	in ISR
													// 2 = 8-bit auto re-load mode, from TH0 to overwise

   	#define		T0_CLK_OUT_EN			1			// 0 = disable clk output(P3.4)
													//!0 = enable clk output

	#define		T0_INTERVAL_VALUE		100			// just for mode2 used

	#define		T0_PWM_RATIO			100			// just for mode0 used
	
	extern unsigned char gTimer0Counter;


	extern void vTimer0IlrcoInit(void);


#endif