#include "timer0_ilrco.h"

unsigned char gTimer0Counter;

//*********************************************************
//														   
//*********************************************************
void vTimer0IlrcoInit(void)
{
 TCON  = 0;

 AUXR2 &= (~T0CKOE); 
 if(T0_CLK_OUT_EN!=0)
 	AUXR2 |= T0CKOE;  	 

 __DRV_SFR_PageIndex(0);
 AUXR3 &= (~T0XL);			//select source from ILRCO			
 AUXR2 |= T0X12; 	
 TMOD  |= T0C_T;

 TMOD &= 0xFC;
 switch(T0_MODE_SEL)
 	{
	case 1:					//Timer0 as 16-bit up load overwise
	 	TMOD |= 0x01;		
	 	TH0   = 0;
 		TL0   = 0;
		break;
	case 2:					//Timer0 as 8-bit auto re-load overwise				
	 	TMOD |= 0x02;		
	 	TH0   = (256-T0_INTERVAL_VALUE);
 		TL0   = (256-T0_INTERVAL_VALUE);
		break;
	case 0:					//Timer0 as 8-bit up load overwise
	default:			 
	 	TH0 = T0_PWM_RATIO;
 		TL0 = 0;
		break;
	}

 AUXR3 &= (~(T0PS1|T0PS0));	//select P3.4

 ET0 = 1;					//enable interrupt
 TR0 = 1;
}

void Timer0_TF0_ISR(void)   interrupt TIMER0_ISR_VECTOR 
{
 _push_(SFRPI);
 gTimer0Counter++;
 _pop_(SFRPI);
}