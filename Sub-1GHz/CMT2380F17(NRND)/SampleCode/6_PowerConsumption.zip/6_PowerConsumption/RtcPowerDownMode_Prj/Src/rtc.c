#include "rtc.h"

unsigned char gRtcCounter;

//*********************************************************
//														   
//*********************************************************
void vRTCInit(void)
{
 unsigned char tmp;

 __DRV_SFR_PageIndex(0);
 RTCCR = 0;
 
 tmp  = 0;
 tmp |= ((RTC_CLK_SRC_SEL&0x07)<<5);
 tmp |= ((RTC_RPSC_VALUE&0x07)<<2);
 tmp |= ((RTC_CLK_SEL&0x0C)>>2);
 DRV_PageP_Write(CKCON4_P, tmp);   		//CKCON4 w/r only in P page        

 tmp  = 0x3F;
 tmp |= ((RTC_CLK_SEL&0x03)<<6);
 DRV_PageP_Write(RTCTM_P, tmp);         //RTCTM w/r need in P page 

 __DRV_SFR_PageIndex(0); 
 PCON1 |= RTCF;							//write 1 for clear RTC interrupt flag
 SFIE  |= RTCFIE;						//enable for wakeup uC in idle or stop mode
 
 EIE1  |= ESF; 

 RTCCR = (RTC_INTERVAL_VALUE&0x3F);
 if(RTC_CLK_OUT_EN!=0)
 	RTCCR |= RTCO;

 RTCCR |= RTCE;							//eanble RTC module 
}


void System_Flag_ISR()  interrupt SYSFLAG_ISR_VECTOR
{
 _push_(SFRPI);

 __DRV_SFR_PageIndex(0); 

 if(PCON1&RTCF) 
	{	
	PCON1 |= RTCF;
	gRtcCounter++;	
	} 

 _pop_(SFRPI);
}
