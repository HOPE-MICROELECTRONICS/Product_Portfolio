/*********************************************************************
    Project: Power Down Mode
    Author:  QY.Ruan
			 CMT2380F17 QFN40_ 
			 CpuCLK=12MHz, SysCLK=12MHz
	Description:
			 After power on reset, LED(P45) is light, then press K2(key) until LED off.
			 And then go to power down mode. 
			 Power consumption is about 2.2uA (include RF go to sleep mode)
	Note:

    Creat time::
    Modify::
    
*********************************************************************/
#include 	"demo.h"

#define 	MCU_SYSCLK		12000000
#define 	MCU_CPUCLK		(MCU_SYSCLK)


#define		D_LED			P31

#define		LED				P45

#define		KEY2			P22
#define		KEY1			P24

/*************************************************
Function:     	void DelayXus(u16 xUs)
Description:   	dealy��unit:us
Input:     			u8 Us -> *1us  (1~255)
Output:     
*************************************************/
void DelayXus(u8 xUs)
{
 while(xUs!=0)
	{
	#if (MCU_CPUCLK>=11059200)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=14745600)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=16000000)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=22118400)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif
	
	#if (MCU_CPUCLK>=24000000)
		_nop_();
		_nop_();
	#endif		

	#if (MCU_CPUCLK>=29491200)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=32000000)
		_nop_();
		_nop_();
	#endif

	xUs--;
	}
}

/*************************************************
Function:     	void DelayXms(u16 xMs)
Description:    dealy��unit:ms
Input:     			u16 xMs -> *1ms  (1~65535)
Output:     
*************************************************/
void DelayXms(u16 xMs)
{
 while(xMs!=0)
	{
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	xMs--;
	}
}

void WaitKeyPress(void)
{
 u8 i; 

 for(i=0; i<15; )
 	{
	DelayXms(20);
	if(!KEY2)
		i++;
	else
		i = 0;
	}
}

void main ()
{
 unsigned char tmp;

 System_Init();
 EA = 0;						//enable interrupt
 
 DelayXms(250);

 vSpiInit();
 vInitRadio();
 vIntSrcCfg(INT_PKT_DONE, INT_RX_FIFO_WBYTE);
 gPayloadLength = UHF_PKT_LEN;
 bGoSleep();

 D_LED = 0;
 WaitKeyPress();
 _nop_();
 _nop_();
 D_LED = 1;

 tmp  = DRV_PageP_Read(DCON0_P);  //disable OCD Port
 tmp &= (~OCDE_P);
 DRV_PageP_Write(DCON0_P, tmp); 

 LED = 1;
 DelayXms(250);
 LED = 0;

 __DRV_SFR_PageIndex(0);
 PCON0 |= PD;	 					//go into stop mode

 while(1);
}
