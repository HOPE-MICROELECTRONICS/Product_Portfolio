#include "wdt_timer.h"

unsigned char gWdtCounter;


void vWdtTimerInit(void)
{
 unsigned char tmp;

 __DRV_SFR_PageIndex(0);		//clrwdt	
 WDTCR |= CLRW;

 tmp  = DRV_PageP_Read(CKCON3_P);
 tmp &= (~(WDTCS1_P|WDTCS0_P|WDTFS_P));
 if(BY_PASS_COUNTER!=0) 
 	tmp |= WDTFS_P;
 tmp |= ((WDT_CLK_SEL&0x03)<<6);
 DRV_PageP_Write(CKCON3_P, tmp);

 tmp  = 0;
 if(NON_STOP_IN_PD!=0)
 	tmp |= NSW_P;
 if(NON_STOP_IN_IDLE!=0)
 	tmp |= WIDL_P;
 tmp |= (ENW_P|CLRW_P);
 tmp |= (WDT_PS_SEL&0x07);
 DRV_PageP_Write(WDTCR_P, tmp);

 __DRV_SFR_PageIndex(0);
 EIE1  |= ESF;					//enable system interrupt
 SFIE  |= WDTFIE;				//enable WDT interrupt
 PCON1 |= WDTF;
}

void System_Flag_ISR()  interrupt SYSFLAG_ISR_VECTOR
{
 _push_(SFRPI);

 __DRV_SFR_PageIndex(0); 

 if(PCON1&WDTF) 
	{	
	PCON1 |= WDTF;
	gWdtCounter++;	
	} 

 _pop_(SFRPI);
}





