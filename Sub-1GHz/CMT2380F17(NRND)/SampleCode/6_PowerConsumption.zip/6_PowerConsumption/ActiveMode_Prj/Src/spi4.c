#include "spi4.h"

void vSpiSoftDelay(void)
{
 #if (FIFO_DLY_VAL==0)
	return;
 #else
 	unsigned char i;
	for(i=FIFO_DLY_VAL; i!=0; i-- )
		_nop_();
 #endif
}

//*********************************************************
//														   
//*********************************************************
void vSpiInit(void)
{
  //spi master mode, msb first, CPOL & CPHA both 0, clk=sys_clk/4

 __DRV_SFR_PageIndex(4);
 AUXR7 &= (~SPI0M0);		//disable �ջ���ģʽ 

 __DRV_SFR_PageIndex(7);
 AUXR10 &= (~S0PS1);		//select nSS(P3.3), MOSI(P1.5), MISO(P1.6), SCLK(P1.7) 

 __DRV_SFR_PageIndex(0);

 SPCON  = SSIG|SPEN|MSTR;
 SPSTAT = SPIF|WCOL|MODF;
}



void vSpiWrite(unsigned int spi_dat)
{
 nCSB  = 0;
 SPDAT = ((unsigned char)(spi_dat>>8)&0x7F);
 while(SPSTAT&THRF);
 SPDAT = (unsigned char)spi_dat; 
 while(SPSTAT&SPIBSY);
 nCSB  = 1;
 //return(SPDAT);
 return;
}

unsigned char bSpiRead(unsigned char spi_adr)
{
 spi_adr |= 0x80;

 nCSB  = 0;
 SPDAT = spi_adr;
 while(SPSTAT&THRF);
 SPDAT = 0xFF; 
 while(SPSTAT&SPIBSY);
 nCSB  = 1;
 return(SPDAT);
}

void vSpiSendCmd(unsigned char cmd_val)
{
 nCSB  = 0;
 SPDAT = cmd_val;
 while(SPSTAT&SPIBSY);
 nCSB  = 1;
 return; 
}

void vSpiBurstWrite(unsigned char spi_adr, unsigned char ptr[], unsigned char length)
{
 unsigned char i;

 spi_adr &= 0x7F;
  
 nCSB  = 0;
 SPDAT = spi_adr;
 for(i=0; i<length; i++)
 	{
  	while(SPSTAT&THRF);	
 	SPDAT = ptr[i]; 	
	}
 while(SPSTAT&SPIBSY);
 nCSB  = 1;
}

void vSpiBurstRead(unsigned char spi_adr, unsigned char ptr[], unsigned char length)
{
 unsigned char i;

 spi_adr |= 0x80;

 nCSB  = 0;
 SPDAT = spi_adr;
 while(SPSTAT&THRF);	
 for(i=0; i<length; i++)
 	{
 	SPDAT = 0xFF;
   	while(SPSTAT&THRF);	
	ptr[i] = SPDAT; 	
	}
 while(SPSTAT&SPIBSY);
 nCSB  = 1;
}


void vSpiWriteFifo(unsigned char spi_dat)
{
 nFCSB = 0;
 SPDAT = spi_dat;
 while(SPSTAT&SPIBSY);
 nFCSB = 1;
 vSpiSoftDelay();
 return; 
}

unsigned char bSpiReadFifo(void)
{
 nFCSB = 0;
 SPDAT = 0xFF;
 while(SPSTAT&SPIBSY);
 nFCSB = 1;
 vSpiSoftDelay();
 return(SPDAT); 
}

void vSpiBurstWriteFifo(unsigned char ptr[], unsigned char length)
{
 unsigned char i;

 if(length!=0)
 	{
	for(i=0; i<length; i++)
		vSpiWriteFifo(ptr[i]);
	}
 return;
}

void vSpiBurstReadFifo(unsigned char ptr[], unsigned char length)
{
 unsigned char i;

 if(length!=0)
 	{
	for(i=0; i<length; i++)
		ptr[i] = bSpiReadFifo();
	}
 return;
}


