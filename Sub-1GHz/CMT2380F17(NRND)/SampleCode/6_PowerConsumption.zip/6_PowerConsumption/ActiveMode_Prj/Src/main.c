/*********************************************************************
    Project: Active Mode
    Author:  QY.Ruan
			 CMT2380F17 QFN40_ 
			 CpuCLK=12MHz, SysCLK=12MHz
	Description:
			 After power on reset, LED(P45) is light, then press K2(key) until LED flash.
			 And then go to active mode test.
			 

	Note:

    Creat time::
    Modify::
    
*********************************************************************/
#include 	"demo.h"

#define 	MCU_SYSCLK		12000000
#define 	MCU_CPUCLK		(MCU_SYSCLK)


#define		D_LED			P31

#define		LED				P45

#define		KEY2			P22
#define		KEY1			P24

/*************************************************
Function:     	void DelayXus(u16 xUs)
Description:   	dealy��unit:us
Input:     			u8 Us -> *1us  (1~255)
Output:     
*************************************************/
void DelayXus(u8 xUs)
{
 while(xUs!=0)
	{
	#if (MCU_CPUCLK>=11059200)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=14745600)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=16000000)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=22118400)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif
	
	#if (MCU_CPUCLK>=24000000)
		_nop_();
		_nop_();
	#endif		

	#if (MCU_CPUCLK>=29491200)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=32000000)
		_nop_();
		_nop_();
	#endif

	xUs--;
	}
}

/*************************************************
Function:     	void DelayXms(u16 xMs)
Description:    dealy��unit:ms
Input:     			u16 xMs -> *1ms  (1~65535)
Output:     
*************************************************/
void DelayXms(u16 xMs)
{
 while(xMs!=0)
	{
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	xMs--;
	}
}

void WaitKeyPress(void)
{
 u8 i; 

 for(i=0; i<15; )
 	{
	DelayXms(20);
	if(!KEY2)
		i++;
	else
		i = 0;
	}
}

void main ()
{
 unsigned char tmp;
 unsigned char mckd_value;
 unsigned char scks_value;


 unsigned char flash_cmp;
 unsigned char flash_cnt;

 System_Init();
 EA = 1;						//enable interrupt

 vSystemClockRecovry();

 vSpiInit();
 vInitRadio();
 vIntSrcCfg(INT_PKT_DONE, INT_RX_FIFO_WBYTE);
 gPayloadLength = UHF_PKT_LEN;
 bGoSleep();
 
 vTimer0Mode2Init();			//mode2, 8bit reload, reload value=128, clk=sysclk/192

 DelayXms(250);
 
 D_LED = 0;
 WaitKeyPress();
 _nop_();
 _nop_();
 D_LED = 1;

 tmp  = DRV_PageP_Read(DCON0_P);  //disable OCD Port
 tmp &= (~OCDE_P);
 DRV_PageP_Write(DCON0_P, tmp); 

 LED = 0;
 DelayXms(250);

 while(1)
 	{
	for(mckd_value=0; mckd_value<4; mckd_value++)			// MCKDO  =  12MHz,   6MHz,    3MHz,   1.5MHz,  MCKDO==CPUCLK==SYSCLK
		{													// timer0 =	 62.5k, 31.25k,  15.625k, 7.8125k, 
		tmp  = DRV_PageP_Read(CKCON3_P);					// 		  =    2ms,    4ms,      8ms,    16ms,
 		tmp &= 0xF3;
 		tmp |= (mckd_value<<2); 
 		DRV_PageP_Write(CKCON3_P, tmp); 
		
	   	switch(mckd_value)
			{
			case 0: flash_cmp = 0x40; break;
			case 1:	flash_cmp = 0x20; break;
			case 2:	flash_cmp = 0x10; break;
			case 3:	flash_cmp = 0x08; break;
			}

		for(flash_cnt=0; flash_cnt<10; )
			{
			if(gTimer0Counter<flash_cmp)
				LED = 1;
			else
				{
				LED = 0;
				if(gTimer0Counter>=(flash_cmp<<1))
					{
					flash_cnt++;
				    gTimer0Counter = 0;
					}
				}
			}
		}

	LED = 0;
	tmp  = DRV_PageP_Read(CKCON3_P);						//recover to 12MHz
 	tmp &= 0xF3;
	DRV_PageP_Write(CKCON3_P, tmp); 
 	for(gTimer0Counter=0; gTimer0Counter<128; );			//wait for 256ms

	tmp  = DRV_PageP_Read(DCON0_P);							//HSE set 0, for save power consumption
	tmp &= (~HSE_P);					
   	DRV_PageP_Write(DCON0_P, tmp); 

   	for(scks_value=1; scks_value<8; scks_value++)			//scks divider: 6MHz, 3MHz, 1.5MHz, 750kHz, 375kHz, 187.5kHz, 93.75kHz   
		{													//               4ms,  8ms,   16ms,   32ms,   64ms,    128ms, 	256ms, 
		tmp  = DRV_PageP_Read(CKCON0_P);
	    tmp &= 0xF8;
		tmp |= scks_value;
	   	DRV_PageP_Write(CKCON0_P, tmp);

 	   	switch(scks_value)
			{
			case 1:	flash_cmp = 128; break;
			case 2:	flash_cmp = 64;  break;
			case 3:	flash_cmp = 32;  break;
			case 4:	flash_cmp = 16;  break;
			case 5:	flash_cmp = 8;   break;
			case 6:	flash_cmp = 4;   break;
			case 7: flash_cmp = 2;   break;
			}

		for(gTimer0Counter=0; gTimer0Counter<flash_cmp; );
		}

	tmp  = DRV_PageP_Read(DCON0_P);							//HSE set 1, for high speed run test
	tmp |= HSE_P;					
   	DRV_PageP_Write(DCON0_P, tmp); 

	tmp  = DRV_PageP_Read(CKCON0_P);						//recover to SCKS divder to 1
	tmp &= 0xF8;
   	DRV_PageP_Write(CKCON0_P, tmp);
 	for(gTimer0Counter=0; gTimer0Counter<128; );			//wait for 256ms
	
    //==========================================
	tmp  = DRV_PageP_Read(CKCON0_P);						//enable CKM module 
	tmp |= ENCKM_P;
	DRV_PageP_Write(CKCON0_P, tmp);	

	tmp  = DRV_PageP_Read(CKCON2_P);						//MCK=SYS_CLK=CPU_CLK=24MHz, timer0=1ms
	tmp &= 0x10;
	tmp |= 0x04;
	DRV_PageP_Write(CKCON2_P, tmp);	
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );

	tmp  = DRV_PageP_Read(DCON0_P);							//HSE1 set 1, for super high speed run test	
	tmp |= (HSE_P|HSE1_P);									
   	DRV_PageP_Write(DCON0_P, tmp); 

 	tmp  = DRV_PageP_Read(CKCON2_P);						//MCK=SYS_CLK=CPU_CLK=32MHz, timer0=0.75ms
	tmp &= 0x10;
	tmp |= 0x08;
	DRV_PageP_Write(CKCON2_P, tmp);	
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );	
	for(gTimer0Counter=0; gTimer0Counter<250; );

	tmp  = DRV_PageP_Read(CKCON0_P);						//CPU_CLK = SYS_CLK/2
	tmp |= CCKS_P;
	DRV_PageP_Write(CKCON0_P, tmp);	

  	tmp  = DRV_PageP_Read(CKCON2_P);						//MCK=SYS_CLK=48MHz, CPU_CLK=24MHz, timer0=0.5ms
	tmp &= 0x10;
	tmp |= 0x0C;
	DRV_PageP_Write(CKCON2_P, tmp);
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );
	for(gTimer0Counter=0; gTimer0Counter<250; );

	//=====================================================
	vSystemClockRecovry();
 	for(gTimer0Counter=0; gTimer0Counter<128; );			//wait for 256ms	

	DRV_PageP_Write(CKCON2_P, 0x12);						//switch to ILRCO, 
	for(tmp=0; tmp<100; tmp++)
		{
		_nop_(); _nop_(); _nop_(); _nop_();
		}

	tmp  = DRV_PageP_Read(DCON0_P);							//HSE set 0, for save power consumption
	tmp &= (~HSE_P);					
   	DRV_PageP_Write(DCON0_P, tmp); 

	DRV_PageP_Write(CKCON2_P, 0x02); 					   	//disable IHRCO
	for(gTimer0Counter=0; gTimer0Counter<2; );
	
	DRV_PageP_Write(CKCON2_P, 0x12); 					   	//enalbe IHRCO	
	for(tmp=0; tmp<100; tmp++)
		{
		_nop_(); _nop_(); _nop_(); _nop_();
		}

	tmp  = DRV_PageP_Read(DCON0_P);							//HSE set 1, for >6MHz
	tmp |= HSE_P;					
   	DRV_PageP_Write(DCON0_P, tmp); 

	DRV_PageP_Write(CKCON2_P, 0x10);						//switch to IHRCO		
		
	}
}
