

// IHRCO = CPU_CLK = SYS_CLK = 12MHz, CKM disable
// 		IHRCO_SEL   = 0;
//		OSC_IN_SEL  = 0;
//		MCK_OUT_SEL = 0;		
//  	MCK_DIV_OUT_SEL = 0;
// 		SYSCLK_DIV_SEL  = 0;
//		CPU_CLK_SEL = 0;
//		CPU_LP_EN   = 0;
//		CPU_HP_EN   = 0;
//		CKM_EN      = 0;		
//		CKM_IN_SEL  = 0;	//don't care
//		CKM_MODE_SEL= 0;	//don't care
//		ICKO_SEL    = 0/1/2/3;	


// IHRCO = CPU_CLK = SYS_CLK = 12MHz, CKM enabe for PCA(CKMX16, 144MHz)
// 		IHRCO_SEL   = 0;
//		OSC_IN_SEL  = 0;
//		MCK_OUT_SEL = 0;		
//  	MCK_DIV_OUT_SEL = 0;
// 		SYSCLK_DIV_SEL  = 0;
//		CPU_CLK_SEL = 0;
//		CPU_LP_EN   = 0;
//		CPU_HP_EN   = 0;
//		CKM_EN      = 1;		
//		CKM_IN_SEL  = 1;	
//		CKM_MODE_SEL= 1;	
//		ICKO_SEL    = 0/1/2/3;	


// IHRCO = 12MHz, MCK=(IHRCO/2)x4=24MHz, CPU_CLK = SYS_CLK = 24MHz, CKM enabe 
// 		IHRCO_SEL   = 0;
//		OSC_IN_SEL  = 0;
//		MCK_OUT_SEL = 1;		
//  	MCK_DIV_OUT_SEL = 0;
// 		SYSCLK_DIV_SEL  = 0;
//		CPU_CLK_SEL = 0;
//		CPU_LP_EN   = 0;
//		CPU_HP_EN   = 0;
//		CKM_EN      = 1;		
//		CKM_IN_SEL  = 1;	
//		CKM_MODE_SEL= 0;	
//		ICKO_SEL    = 0/1/2/3;	

// IHRCO = 12MHz, MCK=(IHRCO/2)x5.33~=32MHz, CPU_CLK = SYS_CLK = 32MHz, CKM enabe 
// 		IHRCO_SEL   = 0;
//		OSC_IN_SEL  = 0;
//		MCK_OUT_SEL = 2;		
//  	MCK_DIV_OUT_SEL = 0;
// 		SYSCLK_DIV_SEL  = 0;
//		CPU_CLK_SEL = 0;
//		CPU_LP_EN   = 0;
//		CPU_HP_EN   = 1;
//		CKM_EN      = 1;		
//		CKM_IN_SEL  = 1;	
//		CKM_MODE_SEL= 0;	
//		ICKO_SEL    = 0/1/2/3;	


// IHRCO = 12MHz, OSC_IN = 32kHz, MCK = CPU_CLK = SYS_CLK = 32kHz, CKM Disable
// 		IHRCO_SEL   = 0;
//		OSC_IN_SEL  = 2;
//		MCK_OUT_SEL = 0;		
//  	MCK_DIV_OUT_SEL = 0;
// 		SYSCLK_DIV_SEL  = 0;
//		CPU_CLK_SEL = 0;
//		CPU_LP_EN   = 0;
//		CPU_HP_EN   = 0;
//		CKM_EN      = 0;		
//		CKM_IN_SEL  = 1;	
//		CKM_MODE_SEL= 0;	
//		ICKO_SEL    = 0/1/2/3;

	
#ifndef __SYSCLK_H
	
	#define __SYSCLK_H
	
	#include "CMT2380F17_CONFIG.h"
	
	#define		IHRCO_SEL		0			// 0 = 12MHz
											//!0 = 11.059MHz
	
	
	#define		OSC_IN_SEL		2			// 0 = IHRCO (12MHz or 11.059MHz), default
											// 2 = ILRCO (32kHz)
																			
	#define		MCK_OUT_SEL		0			// 0 = OSC_IN, bypass CKM module
											// 1 = CKMI x4 or x6
											// 2 = CKMI x5.33 or x8
											// 3 = CKMI x8 or x12, can be select x2 to PCA
											//!!note: CKMI input clock need limited about 5~6.5MHz											
	
	#define		MCK_DIV_OUT_SEL	0			// MCKDO select, output to SCKS(sysclk divider), PCA
											// 0 = /1, 
											// 1 = /2, 
											// 2 = /4, 
											// 3 = /8, 
											
 	#define		SYSCLK_DIV_SEL	0			// (SCKS) System clock divider select, input by MCKDO
 											// n = MCKDO/2^n,  range 0-7

	#define		CPU_CLK_SEL		0			// CPU Clock select, input by SCKS output
											//  0 = /1
											// !0 = /2
											//!!note: cpu clock limited in 36MHz Max.	

	#define		CPU_LP_EN		0			// when cpu_clk < 6MHz, can save power consumption
											//  0 = disable
											// !0 = enable
											//!!note: if need change cpu_clk >= 6MHz, need disable it first

	#define		CPU_HP_EN		0			// when cpu_clk > 25Mhz,
											//  0 = disable
											// !0 = enable
	
	#define		CKM_EN			0			// 0 = disable CKM module
											// 1 = enable CKM module

	#define		CKM_IN_SEL		1			// 0 = OSC_IN/1, if OSC_IN = 5-6MHz
											// 1 = OSC_IN/2, if OSC_IN = 10-13MHz
											// 2 = OSC_IN/4, if OSC_IN = 20-26MHz

	#define		CKM_MODE_SEL	0			// 0 = x96
											//!0 = x144
	
	
	#define		ICKO_SEL		1			// MCK output clk to P6.0 select
											// 0 = P6.0 as IO
											// 1 = MCK clock
											// 2 = MCK/2 clock
											// 3 = MCK/4 clock

	extern void vSystemClockInit(void);											
	
	extern void vSystemClockRecovry(void);											

#endif	