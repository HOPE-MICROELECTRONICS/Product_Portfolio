#ifndef __RADIO_H
	#define __RADIO_H

	#include "CMT2380F17_CONFIG.h"
	#include "radio_reg.h"
	#include "spi4.h"
	
	#define	UHF_PKT_LEN		20

	#define	RF_GPIO1		P10
	#define	RF_GPIO2		P11
	#define	RF_GPIO3		P34
	
	extern unsigned char bdata gRadioFlag; 
		extern bit gFixedPacket_F;
		extern bit gIntPolar_F;
		extern bit gRssiTrig_F;
		extern bit gPktRecErr_F;
	
	extern unsigned char gPayloadLength;

	
	extern unsigned int code CMTBank[12];
	extern unsigned int code SystemBank[12];
	extern unsigned int code FrequencyBank[8];
	extern unsigned int code DataRateBank[24];
	extern unsigned int code BasebandBank[29];
	extern unsigned int code TXBank[11];


	extern void vRadioDelayUs(unsigned char dly);
	extern void vRadioDelayMs(unsigned char dly);
	
	extern void vInitRadio(void);
	extern void vSoftReset(void);
	extern unsigned char bGoSleep(void);
	extern unsigned char bGoStandby(void);
	extern unsigned char bGoTx(void);
	extern unsigned char bGoRx(void);
	extern void vFastGoRx(void);
	extern unsigned char bGoSwitch(void);
	extern unsigned char bReadStatus(void);
	extern unsigned char bReadRssi(unsigned char unit_dbm);
	
	extern void vGpioFuncCfg(unsigned char io_cfg);
	extern void vIntSrcCfg(unsigned char int_1, unsigned char int_2);
	extern void vInt1SrcCfg(unsigned char int_1);
	extern void vInt2SrcCfg(unsigned char int_2);
	extern void vIntSrcEnable(unsigned char en_int);
	extern unsigned char bIntSrcFlagClr(void);
	extern void vEnableAntSwitch(unsigned char mode);
	
	extern void vClearFifo(void);
	extern unsigned char bReadFifoFlag(void);
	extern unsigned int wReadIntFlag(void);
	
	extern void vEnableRdFifo(void);
	extern void vEnableWrFifo(void);
	extern void vSetPayloadLength(unsigned char mode, unsigned char length);
	extern void vEnableAckPacket(unsigned char en);
	extern unsigned char bReadFifo(void);
	extern void vWriteFifo(unsigned char dat);
	
	extern void vCfgBank(unsigned int code *cfg, unsigned char length);
	extern void vAfterCfg(void);
	extern void vReadCfgBank(unsigned char sta_adr,  unsigned char rd_cfg[], unsigned char length);
	extern void vSetIntPolar(unsigned char polar);
	
	extern unsigned char bGetMessage(unsigned char msg[]);
	extern void vSendMessage(unsigned char msg[], unsigned char length);
	extern void vSetChannelOffset(unsigned int interval);
	extern void vSetChannel(unsigned char channel);
	extern void vSetTxPreamble(unsigned int length);



#endif