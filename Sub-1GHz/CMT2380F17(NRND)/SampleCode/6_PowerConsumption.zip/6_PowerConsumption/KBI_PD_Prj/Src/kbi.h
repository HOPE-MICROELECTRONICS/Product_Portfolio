

#ifndef __KBI_H
	#define __KBI_H

	#include 	"CMT2380F17_CONFIG.h"
	
	
	#define		KBI0_1_PIN_SEL		0			// 0 = KBI0 as P1.0 & KBI1 as P1.1
												//!0 = KBI0 as P4.7 & KBI1 as P3.3
												
	#define		KBI2_3_PIN_SEL		1			// 0 = KBI2 as P3.0 & KBI3 as P3.1
												//!0 = KBI2 as P2.2 & KBI3 as P2.4

	#define		KBI4_5_PIN_SEL		0 			// 0 = KBI4 as P3.3 & KBI5 as P1.5
												// 1 = KBI4 as P3.4 & KBI5 as P3.5
												// 2 = KBI4 as P6.0	& KBI5 as P6.1
												// 3 = KBI4 as P1.5 & KBI5 as P3.3
												
	#define		KBI6_7_PIN_SEL		0			// 0 = KBI6 as P1.6 & KBI7 as P1.7
												//!0 = KBI6 as P3.0 & KBI7 as P3.1																																			

	#define		KBI_MASK_INIT_VAL	0x0C		// 0 = disable KBI.N interrupt 
												// 1 = enable KBI.N interrupt	

	#define		KBI_PATN_VAL		0x0C		// KBI compare value
	
	#define		KBI_FILTER_SEL		2			// 0 = disable
												// 1 = SYS_CLK x3
												// 2 = SYS_CLK/6 x3
												// 3 = S0TOF x3										
	
	#define		KBI_EDGE_SEL		1			// 0 = level detection mode
												//!0 = edge detection mode

	#define		KBI_PATN_SEL		0			// 0 = not equ KBPATN trigger interrupt
												//!0 = equ KBPATN trigger interrupt
	
	extern void vKeyIntInit(void);												

#endif