#include "sysclk.h"


void vSystemClockInit(void)
{
 unsigned char tmp;
 
 tmp = DRV_PageP_Read(DCON0_P);   		
 if(CPU_LP_EN!=0)
  	tmp &= (~HSE_P); 	
 else
  	tmp |= HSE_P;
 if(CPU_HP_EN!=0)
 	tmp |= (HSE_P|HSE1_P);
 else
 	tmp &= (~HSE1_P);
 DRV_PageP_Write(DCON0_P, tmp); 


 __DRV_SFR_PageIndex(0);  		
 AUXR0 &= 0x1F;
 switch(ICKO_SEL)						//P6.0 ICKO
 	{
	case 3: AUXR0 |= 0xE0; break;
 	case 2: AUXR0 |= 0xA0; break;
 	case 1: AUXR0 |= 0x60; break;
 	case 0:
 	default: break;		
 	}

 switch(OSC_IN_SEL)
 	{
 	case 2:								//ILRCO 32kHz , MCKS=00

 		DRV_PageP_Write(CKCON2_P, 0x12);
 		
 		tmp  = DRV_PageP_Read(CKCON3_P);
 		tmp &= 0xF3;
 		tmp |= ((MCK_DIV_OUT_SEL&0x03)<<2); 
 		DRV_PageP_Write(CKCON3_P, tmp); 
 		
 		DRV_PageP_Write(CKCON5_P, 0x00);
 		
 		tmp  = DRV_PageP_Read(DCON0_P);
 		tmp &= 0x5F;
 	 	DRV_PageP_Write(DCON0_P, tmp);	
 	 	
 	 	tmp  = DRV_PageP_Read(CKCON0_P);
 	 	tmp &= 0x10;
 	 	tmp |= SYSCLK_DIV_SEL;
 	 	if(CPU_CLK_SEL!=0)
 	 		tmp |= CCKS_P;
 	 	DRV_PageP_Write(CKCON0_P, tmp);

		for(tmp=0; tmp<100; tmp++)
			{
			_nop_(); _nop_(); _nop_(); _nop_();
			}
		
		DRV_PageP_Write(CKCON2_P, 0x02); 	
 		break;
 	
 	case 0:								//IHRCO
 	default:	
 	 	tmp  = DRV_PageP_Read(CKCON0_P);
 	 	tmp &= 0x10;
 	 	if(IHRCO_SEL!=0)
 	 		tmp |= AFS_P;
		if(CKM_EN!=0)
			tmp |= ENCKM_P; 	 		
 	 	tmp |= SYSCLK_DIV_SEL;
 	 	if(CPU_CLK_SEL!=0)
 	 		tmp |= CCKS_P;
 	 	DRV_PageP_Write(CKCON0_P, tmp);			

 		tmp  = DRV_PageP_Read(CKCON2_P);
 		tmp &= 0xFC;					//select IHRCO, default IHRCO enable
 		tmp |= ((MCK_OUT_SEL&0x03)<<2);
		DRV_PageP_Write(CKCON2_P, tmp); 		

 		tmp  = DRV_PageP_Read(CKCON3_P);
 		tmp &= 0xF3;
 		tmp |= ((MCK_DIV_OUT_SEL&0x03)<<2); 
 		DRV_PageP_Write(CKCON3_P, tmp); 	
 	
 		if(CKM_MODE_SEL!=0)
 	 		DRV_PageP_Write(CKCON5_P, 0x01);	
 		else
 			DRV_PageP_Write(CKCON5_P, 0x00);
 		
 		break;
 	}
}

void vSystemClockRecovry(void)
{
 unsigned char i;

 DRV_PageP_Write(CKCON2_P, 0x10);
 for(i=0; i<100; i++)
 	{
	_nop_(); _nop_(); _nop_(); _nop_(); _nop_();
	}
 	
 DRV_PageP_Write(CKCON0_P, 0x10);	
 DRV_PageP_Write(CKCON3_P, 0x00);
 DRV_PageP_Write(CKCON5_P, 0x00);
 i = DRV_PageP_Read(DCON0_P);
 i &= (~(HSE_P|HSE1_P));
 i |= HSE_P; 
 DRV_PageP_Write(DCON0_P,  i); 
 
 __DRV_SFR_PageIndex(0);  		
 AUXR0 &= 0x1F;
}
