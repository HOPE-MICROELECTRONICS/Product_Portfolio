/*********************************************************************
    Project: Blank
    Author:  QY.Ruan
			 CMT2380F17 QFN40_
			 CpuCLK=12MHz, SysCLK=12MHz

	Description: create blank project
	Note:

    Creat time: 2021-11-20
    Modify:: 
*********************************************************************/
#include "demo.h"


void main ()
{

 	System_Init();

    #if 0   			//for test ITEA Function
    	__DRV_INT_ITEA_Enable();
    #endif


    while(1)
    	{
        //Code
    	}
}