/*********************************************************************
    Project: Radio with Spi3
    Author:	 QY.Ruan
			 CMT2380F17 QFN40_
			 CpuCLK=12MHz, SysCLK=12MHz
	Description:

	Note:

    Creat time::
    Modify::
    
*********************************************************************/
#include 	"demo.h"

#define 	MCU_SYSCLK		12000000
#define 	MCU_CPUCLK		(MCU_SYSCLK)

#define		WORK_MODE		0		// 3 = transmit Prefix(0xAA)
									// 2 = receive mode for sensisity test, GPIO3 for Dout
									// 1 = transmit packet test
									// 0 = receive packet test

#define		D_LED		P31

/*************************************************
Function:     	void DelayXus(u16 xUs)
Description:   	dealy��unit:us
Input:     			u8 Us -> *1us  (1~255)
Output:     
*************************************************/
void DelayXus(u8 xUs)
{
 while(xUs!=0)
	{
	#if (MCU_CPUCLK>=11059200)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=14745600)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=16000000)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=22118400)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif
	
	#if (MCU_CPUCLK>=24000000)
		_nop_();
		_nop_();
	#endif		

	#if (MCU_CPUCLK>=29491200)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=32000000)
		_nop_();
		_nop_();
	#endif

	xUs--;
	}
}

/*************************************************
Function:     	void DelayXms(u16 xMs)
Description:    dealy��unit:ms
Input:     			u16 xMs -> *1ms  (1~65535)
Output:     
*************************************************/
void DelayXms(u16 xMs)
{
 while(xMs!=0)
	{
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	xMs--;
	}
}

void main ()
{
 u8 i;
 u8 rx_cnt;
 u8 xdata tx_buf[UHF_PKT_LEN];
 u8 xdata rx_buf[UHF_PKT_LEN];


 System_Init();

 for(i=0; i<UHF_PKT_LEN; i++)
	tx_buf[i] = i+'0';


 #if	(WORK_MODE==3)								//test base tx prefix
 	vSpiInit();
 	vInitRadio();
 	vIntSrcCfg(INT_TX_DONE, INT_TX_FIFO_NMTY);
 	gPayloadLength = UHF_PKT_LEN;
	bGoTx();
 	while(1)
		{
		D_LED = 0;
		DelayXms(100);
		D_LED = 1;
		DelayXms(100);
		}	
 #endif

 #if	(WORK_MODE==2)		   						//test base rx mode
	vSpiInit();
 	vInitRadio();
 	vIntSrcCfg(INT_PKT_DONE, INT_RX_FIFO_WBYTE);
 	gPayloadLength = UHF_PKT_LEN;
	bGoRx();
	D_LED = 0;
 	while(1)
		{
		if(RF_GPIO1)
			{
			bIntSrcFlagClr();
			vClearFifo(); 
			vFastGoRx();
			}
		}
 #endif
 
 #if	(WORK_MODE==1)								//test transmit packet mode

	 vSpiInit();
	 vInitRadio();
	 vIntSrcCfg(INT_TX_DONE, INT_TX_FIFO_NMTY);
	 while(1)
	 	{
		D_LED = 0;
		vSendMessage(tx_buf, UHF_PKT_LEN);
		while(!RF_GPIO1);
		bGoStandby();
		bIntSrcFlagClr();
		vClearFifo();	
		D_LED = 1;
		DelayXms(50);
		}
 #endif

 #if 	((WORK_MODE==0)||(WORK_MODE>=4))	 	 	//test receive packet mode
	 vSpiInit();
	 vInitRadio();
	 vIntSrcCfg(INT_PKT_DONE, INT_RX_FIFO_WBYTE);
	 gPayloadLength = UHF_PKT_LEN;
	 bGoRx();
	 rx_cnt = 0;
	 while(1)
	 	{
		if(RF_GPIO1)
			{
			bGoStandby();
			bGetMessage(rx_buf);
			i = bIntSrcFlagClr();
			vClearFifo(); 
			i &= 0x03;
			switch(i)
				{
				case 0x03:												//CRC OK & PKT DONE
					rx_cnt++;
					D_LED = 0;
					break;
				case 0x01:												//CRC NG & PKT DONE
				default:
					break;
					}	
			vIntSrcCfg(INT_PKT_DONE, INT_RX_FIFO_WBYTE);
			gPayloadLength = UHF_PKT_LEN;								//��������
			vFastGoRx();
			DelayXms(10);
			D_LED = 1;			
			}
		}
 #endif
}
