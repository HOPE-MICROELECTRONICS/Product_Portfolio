#include "pca_hso.h"


void vPcaHsoOutputInit(void)
{
 unsigned char tmp;
 
 __DRV_SFR_PageIndex(6);
 AUXR9 &= (~(C0FDC1|C0FDC0));
  
 __DRV_SFR_PageIndex(5);
 AUXR8 &= (~(C0PPS2|POE7|POE6));
 if(PWM_CH6_7_PIN_SEL)
 	AUXR8 |= C0PPS2;
 if(PWM_CH6_PIN_EN)
 	AUXR8 |= POE6;
 if(PWM_CH7_PIN_EN)
 	AUXR8 |= POE7;
 
 
 __DRV_SFR_PageIndex(4); 
 if(PCA_C0CKO_EN)
 	AUXR7 |= C0CKOE;
 else
 	AUXR7 &= (~C0CKOE); 
 
 __DRV_SFR_PageIndex(2); 
 if(PCA_C0CKO_PIN_SEL)  	
	AUXR5 |= C0COPS;
 else
 	AUXR5 &= (~C0COPS);
 if(PWM_CH0_AB_PIN_SEL)
 	AUXR5 |= C0PPS0;
 else
 	AUXR5 &= (~C0PPS0);
 if(PWM_CH2_AB_PIN_SEL)
 	AUXR5 |= C0PPS1;
 else
 	AUXR5 &= (~C0PPS1);	
 	


 __DRV_SFR_PageIndex(1);
 PDTCRA  = 0x00;
 PCAPWM6 = 0x00;
 PCAPWM7 = 0x00;
 CCAP6L  = 0x00;
 CCAP7L  = 0x00;
 CCAP6H  = 0x00;
 CCAP7H  = 0x00; 
   

 __DRV_SFR_PageIndex(0);
 tmp = 0x99;
 if(PWW_CH0_A_PIN_EN)
 	tmp |= POE0A;
 if(PWW_CH0_B_PIN_EN)
 	tmp |= POE0B;
 if(PWW_CH2_A_PIN_EN)
 	tmp |= POE2A;
 if(PWW_CH2_B_PIN_EN)
 	tmp |= POE2B;
 PAOE   = tmp;
 AUXR0 &= (~PBKF);
 PWMCR  = 0x00;
 
 CCAPM0 = 0x00;
 CCAPM1 = 0x00;
 CCAPM2 = 0x00;
 CCAPM3 = 0x00;
 CCAPM4 = 0x00;
 CCAPM5 = 0x00;
 
 PCAPWM0 = 0x00;
 PCAPWM1 = 0x00;
 PCAPWM2 = 0x00;
 PCAPWM3 = 0x00;
 PCAPWM4 = 0x00;
 PCAPWM5 = 0x00;
 
 CCAP0L  = 0x00;
 CCAP1L  = 0x00;
 CCAP2L  = 0x00;
 CCAP3L  = 0x00;
 CCAP4L  = 0x00;
 CCAP5L  = 0x00;
 
 CCAP0H  = 0x00;
 CCAP1H  = 0x00;
 CCAP2H  = 0x00;
 CCAP3H  = 0x00;
 CCAP4H  = 0x00;
 CCAP5H  = 0x00;  
 
 if(PWM_CH0_EN)
 	{
	CCAPM0   = 0x4C; 
	PCAPWM0 &= 0x3F;
	if(PWM_CH0_INV_OUTPUT)
		PCAPWM0 |= 0x04;
	CCAP0L = PWM_CH0_CMP_VALUE;
	CCAP0H = (PWM_CH0_CMP_VALUE>>8);
	}

 if(PWM_CH2_EN)
 	{
	CCAPM2   = 0x4C; 
	PCAPWM2 &= 0x3F;
	if(PWM_CH2_INV_OUTPUT)
 		PCAPWM2 |= 0x04;
 	CCAP2L = PWM_CH2_CMP_VALUE;
 	CCAP2H = (PWM_CH2_CMP_VALUE>>8);	
	}

 if(PWM_CH6_EN)
 	{
 	__DRV_SFR_PageIndex(1);	
 	CCAPM6   = 0x4C; 
	PCAPWM6 &= 0x3F;
 	if(PWM_CH6_INV_OUTPUT)
 		PCAPWM6 |= 0x04;		
 	CCAP6L = PWM_CH6_CMP_VALUE;
 	CCAP6H = (PWM_CH6_CMP_VALUE>>8);
	__DRV_SFR_PageIndex(0);		
	}

 if(PWM_CH7_EN)
 	{
 	__DRV_SFR_PageIndex(1);	
 	CCAPM7   = 0x4C; 
	PCAPWM7 &= 0x3F;
 	if(PWM_CH7_INV_OUTPUT)
 		PCAPWM7 |= 0x04;		
 	CCAP7L = PWM_CH7_CMP_VALUE;
 	CCAP7H = (PWM_CH7_CMP_VALUE>>8);
	__DRV_SFR_PageIndex(0);		
	}

 CHRL	 = (PCA_CH_RELOAD_VAL>>8);
 CLRL	 = PCA_CH_RELOAD_VAL;
 
 tmp  = 0;
 tmp |= ((PCA_CLK_SEL&0x07)<<1);
 if(PCA_STOP_IN_IDLE)
 	tmp |= CIDL;
 CMOD = tmp;
 
 CF = 0;			//CCON
 CR = 1;
}