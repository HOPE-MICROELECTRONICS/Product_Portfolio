


#ifndef __PCA_CAPTURE_H
	#define __PCA_CAPTURE_H
	

	#include "CMT2380F17_CONFIG.h"
	
	#define		PCA_CLK_SEL				0			// 0 = SYS_CLK/12
													// 1 = SYS_CLK/2
													// 2 = T0OF(Timer0 Overflow)
													// 3 = ECI(PCA0 External Input)
													// 4 = CKMIX16 
													// 5 = SYS_CLK
													// 6 = S0TOF(S0BRG Overflow)
													// 7 = MCKDO
													
	
	#define		PCA_CH_RELOAD_VAL		0			// 0-65535, pca0 reload value, 16bit mode
	
	
	#define		PCA_STOP_IN_IDLE		0 			// 0 = PCA0 on going even in idle mode
													//!0 = PCA0 stop in idle mode

	#define		PCA_C0CKO_EN			0			// 0 = disable C0CKO
													//!0 = enable C0CKO
													
	#define		PCA_C0CKO_PIN_SEL		1			// 0 = select P4.7 as C0CKO
													//!0 = select P3.3 as C0CKO


	
	#define		PCA_CAP_BUF_EN			0			// 0 = disable capture with buffer, for EX0-EX5 
													//!0 = enable capture with buffer, only for EX0, EX2, EX4

	//========================================================================================================================

	#define		CAP_EX1_EN				0			// 0 = diable PCA0 ch1
													//!0 = enable PCA0 ch1
													//note: CEX1 == P3.3

		#define	CAP_EX1_MODE			0 			// 0 = disable capture 
													// 1 = enable only falling edge capture
													// 2 = enable only raising edge capture 
													// 3 = enable both falling & raising edge capture	
													
	//========================================================================================================================
	#define		CAP_EX3_EN				1			// 0 = diable PCA0 ch3
													//!0 = enable PCA0 ch3
													//note: CEX3 == P3.4

		#define	CAP_EX3_MODE			1 			// 0 = disable capture 
													// 1 = enable only falling edge capture
													// 2 = enable only raising edge capture 
													// 3 = enable both falling & raising edge capture	

	//========================================================================================================================
	#define		CAP_EX5_EN				0			// 0 = diable PCA0 ch1
													//!0 = enable PCA0 ch1
													//note: CEX5 == P3.5

		#define	CAP_EX5_MODE			0 			// 0 = disable capture 
													// 1 = enable only falling edge capture
													// 2 = enable only raising edge capture 
													// 3 = enable both falling & raising edge capture	

	//========================================================================================================================
	#define		CAP_EX0_EN				1			// 0 = diable PCA0 ch0
													//!0 = enable PCA0 ch0 

		#define	CAP_EX0_MODE			1 			// 0 = disable capture 
													// 1 = enable only falling edge capture
													// 2 = enable only raising edge capture 
													// 3 = enable both falling & raising edge capture	

	//========================================================================================================================
	#define		CAP_EX2_EN				0			// 0 = diable PCA0 ch2
													//!0 = enable PCA0 ch2
													
		#define	CAP_EX2_MODE			0			// 0 = disable capture 
													// 1 = enable only falling edge capture
													// 2 = enable only raising edge capture 
													// 3 = enable both falling & raising edge capture	

	//========================================================================================================================
	#define		CAP_EX4_EN				0			// 0 = diable PCA0 ch4
													//!0 = enable PCA0 ch4

		#define	CAP_EX4_MODE			0 			// 0 = disable capture 
													// 1 = enable only falling edge capture
													// 2 = enable only raising edge capture 
													// 3 = enable both falling & raising edge capture	



	#define		CAP_EX0_2_4_PIN_SEL		0			// 0 = P2.2 as CEX0, P2.4 as CEX2, P1.7 as CEX4
													//!0 = P3.0 as CEX0, P2.4 as CEX2, P3.1 as CEX4												
													
	#define		CAP_EX2_IN_SEL			0			// 0 = CEX2 Port Pin
													//!0 = T3EXIas CEX2

	#define		CAP_EX4_IN_SEL			0			// 0 = CEX4 Port Pin
													//!0 = T2EXI as CEX4																								

	extern void vPcaCaptureInit(void);

#endif	