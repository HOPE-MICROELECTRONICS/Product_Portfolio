/*********************************************************************
    Project: PCA0 Capture test, input 500Hz
    Author:  QY.Ruan
			 CMT2380F17 QFN40_
			 CpuCLK=12MHz, SysCLK=12MHz
	Description:
			
	Note:

    Creat time::
    Modify::
    
*********************************************************************/
#include "demo.h"


#define 	MCU_SYSCLK		12000000
#define 	MCU_CPUCLK		(MCU_SYSCLK)

#define		D_LED			P31

#define		LED				P45

#define		KEY2			P22
#define		KEY1			P24

unsigned int ex0_buffer[8];
unsigned int ex1_buffer[8];
unsigned int ex2_buffer[8];
unsigned int ex3_buffer[8];
unsigned int ex4_buffer[8];
unsigned int ex5_buffer[8];

unsigned char ex0_index;
unsigned char ex1_index;
unsigned char ex2_index;
unsigned char ex3_index;
unsigned char ex4_index;
unsigned char ex5_index;


/*************************************************
Function:     	void DelayXus(u16 xUs)
Description:   	dealy��unit:us
Input:     			u8 Us -> *1us  (1~255)
Output:     
*************************************************/
void DelayXus(u8 xUs)
{
 while(xUs!=0)
	{
	#if (MCU_CPUCLK>=11059200)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=14745600)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=16000000)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=22118400)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif
	
	#if (MCU_CPUCLK>=24000000)
		_nop_();
		_nop_();
	#endif		

	#if (MCU_CPUCLK>=29491200)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=32000000)
		_nop_();
		_nop_();
	#endif

	xUs--;
	}
}

/*************************************************
Function:     	void DelayXms(u16 xMs)
Description:    dealy��unit:ms
Input:     			u16 xMs -> *1ms  (1~65535)
Output:     
*************************************************/
void DelayXms(u16 xMs)
{
 while(xMs!=0)
	{
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	xMs--;
	}
}

void WaitKeyPress(void)
{
 u8 i; 

 for(i=0; i<15; )
 	{
	DelayXms(20);
	if(!KEY2)
		i++;
	else
		i = 0;
	}
}


void main ()
{
 u8 tmp;
 System_Init();
 DelayXms(250);
 EA = 1;

// D_LED = 0;
// WaitKeyPress();
// _nop_();
// _nop_();
// D_LED = 1;
//
//
// if(PCA_C0CKO_PIN_SEL==0)
//	{
//	tmp  = DRV_PageP_Read(DCON0_P);  	//disable OCD Port
//	tmp &= (~RSTIO_P);
//	DRV_PageP_Write(DCON0_P, tmp);   
//	DelayXms(10);	
//	}

 ex0_index = 0;
 ex1_index = 0;
 ex2_index = 0;
 ex3_index = 0;
 ex4_index = 0;
 ex5_index = 0;

 vPcaCaptureInit();
 while(1);

}

void pca_capture_ISR(void)   interrupt PCA0_ISR_VECTOR 
{
 _push_(SFRPI);

 __DRV_SFR_PageIndex(0);
 if(CCF0)
 	{
	if(PCA_CAP_BUF_EN)
		{
		ex0_buffer[ex0_index]   = CCAP1H;
		ex0_buffer[ex0_index] <<= 8;
		ex0_buffer[ex0_index]  |= CCAP1L;
		}
	else
		{
		ex0_buffer[ex0_index]   = CCAP0H;
		ex0_buffer[ex0_index] <<= 8;
		ex0_buffer[ex0_index]  |= CCAP0L;
		}		
	ex0_index++;
	if(ex0_index>=8)
		ex0_index = 0;
	CCF0 = 0;
	}

 if(CCF1)
	{
	ex1_buffer[ex1_index]   = CCAP1H;
	ex1_buffer[ex1_index] <<= 8;
	ex1_buffer[ex1_index]  |= CCAP1L;
	ex1_index++;
	if(ex1_index>=8)
		ex1_index = 0;
	CCF1 = 0;		
	}

 if(CCF2)
 	{
	if(PCA_CAP_BUF_EN)
		{
		ex2_buffer[ex2_index]   = CCAP3H;
		ex2_buffer[ex2_index] <<= 8;
		ex2_buffer[ex2_index]  |= CCAP3L;
		}
	else
		{
		ex2_buffer[ex2_index]   = CCAP2H;
		ex2_buffer[ex2_index] <<= 8;
		ex2_buffer[ex2_index]  |= CCAP2L;
		}		
	ex2_index++;
	if(ex2_index>=8)
		ex2_index = 0;	
	CCF2 = 0;
	}
 
 if(CCF3)
 	{
	ex3_buffer[ex3_index]   = CCAP3H;
	ex3_buffer[ex3_index] <<= 8;
	ex3_buffer[ex3_index]  |= CCAP3L;
	ex3_index++;
	if(ex3_index>=8)
		ex3_index = 0;
	CCF3 = 0;		
	}

 if(CCF4)
 	{
	if(PCA_CAP_BUF_EN)
		{
		ex4_buffer[ex4_index]   = CCAP5H;
		ex4_buffer[ex4_index] <<= 8;
		ex4_buffer[ex4_index]  |= CCAP5L;
		}
	else
		{
		ex4_buffer[ex4_index]   = CCAP4H;
		ex4_buffer[ex4_index] <<= 8;
		ex4_buffer[ex4_index]  |= CCAP4L;
		}		
	ex4_index++;
	if(ex4_index>=8)
		ex4_index = 0;
	CCF4 = 0;	
	}

 if(CCF5)
 	{
	ex5_buffer[ex5_index]   = CCAP5H;
	ex5_buffer[ex5_index] <<= 8;
	ex5_buffer[ex5_index]  |= CCAP5L;
	ex5_index++;
	if(ex5_index>=8)
		ex5_index = 0;
	CCF5 = 0;		
	}
    
 _pop_(SFRPI);
}


