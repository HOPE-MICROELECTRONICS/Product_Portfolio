#include "pca_capture.h"

void vPcaCaptureInit(void)
{
 unsigned char tmp;
 
  
 __DRV_SFR_PageIndex(4); 
 if(PCA_C0CKO_EN)
 	AUXR7 |= C0CKOE;
 else
 	AUXR7 &= (~C0CKOE); 
 
 __DRV_SFR_PageIndex(2); 
 
 AUXR5 &= (~(C0IC4S0|C0IC2S0|C0PS0));
 if(CAP_EX4_IN_SEL)
 	AUXR5 |= C0IC4S0;
 if(CAP_EX2_IN_SEL)  	
	AUXR5 |= C0IC2S0;
 if(CAP_EX0_2_4_PIN_SEL)
 	AUXR5 |= C0PS0;

 __DRV_SFR_PageIndex(1);
 PDTCRA  = 0x00;
 PCAPWM6 = 0x00;
 PCAPWM7 = 0x00;
 CCAP6L  = 0x00;
 CCAP7L  = 0x00;
 CCAP6H  = 0x00;
 CCAP7H  = 0x00; 
   

 __DRV_SFR_PageIndex(0);
 PAOE    = 0x99;
 PWMCR   = 0x00;
         
 CCAPM0  = 0x00;
 CCAPM1  = 0x00;
 CCAPM2  = 0x00;
 CCAPM3  = 0x00;
 CCAPM4  = 0x00;
 CCAPM5  = 0x00;
 
 PCAPWM0 = 0x00;
 PCAPWM1 = 0x00;
 PCAPWM2 = 0x00;
 PCAPWM3 = 0x00;
 PCAPWM4 = 0x00;
 PCAPWM5 = 0x00;
 
 if((CAP_EX1_EN!=0)&&(PCA_CAP_BUF_EN==0))
 	{
	CCAPM1   = 0x01;
	CCAPM1  |= ((CAP_EX1_MODE&0x03)<<4);
	}

 if((CAP_EX3_EN!=0)&&(PCA_CAP_BUF_EN==0))
 	{
	CCAPM3   = 0x01;
	CCAPM3  |= ((CAP_EX3_MODE&0x03)<<4);
	}

 if((CAP_EX5_EN!=0)&&(PCA_CAP_BUF_EN==0))
 	{
	CCAPM5   = 0x01;
	CCAPM5  |= ((CAP_EX5_MODE&0x03)<<4);
	}
 
 if(CAP_EX0_EN)
 	{
 	CCAPM0  = 0x01;		
 	CCAPM0  |= ((CAP_EX0_MODE&0x03)<<4);
 	}

 if(CAP_EX2_EN)
 	{
 	CCAPM2  = 0x01;		
 	CCAPM2  |= ((CAP_EX2_MODE&0x03)<<4); 		
 	}

 if(CAP_EX4_EN)
 	{
  	CCAPM4  = 0x01;		
 	CCAPM4  |= ((CAP_EX4_MODE&0x03)<<4);		
 	}
 	

 CHRL = (PCA_CH_RELOAD_VAL>>8);
 CLRL = PCA_CH_RELOAD_VAL;
 
 if(PCA_CAP_BUF_EN)
 	tmp = (BME4|BME2|BME0);
 else
 	tmp = 0;
 tmp |= ((PCA_CLK_SEL&0x07)<<1);
 if(PCA_STOP_IN_IDLE)
 	tmp |= CIDL;
 CMOD = tmp;

 EIE1 |= EPCA;		//enable PCA interrupt
 
 CF = 0;			//CCON
 CR = 1;
}

