


#ifndef __PCA_9B_PWM_H
	#define __PCA_9B_PWM_H
	
	#include "CMT2380F17_CONFIG.h"
	
	#define		PCA_CLK_SEL				5			// 0 = SYS_CLK/12
													// 1 = SYS_CLK/2
													// 2 = T0OF(Timer0 Overflow)
													// 3 = ECI(PCA0 External Input)
													// 4 = CKMIX16 
													// 5 = SYS_CLK
													// 6 = S0TOF(S0BRG Overflow)
													// 7 = MCKDO
													
	
	#define		PCA_CH_RELOAD_VAL		0			// 0-255, pca0 reload value, 8bit mode
	
	
	#define		PCA_STOP_IN_IDLE		0 			// 0 = PCA0 on going even in idle mode
													//!0 = PCA0 stop in idle mode

	#define		PCA_C0CKO_EN			0			// 0 = disable C0CKO
													//!0 = enable C0CKO
													
	#define		PCA_C0CKO_PIN_SEL		1			// 0 = select P4.7 as C0CKO
													//!0 = select P3.3 as C0CKO


	//========================================================================================================================
	#define		PWM_CH0_EN				0			// 0 = diable PCA0 ch0
													//!0 = enable PCA0 ch0 

		#define		PWM_CH0_INV_OUTPUT	0 			// 0 = non toggle output
													//!0 = toggle output	
 		
		#define		PWM_CH0_CMP_INT_VAL	0			// 0-511, 9bit mode		

		#define		PWM_CH0_AB_PIN_SEL	0			// 0 = PWM0A as P1.6, PWM0B as P1.7
													//!0 = PWM0A as P6.0, PWM0B as P6.1

		#define		PWW_CH0_A_PIN_EN	0			// 0 = disable PWM0A output
													//!0 = enable PWM0A output		

		#define		PWW_CH0_B_PIN_EN	0			// 0 = disable PWM0B output
													//!0 = enable PWM0B output			

	//========================================================================================================================
	#define		PWM_CH2_EN				0			// 0 = diable PCA0 ch2
													//!0 = enable PCA0 ch2

		#define		PWM_CH2_INV_OUTPUT	0 			// 0 = non toggle output
													//!0 = toggle output	

 		#define		PWM_CH2_CMP_INT_VAL	0			// 0-511, 9bit mode

  		#define		PWM_CH2_AB_PIN_SEL	1			// 0 = PWM2A as P6.0, PWM2B as P6.1
													//!0 = PWM2A as P3.4, PWM2B as P3.5
		
		#define		PWW_CH2_A_PIN_EN	0			// 0 = disable PWM2A output
													//!0 = enable PWM2A output		

		#define		PWW_CH2_B_PIN_EN	0			// 0 = disable PWM2B output
													//!0 = enable PWM2B output			

	//========================================================================================================================
	#define		PWM_CH6_EN				0			// 0 = diable PCA0 ch6	
												   	//!0 = enable PCA0 ch6 

		#define		PWM_CH6_INV_OUTPUT	0 			// 0 = non toggle output
													//!0 = toggle output
  
 		#define		PWM_CH6_CMP_INT_VAL	0			// 0-511, 9bit mode

		#define		PWM_CH6_7_PIN_SEL	1			// 0 = PWM6 as P6.0, PMW7 as P6.1
													//!0 = PWM6 as P3.0, PWM7 as P3.1
   		
		#define		PWM_CH6_PIN_EN		0			// 0 = disable PWM6 output
													//!0 = enable PWM6 output

	//========================================================================================================================	
	#define		PWM_CH7_EN				1			// 0 = diable PCA0 ch7		
												   	//!0 = enable PCA0 ch7

		#define		PWM_CH7_INV_OUTPUT	0 			// 0 = non toggle output
													//!0 = toggle output
   	
		#define		PWM_CH7_CMP_INT_VAL	255			// 0-511, 9bit mode

		#define		PWM_CH7_PIN_EN		1			// 0 = disable PWM7 output
													//!0 = enable PWM7 output																						
	

	extern void vPca9bPwmOutputInit(void);
	extern void vSetPwm0Buffer(unsigned int val);
	extern void vSetPwm2Buffer(unsigned int val);
	extern void vSetPwm6Buffer(unsigned int val);
	extern void vSetPwm7Buffer(unsigned int val);

#endif	