


#ifndef __PCA_CKO_H
	#define __PCA_CKO_H
	

	#include "CMT2380F17_CONFIG.h"
	
	#define		PCA_CLK_SEL				1			// 0 = SYS_CLK/12
													// 1 = SYS_CLK/2
													// 2 = T0OF(Timer0 Overflow)
													// 3 = ECI(PCA0 External Input)
													// 4 = CKMIX16 
													// 5 = SYS_CLK
													// 6 = S0TOF(S0BRG Overflow)
													// 7 = MCKDO
													
	
	#define		PCA_CH_RELOAD_VAL		100			// 0-65535, pca0 reload value
	
	
	#define		PCA_STOP_IN_IDLE		0 			// 0 = PCA0 on going even in idle mode
													//!0 = PCA0 stop in idle mode

	#define		PCA_C0CKO_EN			1			// 0 = disable C0CKO
													//!0 = enable C0CKO
													
	#define		PCA_C0CKO_PIN_SEL		0			// 0 = select P4.7 as C0CKO
													//!0 = select P3.3 as C0CKO

	extern void vPcaClkOutputInit(void);

#endif	