#include "kbi.h"


void vKeyIntInit(void)
{
 unsigned char tmp;
 
 __DRV_SFR_PageIndex(5);
 if(KBI0_1_PIN_SEL)
 	AUXR8 |= KBI0PS0;
 else
 	AUXR8 &= (~KBI0PS0);	

 __DRV_SFR_PageIndex(3);
 AUXR6 &= 0x0F;
 tmp = 0;
 if(KBI2_3_PIN_SEL) 
 	tmp |= KBI2PS0;
 tmp |= ((KBI4_5_PIN_SEL&0x03)<<6);
 if(KBI6_7_PIN_SEL)
 	tmp |= KBI6PS0;
 AUXR6 |= tmp;
 
 __DRV_SFR_PageIndex(0);
 KBMASK = KBI_MASK_INIT_VAL;
 
 tmp = 0;
 tmp |= ((KBI_FILTER_SEL&0x03)<<6);
 if(KBI_EDGE_SEL)
 	tmp |= KBES;
 if(KBI_PATN_SEL)
 	tmp |= PATN_SEL;
 KBCON = tmp;
 
 KBPATN = KBI_PATN_VAL;

 EIE1 |= EKB;			  			// enable interrupt
}

void KBI_KBIF_ISR()  interrupt KBI_ISR_VECTOR
{
 _push_(SFRPI);
 
 __DRV_SFR_PageIndex(0);
 KBCON &= ~KBIF;

 _pop_(SFRPI);
}