


#ifndef __WDT_TIMER_H
	#define __WDT_TIMER_H

	#include "CMT2380F17_CONFIG.h"


	#define		NON_STOP_IN_PD		1			// 0 = stop WDT counter in PD mode
												//!0 = non-stop WDT counter in PD mode

	#define		NON_STOP_IN_IDLE	1			// 0 = stop WDT counter in IDLE mode
												//!0 = non-stop WDT counter in IDLE mode
	
	#define		WDT_PS_SEL			7			// WDT presclaer, range 0-7
												// 0 = /2
												// 1 = /4
												// 2 = /8
												// 3 = /16
												// 4 = /32
												// 5 = /64
												// 6 = /128
												// 7 = /256


	#define		BY_PASS_COUNTER		0			// 0 = 8-bit wdt counter overwise
												//!0 = 1-bit wdt counter overwise

	#define		WDT_CLK_SEL			0			// 0 = ILRCO
												// 1 = ECKI
												// 2 = SYS_CLK/12
												// 3 = S0TOF
	
	extern unsigned char gWdtCounter;

	extern void vWdtTimerInit(void);


#endif	