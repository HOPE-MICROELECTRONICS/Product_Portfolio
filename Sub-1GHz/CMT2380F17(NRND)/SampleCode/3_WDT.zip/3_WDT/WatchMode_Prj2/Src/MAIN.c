/*********************************************************************
    Project:	CMT2380F17 WatchMode
    Author:		
				CMT2380F17, QFN40 
				CpuCLK=12MHz, SysCLK=12MHz
	Description:
			  WDT, enter Power-Down mode, about 2s wake up by WDT
	Note:

    Creat time::
    Modify::
    
*********************************************************************/
#include "CMT2380F17_CONFIG.h"

#define MCU_SYSCLK		12000000
#define MCU_CPUCLK		(MCU_SYSCLK)
#define LED_G_0		P33
#define LED_R		P34
#define LED_G_1		P35
#define POW_SetMode_PD()			PCON0|=PD;
/*************************************************
Function:     	void DelayXus(u16 xUs)
Description:   	dealy��unit:us
Input:     			u8 Us -> *1us  (1~255)
Output:     
*************************************************/
void DelayXus(u8 xUs)
{
	while(xUs!=0)
	{
#if (MCU_CPUCLK>=11059200)
		_nop_();
#endif
#if (MCU_CPUCLK>=14745600)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
#endif
#if (MCU_CPUCLK>=16000000)
		_nop_();
#endif

#if (MCU_CPUCLK>=22118400)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
#endif
#if (MCU_CPUCLK>=24000000)
		_nop_();
		_nop_();
#endif		
#if (MCU_CPUCLK>=29491200)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
#endif
#if (MCU_CPUCLK>=32000000)
		_nop_();
		_nop_();
#endif

		xUs--;
	}
}

/*************************************************
Function:     	void DelayXms(u16 xMs)
Description:    dealy��unit:ms
Input:     			u16 xMs -> *1ms  (1~65535)
Output:     
*************************************************/
void DelayXms(u16 xMs)
{
	while(xMs!=0)
	{
		DelayXus(200);
		DelayXus(200);
		DelayXus(200);
		DelayXus(200);
		DelayXus(200);
		xMs--;
	}
}

void main ()
{
	u8 i;
  System_Init(); 
	__DRV_WDT_Cmd(ENABLE);	 // Enable WDT Counter
	__DRV_WDT_ClearCounter();// clear WDT
	LED_G_0=0;LED_G_1=0;LED_R=0;
	for(i=0;i<10;i++)
	{
		DelayXms(100);
		__DRV_WDT_ClearCounter();// clear WDT
	}
	LED_G_0=1;LED_G_1=1;LED_R=1;

	while(1)
	{ //  not clear WDT, will trigger WDT interrupt
		for(i=0;i<1;i++)
		{
			LED_G_0=!LED_G_0;
			__DRV_WDT_ClearCounter();// clear WDT
			DelayXms(100);
		}
		__DRV_WDT_ClearCounter();// clear WDT
		POW_SetMode_PD();	// enter PD mode
		_nop_();

	}
}
