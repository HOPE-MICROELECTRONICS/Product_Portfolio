/*********************************************************************
    Project: RTC
    Author:  QY.Ruan
			 CMT2380F17-EQR, QFN40_EB
			 CpuCLK=12MHz, SysCLK=12MHz
	Description:
			 
	Note:

    Creat time::
    Modify::
    
*********************************************************************/
#include "Demo.h"


#define 	MCU_SYSCLK		12000000
#define 	MCU_CPUCLK		(MCU_SYSCLK)

#define		D_LED			P31

#define		KEY2			P22
#define		KEY1			P24


/*************************************************
Function:     	void DelayXus(u16 xUs)
Description:   	dealy��unit:us
Input:     			u8 Us -> *1us  (1~255)
Output:     
*************************************************/
void DelayXus(u8 xUs)
{
 while(xUs!=0)
	{
	#if (MCU_CPUCLK>=11059200)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=14745600)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=16000000)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=22118400)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif
	
	#if (MCU_CPUCLK>=24000000)
		_nop_();
		_nop_();
	#endif		

	#if (MCU_CPUCLK>=29491200)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=32000000)
		_nop_();
		_nop_();
	#endif

	xUs--;
	}
}

/*************************************************
Function:     	void DelayXms(u16 xMs)
Description:    dealy��unit:ms
Input:     			u16 xMs -> *1ms  (1~65535)
Output:     
*************************************************/
void DelayXms(u16 xMs)
{
 while(xMs!=0)
	{
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	xMs--;
	}
}

void WaitKeyPress(void)
{
 u8 i; 

 for(i=0; i<15; )
 	{
	DelayXms(20);
	if(!KEY2)
		i++;
	else
		i = 0;
	}
}

void main ()
{
 u8 tmp;
 System_Init();

 #if (RTC_CLK_OUT_EN!=0)
	WaitKeyPress();
	_nop_();
	_nop_();
	 
	tmp  = DRV_PageP_Read(DCON0_P);  	//disable OCD Port
	tmp &= (~OCDE_P);
	DRV_PageP_Write(DCON0_P, tmp);   
 #endif

 EA  = 1;
 vRTCInit();

 while(1)
 	{
	#if ((RTC_CLK_SRC_SEL==4)||(RTC_CLK_SRC_SEL==5))
		if(gRtcCounter&0x01)
			D_LED = 1;
		else
			D_LED = 0;
	#else
		__DRV_SFR_PageIndex(0);
		//PCON0 |= IDL;						//go into idle mode
		PCON0 |= PD;	 					//go into stop mode
		_nop_();
		_nop_();

		if(gRtcCounter&0x01)
			D_LED = 1;
		else
			D_LED = 0;
	#endif
	
	}
}
