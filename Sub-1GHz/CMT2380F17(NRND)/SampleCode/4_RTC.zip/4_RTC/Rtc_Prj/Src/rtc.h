


#ifndef __RTC_H
	#define __RTC_H

	#include "CMT2380F17_CONFIG.h"


	#define		RTC_CLK_SRC_SEL			1			// 0 = ECKI from P6.0
													// 1 = ILRCO 
													// 2 = WDTPS  #need to config WDT
													// 3 = WDTOF  #need to config WDT
													// 4 = SYSCLK
													// 5 = SYSCLK/12

   	#define		RTC_CLK_OUT_EN			1			// 0 = disable clk output(P4.5)
													//!0 = enable clk output
													
	#define		RTC_CLK_SEL				5			//RTCCS[3:0], 0~15
													// 0 = RPSC/2^15
													// 1 = RPSC/2^14
													// 2 = RPSC/2^13
													// ...
													// n = RPSC/2^(15-n) 
													// 14= RPSC/2^1 
													// 15= RTC_CLK_SRC_SEL (bypass RTC Prescaler)

	#define		RTC_RPSC_VALUE			0			// RTC Prescaler�� range 0��7
													// when RTCCS[3:0]             ==0	 |==1	    ||==2   |==3   |==4   |==5     ||==6   |==7   |==8   |==9  	  ||==10/11/12/13/14/15
													// 3'b000 = RTC_CLK_SRC_SEL /= 32768 | 16384    || 8192 | 4096 | 2048 | 1024   ||  512 |  256 |  128 |   64   ||  32/16/ 8/ 4/ 2/ 1
													// 3'b001 = RTC_CLK_SRC_SEL /= 30720 | 15360    || 7680 | 3840 | 1920 |  960   ||  480 |  240 |  120 |   60   ||  
													// 3'b010 = RTC_CLK_SRC_SEL /= 30720 | 15360    || 7680 | 3840 | 1920 |  960   ||  512 |  256 |  128 |   64   ||  
													// 3'b011 = RTC_CLK_SRC_SEL /= 28800 | 14400    || 7200 | 3600 | 1800 |  900   ||  480 |  240 |  120 |   60   ||  
													// 3'b100 = RTC_CLK_SRC_SEL /= 24576 | 12288    || 8192 | 4096 | 2048 | 1024   ||  512 |  256 |  128 |   64   ||  
													// 3'b101 = RTC_CLK_SRC_SEL /= 23040 | 11520    || 7680 | 3840 | 1920 |  960   ||  480 |  240 |  120 |   60   ||  
													// 3'b110 = RTC_CLK_SRC_SEL /= 23040 | 11520    || 7680 | 3840 | 1920 |  960   ||  512 |  256 |  128 |   64   ||  
													// 3'b111 = RTC_CLK_SRC_SEL /= 21600 | 10800    || 7200 | 3600 | 1800 |  900   ||  480 |  240 |  120 |   60   ||  

	#define		RTC_INTERVAL_VALUE		(64-32)		// RTCRL, RTC reload value, 0-63

	
	extern unsigned char gRtcCounter;
		
	extern void vRTCInit(void);


#endif