
#ifndef __UART0_TIMER1_H
	#define __UART0_TIMER1_H

	#include "CMT2380F17_CONFIG.h"


	#define		RX_MAX					64
	#define		RX_MASK					0x3F
	#define		TX_MAX					20


	#define		UART0_MODE_SEL				1			//1=mode1, 8bit UART, by Timer1 overwise
														//3=mode3, 9bit UART, by Timer1 overwise

	#define		UART0_M3_P_SEL				1			//0 = even parity check, when mode3 active
														//!0= odd parity check, when mode3 active	

	#define		UART0_T1X12_SEL				1			//0 = clk/12
														//!0= clk/1

	#define		UART0_EN_DOUBLE_BR			1			//0 =disable double baudrate,
														//!0=enable double baudrate, 	

																								  
	#define		UART0_EX_DOUBLE_BR			1			//0 =disable extra double baudrate, SMOD2
														//!0=enable extra double baudrate, 	SMOD2
														//!!!note, SMOD2 & SMOD1 can not be set 1 at the same time, & SMOD1 is no use when S0BRG as clock source for UART0	

	#define		UART0_DOR_SEL				1			//0 = MSB�ȴ���														 
														//!0= LSB�ȴ��ͣ�Ĭ�ϣ�UART����
	
	#define		UART0_BYPASS_TI_SEL			0			//0	= ����TI0��Ϊ����0�ж�Դ
	 													//!0= ��ֹTI0��Ϊ����0�ж�Դ
	 													
	#define		UART0_UTIE_SEL				0			//0 = ��ֹ��ϵͳ��־�ж����ж�����������TI0
														//!0= ����TI0��־����ϵͳ��־�жϹ����ж�����	 		
														
	#define		UART0_Timer1_BRT_SEL		230			//when T1X12=0, UART0_EN_DOUBLE_BR=0, UART0_EX_DOUBLE_BR=0  & @12MHz
														//val =  48 ->    150bps @mode1/3,   
														//    = 152	->    300bps @mode1/3, 	
														//    = 204 ->    600bps @mode1/3, 	
														//    = 230	->   1200bps @mode1/3, 	
														//    = 243 ->   2400bps @mode1/3, 	
														//---------------------------------------
														//when T1X12=0, UART0_EN_DOUBLE_BR=1, UART0_EX_DOUBLE_BR=0  & @12MHz	x2
														//val =  48 ->    300bps @mode1/3,   
														//    = 152	->    600bps @mode1/3, 	
														//    = 204 ->   1200bps @mode1/3, 	
														//    = 230	->   2400bps @mode1/3, 	
														//    = 243 ->   4800bps @mode1/3, 	
														//---------------------------------------
														//when T1X12=0, UART0_EN_DOUBLE_BR=0, UART0_EX_DOUBLE_BR=1  & @12MHz	x4
														//val =  48 ->    600bps @mode1/3,   
														//    = 152	->   1200bps @mode1/3, 	
														//    = 204 ->   2400bps @mode1/3, 	
														//    = 230	->   4800bps @mode1/3, 	
														//    = 243 ->   9600bps @mode1/3, 	
														//---------------------------------------
														//when T1X12=0, UART0_EN_DOUBLE_BR=1, UART0_EX_DOUBLE_BR=1  & @12MHz	x8
														//val =  48 ->   1200bps @mode1/3,   
														//    = 152	->   2400bps @mode1/3, 	
														//    = 204 ->   4800bps @mode1/3, 	
														//    = 230	->   9600bps @mode1/3, 	
														//    = 243 ->  19200bps @mode1/3, 	
														//---------------------------------------
														//when T1X12=1, UART0_EN_DOUBLE_BR=0, UART0_EX_DOUBLE_BR=0  & @12MHz   	
														//val = 100 ->   2400bps @mode1/3, 	
														//	  = 178 ->   4800bps @mode1/3, 
														//    = 217 ->   9600bps @mode1/3, 
														//    = 230 ->  14400bps @mode1/3, 
														//---------------------------------------
														//when T1X12=1, UART0_EN_DOUBLE_BR=1, UART0_EX_DOUBLE_BR=0  & @12MHz	x2		
														//val = 100 ->   4800bps @mode1/3, 	
														//	  = 178 ->   9600bps @mode1/3, 
														//    = 217 ->  19200bps @mode1/3, 
														//    = 230 ->  28800bps @mode1/3, 
														//---------------------------------------
														//when T1X12=1, UART0_EN_DOUBLE_BR=0, UART0_EX_DOUBLE_BR=1  & @12MHz	x4		
														//val = 100 ->   9600bps @mode1/3, 	
														//	  = 178 ->  19200bps @mode1/3, 
														//    = 217 ->  38400bps @mode1/3, 
														//    = 230 ->  57600bps @mode1/3, 
														//---------------------------------------
														//when T1X12=1, UART0_EN_DOUBLE_BR=1, UART0_EX_DOUBLE_BR=1  & @12MHz	x8		
														//val = 100 ->  19200bps @mode1/3, 	
														//	  = 178 ->  38400bps @mode1/3, 
														//    = 217 ->  76800bps @mode1/3, 
														//    = 230 -> 115200bps @mode1/3, 

	extern unsigned char xdata gUartRxBuffer[RX_MAX];
	extern unsigned char xdata gUartTxBuffer[TX_MAX];
	extern unsigned char gUartRxWrPtr;
	extern unsigned char gUartRxRdPtr;

	extern void vUart0Init(void);
	extern void vUart0SetBuf(unsigned char dat);

	extern void vUart0PrintString(unsigned char code *str);
	extern void vUart0PrintMessageByAscii(unsigned char *msg_str, unsigned int length);
	extern void vUart0PrintMessageByHex(unsigned char *msg_str, unsigned int length);
	
	extern void vUart0NewLine(void);
	extern unsigned char bHex2Ascii(unsigned char ch);
	
#endif	