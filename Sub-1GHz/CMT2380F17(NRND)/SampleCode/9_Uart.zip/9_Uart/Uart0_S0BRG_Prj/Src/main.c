/*********************************************************************
    Project: Uart0, used S0BRG as baudrate clock source
    Author:  QY.Ruan
			 CMT2380F17-EB
			 CpuCLK=12MHz, SysCLK=12MHz
 	Description:
			 Uart0 
	Note:

    Creat time: 2021-11-11
    Modify::
    
*********************************************************************/
#include 	"Uart0_S0BRG_Prj.h"


#define 	MCU_SYSCLK		12000000
#define 	MCU_CPUCLK		(MCU_SYSCLK)

#define		D4_LED			P33
//#define	D5_LED			P34
#define		D6_LED			P35

/*************************************************
Function:     	void DelayXus(u16 xUs)
Description:   	dealy��unit:us
Input:     			u8 Us -> *1us  (1~255)
Output:     
*************************************************/
void DelayXus(u8 xUs)
{
 while(xUs!=0)
	{
	#if (MCU_CPUCLK>=11059200)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=14745600)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=16000000)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=22118400)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif
	
	#if (MCU_CPUCLK>=24000000)
		_nop_();
		_nop_();
	#endif		

	#if (MCU_CPUCLK>=29491200)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=32000000)
		_nop_();
		_nop_();
	#endif

	xUs--;
	}
}

/*************************************************
Function:     	void DelayXms(u16 xMs)
Description:    dealy��unit:ms
Input:     			u16 xMs -> *1ms  (1~65535)
Output:     
*************************************************/
void DelayXms(u16 xMs)
{
 while(xMs!=0)
	{
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	xMs--;
	}
}

void main ()
{
 u8 i, j;

 u8 rd, wr;

 System_Init();
 
 P31 = 1;

 vUart0Init();

 EA = 1;						//enable interrupt

 __DRV_SFR_PageIndex(0);	 
 while(1)
 	{

//	//only send test 
//	D4_LED = 0;
//	vUart0PrintString("Hello! CMT2380F17-EQR");
//	DelayXms(50);
//	D4_LED = 1;
//	DelayXms(250);
//	DelayXms(250);
//	DelayXms(250);
//	DelayXms(200);


	//received to send
	rd = gUartRxRdPtr;
	wr = gUartRxWrPtr;
	if(rd!=wr)
		{
		if(wr>rd)
			{
			i = wr-rd;
			if(i>=TX_MAX)
				{
				i = gUartRxRdPtr;
				for(i=0; i<TX_MAX; i++)
					gUartTxBuffer[i] = gUartRxBuffer[gUartRxRdPtr++];
				vUart0PrintMessageByHex(gUartTxBuffer, TX_MAX);
				}
			}
		else
			{
			i = wr+RX_MAX-rd;
			if(i>=TX_MAX)
				{
				for(i=gUartRxRdPtr, j=0; i<RX_MAX; i++)
					gUartTxBuffer[j++] = gUartRxBuffer[i];
				for(i=0; j<TX_MAX; j++)
					gUartTxBuffer[j] = gUartRxBuffer[i++];
				gUartRxRdPtr = i;	
				vUart0PrintMessageByHex(gUartTxBuffer, TX_MAX);
				}
			}
		}
	}
}
