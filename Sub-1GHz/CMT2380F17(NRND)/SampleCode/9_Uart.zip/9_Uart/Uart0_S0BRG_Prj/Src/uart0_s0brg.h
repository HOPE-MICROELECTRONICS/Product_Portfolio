
#ifndef __UART0_S0BRG_H
	#define __UART0_S0BRG_H

	#include "CMT2380F17_CONFIG.h"


	#define		RX_MAX					64
	#define		RX_MASK					0x3F
	#define		TX_MAX					20


	#define		UART0_MODE_SEL			1				//0=mode0, Shift Register Mode, by S0BRG overwise
														//1=mode1, 8bit UART, by S0BRG overwise
														//3=mode3, 9bit UART, by S0BRG overwise

	#define		UART0_M3_P_SEL			1				//0 = even parity check, when mode3 active
														//!0= odd parity check, when mode3 active	
																								  
	#define		UART0_EX_DOUBLE_BR		0				//0 =disable extra double baudrate, SMOD2
														//!0=enable extra double baudrate, 	SMOD2
														//!!!note, SMOD2 & SMOD1 can not be set 1 at the same time, & SMOD1 is no use when S0BRG as clock source for UART0	

	#define		UART0_DOR_SEL			1				//0 = MSB�ȴ���														 
														//!0= LSB�ȴ��ͣ�Ĭ�ϣ�UART����
	
	#define		UART0_BYPASS_TI_SEL		0				//0	= ����TI0��Ϊ����0�ж�Դ
	 													//!0= ��ֹTI0��Ϊ����0�ж�Դ
	 													
	#define		UART0_UTIE_SEL			0				//0 = ��ֹ��ϵͳ��־�ж����ж�����������TI0
														//!0= ����TI0��־����ϵͳ��־�жϹ����ж�����	 		
														

	
	#define		UART0_S0_TX12_SEL		1				//0 = S0 select Sysclk/12 as clk source
														//!0= S0 select Sysclk as clk Sysclk
														
	#define		UART0_S0_CKO_EN			1				//0 = disable S0BRG clock output to S0CKO, mapping to P3.3
														//!0= enable S0BRG clock output to S0CKO, mapping to P3.3
														
	#define		UART0_S0_ARTE_ESL		0				//0 = disable auto re-send
														//!0= enable auto re-send																													
																																	
	#define		UART0_S0_BRT_SEL		217			 	//when S0_TX12=0, UART0_EX_DOUBLE_BR=0, & @12MHz
														//val =  48 ->    150bps @mode1/3,   600bps @mode0
														//    = 152	->    300bps @mode1/3, 	1200bps @mode0
														//    = 204 ->    600bps @mode1/3, 	2400bps @mode0
														//    = 230	->   1200bps @mode1/3, 	4800bps @mode0
														//    = 243 ->   2400bps @mode1/3, 	9600bps @mode0
														//---------------------------------------
														//when S0_TX12=1, UART0_EX_DOUBLE_BR=0, & @12MHz
														//val = 100 ->   2400bps @mode1/3, 	9600bps @mode0
														//	  = 178 ->   4800bps @mode1/3, 19200bps @mode0
														//    = 217 ->   9600bps @mode1/3, 38400bps @mode0
														//    = 230 ->  14400bps @mode1/3, 57600bps @mode0


	extern unsigned char xdata gUartRxBuffer[RX_MAX];
	extern unsigned char xdata gUartTxBuffer[TX_MAX];
	extern unsigned char gUartRxWrPtr;
	extern unsigned char gUartRxRdPtr;

	extern void vUart0Init(void);
	extern void vUart0SetBuf(unsigned char dat);

	extern void vUart0PrintString(unsigned char code *str);
	extern void vUart0PrintMessageByAscii(unsigned char *msg_str, unsigned int length);
	extern void vUart0PrintMessageByHex(unsigned char *msg_str, unsigned int length);
	
	extern void vUart0NewLine(void);
	extern unsigned char bHex2Ascii(unsigned char ch);
	
#endif	