#include 	"Uart0_S0BRG_Prj.h"

//*********************************************************
//														   
//*********************************************************
#define GPIO_Init()\
    MWT(\
        __DRV_GPIO_P4_Protected(SPCON0_P4CTL_VALUE);\
        __DRV_GPIO_P6_Protected(SPCON0_P6CTL_VALUE);\
        __DRV_GPIO_SetOCD2IO(DCON0_OCDE_VALUE);\
        __DRV_GPIO_SetRST2IO(DCON0_RSTIO_VALUE);\
        __DRV_GPIO_P1ModeSelect(P1_MODE_VALUE);\
        __DRV_GPIO_P2ModeSelect(P2_MODE_VALUE);\
        __DRV_GPIO_P3ModeSelect(P3_MODE_VALUE);\
        __DRV_GPIO_P4ModeSelect(P4_MODE_VALUE);\
        __DRV_GPIO_P6ModeSelect(P6_MODE_VALUE);\
        __DRV_GPIO_P1OutputDrivingConfig(P1DC0,P1DC_0);\
        __DRV_GPIO_P1OutputDrivingConfig(P1DC1,P1DC_1);\
        __DRV_GPIO_P2OutputDrivingConfig(P2DC0,P2DC_0);\
        __DRV_GPIO_P2OutputDrivingConfig(P2DC1,P2DC_1);\
        __DRV_GPIO_P3OutputDrivingConfig(P3DC0,P3DC_0);\
        __DRV_GPIO_P3OutputDrivingConfig(P3DC1,P3DC_1);\
        __DRV_GPIO_P4OutputDrivingConfig(P4DC1,P4DC_1);\
        __DRV_GPIO_SetP1FastDriving(P1_FDC, FAST);\
        __DRV_GPIO_SetP2FastDriving(P2_FDC, FAST);\
        __DRV_GPIO_SetP3FastDriving(P3_FDC, FAST);\
        __DRV_GPIO_SetP4FastDriving(P4_FDC, FAST);\
    )


//*********************************************************
//														   
//*********************************************************
void System_Init(void)
{
 #if INIT_CMT2380F17_SYSTEM_CLK_WIZARD
	__DRV_CLK_SystemClock_Wizard_Init();
    __DRV_CLK_P60Mux_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_WDT_WIZARD
   	__DRV_WDT_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_RTC_WIZARD
  	__DRV_RTC_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_BODx_WIZARD
  	__DRV_BODx_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_GPIO_WIZARD
   	__DRV_GPIO_Wizard_Init();
 #else
 	GPIO_Init();
 #endif

 #if INIT_CMT2380F17_ADC_WIZARD
   	__DRV_ADC_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_INT_ALL_WIZARD
 	__DRV_INTERRUPT_Wizard_Init();
 #endif
}


