#include "uart0_s0brg.h"

unsigned char xdata gUartRxBuffer[RX_MAX];
unsigned char xdata gUartTxBuffer[TX_MAX];
unsigned char gUartRxWrPtr;
unsigned char gUartRxRdPtr;

void vUart0Init(void)
{ 
 unsigned char i;

 __DRV_SFR_PageIndex(3);
 AUXR6 &= (~SnMIPS);
 AUXR6 |= S0COPS;					//mapping to P3.3

 __DRV_SFR_PageIndex(7);
 AUXR10 &= (~S0PS1);				//TxD for P3.0
 
 __DRV_SFR_PageIndex(0);
 S0CR1 = 0; 	
 AUXR3  &= (~S0PS0);				//RxD for P3.1 
 S0CFG1 = 0x00;
 S0BRT = UART0_S0_BRT_SEL;

 S0CFG = (S0DOR|SMOD3);				//enable S0������
 if(UART0_EX_DOUBLE_BR!=0)
 	S0CFG |= SMOD2;
 if(UART0_DOR_SEL==0)
 	S0CFG &= (~S0DOR);
 if(UART0_BYPASS_TI_SEL!=0)
 	S0CFG |= BTI;
 if(UART0_UTIE_SEL!=0)
 	S0CFG |= UTIE;	


 AUXR2  &= (~T1X12);

 if(UART0_S0_TX12_SEL!=0)
 	S0CR1 |= S0TX12;
 if(UART0_S0_CKO_EN!=0)
 	S0CR1 |= S0CKOE;
 if(UART0_S0_ARTE_ESL!=0)
 	S0CR1 |= ARTE;

 #if (UART0_MODE_SEL==0)
	S0CON = 0x10; 
 	PCON0 &= 0x3F;
 	S0CR1 |= (S0TR|S0TCK);
 #endif
 
 #if (UART0_MODE_SEL==1)
 	S0CON = 0x50;
 	PCON0 &= 0x3F;
 	S0CR1 |= (S0TR|S0TCK|S0RCK);
 #endif

 #if (UART0_MODE_SEL==3)
 	S0CON = 0xD0;
 	PCON0 &= 0x3F;
 	S0CR1 |= (S0TR|S0TCK|S0RCK);
 #endif 

 ES0 = 1;			//enable for RX

 gUartRxWrPtr = 0;
 gUartRxRdPtr = 0;

 for(i=0; i<RX_MAX; i++)
 	gUartRxBuffer[i] = 0;	
}


void UART0_S0RI_S0TI_ISR(void)   interrupt S0_ISR_VECTOR 
{
 _push_(SFRPI);
 _push_(ACC);
 
 __DRV_SFR_PageIndex(0);
 if(RI0)
 	{
	RI0 = 0;	

	#if ((UART0_MODE_SEL==0)||(UART0_MODE_SEL==1))
 		gUartRxBuffer[gUartRxWrPtr++] = S0BUF;
 	#endif

 	#if (UART0_MODE_SEL==3)
		ACC = S0BUF;
 		#if (UART0_M3_P_SEL==0)
			if(RB80==P)
				gUartRxBuffer[gUartRxWrPtr++] = S0BUF;
		#else
			if(RB80!=P)
	 			gUartRxBuffer[gUartRxWrPtr++] = S0BUF;
		#endif
 	#endif	

	gUartRxWrPtr &= RX_MASK;
	}  

 _pop_(ACC);    
 _pop_(SFRPI);
}


void vUart0SetBuf(unsigned char dat)
{
 #if (UART0_MODE_SEL==0)
 	S0BUF = dat;
 #endif

 #if (UART0_MODE_SEL==1)
 	S0BUF = dat;
 #endif

 #if (UART0_MODE_SEL==3)
	ACC = dat;
 	#if (UART0_M3_P_SEL==0)
		TB80 = P;
	#else
	 	TB80 = !P;
	#endif
	S0BUF = dat;
 #endif

 while(!TI0);
 TI0 = 0;
}

void vUart0PrintString(unsigned char code *str)
{
 unsigned int i;
 if(str[0]!='\0')
 	{
 	__DRV_SFR_PageIndex(0);
 	for(i=0; str[i]!='\0'; i++)
		vUart0SetBuf(str[i]);
 	vUart0NewLine();
	}
}

void vUart0PrintMessageByAscii(unsigned char *msg_str, unsigned int length)
{
 unsigned int i;

 if(length!=0)
  	{
 	__DRV_SFR_PageIndex(0);
	for(i=0; i<length; i++)
	 	{
		vUart0SetBuf(bHex2Ascii(msg_str[i]>>4));
		vUart0SetBuf(bHex2Ascii(msg_str[i]));
		}
 	vUart0NewLine();
	}
}

void vUart0PrintMessageByHex(unsigned char *msg_str, unsigned int length)
{
 unsigned int i;

 if(length!=0)
 	{
 	__DRV_SFR_PageIndex(0);
 	for(i=0; i<length; i++)
		vUart0SetBuf(msg_str[i]);
	}
}

void vUart0NewLine(void)
{
 __DRV_SFR_PageIndex(0);
 vUart0SetBuf(0x0D);
 vUart0SetBuf(0x0A);
}

unsigned char bHex2Ascii(unsigned char ch)
{
 ch &= 0x0F;
 if(ch<10)
	{
	ch += '0';
	}	
 else
	{
	ch -= 10;
	ch += 'A';
	} 
 return(ch);
}



