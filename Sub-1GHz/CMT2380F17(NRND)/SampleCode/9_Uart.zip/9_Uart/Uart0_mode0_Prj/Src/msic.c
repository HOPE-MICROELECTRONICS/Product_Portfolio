#include "Demo.h"

#define	TIMER0_INTERVAL_VAL 	10000

unsigned char gSystimer;

//*********************************************************
//														   
//*********************************************************
#define GPIO_Init()\
    MWT(\
        __DRV_GPIO_P4_Protected(SPCON0_P4CTL_VALUE);\
        __DRV_GPIO_P6_Protected(SPCON0_P6CTL_VALUE);\
        __DRV_GPIO_SetOCD2IO(DCON0_OCDE_VALUE);\
        __DRV_GPIO_SetRST2IO(DCON0_RSTIO_VALUE);\
        __DRV_GPIO_P1ModeSelect(P1_MODE_VALUE);\
        __DRV_GPIO_P2ModeSelect(P2_MODE_VALUE);\
        __DRV_GPIO_P3ModeSelect(P3_MODE_VALUE);\
        __DRV_GPIO_P4ModeSelect(P4_MODE_VALUE);\
        __DRV_GPIO_P6ModeSelect(P6_MODE_VALUE);\
        __DRV_GPIO_P1OutputDrivingConfig(P1DC0,P1DC_0);\
        __DRV_GPIO_P1OutputDrivingConfig(P1DC1,P1DC_1);\
        __DRV_GPIO_P2OutputDrivingConfig(P2DC0,P2DC_0);\
        __DRV_GPIO_P2OutputDrivingConfig(P2DC1,P2DC_1);\
        __DRV_GPIO_P3OutputDrivingConfig(P3DC0,P3DC_0);\
        __DRV_GPIO_P3OutputDrivingConfig(P3DC1,P3DC_1);\
        __DRV_GPIO_P4OutputDrivingConfig(P4DC1,P4DC_1);\
        __DRV_GPIO_SetP1FastDriving(P1_FDC, FAST);\
        __DRV_GPIO_SetP2FastDriving(P2_FDC, FAST);\
        __DRV_GPIO_SetP3FastDriving(P3_FDC, FAST);\
        __DRV_GPIO_SetP4FastDriving(P4_FDC, FAST);\
    )

//*********************************************************
//														   
//*********************************************************
void Timer0_Init(void)
{
 TCON  = 0;
 TMOD  = 0x01;			//Timer0 as 16bit up counter & clk=system_clk/12
 TH0 = ((65536-TIMER0_INTERVAL_VAL)>>8);
 TL0 = (65536-TIMER0_INTERVAL_VAL);

 ET0 = 1;				//enable interrupt
 TR0 = 1;
}

void Timer0_TF0_ISR(void)   interrupt TIMER0_ISR_VECTOR 
{
 _push_(SFRPI);
 TL0 = (65536-TIMER0_INTERVAL_VAL);   
 TH0 = ((65536-TIMER0_INTERVAL_VAL)>>8);
 gSystimer++;
 _pop_(SFRPI);
}


//*********************************************************
//														   
//*********************************************************
void System_Init(void)
{
 #if INIT_CMT2380F17_SYSTEM_CLK_WIZARD
	__DRV_CLK_SystemClock_Wizard_Init();
    __DRV_CLK_P60Mux_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_WDT_WIZARD
   	__DRV_WDT_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_RTC_WIZARD
  	__DRV_RTC_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_BODx_WIZARD
  	__DRV_BODx_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_GPIO_WIZARD
   	__DRV_GPIO_Wizard_Init();
 #else
 	GPIO_Init();
 #endif

 #if INIT_CMT2380F17_ADC_WIZARD
   	__DRV_ADC_Wizard_Init();
 #endif

 #if INIT_CMT2380F17_INT_ALL_WIZARD
 	__DRV_INTERRUPT_Wizard_Init();
 #endif
}


//*********************************************************
//														   
//*********************************************************
void vUart0Mode0Init(void)
{ 

 #define		UART0_DOR_SEL				1				//0 = MSB�ȴ���														 
															//!0= LSB�ȴ��ͣ�Ĭ�ϣ�UART����

 #define		UART0_MODE0_SYS_DIV4_SEL	0				//0 = sysclk/12, when sysclk=12MHz, mode0_clk=1MHz
															//!0= sysclk/4,  when sysclk=12MHz, mode0_clk=3MHz

 __DRV_SFR_PageIndex(3);
 AUXR6 &= (~SnMIPS);
 AUXR6 |= S0COPS;					//S0CKO mapping to P3.3

 __DRV_SFR_PageIndex(7);
 AUXR10 &= (~S0PS1);				//TxD for P3.0


 __DRV_SFR_PageIndex(0);
 S0CR1  = 0x00;						//default
 S0BRT  = 0x00;
 S0CFG1 = 0x00;
 AUXR3 &= (~S0PS0);					//RxD for P3.1 

 S0CFG  = S0DOR;					//
 if(UART0_DOR_SEL==0)
 	S0CFG &= (~S0DOR); 
 if(UART0_MODE0_SYS_DIV4_SEL!=0)
	S0CFG |= URM0X3;

 S0CON  = 0x00; 					//select Mode0 & disable RX
 AUXR2  = 0x00; 
 PCON0 &= 0x7F;						//disable double baudrate & don't care in mode0
 
}


