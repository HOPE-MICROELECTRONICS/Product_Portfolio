/**
 ******************************************************************************
 *
 * @file        MAIN.C
 *
 * @brief       This is the C code format main file.
 *
 * @par         Project
 *              CMT2380F17
 * @version     v0.02
 * @date        2020/01/16
 * @copyright   Copyright CMOSTEK Microelectronics Co., Ltd.
 *              All rights reserved.
 *
 ******************************************************************************
 * @par         Disclaimer
 *      The Demo software is provided "AS IF"  without any warranty, either
 *      expressed or implied, including, but not limited to, the implied warranties
 *      of merchantability and fitness for a particular purpose.  The author will
 *      not be liable for any special, incidental, consequential or indirect
 *      damages due to loss of data or any other reason.
 *      These statements agree with the world wide and local dictated laws about
 *      authorship and violence against these laws.
 ******************************************************************************
 ******************************************************************************
 */

#include "CMT2380F17_CONFIG.h"



void main ()
{

    System_Init();

    #if 0   //for test ITEA Function
    __DRV_INT_ITEA_Enable();
    #endif




    while (1)
    	{
		printf("Hello ,UART0 Initial with Wizard\r\n");
		printf("Txd = P31, Rxd = P30, Baud rate = 57600\r\n");
		printf("0 1 2 3 4 5 6 7 8 9 0\r\n");	
		printf("~ ! @ # $ % ^ & * ( ) _ + = { } [ ] ; : ' ? . , \r\n");				
		printf("a b c d e f g h i j k l m n o p q r s t u v w x y z\r\n");		
		printf("A B C D E F G H I J K L M N O P Q R S T U V W X Y Z\r\n");
      	while (1);						
        //Code
    	}
}
