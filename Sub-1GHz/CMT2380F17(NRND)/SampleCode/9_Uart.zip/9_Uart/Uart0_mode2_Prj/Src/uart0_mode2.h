
#ifndef __UART0_MODE2_H
	#define __UART0_MODE2_H

	#include "CMT2380F17_CONFIG.h"


	#define		RX_MAX					64
	#define		RX_MASK					0x3F
	#define		TX_MAX					20


 	#define		UART0_MODE0_SYS_DIV4_SEL	1			//0 = div/64   =  /64, 
														//!0= div/64x3 = /192, 
                                                        // val=0, EN_BR=0 & EX_BR=0 -> x1/64 = /64,	 when sysclk=12MHz, br=187.5kbps
														//        EN_BR=1 & EX_BR=0 -> x2/64 = /32,  when sysclk=12MHz, br=375kbps
														//        EN_BR=0 & EX_BR=1 -> x4/64 = /16,	 when sysclk=12MHz, br=750kbps   **
														//		  EN_BR=1 & EX_BR=1 -> x8/64 = 1/8,	 when sysclk=12MHz, br=1.5Mbps	 **
														//
														// val=1, EN_BR=0 & EX_BR=0 -> x1/192= /192, when sysclk=12MHz, br=62.5kbps
														//        EN_BR=1 & EX_BR=0 -> x2/192 = /96, when sysclk=12MHz, br=125kbps
														//        EN_BR=0 & EX_BR=1 -> x4/192 = /48, when sysclk=12MHz, br=250kbps			    750kbps
														//		  EN_BR=1 & EX_BR=1 -> x8/192 = /24, when sysclk=12MHz, br=500kbps	 **		    1.5Mbps
														//



	#define		UART0_M3_P_SEL				1			//0 = even parity check, when mode3 active
														//!0= odd parity check, when mode3 active	
																								  
	#define		UART0_EN_DOUBLE_BR			0			//0 =disable double baudrate,
														//!0=enable double baudrate, 	

	#define		UART0_EX_DOUBLE_BR			1			//0 =disable extra double baudrate, SMOD2
														//!0=enable extra double baudrate, 	SMOD2														

	#define		UART0_DOR_SEL				1			//0 = MSB�ȴ���														 
														//!0= LSB�ȴ��ͣ�Ĭ�ϣ�UART����
	
	#define		UART0_BYPASS_TI_SEL			0			//0	= ����TI0��Ϊ����0�ж�Դ
	 													//!0= ��ֹTI0��Ϊ����0�ж�Դ
	 													
	#define		UART0_UTIE_SEL				0			//0 = ��ֹ��ϵͳ��־�ж����ж�����������TI0
														//!0= ����TI0��־����ϵͳ��־�жϹ����ж�����	 		
														

	extern unsigned char xdata gUartRxBuffer[RX_MAX];
	extern unsigned char xdata gUartTxBuffer[TX_MAX];
	extern unsigned char gUartRxWrPtr;
	extern unsigned char gUartRxRdPtr;

	extern void vUart0Init(void);
	extern void vUart0SetBuf(unsigned char dat);

	extern void vUart0PrintString(unsigned char code *str);
	extern void vUart0PrintMessageByAscii(unsigned char *msg_str, unsigned int length);
	extern void vUart0PrintMessageByHex(unsigned char *msg_str, unsigned int length);
	
	extern void vUart0NewLine(void);
	extern unsigned char bHex2Ascii(unsigned char ch);
	
#endif	