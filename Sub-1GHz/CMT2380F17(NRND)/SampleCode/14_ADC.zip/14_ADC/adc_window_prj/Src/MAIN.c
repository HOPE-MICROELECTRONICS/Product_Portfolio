/*********************************************************************
    Project:	CMT2380F17 ADC window mode
    Author:		YZY
				CMT2380F17-EB
				CpuCLK=12MHz, SysCLK=12MHz
	Description:
				ADC Window Detect in P10(AIN0)
	Note:

    Creat time::
    Modify::
    
*********************************************************************/
#include "CMT2380F17_CONFIG.h"

#include "Global.h"

void main ()
{
	u8 i;

  	System_Init(); 
  	
	AdcBufCnt=0;
	bADCFinish=FALSE;

	printf("\nStart!");
  	
	LED_G_0=0;LED_G_1=0;LED_R=0;
	DelayXms(1000);
	LED_G_0=1;LED_G_1=1;LED_R=1;

    while(1)
    {
		DelayXms(500);
		LED_G_0 = !LED_G_0;

		if(bADCFinish)
		{
			LED_R=1;
			printf("\nADC Win:");
			for(i=0;i<TEST_ADC_BUF_SIZE;i++)
			{
				printf("%04X ",wAdcBuf[i]);
			}
			bADCFinish=FALSE;
			__DRV_ADC_IT_Cmd(ENABLE);			// send data completed,restart ADC interrupt
		}
    }
}
