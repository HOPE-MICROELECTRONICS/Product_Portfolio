


#ifndef __ADC12_H
	#define __ADC12_H

	#include "CMT2380F17_CONFIG.h"


	#define		ADC_IN_SEL			8				// 0 = AIN0, P1.0
													// 1 = AIN1, P1.1
													// 2 = AIN2, P2.2
													// 3 = AIN3, P2.4
													// 4 = AIN4, P3.0
													// 5 = AIN5, P1.5
													// 6 = AIN6, P1.6
													// 7 = AIN7, P1.7
													// 8 = IVR,  IVR_1.4V
													// 9 = VSS

	#define		ADC_CLK_SEL			0				// 0 = SYS_CLK
													// 1 = SYS_CLK/2														
													// 2 = SYS_CLK/4
													// 3 = SYS_CLK/8
													// 4 = SYS_CLK/16
													// 5 = SYS_CLK/32
													// 6 = S0TOF/2
													// 7 = T2OF/2
													//!!note: ADC clock max. for 24MHz
													
	
	#define		ADC_RESULT_RIGHT_JUSTIFIED		0	// 0 = ADCDH[7:0]+ADCDL[7:4], MSB->LSB
													//!0 = ADCDH[3:0]+ADCDL[7:0], MSB->LSB
													
	#define		ADC_TRIG_MODE					0	// 0 = set ADCS to 1,
													// 1 = Timer0 overwise trigger, 
													// 2 = continusous mode,
													// 3 = S0BRG overwise trigger, 
	
	#define		ADC_POWER_CONSUMPTION_SEL		0 	// 0 = high speed & high power consumption
													// 1 = normal speed & normal power consumption
													// 2 = lower speed & lower power consumption
													// 3 = lowest speed & lowest power consumption
	
	#define		ADC_RESOLUTION_SEL				0	// 0 = 12-bit												 												
													// 1 = 10-bit		
													// 2 = 8-bit

	#define		ADC_SHT_VALUE					0	// ADC Sampling extra clock value
													// conversion rate = ADC_CLK/(30+X), 


	extern void vADC12Init(void);
	extern unsigned int wADC12GetResult(void);
	extern unsigned int wGetIVRValue(void);

#endif
