#include "adc12.h"

void vADC12Init(void)
{
 unsigned char tmp;
 
 if(ADC_IN_SEL==8)
 	{
 	tmp  = DRV_PageP_Read(PCON3_P); 	
 	tmp |= IVREN_P;
 	DRV_PageP_Write(PCON3_P, tmp);
 	}
 	
 __DRV_SFR_PageIndex(0x0E);
 ADCFG14 = 0x00;
 __DRV_SFR_PageIndex(0x0D);
 ADCFG13 = 0xFF;
 __DRV_SFR_PageIndex(0x0C);
 ADCFG12 = 0xFF;
 __DRV_SFR_PageIndex(0x0B);
 ADCFG11 = 0xFF;

 __DRV_SFR_PageIndex(5);
 ADCFG5  = 0x00;
 __DRV_SFR_PageIndex(4);
 ADCFG4  = 0x00;

 __DRV_SFR_PageIndex(3);
 tmp = 0;
 switch(ADC_POWER_CONSUMPTION_SEL)
 	{
 	case 0: break;
 	case 2: tmp |= 0x80; break;
 	case 3: tmp |= 0xC0; break;
 	case 1:
 	default:tmp |= 0x40; break;	
 	}
 switch(ADC_RESOLUTION_SEL)
 	{
 	case 1: tmp |= 0x04; break;
 	case 2: tmp |= 0x08; break;
 	case 3: tmp |= 0x0C; break;	
 	case 0: 
 	default: break;	
 	} 	
 ADCFG3  = tmp;
 	
 __DRV_SFR_PageIndex(2);
 ADCFG2  = ADC_SHT_VALUE;
   	
 __DRV_SFR_PageIndex(1);
 ADCFG1 = 0x00;
 
 __DRV_SFR_PageIndex(0);   
 tmp  = 0;
 tmp |= ((ADC_CLK_SEL&0x07)<<5);
 if(ADC_RESULT_RIGHT_JUSTIFIED!=0)
 	tmp |= ADRJ;
 if(ADC_IN_SEL>=8)
 	tmp |= ACHS;
 tmp |= (ADC_TRIG_MODE&0x03); 
 ADCFG0 = tmp;
 
 tmp  = 0;
 tmp |= ADCEN;
 tmp |= (ADC_IN_SEL&0x07);
 ADCON0 = tmp;
}

void vADC12Disable(void)
{
 __DRV_SFR_PageIndex(0);  
 ADCON0 = 0x00;
}

unsigned int wADC12GetResult(void)
{
 unsigned int  result;
 
 __DRV_SFR_PageIndex(0);
 
 ADCON0 |= ADCS;				//trigger conversion	
 while((ADCON0&ADCI)==0); 		//wait for finish

 result   = ADCDH;
 result <<= 8;
 result  |= ADCDL;	

 ADCON0 &= (~ADCI); 			//clear flag

 if(ADC_RESULT_RIGHT_JUSTIFIED==0)
 	result >>= 4;
 return(result);
}

unsigned int wGetIVRValue(void)
{
 unsigned int val;

 __DRV_SFR_PageIndex(0);
 
 ISPCR  = 0x80;
 IFMT   = 0x06;
 IFADRH = 0x00;
 IFADRL = 0xC0;
	
 SCMD = 0x46;
 SCMD = 0xB9;
 val  = IFD;
 val<<= 8;

 IFADRL ++;
 SCMD = 0x46;
 SCMD = 0xB9;
 val |= IFD;

 ISPCR = 0x00;

 return(val);
}
