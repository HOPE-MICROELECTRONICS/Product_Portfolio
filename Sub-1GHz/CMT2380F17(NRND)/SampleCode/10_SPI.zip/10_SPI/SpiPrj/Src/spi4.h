

#ifndef __SPI4_H
	#define __SPI4_H

	#include "CMT2380F17_CONFIG.h"	  

	#define		FIFO_DLY_VAL	0	

	#define		nCSB 			P33
	#define		nFCSB			P35
	#define		MOSI			P15
	#define		MISO			P16
	#define 	SCLK			P17
	

	extern void vSpiSoftDelay(void);
	extern void vSpiInit(void);
	extern unsigned char bSpiWrite(unsigned int spi_dat);
	extern unsigned char bSpiRead(unsigned char spi_adr);
	extern void vSpiSendCmd(unsigned char cmd_val);
	extern void vSpiBurstWrite(unsigned char spi_adr, unsigned char ptr[], unsigned char length);
	extern void vSpiBurstRead(unsigned char spi_adr, unsigned char ptr[], unsigned char length);

	extern void vSpiWriteFifo(unsigned char spi_dat);
	extern unsigned char bSpiReadFifo(void);
	extern void vSpiBurstWriteFifo(unsigned char ptr[], unsigned char length);
	extern void vSpiBurstReadFifo(unsigned char ptr[], unsigned char length);
#endif

