/*********************************************************************
    Project: CMT2380F17-DEMO
    Author:  QY.Ruan
			 CMT2380F17 QFN40
			 CpuCLK=12MHz, SysCLK=12MHz
	Description:
				
	Note:

    Creat time::
    Modify::
    
*********************************************************************/
#include "SpiPrj.h"



#define 	MCU_SYSCLK		12000000
#define 	MCU_CPUCLK		(MCU_SYSCLK)

/*************************************************
Function:     	void DelayXus(u16 xUs)
Description:   	dealy��unit:us
Input:     			u8 Us -> *1us  (1~255)
Output:     
*************************************************/
void DelayXus(u8 xUs)
{
 while(xUs!=0)
	{
	#if (MCU_CPUCLK>=11059200)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=14745600)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=16000000)
		_nop_();
	#endif

	#if (MCU_CPUCLK>=22118400)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif
	
	#if (MCU_CPUCLK>=24000000)
		_nop_();
		_nop_();
	#endif		

	#if (MCU_CPUCLK>=29491200)
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	#endif

	#if (MCU_CPUCLK>=32000000)
		_nop_();
		_nop_();
	#endif

	xUs--;
	}
}

/*************************************************
Function:     	void DelayXms(u16 xMs)
Description:    dealy��unit:ms
Input:     			u16 xMs -> *1ms  (1~65535)
Output:     
*************************************************/
void DelayXms(u16 xMs)
{
 while(xMs!=0)
	{
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	DelayXus(200);
	xMs--;
	}
}

void main ()
{
 u8 i;
 u8 test[16];
 u8 get[16];


 System_Init();

 vSpiInit();

 for(i=0; i<16; i++)
	test[i] = i+'0';

 while(1)
 	{
	bSpiWrite(0x1234);
	DelayXms(10);
	bSpiRead(0x12);
	DelayXms(50);

	vSpiSendCmd(0x7F);
	DelayXms(50);

	vSpiBurstWrite(0x10, test, 16);
	DelayXms(10);
	vSpiBurstRead(0x10, get, 16);
	DelayXms(50);

	vSpiWriteFifo(0x55);
	DelayXms(10);
	bSpiReadFifo();
	DelayXms(50);

	vSpiBurstWriteFifo(test, 16);
	DelayXms(10);
	vSpiBurstReadFifo(get, 16);
	DelayXms(50);
	}
}
