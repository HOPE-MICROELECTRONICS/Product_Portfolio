

#ifndef __SPI3_H
	#define __SPI3_H

	#include "CMT2380F17_CONFIG.h"

	#define		FIFO_DLY_VAL	0	

	#define		nCSB 			P33
	#define		nFCSB			P35
	#define		SDA				P15
	#define 	SCK				P17
	

	extern void vSpiSoftDelay(void);
	extern void vSpiInit(void);
	extern void vSpiWriteByte(unsigned char dat);
	extern unsigned char bSpiReadByte(void);
	extern void vSpiWrite(unsigned int dat);
	extern void vSpiSendCmd(unsigned char cmd_val);
	extern unsigned char bSpiRead(unsigned char addr);
	extern void vSpiBurstWrite(unsigned char spi_adr, unsigned char ptr[], unsigned char length);
	extern void vSpiBurstRead(unsigned char spi_adr, unsigned char ptr[], unsigned char length);

	extern void vSpiWriteFifo(unsigned char dat);
	extern unsigned char bSpiReadFifo(void);
	extern void vSpiBurstWriteFifo(unsigned char ptr[], unsigned char length);
	extern void vSpiBurstReadFifo(unsigned char ptr[], unsigned char length);
#endif