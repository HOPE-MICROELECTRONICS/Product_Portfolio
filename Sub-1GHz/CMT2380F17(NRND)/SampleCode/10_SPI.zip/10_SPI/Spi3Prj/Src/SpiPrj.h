#include "CMT2380F17_CONFIG.h"	  
#include "spi3.h"


//<i> The checked terms in this wizard will be initialized.
//      <q> System Clock
//      <i> Check this term, then macros __DRV_CLK_SystemClock_Wizard_Init() and __DRV_CLK_P60Mux_Wizard_Init()  will initialize system clock.
#define		INIT_CMT2380F17_SYSTEM_CLK_WIZARD	0

//      <q>Watch Dog Timer(WDT)
//      <i> Check this term, then macro __DRV_WDT_Wizard_Init() will initialize WDT.
#define 	INIT_CMT2380F17_WDT_WIZARD      	0

//      <q>Real Time Clock(RTC)
//      <i> Check this term, then macro __DRV_Wizard_RTC_Init() will initialize RTC.
#define 	INIT_CMT2380F17_RTC_WIZARD      	0

//      <q>Brown-Out Detector(BODx)
//      <i> Check this term, then macro __DRV_BODx_Wizard_Init() will initialize BODx.
#define 	INIT_CMT2380F17_BODx_WIZARD      	0

//      <q> Global Interrupts
//      <i> Check this term if you want to enable interrupts.
//      <i> Then, please go to MG82F6D17_INTERRUPT.h to pick the interrupts you need. 
//      <i> Now __DRV_INTERRUPT_Wizard_Init() will help you initialize them.
#define 	INIT_CMT2380F17_INT_ALL_WIZARD      0

//      <q>General Purpose Input/Output(GPIO)
//      <i> Check this term, then macro __DRV_GPIO_Wizard_Init() will initialize GPIO.
#define 	INIT_CMT2380F17_GPIO_WIZARD      	0

//      <q>Serial Port 0 (UART0)
//      <i> Check this term, then DRV_UART0_Wizard_Init() will initialize UART0.
#define 	INIT_CMT2380F17_UART0_WIZARD      	0

//      <q>Serial Port 1 (UART1)
//      <i> Check this term, then DRV_UART1_Wizard_Init() will initialize UART1.
#define 	INIT_CMT2380F17_UART1_WIZARD      	0

//      <q>ADC
//      <i>  Check this term, then macros __DRV_ADC_Wizard_Init() will initialize ADC.
#define 	INIT_CMT2380F17_ADC_WIZARD    		0




//*********************************************************
//				Port Config
//*********************************************************
// Port  Function 		System		  		    Mode
//	P1.0   GPIO1		INT1				P10_InputOnly		
//  P1.1   GPIO2		INT2				P11_InputOnly
//  P1.5   SDA+			MOSI				P15_PushPull	
//  P1.6   SDA		  	MISO				P16_InputOnly
//  P1.7   SCK			SCLK				P17_PushPull
//                                                                                                                          			    			
//	P2.2   KEY2		 	KBI2 		   		P22_OpenDrainPullUp
//  P2.4   KEY1			KBI3				P24_OpenDrainPullUp
//
//  P3.0   RxD			UartRxD			    P30_QuasiMode
//  P3.1   TxD 			UartTxD				P31_QuasiMode
//  P3.3   CSB			nSS					P33_PushPull
//  P3.4   GPIO3     	INT0				P34_InputOnly
//  P3.5   FCSB								P35_PushPull
// 
//  P4.4   BEEP  		OCD_SCL				P44_PushPull			//for OCD 
//  P4.5   LED			OCD_SDA				P45_PushPull			//for OCD
//	P4.7   NC			Reset				P47_PushPull			//for Reset
// 	
//  P6.0   NC			PWM2A				P60_PushPull
//  P6.1   NC			PWM2B			  	P61_PushPull
//

#define		P1_MODE_VALUE		(P10_InputOnly|P11_InputOnly|P15_PushPull|P16_InputOnly|P17_PushPull)
#define		P2_MODE_VALUE		(P22_OpenDrainPullUp|P24_OpenDrainPullUp)
#define		P3_MODE_VALUE		(P30_QuasiMode|P31_QuasiMode|P33_PushPull|P34_InputOnly|P35_PushPull)
#define		P4_MODE_VALUE		(P44_PushPull|P45_PushPull|P47_PushPull)	
#define		P6_MODE_VALUE		(P60_PushPull|P61_PushPull)

//<i> Users can activate writing protection of Port4/6 using this option. Then, only PageP access can modify.
	//<o0> Port 4 <0=> Disable (Default) <1=> Enable
	//<i> Enable, only PageP access can modify P4. Modifications in Page 0~F are not allowed.
    //<o1> Port 6 <0=> Disable (Default) <1=> Enable
    //<i> Enable, only PageP access can modify P6. Modifications in Page 0~F are not allowed.
    #define     SPCON0_P4CTL_VALUE    	0
    #define     SPCON0_P6CTL_VALUE    	0

 
 	#define 	DCON0_OCDE_VALUE	  	1		//1:Enable OCD Interface(P4.4&P4.5);	0:Disable OCD Interface
    #define 	DCON0_RSTIO_VALUE		1		//1:Enable P4.7 as Reset Pin;     		0:Disable Reset Pin, P4.7 as gpio






//*********************************************************
//				Functions
//*********************************************************
//msic.c
extern void System_Init(void);
extern void DRV_UART0_Wizard_Init(void);
extern void DRV_UART1_Wizard_Init(void);