/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file    cmt2310a_hal.h
 * @brief   CMT2310A transceiver RF chip driver
 *
 * @version 1.0
 * @date    Jun 23 2020
 * @author  CMOSTEK R@D
 */

#ifndef __CMT2310A_HAL_H
#define __CMT2310A_HAL_H

#include "typedefs.h"
#include "gpio_defs.h"
#include "common.h"
#include "system.h"
#include "cmt_spi4.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ************************************************************************
*  The following need to be modified by user
*  ************************************************************************ */
#define cmt2310a_set_gipo0_in()         SET_GPIO_IN(CMT_GPIO0_GPIO)
#define cmt2310a_set_gipo1_in()         SET_GPIO_IN(CMT_GPIO1_GPIO)
#define cmt2310a_set_nirq_in()          SET_GPIO_IN(CMT_NIRQ_GPIO)
#define cmt2310a_read_gpio0()           READ_GPIO_PIN(CMT_GPIO0_GPIO)
#define cmt2310a_read_gpio1()           READ_GPIO_PIN(CMT_GPIO1_GPIO)
#define cmt2310a_read_nirq()            READ_GPIO_PIN(CMT_NIRQ_GPIO)
#define cmt2310a_delay_ms(ms)           system_delay_ms(ms)
#define cmt2310a_delay_us(us)           system_delay_us(us)
#define cmt2310a_get_tick_count()       g_nSysTickCount
/* ************************************************************************ */

void cmt2310a_init_gpio(void);

u8 cmt2310a_read_reg(u8 addr);
void cmt2310a_write_reg(u8 addr, u8 dat);
void cmt2310a_set_reg_bits(u8 addr, u8 dat, u8 bits_mask);

void cmt2310a_read_regs(u8 addr, u8 buf[], u16 len);
void cmt2310a_write_regs(u8 addr, const u8 buf[], u16 len);

void cmt2310a_batch_read_regs(u8 buf[], u16 len);
void cmt2310a_batch_write_regs(const u8 buf[], u16 len);

void cmt2310a_read_fifo(u8 buf[], u16 len);
void cmt2310a_write_fifo(const u8 buf[], u16 len);

#ifdef __cplusplus
}
#endif

#endif
