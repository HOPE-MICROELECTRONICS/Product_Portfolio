/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file    cmt2310a_defs.h
 * @brief   CMT2310A transceiver RF chip driver
 *
 * @version 1.0
 * @date    Jun 23 2020
 * @author  CMOSTEK R@D
 */

#ifndef __CMT2310A_DEFS_H
#define __CMT2310A_DEFS_H

/* ---------- CUS PAGE0 defines ---------- */
#define CMT2310A_CTL_REG_00              0x00
#define CMT2310A_CTL_REG_01              0x01
#define CMT2310A_CTL_REG_02              0x02
#define CMT2310A_CTL_REG_03              0x03
#define CMT2310A_CTL_REG_04              0x04
#define CMT2310A_CTL_REG_05              0x05
#define CMT2310A_CTL_REG_06              0x06
#define CMT2310A_CTL_REG_07              0x07
#define CMT2310A_CTL_REG_08              0x08
#define CMT2310A_CTL_REG_09              0x09
#define CMT2310A_CTL_REG_10              0x0A
#define CMT2310A_CTL_REG_11              0x0B
#define CMT2310A_CTL_REG_12              0x0C
#define CMT2310A_CTL_REG_13              0x0D
#define CMT2310A_CTL_REG_14              0x0E
#define CMT2310A_CTL_REG_15              0x0F
#define CMT2310A_CTL_REG_16              0x10
#define CMT2310A_CTL_REG_17              0x11
#define CMT2310A_CTL_REG_18              0x12
#define CMT2310A_CTL_REG_19              0x13
#define CMT2310A_CTL_REG_20              0x14
#define CMT2310A_CTL_REG_21              0x15
#define CMT2310A_CTL_REG_22              0x16
#define CMT2310A_CTL_REG_23              0x17
#define CMT2310A_CTL_REG_24              0x18
#define CMT2310A_CTL_REG_25              0x19
#define CMT2310A_CTL_REG_26              0x1A
#define CMT2310A_CTL_REG_27              0x1B
#define CMT2310A_CTL_REG_28              0x1C
#define CMT2310A_CTL_REG_29              0x1D
#define CMT2310A_CTL_REG_30              0x1E
#define CMT2310A_CTL_REG_31              0x1F
#define CMT2310A_CTL_REG_32              0x20
#define CMT2310A_CTL_REG_33              0x21
#define CMT2310A_CTL_REG_34              0x22
#define CMT2310A_CTL_REG_35              0x23
#define CMT2310A_CTL_REG_36              0x24
#define CMT2310A_CTL_REG_37              0x25
#define CMT2310A_CTL_REG_38              0x26
#define CMT2310A_CTL_REG_39              0x27
#define CMT2310A_CTL_REG_40              0x28
#define CMT2310A_CTL_REG_41              0x29
#define CMT2310A_CTL_REG_42              0x2A
#define CMT2310A_CTL_REG_43              0x2B
#define CMT2310A_CTL_REG_44              0x2C
#define CMT2310A_CTL_REG_45              0x2D
#define CMT2310A_CTL_REG_46              0x2E
#define CMT2310A_CTL_REG_47              0x2F
#define CMT2310A_CTL_REG_48              0x30
#define CMT2310A_CTL_REG_49              0x31
#define CMT2310A_CTL_REG_50              0x32
#define CMT2310A_CTL_REG_51              0x33
#define CMT2310A_CTL_REG_52              0x34
#define CMT2310A_CTL_REG_53              0x35
#define CMT2310A_CTL_REG_54              0x36
#define CMT2310A_CTL_REG_55              0x37
#define CMT2310A_CTL_REG_56              0x38
#define CMT2310A_CTL_REG_57              0x39
#define CMT2310A_CTL_REG_58              0x3A
#define CMT2310A_CTL_REG_59              0x3B
#define CMT2310A_CTL_REG_60              0x3C
#define CMT2310A_CTL_REG_61              0x3D
#define CMT2310A_CTL_REG_62              0x3E
#define CMT2310A_CTL_REG_63              0x3F
#define CMT2310A_CTL_REG_64              0x40
#define CMT2310A_CTL_REG_65              0x41
#define CMT2310A_CTL_REG_66              0x42
#define CMT2310A_CTL_REG_67              0x43
#define CMT2310A_CTL_REG_68              0x44
#define CMT2310A_CTL_REG_69              0x45
#define CMT2310A_CTL_REG_70              0x46
#define CMT2310A_CTL_REG_71              0x47
#define CMT2310A_CTL_REG_72              0x48
#define CMT2310A_CTL_REG_73              0x49
#define CMT2310A_CTL_REG_74              0x4A
#define CMT2310A_CTL_REG_75              0x4B
#define CMT2310A_CTL_REG_76              0x4C
#define CMT2310A_CTL_REG_77              0x4D
#define CMT2310A_CTL_REG_78              0x4E
#define CMT2310A_CTL_REG_79              0x4F
#define CMT2310A_CTL_REG_80              0x50
#define CMT2310A_CTL_REG_81              0x51
#define CMT2310A_CTL_REG_82              0x52
#define CMT2310A_CTL_REG_83              0x53
#define CMT2310A_CTL_REG_84              0x54
#define CMT2310A_CTL_REG_85              0x55
#define CMT2310A_CTL_REG_86              0x56
#define CMT2310A_CTL_REG_87              0x57
#define CMT2310A_CTL_REG_88              0x58
#define CMT2310A_CTL_REG_89              0x59
#define CMT2310A_CTL_REG_90              0x5A
#define CMT2310A_CTL_REG_91              0x5B
#define CMT2310A_CTL_REG_92              0x5C
#define CMT2310A_CTL_REG_93              0x5D
#define CMT2310A_CTL_REG_94              0x5E
#define CMT2310A_CTL_REG_95              0x5F
#define CMT2310A_CTL_REG_96              0x60
#define CMT2310A_CTL_REG_97              0x61
#define CMT2310A_CTL_REG_98              0x62
#define CMT2310A_CTL_REG_99              0x63
#define CMT2310A_CTL_REG_100             0x64
#define CMT2310A_CTL_REG_101             0x65
#define CMT2310A_CTL_REG_102             0x66
#define CMT2310A_CTL_REG_103             0x67
#define CMT2310A_CTL_REG_104             0x68
#define CMT2310A_CTL_REG_105             0x69
#define CMT2310A_CTL_REG_106             0x6A
#define CMT2310A_CTL_REG_107             0x6B
#define CMT2310A_CTL_REG_108             0x6C
#define CMT2310A_CTL_REG_109             0x6D
#define CMT2310A_CTL_REG_110             0x6E
#define CMT2310A_CTL_REG_111             0x6F
#define CMT2310A_CTL_REG_112             0x70
#define CMT2310A_CTL_REG_113             0x71
#define CMT2310A_CTL_REG_114             0x72
#define CMT2310A_CTL_REG_115             0x73
#define CMT2310A_CTL_REG_116             0x74
#define CMT2310A_CTL_REG_117             0x75
#define CMT2310A_CTL_REG_118             0x76
#define CMT2310A_CTL_REG_119             0x77
#define CMT2310A_FIFO_PORT               0x7A
#define CMT2310A_CRW_PORT                0x7B
#define CMT2310A_CTL_REG_126             0x7E
#define CMT2310A_SOFT_RST                0x7F


/* ---------- CUS PAGE1 defines ---------- */
#define CMT2310A_CMT_REG_00              0x00
#define CMT2310A_CMT_REG_01              0x01
#define CMT2310A_CMT_REG_02              0x02
#define CMT2310A_CMT_REG_03              0x03
#define CMT2310A_CMT_REG_04              0x04
#define CMT2310A_CMT_REG_05              0x05
#define CMT2310A_CMT_REG_06              0x06
#define CMT2310A_CMT_REG_07              0x07
#define CMT2310A_CMT_REG_08              0x08
#define CMT2310A_CMT_REG_09              0x09
#define CMT2310A_CMT_REG_10              0x0A
#define CMT2310A_CMT_REG_11              0x0B
#define CMT2310A_CMT_REG_12              0x0C
#define CMT2310A_CMT_REG_13              0x0D
#define CMT2310A_CMT_REG_14              0x0E
#define CMT2310A_CMT_REG_15              0x0F
#define CMT2310A_TX_FREQ_REG_00          0x10
#define CMT2310A_TX_FREQ_REG_01          0x11
#define CMT2310A_TX_FREQ_REG_02          0x12
#define CMT2310A_TX_FREQ_REG_03          0x13
#define CMT2310A_TX_MODE_REG_00          0x14
#define CMT2310A_TX_DR_REG_00            0x15
#define CMT2310A_TX_DR_REG_01            0x16
#define CMT2310A_TX_DR_REG_02            0x17
#define CMT2310A_TX_DR_REG_03            0x18
#define CMT2310A_TX_DR_REG_04            0x19
#define CMT2310A_TX_DR_REG_05            0x1A
#define CMT2310A_TX_DEV_REG_00           0x1B
#define CMT2310A_TX_DEV_REG_01           0x1C
#define CMT2310A_TX_DEV_REG_02           0x1D
#define CMT2310A_TX_PWR_REG_00           0x1E
#define CMT2310A_TX_PWR_REG_01           0x1F
#define CMT2310A_TX_PWR_REG_02           0x20
#define CMT2310A_TX_PWR_REG_03           0x21
#define CMT2310A_TX_PWR_REG_04           0x22
#define CMT2310A_TX_PWR_REG_05           0x23
#define CMT2310A_TX_PWR_REG_06           0x24
#define CMT2310A_TX_MISC_REG_00          0x25
#define CMT2310A_TX_MISC_REG_01          0x26
#define CMT2310A_TX_MISC_REG_02          0x27
#define CMT2310A_TX_RESEV_00             0x28
#define CMT2310A_TX_RESEV_01             0x29
#define CMT2310A_TX_RESEV_02             0x2A
#define CMT2310A_TX_RESEV_03             0x2B
#define CMT2310A_TX_RESEV_04             0x2C
#define CMT2310A_TX_RESEV_05             0x2D
#define CMT2310A_TX_RESEV_06             0x2E
#define CMT2310A_TX_RESEV_07             0x2F
#define CMT2310A_RX_FREQ_REG_00          0x30
#define CMT2310A_RX_FREQ_REG_01          0x31
#define CMT2310A_RX_FREQ_REG_02          0x32
#define CMT2310A_RX_FREQ_REG_03          0x33
#define CMT2310A_RX_FREQ_REG_04          0x34
#define CMT2310A_RX_IRF_REG_00           0x35
#define CMT2310A_RX_IRF_REG_01           0x36
#define CMT2310A_RX_IRF_REG_02           0x37
#define CMT2310A_RX_IRF_REG_03           0x38
#define CMT2310A_RX_PWR_REG_00           0x39
#define CMT2310A_RX_PWR_REG_01           0x3A
#define CMT2310A_RX_PWR_REG_02           0x3B
#define CMT2310A_RX_DR_REG_00            0x3C
#define CMT2310A_RX_DR_REG_01            0x3D
#define CMT2310A_RX_DR_REG_02            0x3E
#define CMT2310A_RX_DR_REG_03            0x3F
#define CMT2310A_RX_DR_REG_04            0x40
#define CMT2310A_RX_DR_REG_05            0x41
#define CMT2310A_RX_DR_REG_06            0x42
#define CMT2310A_RX_DR_REG_07            0x43
#define CMT2310A_RX_CDR_REG_00           0x44
#define CMT2310A_RX_CDR_REG_01           0x45
#define CMT2310A_RX_CDR_REG_02           0x46
#define CMT2310A_RX_CDR_REG_03           0x47
#define CMT2310A_RX_CHNL_REG_00          0x48
#define CMT2310A_RX_CHNL_REG_01          0x49
#define CMT2310A_RX_CHNL_REG_02          0x4A
#define CMT2310A_RX_AGC_REG_00           0x4B
#define CMT2310A_RX_AGC_REG_01           0x4C
#define CMT2310A_RX_AGC_REG_02           0x4D
#define CMT2310A_RX_AGC_REG_03           0x4E
#define CMT2310A_RX_AGC_REG_04           0x4F
#define CMT2310A_RX_AGC_REG_05           0x50
#define CMT2310A_RX_AGC_REG_06           0x51
#define CMT2310A_RX_2FSK_REG_00          0x52
#define CMT2310A_RX_2FSK_REG_01          0x53
#define CMT2310A_RX_2FSK_REG_02          0x54
#define CMT2310A_RX_2FSK_REG_03          0x55
#define CMT2310A_RX_AFC_REG_00           0x56
#define CMT2310A_RX_AFC_REG_01           0x57
#define CMT2310A_RX_AFC_REG_02           0x58
#define CMT2310A_RX_AFC_REG_03           0x59
#define CMT2310A_RX_4FSK_REG_00          0x5A
#define CMT2310A_RX_4FSK_REG_01          0x5B
#define CMT2310A_RX_4FSK_REG_02          0x5C
#define CMT2310A_RX_4FSK_REG_03          0x5D
#define CMT2310A_RX_OOK_REG_00           0x5E
#define CMT2310A_RX_OOK_REG_01           0x5F
#define CMT2310A_RX_OOK_REG_02           0x60
#define CMT2310A_RX_OOK_REG_03           0x61
#define CMT2310A_RX_RSSI_REG_00          0x62
#define CMT2310A_RX_RSSI_REG_01          0x63
#define CMT2310A_RX_DOUT_REG_00          0x64
#define CMT2310A_RX_IRCAL_REG_00         0x65
#define CMT2310A_RX_ADCR_REG_00          0x66
#define CMT2310A_RX_ANTD_REG_00          0x67
#define CMT2310A_RX_FW_REG_00            0x68
#define CMT2310A_RX_IQS_REG_00           0x69
#define CMT2310A_RX_IQS_REG_01           0x6A
#define CMT2310A_RX_IQS_REG_02           0x6B
#define CMT2310A_RX_IQS_REG_03           0x6C
#define CMT2310A_RX_IQS_REG_04           0x6D
#define CMT2310A_RX_IQS_REG_05           0x6E
#define CMT2310A_RX_IQS_REG_06           0x6F

/* ---------- CUS PAGE2 defines ---------- */
#define CMT2310A_FREQ_CHANL_00           0x00
#define CMT2310A_FREQ_CHANL_01           0x01
#define CMT2310A_FREQ_CHANL_02           0x02
#define CMT2310A_FREQ_CHANL_03           0x03
#define CMT2310A_FREQ_CHANL_04           0x04
#define CMT2310A_FREQ_CHANL_05           0x05
#define CMT2310A_FREQ_CHANL_06           0x06
#define CMT2310A_FREQ_CHANL_07           0x07
#define CMT2310A_FREQ_CHANL_08           0x08
#define CMT2310A_FREQ_CHANL_09           0x09
#define CMT2310A_FREQ_CHANL_10           0x0A
#define CMT2310A_FREQ_CHANL_11           0x0B
#define CMT2310A_FREQ_CHANL_12           0x0C
#define CMT2310A_FREQ_CHANL_13           0x0D
#define CMT2310A_FREQ_CHANL_14           0x0E
#define CMT2310A_FREQ_CHANL_15           0x0F
#define CMT2310A_FREQ_CHANL_16           0x10
#define CMT2310A_FREQ_CHANL_17           0x11
#define CMT2310A_FREQ_CHANL_18           0x12
#define CMT2310A_FREQ_CHANL_19           0x13
#define CMT2310A_FREQ_CHANL_20           0x14
#define CMT2310A_FREQ_CHANL_21           0x15
#define CMT2310A_FREQ_CHANL_22           0x16
#define CMT2310A_FREQ_CHANL_23           0x17
#define CMT2310A_FREQ_CHANL_24           0x18
#define CMT2310A_FREQ_CHANL_25           0x19
#define CMT2310A_FREQ_CHANL_26           0x1A
#define CMT2310A_FREQ_CHANL_27           0x1B
#define CMT2310A_FREQ_CHANL_28           0x1C
#define CMT2310A_FREQ_CHANL_29           0x1D
#define CMT2310A_FREQ_CHANL_30           0x1E
#define CMT2310A_FREQ_CHANL_31           0x1F
#define CMT2310A_FREQ_CHANL_32           0x20
#define CMT2310A_FREQ_CHANL_33           0x21
#define CMT2310A_FREQ_CHANL_34           0x22
#define CMT2310A_FREQ_CHANL_35           0x23
#define CMT2310A_FREQ_CHANL_36           0x24
#define CMT2310A_FREQ_CHANL_37           0x25
#define CMT2310A_FREQ_CHANL_38           0x26
#define CMT2310A_FREQ_CHANL_39           0x27
#define CMT2310A_FREQ_CHANL_40           0x28
#define CMT2310A_FREQ_CHANL_41           0x29
#define CMT2310A_FREQ_CHANL_42           0x2A
#define CMT2310A_FREQ_CHANL_43           0x2B
#define CMT2310A_FREQ_CHANL_44           0x2C
#define CMT2310A_FREQ_CHANL_45           0x2D
#define CMT2310A_FREQ_CHANL_46           0x2E
#define CMT2310A_FREQ_CHANL_47           0x2F
#define CMT2310A_FREQ_CHANL_48           0x30
#define CMT2310A_FREQ_CHANL_49           0x31
#define CMT2310A_FREQ_CHANL_50           0x32
#define CMT2310A_FREQ_CHANL_51           0x33
#define CMT2310A_FREQ_CHANL_52           0x34
#define CMT2310A_FREQ_CHANL_53           0x35
#define CMT2310A_FREQ_CHANL_54           0x36
#define CMT2310A_FREQ_CHANL_55           0x37
#define CMT2310A_FREQ_CHANL_56           0x38
#define CMT2310A_FREQ_CHANL_57           0x39
#define CMT2310A_FREQ_CHANL_58           0x3A
#define CMT2310A_FREQ_CHANL_59           0x3B
#define CMT2310A_FREQ_CHANL_60           0x3C
#define CMT2310A_FREQ_CHANL_61           0x3D
#define CMT2310A_FREQ_CHANL_62           0x3E
#define CMT2310A_FREQ_CHANL_63           0x3F


#define VAL_BIT0                         0x01
#define VAL_BIT1                         0x02
#define VAL_BIT2                         0x04
#define VAL_BIT3                         0x08
#define VAL_BIT4                         0x10
#define VAL_BIT5                         0x20
#define VAL_BIT6                         0x40
#define VAL_BIT7                         0x80

#define BIT0                             0
#define BIT1                             1
#define BIT2                             2
#define BIT3                             3
#define BIT4                             4
#define BIT5                             5
#define BIT6                             6
#define BIT7                             7

/* ********** CMT2310A_CTL_REG_00 registers ********** */
#define M_BOOT_MAIN                       VAL_BIT1
#define M_POWERUP                         VAL_BIT0

/* ********** CMT2310A_CTL_REG_01 registers ********** */
#define M_GO_RXFS                         VAL_BIT5
#define M_GO_TXFS                         VAL_BIT4
#define M_GO_RX                           VAL_BIT3
#define M_GO_TX                           VAL_BIT2
#define M_GO_READY                        VAL_BIT1
#define M_GO_SLEEP                        VAL_BIT0

/* ********** CMT2310A_CTL_REG_02 registers ********** */
#define M_MCU_GPIO_EN                     VAL_BIT2
#define M_ANT_DIV_MANU                    VAL_BIT1
#define M_ANT_SELECT                      VAL_BIT0

/* ********** CMT2310A_CTL_REG_04 registers ********** */
#define M_TX_DIN_EN                       VAL_BIT6
#define M_GPIO1_SEL                       (VAL_BIT5|VAL_BIT4|VAL_BIT3)
#define M_GPIO0_SEL                       (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* ********** CMT2310A_CTL_REG_05 registers ********** */
#define M_TX_DIN_SEL                      (VAL_BIT7|VAL_BIT6)
#define M_GPIO3_SEL                       (VAL_BIT5|VAL_BIT4|VAL_BIT3)
#define M_GPIO2_SEL                       (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* ********** CMT2310A_CTL_REG_06 registers ********** */
#define M_DIG_CLKOUT_EN                   VAL_BIT6
#define M_GPIO5_SEL                       (VAL_BIT5|VAL_BIT4|VAL_BIT3)
#define M_GPIO4_SEL                       (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* ********** CMT2310A_CTL_REG_07 registers ********** */
#define M_LFXO_PAD_EN                     VAL_BIT5
#define M_API_STOP                        VAL_BIT4
#define M_SPI_3W_EN                       VAL_BIT3
#define M_NIRQ_SEL                        (VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* ********** CMT2310A_CTL_REG_09 registers ********** */
#define M_API_CMD_FLAG                    VAL_BIT7
#define M_API_RESP                        (VAL_BIT6|VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* ********** CMT2310A_CTL_REG_10 registers ********** */
#define M_STATE_IS_TX                     VAL_BIT5
#define M_STATE_IS_RX                     VAL_BIT4
#define M_STATE_IS_TFS                    VAL_BIT3
#define M_STATE_IS_RFS                    VAL_BIT2
#define M_STATE_IS_READY                  VAL_BIT1
#define M_STATE_IS_SLEEP                  VAL_BIT0

/* ********** CMT2310A_CTL_REG_14 registers ********** */
#define M_RX_FIFO_FULL_RX_EN              VAL_BIT7
#define M_RX_FIFO_NMTY_RX_EN              VAL_BIT6
#define M_RX_FIFO_TH_RX_EN                VAL_BIT5
#define M_RX_FIFO_OVF_EN                  VAL_BIT3
#define M_TX_FIFO_FULL_EN                 VAL_BIT2
#define M_TX_FIFO_NMTY_EN                 VAL_BIT1
#define M_TX_FIFO_TH_EN                   VAL_BIT0

/* ********** CMT2310A_CTL_REG_15 registers ********** */
#define M_ANT_INSTR                       VAL_BIT0

/* ********** CMT2310A_CTL_REG_16 registers ********** */
#define M_INT1_SEL                        (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* ********** CMT2310A_CTL_REG_17 registers ********** */
#define M_INT1_POLAR                      VAL_BIT7
#define M_INT2_POLAR                      VAL_BIT6
#define M_INT2_SEL                        (VAL_BIT5|VAL_BIT4|VAL_BIT3|VAL_BIT2|VAL_BIT1|VAL_BIT0)

/* ********** CMT2310A_CTL_REG_18 registers ********** */
#define M_SLEEP_TMO_EN                    VAL_BIT7
#define M_RX_TMO_EN                       VAL_BIT6
#define M_TX_DONE_EN                      VAL_BIT5
#define M_PREAM_PASS_EN                   VAL_BIT4
#define M_SYNC_PASS_EN                    VAL_BIT3
#define M_ADDR_PASS_EN                    VAL_BIT2
#define M_CRC_PASS_EN                     VAL_BIT1
#define M_PKT_DONE_EN                     VAL_BIT0

/* ********** CMT2310A_CTL_REG_19 registers ********** */
#define M_INT3_POLAR                      VAL_BIT7
#define M_PD_FIFO                         VAL_BIT6
#define M_FIFO_TH_8                       VAL_BIT5
#define M_FIFO_AUTO_CLR_RX_EN             VAL_BIT4
#define M_FIFO_AUTO_RES_TX_EN             VAL_BIT3
#define M_FIFO_TX_TEST_EN                 VAL_BIT2
#define M_FIFO_MERGE_EN                   VAL_BIT1
#define M_FIFO_TX_RX_SEL                  VAL_BIT0

/* ********** CMT2310A_CTL_REG_21 registers ********** */
#define M_RSSI_PJD_VALID_EN               VAL_BIT6
#define M_OP_CMD_FAILED_EN                VAL_BIT5
#define M_RSSI_COLL_EN                    VAL_BIT4
#define M_PKT_ERR_EN                      VAL_BIT3
#define M_LBD_STATUS_EN                   VAL_BIT2
#define M_LBD_STOP_EN                     VAL_BIT1
#define M_LD_STOP_EN                      VAL_BIT0

/* ********** CMT2310A_CTL_REG_22 registers ********** */
#define M_FREQ_HOP_MANU_EN                VAL_BIT7
#define M_RX_HOP_PERSIST                  VAL_BIT5
#define M_FREQ_SW_STATE                   VAL_BIT6
#define M_TX_DATA_INV                     VAL_BIT4
#define M_PA_DIFF_SEL                     VAL_BIT3
#define M_TRX_SWT_INV                     VAL_BIT2
#define M_TRX_SWT_EN                      VAL_BIT1
#define M_ANT_LOCK_EN                     VAL_BIT0

/* ********** CMT2310A_CTL_REG_23 registers ********** */
#define M_API_DONE_EN                     VAL_BIT7
#define M_CCA_STATUS_EN                   VAL_BIT6
#define M_CSMA_DONE_EN                    VAL_BIT5
#define M_TX_DC_DONE_EN                   VAL_BIT4
#define M_ACK_RECV_FAILED_EN              VAL_BIT3
#define M_TX_RESEND_DONE_EN               VAL_BIT2
#define M_NACK_RECV_EN                    VAL_BIT1
#define M_SEQ_MATCH_EN                    VAL_BIT0

/* ********** CMT2310A_CTL_REG_24 registers ********** */
#define M_SLEEP_TMO_FLG                   VAL_BIT5
#define M_RX_TMO_FLG                      VAL_BIT4
#define M_TX_DONE_FLG                     VAL_BIT3
#define M_SLEEP_TMO_CLR                   VAL_BIT2
#define M_RX_TMO_CLR                      VAL_BIT1
#define M_TX_DONE_CLR                     VAL_BIT0

/* ********** CMT2310A_CTL_REG_25 registers ********** */
#define M_PREAM_PASS_CLR                  VAL_BIT4
#define M_SYNC_PASS_CLR                   VAL_BIT3
#define M_ADDR_PASS_CLR                   VAL_BIT2
#define M_CRC_PASS_CLR                    VAL_BIT1
#define M_PKT_DONE_CLR                    VAL_BIT0

/* ********** CMT2310A_CTL_REG_26 registers ********** */
#define M_SYNC1_PASS_FLG                  VAL_BIT5
#define M_PREAM_PASS_FLG                  VAL_BIT4
#define M_SYNC_PASS_FLG                   VAL_BIT3
#define M_ADDR_PASS_FLG                   VAL_BIT2
#define M_CRC_PASS_FLG                    VAL_BIT1
#define M_PKT_DONE_FLG                    VAL_BIT0

/* ********** CMT2310A_CTL_REG_27 registers ********** */
#define M_TX_FIFO_RESTORE                 VAL_BIT2
#define M_RX_FIFO_CLR                     VAL_BIT1
#define M_TX_FIFO_CLR                     VAL_BIT0

/* ********** CMT2310A_CTL_REG_28 registers ********** */
#define M_RX_FIFO_FULL_FLG                VAL_BIT7
#define M_RX_FIFO_NMTY_FLG                VAL_BIT6
#define M_RX_FIFO_TH_FLG                  VAL_BIT5
#define M_RX_FIFO_OVF_FLG                 VAL_BIT3
#define M_TX_FIFO_FULL_FLG                VAL_BIT2
#define M_TX_FIFO_NMTY_FLG                VAL_BIT1
#define M_TX_FIFO_TH_FLG                  VAL_BIT0

/* ********** CMT2310A_CTL_REG_29 registers ********** */
#define M_ANT_LOCK_CLR                    VAL_BIT4
#define M_OP_CMD_FAILED_CLR               VAL_BIT3
#define M_RSSI_COLL_CLR                   VAL_BIT2
#define M_PKT_ERR_CLR                     VAL_BIT1
#define M_LBD_STATUS_CLR                  VAL_BIT0

/* ********** CMT2310A_CTL_REG_30 registers ********** */
#define M_ANT_LOCK_FLG                    VAL_BIT4
#define M_OP_CMD_FAILED_FLG               VAL_BIT3
#define M_RSSI_COLL_FLG                   VAL_BIT2
#define M_PKT_ERR_FLG                     VAL_BIT1
#define M_LBD_STATUS_FLG                  VAL_BIT0

/* ********** CMT2310A_CTL_REG_31 registers ********** */
#define M_API_DONE_CLR                    VAL_BIT7
#define M_CCA_STATUS_CLR                  VAL_BIT6
#define M_CSMA_DONE_CLR                   VAL_BIT5
#define M_TX_DC_DONE_CLR                  VAL_BIT4
#define M_ACK_RECV_FAILED_CLR             VAL_BIT3
#define M_TX_RESEND_DONE_CLR              VAL_BIT2
#define M_NACK_RECV_CLR                   VAL_BIT1
#define M_SEQ_MATCH_CLR                   VAL_BIT0

/* ********** CMT2310A_CTL_REG_32 registers ********** */
#define M_API_DONE_FLG                    VAL_BIT7
#define M_CCA_STATUS_FLG                  VAL_BIT6
#define M_CSMA_DONE_FLG                   VAL_BIT5
#define M_TX_DC_DONE_FLG                  VAL_BIT4
#define M_ACK_RECV_FAILED_FLG             VAL_BIT3
#define M_TX_RESEND_DONE_FLG              VAL_BIT2
#define M_NACK_RECV_FLG                   VAL_BIT1
#define M_SEQ_MATCH_FLG                   VAL_BIT0


/* ********** CMT2310A_CTL_REG_126 registers ********* */
#define M_HV_PAGE_SEL                     (VAL_BIT7|VAL_BIT6)


/* ******** CMT2310A STATE *************************** */
#define STATE_IS_IDLE                       0x00
#define STATE_IS_SLEEP                      0x81
#define STATE_IS_READY                      0x82
#define STATE_IS_RFS                        0x84
#define STATE_IS_TFS                        0x88
#define STATE_IS_RX                         0x90
#define STATE_IS_TX                         0xA0

/* ******** GPIO0_SEL ******************************** */
#define GPIO0_SEL_DOUT                      0x00
#define GPIO0_SEL_INT1                      0x01
#define GPIO0_SEL_INT2                      0x02
#define GPIO0_SEL_DCLK                      0x03

/* ******** GPIO1_SEL ******************************** */
#define GPIO1_SEL_DCLK                      0x00
#define GPIO1_SEL_INT1                      0x01
#define GPIO1_SEL_INT2                      0x02
#define GPIO1_SEL_DOUT                      0x03

/* ******** GPIO2_SEL ******************************** */
#define GPIO2_SEL_INT1                      0x00
#define GPIO2_SEL_INT2                      0x01
#define GPIO2_SEL_DCLK                      0x02
#define GPIO2_SEL_DOUT                      0x03

/* ******** GPIO3_SEL ******************************** */
#define GPIO3_SEL_INT2                      0x00
#define GPIO3_SEL_INT1                      0x01
#define GPIO3_SEL_DCLK                      0x02
#define GPIO3_SEL_DOUT                      0x03
#define GPIO3_SEL_DIN                       0x05

/* ******** GPIO4_SEL ******************************** */
#define GPIO4_SEL_DOUT                      0x00
#define GPIO4_SEL_INT1                      0x01
#define GPIO4_SEL_INT2                      0x02
#define GPIO4_SEL_DCLK                      0x03
#define GPIO4_SEL_DIN                       0x05

/* ******** GPIO5_SEL ******************************** */
#define GPIO5_SEL_RSTN                      0x00
#define GPIO5_SEL_INT1                      0x01
#define GPIO5_SEL_INT2                      0x02
#define GPIO5_SEL_DOUT                      0x03
#define GPIO5_SEL_DCLK                      0x04

/* ******** TX_DIN_SEL ****************************** */
#define TX_DIN_SEL_GPIO3                    0x00
#define TX_DIN_SEL_GPIO4                    0x01
#define TX_DIN_SEL_NIRQ                     0x02

/* ******** NIRQ_SEL ******************************** */
#define NIRQ_SEL_INT1                       0x00
#define NIRQ_SEL_INT2                       0x01
#define NIRQ_SEL_DCLK                       0x02
#define NIRQ_SEL_DOUT                       0x03
#define NIRQ_SEL_DIN                        0x04

/* ******* INT1/2_SEL ****************************** */
#define INT_SRC_MIX                         0x00
#define INT_SRC_ANT_LOCK                    0x01
#define INT_SRC_RSSI_PJD_VALID              0x02
#define INT_SRC_PREAM_PASS                  0x03
#define INT_SRC_SYNC_PASS                   0x04
#define INT_SRC_ADDR_PASS                   0x05
#define INT_SRC_CRC_PASS                    0x06
#define INT_SRC_PKT_OK                      0x07
#define INT_SRC_PKT_DONE                    0x08
#define INT_SRC_SLEEP_TMO                   0x09
#define INT_SRC_RX_TMO                      0x0A
#define INT_SRC_RX_FIFO_NMTY                0x0B
#define INT_SRC_RX_FIFO_TH                  0x0C
#define INT_SRC_RX_FIFO_FULL                0x0D
#define INT_SRC_RX_FIFO_WBYTE               0x0E
#define INT_SRC_RX_FIFO_OVF                 0x0F
#define INT_SRC_TX_DONE                     0x10
#define INT_SRC_TX_FIFO_NMTY                0x11
#define INT_SRC_TX_FIFO_TH                  0x12
#define INT_SRC_TX_FIFO_FULL                0x13
#define INT_SRC_STATE_IS_READY              0x14
#define INT_SRC_STATE_IS_FS                 0x15
#define INT_SRC_STATE_IS_RX                 0x16
#define INT_SRC_STATE_IS_TX                 0x17
#define INT_SRC_LBD_STATUS                  0x18
#define INT_SRC_API_CMD_FAILED              0x19
#define INT_SRC_API_DONE                    0x1A
#define INT_SRC_TX_DC_DONE                  0x1B
#define INT_SRC_ACK_RECV_FAILED             0x1C
#define INT_SRC_TX_RESEND_DONE              0x1D
#define INT_SRC_NACK_RECV                   0x1E
#define INT_SRC_SEQ_MATCH                   0x1F
#define INT_SRC_CSMA_DONE                   0x20
#define INT_SRC_CCA_STATUS                  0x21


#endif
























