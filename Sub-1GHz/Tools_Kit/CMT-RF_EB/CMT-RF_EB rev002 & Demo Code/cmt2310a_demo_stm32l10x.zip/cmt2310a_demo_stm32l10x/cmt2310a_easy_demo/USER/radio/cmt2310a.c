/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file    cmt2310a.c
 * @brief   CMT2310A transceiver RF chip driver
 *
 * @version 1.0
 * @date    Jun 23 2020
 * @author  CMOSTEK R@D
 */

#include "cmt2310a.h"

/*! ********************************************************
* @name    cmt2310a_soft_reset
* @desc    Soft reset.
* *********************************************************/
void cmt2310a_soft_reset(void)
{
    cmt2310a_write_reg(0x7F, 0xFF);
}

/*! ********************************************************
* @name    cmt2310a_select_spi_wire_mode
* @desc    select spi wire mode(must be called after powerup)
* @param   spi_3w  0: 4-wire mode, 1:3-wire mode
* *********************************************************/
void cmt2310a_select_spi_wire_mode(u8 spi_3w)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_07, (spi_3w << BIT3));
}

/*! ********************************************************
* @name    cmt2310a_powerup_boot
* @desc    powerup boot.
* *********************************************************/
void cmt2310a_powerup_boot(void)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_00, 0x03);
}

/*! ********************************************************
* @name    cmt2310a_select_reg_page
* @desc    select reg page
* @param   page_sel  0: page 0, 1: page 1, 2:page 2
* *********************************************************/
void cmt2310a_select_reg_page(u8 page_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_126, (page_sel << BIT6), M_HV_PAGE_SEL);
}

/*! ********************************************************
* @name    cmt2310a_api_command_and_wait
* @desc    send api command and wait done
* @param   api_cmd  api command(only support 0x01)
* @return  TRUE or FALSE
* *********************************************************/
BOOL cmt2310a_api_command_and_wait(u8 api_cmd)
{
    u8 cmd_state;
    u32 end_tick = cmt2310a_get_tick_count() + 2000; /* max wait 1000 ms */
    u8 wait_state = M_API_CMD_FLAG | api_cmd;

    cmt2310a_write_reg(CMT2310A_CTL_REG_08, api_cmd);

    while(cmt2310a_get_tick_count() < end_tick)
    {
        cmt2310a_delay_ms(2);
        cmd_state = cmt2310a_read_reg(CMT2310A_CTL_REG_09);

        if(wait_state==cmd_state)
            return TRUE;
    }

    return FALSE;
}

/*! ********************************************************
* @name    cmt2310a_get_chip_state
* @desc    Get the chip state.
* @return
*          STATE_IS_IDLE
*          STATE_IS_SLEEP
*          STATE_IS_READY
*          STATE_IS_RFS
*          STATE_IS_TFS
*          STATE_IS_RX
*          STATE_IS_TX
* *********************************************************/
u8 cmt2310a_get_chip_state(void)
{
    return  cmt2310a_read_reg(CMT2310A_CTL_REG_10);
}

BOOL cmt2310a_switch_state_and_wait(u8 go_cmd, u8 wait_state, u32 end_tick)
{
    u8 cur_state;

    cmt2310a_write_reg(CMT2310A_CTL_REG_01, go_cmd);

    while(cmt2310a_get_tick_count() < end_tick)
    {
        cmt2310a_delay_us(20);
        cur_state = cmt2310a_get_chip_state();

        if(wait_state==cur_state)
            return TRUE;
    }

    return FALSE;
}

/*! ********************************************************
* @name    cmt2310a_auto_switch_state
* @desc    Auto switch the chip state, and 10 ms as timeout.
* @param   go_cmd: the chip next state
*            M_GO_RXFS
*            M_GO_TXFS
*            M_GO_RX
*            M_GO_TX
*            M_GO_READY
*            M_GO_SLEEP
* @return  TRUE or FALSE
* *********************************************************/
BOOL cmt2310a_auto_switch_state(u8 go_cmd)
{
#ifdef ENABLE_AUTO_SWITCH_CHIP_STATUS
    u32 end_tick = cmt2310a_get_tick_count() + 10;
    u8  wait_state;

    switch(go_cmd)
    {
    case M_GO_RXFS : wait_state = STATE_IS_RFS     ; break;
    case M_GO_TXFS : wait_state = STATE_IS_TFS     ; break;
    case M_GO_RX   : wait_state = STATE_IS_RX      ; break;
    case M_GO_TX   : wait_state = STATE_IS_TX      ; break;
    case M_GO_READY: wait_state = STATE_IS_READY   ; break;
    case M_GO_SLEEP: wait_state = STATE_IS_SLEEP   ; break;
    }

    return cmt2310a_switch_state_and_wait(go_cmd, wait_state, end_tick);

#else
    cmt2310a_write_reg(CMT2310A_CTL_REG_01, go_cmd);
    return TRUE;
#endif
}

/*! ********************************************************
* @name    cmt2310a_go_sleep
* @desc    Entry SLEEP mode.
* @return  TRUE or FALSE
* *********************************************************/
BOOL cmt2310a_go_sleep(void)
{
    return cmt2310a_auto_switch_state(M_GO_SLEEP);
}

/*! ********************************************************
* @name    cmt2310a_go_ready
* @desc    Entry ready mode.
* @return  TRUE or FALSE
* *********************************************************/
BOOL cmt2310a_go_ready(void)
{
    return cmt2310a_auto_switch_state(M_GO_READY);
}

/*! ********************************************************
* @name    cmt2310a_go_txfs
* @desc    Entry TFS mode.
* @return  TRUE or FALSE
* *********************************************************/
BOOL cmt2310a_go_txfs(void)
{
    return cmt2310a_auto_switch_state(M_GO_TXFS);
}

/*! ********************************************************
* @name    cmt2310a_go_rxfs
* @desc    Entry RFS mode.
* @return  TRUE or FALSE
* *********************************************************/
BOOL cmt2310a_go_rxfs(void)
{
    return cmt2310a_auto_switch_state(M_GO_RXFS);
}

/*! ********************************************************
* @name    cmt2310a_go_tx
* @desc    Entry Tx mode.
* @return  TRUE or FALSE
* *********************************************************/
BOOL cmt2310a_go_tx(void)
{
    return cmt2310a_auto_switch_state(M_GO_TX);
}

/*! ********************************************************
* @name    cmt2310a_go_rx
* @desc    Entry Rx mode.
* @return  TRUE or FALSE
* *********************************************************/
BOOL cmt2310a_go_rx(void)
{
    return cmt2310a_auto_switch_state(M_GO_RX);
}

/*! ********************************************************
* @name    cmt2310a_enable_tx_din
* @desc    enable tx din or not
* @param   en: 1:enable, 0:disable
* *********************************************************/
void cmt2310a_enable_tx_din(u8 en)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_04, (en << BIT6), M_TX_DIN_EN);
}

/*! ********************************************************
* @name    cmt2310a_enable_digtal_clkout
* @desc    enable digtal clkout or not
* @param   en: 1:enable, 0:disable
* *********************************************************/
void cmt2310a_enable_digtal_clkout(u8 en)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_06, (en << BIT6), M_DIG_CLKOUT_EN);
}

/*! ********************************************************
* @name    cmt2310a_enable_lfxo_pad
* @desc    enable lfxo pin(GPIO2 and GPIO3) or not
* @param   en: 1:enable, 0:disable
* *********************************************************/
void cmt2310a_enable_lfxo_pad(u8 en)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_07, (en << BIT5), M_LFXO_PAD_EN);
}

/*! ********************************************************
* @name    cmt2310a_config_gpio0
* @desc    Config GPIO0 pins mode.
* @param   gpio_sel:
*            GPIO0_SEL_DOUT
*            GPIO0_SEL_INT1
*            GPIO0_SEL_INT2
*            GPIO0_SEL_DCLK
* *********************************************************/
void cmt2310a_config_gpio0(u8 gpio_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_04, (gpio_sel << BIT0), M_GPIO0_SEL);
}

/*! ********************************************************
* @name    cmt2310a_config_gpio1
* @desc    Config GPIO1 pins mode.
* @param   gpio_sel:
*            GPIO1_SEL_DCLK
*            GPIO1_SEL_INT1
*            GPIO1_SEL_INT2
*            GPIO1_SEL_DOUT
* *********************************************************/
void cmt2310a_config_gpio1(u8 gpio_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_04, (gpio_sel << BIT3), M_GPIO1_SEL);
}

/*! ********************************************************
* @name    cmt2310a_config_gpio2
* @desc    Config GPIO2 pins mode.
* @param   gpio_sel:
*            GPIO2_SEL_INT1
*            GPIO2_SEL_INT2
*            GPIO2_SEL_DCLK
*            GPIO2_SEL_DOUT
* *********************************************************/
void cmt2310a_config_gpio2(u8 gpio_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_05, (gpio_sel << BIT0), M_GPIO2_SEL);
}

/*! ********************************************************
* @name    cmt2310a_config_gpio3
* @desc    Config GPIO3 pins mode.
* @param   gpio_sel:
*            GPIO3_SEL_INT2
*            GPIO3_SEL_INT1
*            GPIO3_SEL_DCLK
*            GPIO3_SEL_DOUT
*            GPIO3_SEL_DIN
* *********************************************************/
void cmt2310a_config_gpio3(u8 gpio_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_05, (gpio_sel << BIT3), M_GPIO3_SEL);
}

/*! ********************************************************
* @name    cmt2310a_config_gpio4
* @desc    Config GPIO4 pins mode.
* @param   gpio_sel:
*            GPIO4_SEL_DOUT
*            GPIO4_SEL_INT1
*            GPIO4_SEL_INT2
*            GPIO4_SEL_DCLK
*            GPIO4_SEL_DIN
* *********************************************************/
void cmt2310a_config_gpio4(u8 gpio_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_06, (gpio_sel << BIT0), M_GPIO4_SEL);
}

/*! ********************************************************
* @name    cmt2310a_config_gpio5
* @desc    Config GPIO5 pins mode.
* @param   gpio_sel:
*            GPIO5_SEL_RSTN
*            GPIO5_SEL_INT1
*            GPIO5_SEL_INT2
*            GPIO5_SEL_DOUT
*            GPIO5_SEL_DCLK
* *********************************************************/
void cmt2310a_config_gpio5(u8 gpio_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_06, (gpio_sel << BIT3), M_GPIO5_SEL);
}

/*! ********************************************************
* @name    cmt2310a_config_nirq
* @desc    Config NIRQ pins mode.
* @param   nirq_sel:
*            NIRQ_SEL_INT1
*            NIRQ_SEL_INT2
*            NIRQ_SEL_DCLK
*            NIRQ_SEL_DOUT
*            NIRQ_SEL_DIN
* *********************************************************/
void cmt2310a_config_nirq(u8 nirq_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_07, (nirq_sel << BIT0), M_NIRQ_SEL);
}

/*! ********************************************************
* @name    cmt2310a_config_tx_din
* @desc    Config tx din pins mode.
* @param   tx_din_sel:
*            TX_DIN_SEL_GPIO3
*            TX_DIN_SEL_GPIO4
*            TX_DIN_SEL_NIRQ
* *********************************************************/
void cmt2310a_config_tx_din(u8 tx_din_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_05, (tx_din_sel << BIT6), M_TX_DIN_SEL);
}


/*! ********************************************************
* @name    cmt2310a_config_interrupt
* @desc    Config interrupt on INT1 and INT2.
* @param   int1_sel, int2_sel
*          INT_SRC_MIX                         0x00
*          INT_SRC_ANT_LOCK                    0x01
*          INT_SRC_RSSI_PJD_VALID              0x02
*          INT_SRC_PREAM_PASS                  0x03
*          INT_SRC_SYNC_PASS                   0x04
*          INT_SRC_ADDR_PASS                   0x05
*          INT_SRC_CRC_PASS                    0x06
*          INT_SRC_PKT_OK                      0x07
*          INT_SRC_PKT_DONE                    0x08
*          INT_SRC_SLEEP_TMO                   0x09
*          INT_SRC_RX_TMO                      0x0A
*          INT_SRC_RX_FIFO_NMTY                0x0B
*          INT_SRC_RX_FIFO_TH                  0x0C
*          INT_SRC_RX_FIFO_FULL                0x0D
*          INT_SRC_RX_FIFO_WBYTE               0x0E
*          INT_SRC_RX_FIFO_OVF                 0x0F
*          INT_SRC_TX_DONE                     0x10
*          INT_SRC_TX_FIFO_NMTY                0x11
*          INT_SRC_TX_FIFO_TH                  0x12
*          INT_SRC_TX_FIFO_FULL                0x13
*          INT_SRC_STATE_IS_READY              0x14
*          INT_SRC_STATE_IS_FS                 0x15
*          INT_SRC_STATE_IS_RX                 0x16
*          INT_SRC_STATE_IS_TX                 0x17
*          INT_SRC_LBD_STATUS                  0x18
*          INT_SRC_API_CMD_FAILED              0x19
*          INT_SRC_API_DONE                    0x1A
*          INT_SRC_TX_DC_DONE                  0x1B
*          INT_SRC_ACK_RECV_FAILED             0x1C
*          INT_SRC_TX_RESEND_DONE              0x1D
*          INT_SRC_NACK_RECV                   0x1E
*          INT_SRC_SEQ_MATCH                   0x1F
*          INT_SRC_CSMA_DONE                   0x20
*          INT_SRC_CCA_STATUS                  0x21
* *********************************************************/
void cmt2310a_config_interrupt(u8 int1_sel, u8 int2_sel)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_16, int1_sel, M_INT1_SEL);
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_17, int2_sel, M_INT2_SEL);
}

/*! ********************************************************
* @name    cmt2310a_set_interrupt_polar
* @desc    Set the polarity of the interrupt 1/2.
* @param   int1/2_polar   0: active-high, 1: active-low
* *********************************************************/
void cmt2310a_set_interrupt_polar(u8 int1_polar, u8 int2_polar)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_17, (int1_polar << BIT7) | (int2_polar << BIT6), (M_INT1_POLAR | M_INT2_POLAR));
}

/*! ********************************************************
* @name    cmt2310a_set_fifo_threshold
* @desc    Set FIFO threshold.
* @param   fifo_th(0~256)
* *********************************************************/
void cmt2310a_set_fifo_threshold(u16 fifo_th)
{
    u8 tmp;

    tmp = (fifo_th >> 8);
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_19, (tmp << BIT5), M_FIFO_TH_8);
    tmp = fifo_th & 0xff;
    cmt2310a_write_reg(CMT2310A_CTL_REG_20, tmp);
}

/*! ********************************************************
* @name    cmt2310a_fifo_sleep_save
* @desc    save fifo content in sleep or not.
* @param   saved   0: save  , 1: no save
* *********************************************************/
void cmt2310a_fifo_sleep_save(u8 saved)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_19, (saved << BIT6), M_PD_FIFO);
}

/*! ********************************************************
* @name    cmt2310a_enable_rx_fifo_auto_clear
* @desc    enable rx fifo auto clear or not
* @param   en   0: disable  , 1: enable
* *********************************************************/
void cmt2310a_enable_rx_fifo_auto_clear(u8 en)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_19, (en << BIT4), M_FIFO_AUTO_CLR_RX_EN);
}

/*! ********************************************************
* @name    cmt2310a_enable_tx_fifo_auto_restore
* @desc    enable tx fifo auto restore or not
* @param   en   0: disable  , 1: enable
* *********************************************************/
void cmt2310a_enable_tx_fifo_auto_restore(u8 en)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_19, (en << BIT3), M_FIFO_AUTO_RES_TX_EN);
}

/*! ********************************************************
* @name    cmt2310a_enable_fifo_merge
* @desc    enable fifo merge or not
* @param   en
*           0: use a 128-byte FIFO for Tx and another 128-byte FIFO for Rx(default)
*           1: use a single 256-byte FIFO for either Tx or Rx
* *********************************************************/
void cmt2310a_enable_fifo_merge(u8 en)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_19, (en << BIT1), M_FIFO_MERGE_EN);
}

/*! ********************************************************
* @name    cmt2310a_fifo_tx_rx_sel
* @desc    select tx or rx fifo(only valid by fifo merge enable)
* @param   rw   0: rx fifo, 1: tx fifo
* *********************************************************/
void cmt2310a_fifo_tx_rx_sel(u8 rw)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_19, (rw << BIT0), M_FIFO_TX_RX_SEL);
}

/*! ********************************************************
* @name    cmt2310a_enable_interrupt_source_0
* @desc    Enable interrupt source 0.
* @param   en
*            M_SLEEP_TMO_EN   |
*            M_RX_TMO_EN      |
*            M_TX_DONE_EN     |
*            M_PREAM_PASS_EN  |
*            M_SYNC_PASS_EN   |
*            M_ADDR_PASS_EN   |
*            M_CRC_PASS_EN    |
*            M_PKT_DONE_EN
* *********************************************************/
void cmt2310a_enable_interrupt_source_0(u8 en)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_18, en);
}

/*! ********************************************************
* @name    cmt2310a_enable_interrupt_source_1
* @desc    Enable interrupt source 1.
* @param   en
*            M_RSSI_PJD_VALID_EN  |
*            M_OP_CMD_FAILED_EN   |
*            M_RSSI_COLL_EN       |
*            M_PKT_ERR_EN         |
*            M_LBD_STATUS_EN      |
*            M_LBD_STOP_EN        |
*            M_LD_STOP_EN
* *********************************************************/
void cmt2310a_enable_interrupt_source_1(u8 en)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_21, en);
}

/*! ********************************************************
* @name    cmt2310a_enable_interrupt_source_2
* @desc    Enable interrupt source 2.
* @param   en
*            M_API_DONE_EN         |
*            M_CCA_STATUS_EN       |
*            M_CSMA_DONE_EN        |
*            M_TX_DC_DONE_EN       |
*            M_ACK_RECV_FAILED_EN  |
*            M_TX_RESEND_DONE_EN   |
*            M_NACK_RECV_EN        |
*            M_SEQ_MATCH_EN
* *********************************************************/
void cmt2310a_enable_interrupt_source_2(u8 en)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_23, en);
}


/*! ********************************************************
* @name    cmt2310a_enable_interrupt_source_fifo
* @desc    Enable interrupt source fifo.
* @param   en
*            M_RX_FIFO_FULL_RX_EN  |
*            M_RX_FIFO_NMTY_RX_EN  |
*            M_RX_FIFO_TH_RX_EN    |
*            M_RX_FIFO_OVF_EN      |
*            M_TX_FIFO_FULL_EN     |
*            M_TX_FIFO_NMTY_EN     |
*            M_TX_FIFO_TH_EN       
* *********************************************************/
void cmt2310a_enable_interrupt_source_fifo(u8 en)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_14, en);
}

/*! ********************************************************
* @name    cmt2310a_clear_interrupt_flag_0
* @desc    clear interrupt flag 0.
* @param   clr
*            M_SLEEP_TMO_CLR  |
*            M_RX_TMO_CLR     |
*            M_TX_DONE_CLR
* *********************************************************/
void cmt2310a_clear_interrupt_flag_0(u8 clr)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_24, clr);
}

/*! ********************************************************
* @name    cmt2310a_get_interrupt_flag_0
* @desc    get interrupt flag 0.
* @return   interrupt flag 0
*            M_SLEEP_TMO_FLG  |
*            M_RX_TMO_FLG     |
*            M_TX_DONE_FLG
* *********************************************************/
u8 cmt2310a_get_interrupt_flag_0(void)
{
    return cmt2310a_read_reg(CMT2310A_CTL_REG_24) & (M_SLEEP_TMO_FLG|M_RX_TMO_FLG|M_TX_DONE_FLG);
}

/*! ********************************************************
* @name    cmt2310a_clear_interrupt_flag_1
* @desc    clear interrupt flag 1.
* @param   clr
*            M_PREAM_PASS_CLR |
*            M_SYNC_PASS_CLR  |
*            M_ADDR_PASS_CLR  |
*            M_CRC_PASS_CLR   |
*            M_PKT_DONE_CLR
* *********************************************************/
void cmt2310a_clear_interrupt_flag_1(u8 clr)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_25, clr);
}

/*! ********************************************************
* @name    cmt2310a_get_interrupt_flag_1
* @desc    get interrupt flag 1.
* @return   interrupt flag 1
*            M_SYNC1_PASS_FLG  |
*            M_PREAM_PASS_FLG  |
*            M_SYNC_PASS_FLG   |
*            M_ADDR_PASS_FLG   |
*            M_CRC_PASS_FLG    |
*            M_PKT_DONE_FLG
* *********************************************************/
u8 cmt2310a_get_interrupt_flag_1(void)
{
    return cmt2310a_read_reg(CMT2310A_CTL_REG_26) & (M_SYNC1_PASS_FLG|M_PREAM_PASS_FLG|M_SYNC_PASS_FLG|M_ADDR_PASS_FLG|M_CRC_PASS_FLG|M_PKT_DONE_FLG);
}

/*! ********************************************************
* @name    cmt2310a_get_fifo_flag
* @desc    get fifo flag .
* @return   fifo flag
*            M_RX_FIFO_FULL_FLG  |
*            M_RX_FIFO_NMTY_FLG  |
*            M_RX_FIFO_TH_FLG    |
*            M_RX_FIFO_OVF_FLG   |
*            M_TX_FIFO_FULL_FLG  |
*            M_TX_FIFO_NMTY_FLG  |
*            M_TX_FIFO_TH_FLG
* *********************************************************/
u8 cmt2310a_get_fifo_flag(void)
{
    return cmt2310a_read_reg(CMT2310A_CTL_REG_28);
}

/*! ********************************************************
* @name    cmt2310a_clear_interrupt_flag_2
* @desc    clear interrupt flag 2.
* @param   clr
*            M_ANT_LOCK_CLR      |
*            M_OP_CMD_FAILED_CLR |
*            M_RSSI_COLL_CLR     |
*            M_PKT_ERR_CLR       |
*            M_LBD_STATUS_CLR
* *********************************************************/
void cmt2310a_clear_interrupt_flag_2(u8 clr)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_29, clr);
}

/*! ********************************************************
* @name    cmt2310a_get_interrupt_flag_2
* @desc    get interrupt flag 2.
* @return   interrupt flag 2
*            M_ANT_LOCK_FLG      |
*            M_OP_CMD_FAILED_FLG |
*            M_RSSI_COLL_FLG     |
*            M_PKT_ERR_FLG       |
*            M_LBD_STATUS_FLG
* *********************************************************/
u8 cmt2310a_get_interrupt_flag_2(void)
{
    return cmt2310a_read_reg(CMT2310A_CTL_REG_30) & (M_ANT_LOCK_FLG|M_OP_CMD_FAILED_FLG|M_RSSI_COLL_FLG|M_PKT_ERR_FLG|M_LBD_STATUS_FLG);
}

/*! ********************************************************
* @name    cmt2310a_clear_interrupt_flag_3
* @desc    clear interrupt flag 3.
* @return   clr
*            M_API_DONE_CLR        |
*            M_CCA_STATUS_CLR      |
*            M_CSMA_DONE_CLR       |
*            M_TX_DC_DONE_CLR      |
*            M_ACK_RECV_FAILED_CLR |
*            M_TX_RESEND_DONE_CLR  |
*            M_NACK_RECV_CLR       |
*            M_SEQ_MATCH_CLR
* *********************************************************/
void cmt2310a_clear_interrupt_flag_3(u8 clr)
{
    cmt2310a_write_reg(CMT2310A_CTL_REG_31, clr);
}

/*! ********************************************************
* @name    cmt2310a_get_interrupt_flag_3
* @desc    get interrupt flag 3.
* @return   interrupt flag 3
*            M_API_DONE_FLG         |
*            M_CCA_STATUS_FLG       |
*            M_CSMA_DONE_FLG        |
*            M_TX_DC_DONE_FLG       |
*            M_ACK_RECV_FAILED_FLG  |
*            M_TX_RESEND_DONE_FLG   |
*            M_NACK_RECV_FLG        |
*            M_SEQ_MATCH_FLG
* *********************************************************/
u8 cmt2310a_get_interrupt_flag_3(void)
{
    return cmt2310a_read_reg(CMT2310A_CTL_REG_32);
}

/*! ********************************************************
* @name    cmt2310a_enable_antenna_switch
* @desc    Enable antenna switch, output TX_ACTIVE/RX_ACTIVE
*          via GPIO0/GPIO1.
* @param  en  0: disable, 1: enable
 *       mode
*            0:
*               RX_ACTIVE: GPIO0 output 1, GPIO2 output 0
*               TX_ACTIVE: GPIO0 output 0, GPIO2 output 1
*            1:
*               RX_ACTIVE: GPIO0 output 0, GPIO2 output 1
*               TX_ACTIVE: GPIO0 output 1, GPIO2 output 0
* *********************************************************/
void cmt2310a_enable_antenna_switch(u8 en, u8 mode)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_22, (mode << BIT1) | (en << BIT0), (M_TRX_SWT_INV|M_TRX_SWT_EN));
}

/*! ********************************************************
* @name    cmt2310a_select_pa_mode
* @desc    select pa mode
* @param  mode  0: single, 1: difference
* *********************************************************/
void cmt2310a_select_pa_mode(u8 mode)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_22, (mode << BIT3), M_PA_DIFF_SEL);
}

/*! ********************************************************
* @name    cmt2310a_invert_tx_data
* @desc    invert tx data(only valid if the data is transmitted via GPIO)
* @param  mode  0: normal, 1: invert
* *********************************************************/
void cmt2310a_invert_tx_data(u8 inv)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_22, (inv << BIT4), M_TX_DATA_INV);
}

/*! ********************************************************
* @name    cmt2310a_clear_tx_fifo
* @desc    clear tx fifo
* *********************************************************/
void cmt2310a_clear_tx_fifo(void)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_27, M_TX_FIFO_CLR, M_TX_FIFO_CLR);
}

/*! ********************************************************
* @name    cmt2310a_clear_rx_fifo
* @desc    clear rx fifo
* *********************************************************/
void cmt2310a_clear_rx_fifo(void)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_27, M_RX_FIFO_CLR, M_RX_FIFO_CLR);
}

/*! ********************************************************
* @name    cmt2310a_restore_tx_fifo
* @desc    retore tx fifo
* *********************************************************/
void cmt2310a_restore_tx_fifo(void)
{
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_27, M_TX_FIFO_RESTORE, M_TX_FIFO_RESTORE);
}

/*! ********************************************************
* @name    cmt2310a_is_exist
* @desc    Chip indentify.
* @return  TRUE: chip is exist, FALSE: chip not found
* *********************************************************/
BOOL cmt2310a_is_exist(void)
{
    u8 back, dat;

    back = cmt2310a_read_reg(CMT2310A_CTL_REG_12);
    cmt2310a_write_reg(CMT2310A_CTL_REG_12, 0xAA);

    dat = cmt2310a_read_reg(CMT2310A_CTL_REG_12);
    cmt2310a_write_reg(CMT2310A_CTL_REG_12, back);

    if(0xAA==dat)
        return TRUE;
    else
        return FALSE;
}

/*! ********************************************************
* @name    cmt2310a_get_rssi_value
* @desc    Get RSSI dBm.
* @return  dBm
* *********************************************************/
int cmt2310a_get_rssi_value(void)
{
    return (int8_t)cmt2310a_read_reg(CMT2310A_CTL_REG_34);
}


/*! ********************************************************
* @name    cmt2310a_set_payload_length
* @desc    Set payload length.
* @param   length
* *********************************************************/
void cmt2310a_set_payload_length(u16 length)
{
    u8 tmp;

    tmp = length & 0xff;
    cmt2310a_write_reg(CMT2310A_CTL_REG_61, tmp);

    tmp = length >> 8;
    cmt2310a_write_reg(CMT2310A_CTL_REG_62, tmp);
}

/*! ********************************************************
* @name    cmt2310a_init
* @desc    Initialize chip status.
* *********************************************************/
void cmt2310a_init(void)
{
#ifdef SPI_3W_EN  /* cmt_spi4.h */
    cmt2310a_select_spi_wire_mode(1);
#endif
    cmt2310a_soft_reset();
    cmt2310a_delay_ms(20);

}

/*! ********************************************************
* @name    cmt2310a_config_page_regs
* @desc    Writes the buffer contents to the cmt2310a regs(
           page0: register address start from 0x28,
           page1: register address start from 0x00,
           page2: register address start from 0x00).
* @param   buf: buffer containing data to be put on the regs
*          len: number of bytes to be written to the regs
*          page_sel  0: page 0, 1: page 1, 2:page 2
* *********************************************************/
void cmt2310a_config_page_regs(u8 page_sel, const u8 page_regs[], u8 len)
{
    cmt2310a_select_reg_page(page_sel);

    cmt2310a_batch_write_regs(page_regs, len);

    /* select back to page 0(default) */
    cmt2310a_select_reg_page(0);
}


