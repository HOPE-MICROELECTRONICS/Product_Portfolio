#include "typedefs.h"
#include <stdio.h>
#include <string.h>

#include "common.h"
#include "system.h"
#include "time_server.h"
#include "interrupt_server.h"
#include "key_server.h"

#include "gpio_defs.h"
#include "led.h"
#include "lcd12864.h"
#include "buzzer.h"

#include "radio.h"

#define RF_PACKET_SIZE 32               /* Define the payload size here */

static u8 g_rx_buffer[RF_PACKET_SIZE];   /* RF Rx buffer */
static u8 g_tx_buffer[RF_PACKET_SIZE];   /* RF Tx buffer */

static BOOL g_enable_master = TRUE;     /* Master/Slave selection */

static u16 g_recv_count = 0;
static u16 g_send_count = 0;
static u16 g_err_count  = 0;

void mcu_init(void)
{
    /* system init */
    SystemInit();
    GPIO_Config();
    NVIC_Config();
    SystemTimerDelay_Config();
    Timer5_Config();

    /* services init */
    time_server_init();
    IntSrv_Init();
    Key_Init();

    /* periph init */
    led_init();
    lcd12864_init();
    buzzer_init();

    lcd12864_led_on();
}

/* Manages the master operation */
void on_master(void)
{
    char str[32];

    switch(rf_process())
    {
    case RF_IDLE:
    {
        g_send_count++;
        g_tx_buffer[0] = (u8)g_send_count;
        g_tx_buffer[1] = g_send_count >> 8;

        rf_start_tx(g_tx_buffer, RF_PACKET_SIZE, 1000);
        break;
    }

    case RF_TX_DONE:
    {
        led_onAutoOff(LED_INDEX1, 50);

        sprintf(str, "send: %d", g_send_count);
        views_print_line(1, str);

        rf_start_rx(g_rx_buffer, RF_PACKET_SIZE, 1000);
        break;
    }

    case RF_RX_DONE:
    {
        led_onAutoOff(LED_INDEX2, 50);

        g_recv_count++;
        sprintf(str, "recv: %d", g_recv_count);
        views_print_line(2, str);

        break;
    }

    case RF_RX_TIMEOUT:
    {
        sprintf(str, "recv: timeout");
        views_print_line(2, str);

        break;
    }

    case RF_ERROR:
    {
        led_onAutoOff(LED_INDEX3, 1000);

        sprintf(str, "error: %d", ++g_err_count);
        views_print_line(3, str);

        break;
    }

    default:
        break;
    }
}

/* Manages the slave operation */
void on_slave(void)
{
    char str[32];

    switch(rf_process())
    {
    case RF_IDLE:
    {
        rf_start_rx(g_rx_buffer, RF_PACKET_SIZE, INFINITE);
        break;
    }

    case RF_RX_DONE:
    {
        led_onAutoOff(LED_INDEX2, 50);

        g_recv_count++;
        sprintf(str, "recv: %d", g_recv_count);
        views_print_line(1, str);

        cmt2310a_delay_ms(10);

        g_send_count++;
        g_tx_buffer[0] = (u8)g_send_count;
        g_tx_buffer[1] = g_send_count >> 8;

        rf_start_tx(g_tx_buffer, RF_PACKET_SIZE, 1000);

        break;
    }

    case RF_TX_DONE:
    {
        led_onAutoOff(LED_INDEX1, 50);

        sprintf(str, "send: %d", g_send_count);
        views_print_line(2, str);

        break;
    }

    case RF_ERROR:
    {
        led_onAutoOff(LED_INDEX3, 1000);

        sprintf(str, "error: %d", ++g_err_count);
        views_print_line(3, str);

        break;
    }

    default:
        break;
    }
}

/* Main application entry point */
int main(void)
{
    int i;

    for(i=0; i<RF_PACKET_SIZE; i++)
        g_tx_buffer[i] = i+1;

    mcu_init();
    rf_init();

    if(FALSE==cmt2310a_is_exist()) {
        views_print_line(0, "CMT2310A not found!");
        led_on(LED_INDEX3);
        while(1);
    }
    else {
        views_print_line(0, "CMT2310A ready");
    }

    while(1)
    {
        if(TRUE==g_enable_master) {
            on_master();
        }
        else {
            on_slave();
        }
    }
}

