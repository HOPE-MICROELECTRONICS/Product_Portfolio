#include "cmt_spi4.h"
#include "gpio_defs.h"
#include "common.h"

/* ************************************************************************
*  The following need to be modified by user
*  ************************************************************************ */
#define cmt_spi4_csb_out()      SET_GPIO_OUT(CMT_CSB_GPIO)
#define cmt_spi4_miso_out()     SET_GPIO_OUT(CMT_MISO_GPIO)
#define cmt_spi4_miso_in()      SET_GPIO_IN(CMT_MISO_GPIO)
#define cmt_spi4_scl_out()      SET_GPIO_OUT(CMT_SCL_GPIO)
#define cmt_spi4_mosi_out()     SET_GPIO_OUT(CMT_MOSI_GPIO)
#define cmt_spi4_mosi_in()      SET_GPIO_IN(CMT_MOSI_GPIO)

#define cmt_spi4_csb_1()        SET_GPIO_H(CMT_CSB_GPIO)
#define cmt_spi4_csb_0()        SET_GPIO_L(CMT_CSB_GPIO)

#define cmt_spi4_miso_1()       SET_GPIO_H(CMT_MISO_GPIO)
#define cmt_spi4_miso_0()       SET_GPIO_L(CMT_MISO_GPIO)
#define cmt_spi4_miso_read()    READ_GPIO_PIN(CMT_MISO_GPIO)
    
#define cmt_spi4_scl_1()        SET_GPIO_H(CMT_SCL_GPIO)
#define cmt_spi4_scl_0()        SET_GPIO_L(CMT_SCL_GPIO)

#define cmt_spi4_mosi_1()        SET_GPIO_H(CMT_MOSI_GPIO)
#define cmt_spi4_mosi_0()        SET_GPIO_L(CMT_MOSI_GPIO)
#define cmt_spi4_mosi_read()     READ_GPIO_PIN(CMT_MOSI_GPIO)
/* ************************************************************************ */
    
void cmt_spi4_delay(void)
{
    u32 n = 7;
    while(n--);
}

void cmt_spi4_delay_us(void)
{
    u16 n = 8;
    while(n--);
}

void cmt_spi4_init(void)
{
    cmt_spi4_csb_1();
    cmt_spi4_csb_out();
    cmt_spi4_csb_1();   /* CSB has an internal pull-up resistor */
    
    cmt_spi4_scl_0();
    cmt_spi4_scl_out();
    cmt_spi4_scl_0();   /* SCL has an internal pull-down resistor */
    
    cmt_spi4_mosi_1();
    cmt_spi4_mosi_out();
    cmt_spi4_mosi_1();
    
#ifndef SPI_3W_EN
    cmt_spi4_miso_1();
    cmt_spi4_miso_in();
    cmt_spi4_miso_1(); 
#endif

    cmt_spi4_delay();
}

void cmt_spi4_send(u8 data8)
{
    u8 i;

    for(i=0; i<8; i++)
    {
        cmt_spi4_scl_0();

        /* Send byte on the rising edge of SCL */
        if(data8 & 0x80)
            cmt_spi4_mosi_1();
        else            
            cmt_spi4_mosi_0();

        cmt_spi4_delay();

        data8 <<= 1;
        cmt_spi4_scl_1();
        cmt_spi4_delay();
    }
}

u8 cmt_spi4_recv(void)
{
    u8 i;
    u8 data8 = 0xFF;

    for(i=0; i<8; i++)
    {
        cmt_spi4_scl_0();
        cmt_spi4_delay();
        data8 <<= 1;

        cmt_spi4_scl_1();

        /* Read byte on the rising edge of SCL */
#ifndef SPI_3W_EN
        if(cmt_spi4_miso_read())
#else 
        if(cmt_spi4_mosi_read())
#endif 
            data8 |= 0x01;
        else
            data8 &= ~0x01;

        cmt_spi4_delay();
    }

    return data8;
}


void cmt_spi4_write(u8 addr, const u8* p_buf, u16 len)
{
    u16 i;
    
    cmt_spi4_mosi_1();
    cmt_spi4_mosi_out();
    cmt_spi4_mosi_1();

    cmt_spi4_scl_0();
    cmt_spi4_scl_out();
    cmt_spi4_scl_0(); 

    cmt_spi4_csb_0();
    cmt_spi4_csb_out();
    cmt_spi4_csb_0();

    /* > 0.5 SCL cycle */
    cmt_spi4_delay();
    cmt_spi4_delay();

    /* r/w = 0 */
    cmt_spi4_send(addr&0x7F);
    
    for(i = 0; i < len; i++) 
    {
        cmt_spi4_send(p_buf[i]);
    }

    cmt_spi4_scl_0();

    /* > 0.5 SCL cycle */
    cmt_spi4_delay();
    cmt_spi4_delay();

    cmt_spi4_csb_1();
    
    cmt_spi4_mosi_1();
#ifdef SPI_3W_EN
    cmt_spi4_mosi_in();
#endif 
}


void cmt_spi4_read(u8 addr, u8* p_buf, u16 len)
{
    u16 i;
    
    cmt_spi4_mosi_1();
    cmt_spi4_mosi_out();
    cmt_spi4_mosi_1();
#ifndef SPI_3W_EN
    cmt_spi4_miso_1();
    cmt_spi4_miso_in();
    cmt_spi4_miso_1();
#endif 
    cmt_spi4_scl_0();
    cmt_spi4_scl_out();
    cmt_spi4_scl_0(); 

    cmt_spi4_csb_0();
    cmt_spi4_csb_out();
    cmt_spi4_csb_0();

    /* > 0.5 SCL cycle */
    cmt_spi4_delay();
    cmt_spi4_delay();

    /* r/w = 1 */
    cmt_spi4_send(addr|0x80);
#ifdef SPI_3W_EN
    cmt_spi4_mosi_in();
    cmt_spi4_delay();
#endif
    for(i = 0; i < len; i++)
    {
        p_buf[i] = cmt_spi4_recv();
    }

    cmt_spi4_scl_0();

    /* > 0.5 SCL cycle */
    cmt_spi4_delay();
    cmt_spi4_delay();

    cmt_spi4_csb_1();
    
    cmt_spi4_mosi_1();

}



