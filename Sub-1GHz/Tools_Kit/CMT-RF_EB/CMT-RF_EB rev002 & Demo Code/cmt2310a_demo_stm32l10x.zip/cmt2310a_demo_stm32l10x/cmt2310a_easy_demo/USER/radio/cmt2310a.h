/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file    cmt2310a.h
 * @brief   CMT2310A transceiver RF chip driver
 *
 * @version 1.0
 * @date    Jun 23 2020
 * @author  CMOSTEK R@D
 */

#ifndef __CMT2310A_H
#define __CMT2310A_H

#include "typedefs.h"
#include "cmt2310a_defs.h"
#include "cmt2310a_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ENABLE_AUTO_SWITCH_CHIP_STATUS   /* Enable the auto switch chip status */

/* ************************************************************************
   The following are for chip status controls.
*  ************************************************************************ */
void cmt2310a_soft_reset(void);
void cmt2310a_select_spi_wire_mode(u8 spi_3w);
void cmt2310a_powerup_boot(void);
void cmt2310a_select_reg_page(u8 page_sel);
BOOL cmt2310a_api_command_and_wait(u8 api_cmd);
u8 cmt2310a_get_chip_state(void);
BOOL cmt2310a_switch_state_and_wait(u8 go_cmd, u8 wait_state, u32 end_tick);
BOOL cmt2310a_auto_switch_state(u8 go_cmd);
BOOL cmt2310a_go_sleep(void);
BOOL cmt2310a_go_ready(void);
BOOL cmt2310a_go_txfs(void);
BOOL cmt2310a_go_rxfs(void);
BOOL cmt2310a_go_tx(void);
BOOL cmt2310a_go_rx(void);

/* ************************************************************************
*  The following are for chip interrupts, GPIO, FIFO operations.
*  ************************************************************************ */
void cmt2310a_config_gpio0(u8 gpio_sel);
void cmt2310a_config_gpio1(u8 gpio_sel);
void cmt2310a_config_gpio2(u8 gpio_sel);
void cmt2310a_config_gpio3(u8 gpio_sel);
void cmt2310a_config_gpio4(u8 gpio_sel);
void cmt2310a_config_gpio5(u8 gpio_sel);
void cmt2310a_config_nirq(u8 nirq_sel);


void cmt2310a_config_interrupt(u8 int1_sel, u8 int2_sel);
void cmt2310a_set_interrupt_polar(u8 int1_polar, u8 int2_polar);
void cmt2310a_enable_interrupt_source_0(u8 en);
void cmt2310a_enable_interrupt_source_1(u8 en);
void cmt2310a_enable_interrupt_source_2(u8 en);
void cmt2310a_enable_interrupt_source_fifo(u8 en);
void cmt2310a_clear_interrupt_flag_0(u8 clr);
u8 cmt2310a_get_interrupt_flag_0(void);
void cmt2310a_clear_interrupt_flag_1(u8 clr);
u8 cmt2310a_get_interrupt_flag_1(void);
u8 cmt2310a_get_fifo_flag(void);
void cmt2310a_clear_interrupt_flag_2(u8 clr);
u8 cmt2310a_get_interrupt_flag_2(void);
void cmt2310a_clear_interrupt_flag_3(u8 clr);
u8 cmt2310a_get_interrupt_flag_3(void);

void cmt2310a_set_fifo_threshold(u16 fifo_th);
void cmt2310a_fifo_sleep_save(u8 saved);
void cmt2310a_enable_rx_fifo_auto_clear(u8 en);
void cmt2310a_enable_tx_fifo_auto_restore(u8 en);
void cmt2310a_enable_fifo_merge(u8 en);
void cmt2310a_fifo_tx_rx_sel(u8 rw);
void cmt2310a_clear_tx_fifo(void);
void cmt2310a_clear_rx_fifo(void);
void cmt2310a_restore_tx_fifo(void);


/* ************************************************************************
*  The following are for Tx DIN operations in direct mode.
*  ************************************************************************ */
void cmt2310a_enable_tx_din(u8 en);
void cmt2310a_config_tx_din(u8 tx_din_sel);
void cmt2310a_invert_tx_data(u8 inv);

/* ************************************************************************
*  The following are general operations.
*  ************************************************************************ */
void cmt2310a_enable_digtal_clkout(u8 en);
void cmt2310a_enable_lfxo_pad(u8 en);
void cmt2310a_enable_antenna_switch(u8 en, u8 mode);
void cmt2310a_select_pa_mode(u8 mode);
int cmt2310a_get_rssi_value(void);
void cmt2310a_set_payload_length(u16 length);
BOOL cmt2310a_is_exist(void);

/* ************************************************************************
*  The following are for chip initializes.
*  ************************************************************************ */
void cmt2310a_init(void);
void cmt2310a_config_page_regs(u8 page_sel, const u8 page_regs[], u8 len);

#ifdef __cplusplus
}
#endif

#endif
