/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file    radio.c
 * @brief   Generic radio handlers
 *
 * @version 1.0
 * @date    Jun 23 2020
 * @author  CMOSTEK R@D
 */

#include "radio.h"
#include "cmt2310a_params.h"

#include <string.h>

static EnumRFStatus g_next_state = RF_STATE_IDLE;
static u8* g_ptr_rx_buffer = NULL;
static u8* g_ptr_tx_buffer = NULL;
static u16 g_rx_length = 0;
static u16 g_tx_length = 0;

static u32 g_rx_timeout = INFINITE;
static u32 g_tx_timeout = INFINITE;
static u32 g_rx_time_count = 0;
static u32 g_tx_time_count = 0;

static u8 rf_check_received_data(u8 buf[], u16 len)
{
    u8 i;
    for(i = 2; i < len; i++)
    {
        if(buf[i] != (i+1))
        {
            return 1; // check failed 
        }
    }
    return 0; // check ok
}

void rf_init(void)
{
    cmt2310a_init_gpio();

    cmt2310a_init();

    rf_config();
}

void rf_config(void)
{
    /* Config registers */
    cmt2310a_config_page_regs(0, g_cmt2310a_page0, CMT2310A_PAGE0_SIZE); /* config page 0 */
    cmt2310a_config_page_regs(1, g_cmt2310a_page1, CMT2310A_PAGE1_SIZE); /* config page 1 */
#ifdef CMT2310A_AUTO_HOP_ENABLE /* cmt2310a_param.h exported by rfpdk */
    cmt2310a_config_page_regs(2, g_cmt2310a_page2, CMT2310A_PAGE2_SIZE); /* config page 2 */
    cmt2310a_write_reg(CMT2310A_CTL_REG_12, freq_space_val);
    cmt2310a_write_reg(CMT2310A_CTL_REG_13, freq_times_val);
    cmt2310a_set_reg_bits(CMT2310A_CTL_REG_22, ((freq_switch_state_val << BIT5)|(freq_hop_persist_val << BIT6)), (M_RX_HOP_PERSIST|M_FREQ_SW_STATE));
#endif
    cmt2310a_powerup_boot();
    cmt2310a_delay_ms(5);

    cmt2310a_go_ready();
    cmt2310a_delay_ms(2);

    /* do dc-offset calibration */
    cmt2310a_api_command_and_wait(0x02);

    cmt2310a_delay_ms(2);
    
    /* do ir calibration */
    cmt2310a_api_command_and_wait(0x01);

    /* Config GPIOs */
    cmt2310a_config_gpio0(GPIO0_SEL_INT1); /* INT1 -> GPIO0 */
    cmt2310a_config_gpio1(GPIO1_SEL_INT2); /* INT2 -> GPIO1 */

    //cmt2310a_config_gpio2(GPIO2_SEL_DOUT); 
    //cmt2310a_config_gpio3(GPIO3_SEL_DCLK); 

    /* Config interrupt */
    cmt2310a_config_interrupt(
        INT_SRC_TX_DONE,   /* Config TX_DONE  -> INT1 */
        INT_SRC_PKT_DONE   /* Config PKT_DONE -> INT2 */
        );

    /* config interrupt polar */
    cmt2310a_set_interrupt_polar(0,0); /* INT1: active-high, INT2: active-high */

    /* enable interrupt source */
    cmt2310a_enable_interrupt_source_0(
        M_TX_DONE_EN     |
        M_PREAM_PASS_EN  |
        M_SYNC_PASS_EN   |
        M_ADDR_PASS_EN   |
        M_CRC_PASS_EN    |
        M_PKT_DONE_EN
        );

    /* enable interrupt source fifo*/
    cmt2310a_enable_interrupt_source_fifo(
        M_RX_FIFO_FULL_RX_EN  |
        M_RX_FIFO_NMTY_RX_EN  |
        M_RX_FIFO_TH_RX_EN    |
        M_RX_FIFO_OVF_EN      |
        M_TX_FIFO_FULL_EN     |
        M_TX_FIFO_NMTY_EN     |
        M_TX_FIFO_TH_EN     
        );

    /* Use a single 256-byte FIFO for either Tx or Rx */
    //cmt2310a_enable_fifo_merge(1);

    //cmt2310a_set_fifo_threshold(16);

    /* save fifo at sleep state or not */
    //cmt2310a_fifo_sleep_save(0); /* 0: save, 1: no save */

    /* select pa mode, 0: single, 1: difference */
    cmt2310a_select_pa_mode(0);
}


void rf_start_rx(u8 buf[], u16 len, u32 timeout)
{
    g_ptr_rx_buffer = buf;
    g_rx_length = len;
    g_rx_timeout = timeout;

    memset(g_ptr_rx_buffer, 0, g_rx_length);

    g_next_state = RF_STATE_RX_START;
}

void rf_start_tx(u8 buf[], u16 len, u32 timeout)
{
    g_ptr_tx_buffer = buf;
    g_tx_length = len;
    g_tx_timeout = timeout;

    g_next_state = RF_STATE_TX_START;
}

EnumRFResult rf_process(void)
{
    EnumRFResult nRes = RF_BUSY;

    switch(g_next_state)
    {
    case RF_STATE_IDLE:
    {
        nRes = RF_IDLE;
        break;
    }

    case RF_STATE_RX_START:
    {
        cmt2310a_go_ready();
        cmt2310a_delay_ms(2);

        cmt2310a_clear_interrupt_flag_1(
                        M_PREAM_PASS_CLR |
                        M_SYNC_PASS_CLR  |
                        M_ADDR_PASS_CLR  |
                        M_CRC_PASS_CLR   |
                        M_PKT_DONE_CLR
                        );

        /* if fifo merge is enable, enable spi to write the FIFO */
        //cmt2310a_fifo_tx_rx_sel(0);

        cmt2310a_clear_rx_fifo();

        if(FALSE==cmt2310a_go_rx())
            g_next_state = RF_STATE_ERROR;
        else
            g_next_state = RF_STATE_RX_WAIT;

        g_rx_time_count = cmt2310a_get_tick_count();

        break;
    }

    case RF_STATE_RX_WAIT:
    {

        //if(M_PKT_DONE_FLG & cmt2310a_get_interrupt_flag_1())  /* Read PKT_DONE flag */
        if(cmt2310a_read_gpio1())  /* Read INT2, PKT_DONE */
        {
            g_next_state = RF_STATE_RX_DONE;
        }

        if( (INFINITE != g_rx_timeout) && ((g_nSysTickCount-g_rx_time_count) > g_rx_timeout) )
            g_next_state = RF_STATE_RX_TIMEOUT;

        break;
    }

    case RF_STATE_RX_DONE:
    {
        cmt2310a_go_ready();
        cmt2310a_delay_ms(2);

        /* The length need be smaller than 128 */
        cmt2310a_read_fifo(g_ptr_rx_buffer, g_rx_length);


        cmt2310a_go_sleep();
        cmt2310a_delay_ms(2);

        if(rf_check_received_data(g_ptr_rx_buffer, g_rx_length))
        {
            g_next_state = RF_STATE_ERROR;
        }
        else 
        {
            g_next_state = RF_STATE_IDLE;
            nRes = RF_RX_DONE;
        }
        
        break;
    }

    case RF_STATE_RX_TIMEOUT:
    {
        cmt2310a_go_sleep();
        cmt2310a_delay_ms(2);

        g_next_state = RF_STATE_IDLE;
        nRes = RF_RX_TIMEOUT;
        break;
    }

    case RF_STATE_TX_START:
    {
        cmt2310a_go_ready();
        cmt2310a_delay_ms(2);

        cmt2310a_clear_interrupt_flag_0(M_TX_DONE_CLR);

        /* if fifo merge is enable, enable spi to write the FIFO */
        //cmt2310a_fifo_tx_rx_sel(1);

        cmt2310a_clear_tx_fifo();

        /* The length need be smaller than 128 */
        cmt2310a_write_fifo(g_ptr_tx_buffer, g_tx_length);

        if( 0==(M_TX_FIFO_NMTY_FLG & cmt2310a_get_fifo_flag()) )
            g_next_state = RF_STATE_ERROR;

        if(FALSE==cmt2310a_go_tx())
            g_next_state = RF_STATE_ERROR;
        else
            g_next_state = RF_STATE_TX_WAIT;

        g_tx_time_count = cmt2310a_get_tick_count();

        break;
    }

    case RF_STATE_TX_WAIT:
    {

        //if(M_TX_DONE_FLG & cmt2310a_get_interrupt_flag_0())  /* Read TX_DONE flag */
        if(cmt2310a_read_gpio0())  /* Read INT1, TX_DONE */
        {
            g_next_state = RF_STATE_TX_DONE;
        }

        if( (INFINITE != g_tx_timeout) && ((g_nSysTickCount-g_tx_time_count) > g_tx_timeout) )
            g_next_state = RF_STATE_TX_TIMEOUT;

        break;
    }

    case RF_STATE_TX_DONE:
    {
        cmt2310a_go_sleep();
        cmt2310a_delay_ms(2);

        g_next_state = RF_STATE_IDLE;
        nRes = RF_TX_DONE;
        break;
    }

    case RF_STATE_TX_TIMEOUT:
    {
        cmt2310a_go_sleep();
        cmt2310a_delay_ms(2);

        g_next_state = RF_STATE_IDLE;
        nRes = RF_TX_TIMEOUT;
        break;
    }

    case RF_STATE_ERROR:
    {
        rf_init();

        g_next_state = RF_STATE_IDLE;
        nRes = RF_ERROR;
        break;
    }

    default:
        break;
    }

    return nRes;
}

