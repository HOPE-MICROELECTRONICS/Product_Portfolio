#ifndef __CMT_SPI4_H
#define __CMT_SPI4_H

#include "typedefs.h"
#include "stm32f10x_conf.h"

/* *************************************************************************************************
* if define SPI_3W_EN, cmt220a is accessed by 3 pins spi; or cmt2310a is accessed by 4 pins spi(default)
***************************************************************************************************/
//#define SPI_3W_EN

__inline void cmt_spi4_delay(void);
__inline void cmt_spi4_delay_us(void);

void cmt_spi4_init(void);


void cmt_spi4_write(u8 addr, const u8* p_buf, u16 len);
void cmt_spi4_read(u8 addr, u8* p_buf, u16 len);

void cmt_spi4_write_3pin(u8 addr, const u8* p_buf, u16 len);
void cmt_spi4_read_3pin(u8 addr, u8* p_buf, u16 len);

#endif
