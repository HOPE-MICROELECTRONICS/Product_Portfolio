/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file    cmt2310a_hal.c
 * @brief   CMT2310A transceiver RF chip driver
 *
 * @version 1.0
 * @date    Jun 23 2020
 * @author  CMOSTEK R@D
 */

#include "cmt2310a_hal.h"
#include "cmt2310a_defs.h"

/*! ********************************************************
* @name    cmt2310a_init_gpio
* @desc    Initializes the cmt2310a interface GPIOs.
* *********************************************************/
void cmt2310a_init_gpio(void)
{
    cmt2310a_set_gipo0_in();
    cmt2310a_set_gipo1_in();
    cmt2310a_set_nirq_in();

    cmt_spi4_init();
}

/*! ********************************************************
* @name    cmt2310a_read_reg
* @desc    Read the cmt2310a register at the specified address.
* @param   addr: register address
* @return  Register value
* *********************************************************/
u8 cmt2310a_read_reg(u8 addr)
{
    u8 dat = 0xFF;
    cmt_spi4_read(addr, &dat, 1);

    return dat;
}

/*! ********************************************************
* @name    cmt2310a_write_reg
* @desc    Write the cmt2310a register at the specified address.
* @param   addr: register address
*          dat: register value
* *********************************************************/
void cmt2310a_write_reg(u8 addr, u8 dat)
{
    cmt_spi4_write(addr, &dat, 1);
}

/*! ********************************************************
* @name    cmt2310a_set_reg_bits
* @desc    set bits value of the cmt2310a register
* @param   addr: register address
*          dat: bits value
*          bit_masks: the mask of bits
* *********************************************************/
void cmt2310a_set_reg_bits(u8 addr, u8 dat, u8 bits_mask)
{
    u8 reg_val;

    reg_val = cmt2310a_read_reg(addr);
    reg_val &= ~bits_mask;
    reg_val |= (dat & bits_mask);
    cmt_spi4_write(addr, &reg_val, 1);
}

/*! ********************************************************
* @name    cmt2310a_read_regs
* @desc    Reads the contents of the cmt2310a regs.
* @param   addr: register start address
           buf: buffer where to copy the regs read data
*          len: number of bytes to be read from the regs
* *********************************************************/
void cmt2310a_read_regs(u8 addr, u8 buf[], u16 len)
{
    u16 i;

    for(i = 0; i < len; i++)
    {
        buf[i] = cmt2310a_read_reg(addr);
        addr += 1;
    }
}

/*! ********************************************************
* @name    cmt2310a_write_regs
* @desc    Writes the buffer contents to the cmt2310a regs.
* @param   addr: register start address
           buf: buffer containing data to be put on the regs
*          len: number of bytes to be written to the regs
* *********************************************************/
void cmt2310a_write_regs(u8 addr, const u8 buf[], u16 len)
{
    u16 i;

    for(i = 0; i < len; i++)
    {
        cmt2310a_write_reg(addr, buf[i]);
        addr += 1;
    }
}

/*! ********************************************************
* @name    cmt2310a_batch_read_regs
* @desc    Reads the contents of the cmt2310a regs(
           page0: register address start from 0x28,
           page1: register address start from 0x00).
* @param   buf: buffer where to copy the regs read data
*          len: number of bytes to be read from the regs
* *********************************************************/
void cmt2310a_batch_read_regs(u8 buf[], u16 len)
{
    cmt_spi4_read(CMT2310A_CRW_PORT, buf, len);
}

/*! ********************************************************
* @name    cmt2310a_batch_write_regs
* @desc    Writes the buffer contents to the cmt2310a regs(
           page0: register address start from 0x28,
           page1: register address start from 0x00).
* @param   buf: buffer containing data to be put on the regs
*          len: number of bytes to be written to the regs
* *********************************************************/
void cmt2310a_batch_write_regs(const u8 buf[], u16 len)
{
    cmt_spi4_write(CMT2310A_CRW_PORT, buf, len);
}

/*! ********************************************************
* @name    cmt2310a_read_fifo
* @desc    Reads the contents of the cmt2310a FIFO.
* @param   buf: buffer where to copy the FIFO read data
*          len: number of bytes to be read from the FIFO
* *********************************************************/
void cmt2310a_read_fifo(u8 buf[], u16 len)
{
    cmt_spi4_read(CMT2310A_FIFO_PORT, buf, len);
}

/*! ********************************************************
* @name    cmt2310a_write_fifo
* @desc    Writes the buffer contents to the cmt2310a FIFO.
* @param   buf: buffer containing data to be put on the FIFO
*          len: number of bytes to be written to the FIFO
* *********************************************************/
void cmt2310a_write_fifo(const u8 buf[], u16 len)
{
    cmt_spi4_write(CMT2310A_FIFO_PORT, buf, len);
}
