


#ifndef	_CMT2310A_EB_

	#define _CMT2310A_EB_

	#include 	"base_types.h"

	#include 	"adt.h"
	#include 	"aes.h"
	#include 	"bt.h"
	#include 	"crc.h"
	#include 	"ddl.h"
	#include 	"flash.h"
	#include 	"gpio.h"
	#include 	"lpm.h"
	#include 	"lptim.h"
	#include 	"trng.h"
	#include 	"uart.h"
	#include	"crc.h"

	#include 	"radio.h"	



	#define		LIMIT_TIMER_TX_CNT	100
	#define		LIMIT_TIMER_RX_CNT	500	
	

	#define	  	UART_TXD_LEN		1024
	#define	 	UART_RXD_LEN		1024
	#define		UART_RXD_LIMIT		1024		

	#define		UHF_LEN				16
		
	#define 	BUFFER_SIZE 		32u			

	/******************************************************************************
	Pxx_SEL:����GPIO�Ĺ���(��Ϊ��ͨGPIO�����������ù���)
	PxDIR:  ����������üĴ���                        	1=����      0=���
	PxIN:   ����ֵ�Ĵ���(��ȡ�˿ڵ�ƽ״̬)
	PxOUT:  �����ƽ״̬���üĴ���
	PxADS:  ��ģ���üĴ���		                       	1=ģ��	    0=����(Ĭ��)
	PxBSET: ��λ�Ĵ���
	PxBCLR: ����λ�Ĵ���
	PxDR:   �����������üĴ���		 	               	1=������	0=������(Ĭ��)
	PxPU:	����ʹ�����üĴ���							1=ʹ��		0=��ֹ(Ĭ��)
	PxPD:	����ʹ�����üĴ���							1=ʹ��		0=��ֹ(Ĭ��)
	PxOD:	��©������üĴ���							1=ʹ��		0=��ֹ(Ĭ��)
	PxHIE:	�ߵ�ƽ�ж�ʹ�����üĴ���
	PxLIE:  �͵�ƽ�ж�ʹ�����üĴ���
	PxRIE:  �������ж�ʹ�����üĴ���
	PxFIE:	�½����ж�ʹ�����üĴ���
	Px_STAT:�ж�״̬�Ĵ���
	Px_ICLR:�ж�����Ĵ���
	******************************************************************************/

	//PA                            	   PxDIR   PxOUT    PxADS     PxDR    PxPU    PxPD   PxOD	PxHIE    PxLIE	  PxRIE 	PxFIE	 Pxx_SEL
  	#define	PA00		0x0001		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000     
  	#define PA01	   	0x0002		//       1       1        0        0       1       0      0       0        0        0         0		 0x0000     
  	#define PA02	    0x0004  	//       1       1        0        0       1       0      0       0        0        0         0      0x0001	    * UART1_TXD
  	#define PA03  		0x0008		//       1       1        0        0       1       0      0       0        0        0         0      0x0001     * UART1_RXD
	#define	CSB			0x0010		//		 0		 1        0        0       0       0      0       0        0        0         0      0x0001     * PA04 == CSB
	#define	SCLK		0x0020		//		 0       0		  0        0       0       0      0       0        0        0         0      0x0001     * PA05 == SCLK
	#define	MISO		0x0040		//		 1       1        0        0       1       0      0       0        0        0         0      0x0001     * PA06 == MISO
	#define	MOSI		0x0080		//  	 0       1        0        0	   0       0      0       0        0        0         0      0x0001     * PA07 == MOSI
	#define	PA08		0x0100		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000
	#define PA09		0x0200		//       1       1        0        0       1       0      0       0        0        0         0      0x0000
	#define	PA10		0x0400		//       1       1        0        0       1       0      0       0        0        0         0 	 0x0000                         
	#define	PA11		0x0800		//       1       1        0        0       1       0      0       0        0        0         0      0x0000
	#define	PA12		0x1000		//       1       1        0        0       1       0      0       0        0        0         0      0x0000 
	#define	SWCLK		0x2000		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000 
	#define	SWDIO		0x4000		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000 
	#define	PA15		0x8000		//		 1       1        0        0       1       0      0       0        0        0         0 	 0x0000 	 	

	//PB                            	   PxDIR   PxOUT    PxADS     PxDR    PxPU    PxPD   PxOD	PxHIE    PxLIE	  PxRIE 	PxFIE	 Pxx_SEL
  	#define RF_GPIO0  	0x0001		//		 1       1        0        0       0       0      0       0        0        0         0 	 0x0000	    * GPIO0
  	#define RF_GPIO1   	0x0002		//		 1       1        0        0       0       0      0       0        0        0         0      0x0000     * GPIO1
	#define	RF_nIRQ		0x0004		//		 1       1        0        0       0       0      0       0        0        0         0      0x0000     * nIRQ
	#define KEY5		0x0008		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000		* KEY5
	#define	KEY4		0x0010		//		 1       1        0        0       1       0      0       0        0        0         0  	 0x0000     * KEY4
	#define	KEY3		0x0020		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000     * KEY3
	#define	TxD			0x0040		//		 0       1        0        0       0       0      0       0        0        0         0		 0x0002     * UART0_TxD
	#define	RxD			0x0080		//		 1       1        0        0       1       0      0       0        0        0         0      0x0002     * UART0_RxD
	#define	KEY2		0x0100		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000     * KEY2
	#define	KEY1		0x0200		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000     * KEY1 
	#define	PB10		0x0400		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000 
	#define	PB11		0x0800		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000  
	#define	L_CS		0x1000		//		 0       1        0        0       0       0      0       0        0        0         0      0x0000     * LCD_CS
	#define	L_RST		0x2000		//		 0       1        0        0       0       0      0       0        0        0         0      0x0000     * LCD_RESET
	#define	L_RS		0x4000		//		 0       1        0        0       0       0      0       0        0        0         0      0x0000     * LCD_RS
	#define	L_SDA		0x8000		//		 0       1        0        0       0       0      0       0        0        0         0	     0x0000 	* LCD_SDA		                                                                                      		
		                                                                                      
	//PC                            	   PxDIR   PxOUT    PxADS     PxDR    PxPU    PxPD   PxOD	PxHIE    PxLIE	  PxRIE 	PxFIE	 Pxx_SEL
  	#define PC00	  	0x0001		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000
  	#define PC01   		0x0002		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000 
	#define	PC02		0x0004		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000
	#define PC03   		0x0008		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000
	#define	RF_GPIO4	0x0010		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000    * GPIO4/GPIO5
	#define	PC05		0x0020		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000    
	#define	L_SCK		0x0040		//		 0       0        0        0       0       0      0       0        0        0         0      0x0000    * LCD_SCK
	#define	L_LED		0x0080		//		 0       0        0        0       0       0      0       0        0        0         0      0x0000    * LCD_LEDA
	#define	PC08		0x0100		//		 1       0        0        0       1       0      0       0        0        0         0	     0x0000 
	#define	PC09		0x0200		//		 1       0        0        0       1       0      0       0        0        0         0	     0x0000
	#define LED3   		0x0400		//		 0       0        0        0       0       0      0       0        0        0         0      0x0000    * LED3
	#define	LED2		0x0800		//		 0       0        0        0       0       0      0       0        0        0         0      0x0000    * LED2
	#define	LED1		0x1000		//		 0       0        0        0       0       0      0       0        0        0         0      0x0000    * LED1
	#define	PC13		0x2000		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000
    #define	X32K_1		0x4000		//		 1       1        1        0       0       0      0       0        0        0         0      0x0000
    #define	X32K_2		0x8000		//		 1       1        1        0       0       0      0       0        0        0         0      0x0000
    
    //PD                            	   PxDIR   PxOUT    PxADS     PxDR    PxPU    PxPD   PxOD	PxHIE    PxLIE	  PxRIE 	PxFIE	 Pxx_SEL
	#define	X32M_1		0x0001		//		 1       1        1        0       0       0      0       0        0        0         0      0x0000
	#define	X32M_2		0x0002		//		 1       1        1        0       0       0      0       0        0        0         0      0x0000
	#define	BUZZER		0x0004		//		 0       0        0        0       0       0      0       0        0        0         0      0x0000   * BUZZER
	#define	BOOT		0x0008		//		 1       1        0        0       0       0      0       0        0        0         0 	 0x0000	 
	#define	PD04		0x0010		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000
	#define	PD05		0x0020		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000 
	#define	PD06		0x0040		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000 
	#define	PD07		0x0080		//		 1       1        0        0       1       0      0       0        0        0         0      0x0000


	#define	PA_DIR_VALUE   	0x0000FF4F
	#define	PB_DIR_VALUE   	0x00000FBF
	#define	PC_DIR_VALUE   	0x0000E33F
	#define	PD_DIR_VALUE   	0x000000FB
	                      	
	#define	PA_OUT_VALUE   	0x0000FFDF
	#define	PB_OUT_VALUE   	0x0000FFFF
	#define	PC_OUT_VALUE   	0x0000E03F
	#define	PD_OUT_VALUE   	0x000000FB
	
	#define	PA_ADS_VALUE	0x00000000
	#define	PB_ADS_VALUE	0x00000000
	#define	PC_ADS_VALUE	0x0000C000
	#define	PD_ADS_VALUE	0x00000003
	
	#define PA_DR_VALUE		0x00000000
	#define	PB_DR_VALUE		0x00000000
	#define PC_DR_VALUE		0x00000000
	#define	PD_DR_VALUE		0x00000000
	
	#define	PA_PU_VALUE    	0x0000FF4F
	#define	PB_PU_VALUE    	0x00000FB8
	#define	PC_PU_VALUE    	0x0000233F
	#define	PD_PU_VALUE    	0x000000F0
	
	#define	PA_PD_VALUE		0x00000000
	#define	PB_PD_VALUE		0x00000000
	#define	PC_PD_VALUE		0x00000000
	#define	PD_PD_VALUE		0x00000000
	
	#define	PA_OD_VALUE		0x00000000
	#define	PB_OD_VALUE		0x00000000
	#define	PC_OD_VALUE		0x00000000
	#define	PD_OD_VALUE		0x00000000
	
	#define	PA_HIE_VALUE	0x00000000
	#define	PB_HIE_VALUE	0x00000000
	#define	PC_HIE_VALUE	0x00000000
	#define	PD_HIE_VALUE	0x00000000
	
	#define	PA_LIE_VALUE	0x00000000
	#define	PB_LIE_VALUE	0x00000000
	#define	PC_LIE_VALUE	0x00000000
	#define	PD_LIE_VALUE	0x00000000
	
	#define	PA_RIE_VALUE	0x00000000
	#define	PB_RIE_VALUE	0x00000000
	#define	PC_RIE_VALUE	0x00000000
	#define	PD_RIE_VALUE	0x00000000
	
	#define	PA_FIE_VALUE	0x00000000
	#define	PB_FIE_VALUE	0x00000000
	#define	PC_FIE_VALUE	0x00000000
	#define	PD_FIE_VALUE	0x00000000
	
	#define	PA0_SEL_VALUE	0x00000000			
	#define	PA1_SEL_VALUE	0x00000000
	#define	PA2_SEL_VALUE	0x00000000
	#define	PA3_SEL_VALUE	0x00000000
	#define	PA4_SEL_VALUE	0x00000001			//SPI_CSB
	#define	PA5_SEL_VALUE	0x00000001			//SPI_SCLK
	#define	PA6_SEL_VALUE	0x00000001			//SPI_MISO	
	#define	PA7_SEL_VALUE	0x00000001			//SPI_MOSI
	#define	PA8_SEL_VALUE	0x00000000
	#define	PA9_SEL_VALUE	0x00000000
	#define	PA10_SEL_VALUE	0x00000000
	#define	PA11_SEL_VALUE	0x00000000
	#define	PA12_SEL_VALUE	0x00000000
	#define	PA13_SEL_VALUE	0x00000000
	#define	PA14_SEL_VALUE	0x00000000
	#define	PA15_SEL_VALUE	0x00000000
	
	#define	PB0_SEL_VALUE	0x00000000
	#define	PB1_SEL_VALUE	0x00000000
	#define	PB2_SEL_VALUE	0x00000000
	#define	PB3_SEL_VALUE	0x00000000
	#define	PB4_SEL_VALUE	0x00000000
	#define	PB5_SEL_VALUE	0x00000000
	#define	PB6_SEL_VALUE	0x00000002
	#define	PB7_SEL_VALUE	0x00000002
	#define	PB8_SEL_VALUE	0x00000000
	#define	PB9_SEL_VALUE	0x00000000
	#define	PB10_SEL_VALUE	0x00000000
	#define	PB11_SEL_VALUE	0x00000000
	#define	PB12_SEL_VALUE	0x00000000
	#define	PB13_SEL_VALUE	0x00000000
	#define	PB14_SEL_VALUE	0x00000000
	#define	PB15_SEL_VALUE	0x00000000
	
	#define	PC0_SEL_VALUE	0x00000000
	#define	PC1_SEL_VALUE	0x00000000
	#define	PC2_SEL_VALUE	0x00000000
	#define	PC3_SEL_VALUE	0x00000000
	#define	PC4_SEL_VALUE	0x00000000
	#define	PC5_SEL_VALUE	0x00000000
	#define	PC6_SEL_VALUE	0x00000000
	#define	PC7_SEL_VALUE	0x00000000
	#define	PC8_SEL_VALUE	0x00000000
	#define	PC9_SEL_VALUE	0x00000000
	#define	PC10_SEL_VALUE	0x00000000
	#define	PC11_SEL_VALUE	0x00000000
	#define	PC12_SEL_VALUE	0x00000000
	#define	PC13_SEL_VALUE	0x00000000
	#define	PC14_SEL_VALUE	0x00000000
	#define	PC15_SEL_VALUE	0x00000000
	
	#define	PD0_SEL_VALUE	0x00000000
	#define	PD1_SEL_VALUE	0x00000000
	#define	PD2_SEL_VALUE	0x00000000
	#define	PD3_SEL_VALUE	0x00000000
	#define	PD4_SEL_VALUE	0x00000000
	#define	PD5_SEL_VALUE	0x00000000
	#define	PD6_SEL_VALUE	0x00000000
	#define	PD7_SEL_VALUE	0x00000000

	//-------------------LCD Pin Control--------------------------
	#define	SET_LEDA()			(M0P_GPIO->PCOUT |= L_LED)
	#define	CLR_LEDA()			(M0P_GPIO->PCOUT &= (~L_LED))	
	
	#define	SET_LCD_CS()   		(M0P_GPIO->PBOUT |= L_CS)
	#define	CLR_LCD_CS()   		(M0P_GPIO->PBOUT &= (~L_CS))
	                    		
	#define	SET_LCD_RST()		(M0P_GPIO->PBOUT |= L_RST)
	#define	CLR_LCD_RST()		(M0P_GPIO->PBOUT &= (~L_RST))
	                        	
	#define	SET_LCD_RS()		(M0P_GPIO->PBOUT |= L_RS)
	#define	CLR_LCD_RS()		(M0P_GPIO->PBOUT &= (~L_RS))
	                        	
	#define	SET_LCD_SDA()		(M0P_GPIO->PBOUT |= L_SDA)
	#define	CLR_LCD_SDA()		(M0P_GPIO->PBOUT &= (~L_SDA))
	                        	
	#define	SET_LCD_SCK()   	(M0P_GPIO->PCOUT |= L_SCK)	
	#define	CLR_LCD_SCK()   	(M0P_GPIO->PCOUT &= (~L_SCK))
	                    	
	#define LCD_SDA_Output()	(M0P_GPIO->PBDIR&=(~L_SDA))
	#define	LCD_SDA_Input()  	(M0P_GPIO->PBDIR|=L_SDA)
	
	#define LCD_SDA_H()    		(M0P_GPIO->PBIN&L_SDA)
	#define LCD_SDA_L()			((M0P_GPIO->PBIN&L_SDA)==0)

	//=======================Control Interface=====================
	#define	SET_LED1()			(M0P_GPIO->PCOUT |= LED1)      
	#define	CLR_LED1()			(M0P_GPIO->PCOUT &= (~LED1))	

	#define	SET_LED2()			(M0P_GPIO->PCOUT |= LED2)      
	#define	CLR_LED2()			(M0P_GPIO->PCOUT &= (~LED2))	

	#define	SET_LED3()			(M0P_GPIO->PCOUT |= LED3)      
	#define	CLR_LED3()			(M0P_GPIO->PCOUT &= (~LED3))	

	#define SET_BUZZER()		(M0P_GPIO->PDOUT |= BUZZER)       
	#define	CLR_BUZZER()		(M0P_GPIO->PDOUT &= (~BUZZER))	   

	#define	KEY1_PRESS()		((M0P_GPIO->PBIN&KEY1)==0)
	#define	KEY1_RELEASE()		(M0P_GPIO->PBIN&KEY1)
	
	#define	KEY2_PRESS()		((M0P_GPIO->PBIN&KEY2)==0)
	#define	KEY2_RELEASE()		(M0P_GPIO->PBIN&KEY2)

	#define	KEY3_PRESS()		((M0P_GPIO->PBIN&KEY3)==0)
	#define	KEY3_RELEASE()		(M0P_GPIO->PBIN&KEY3)

	#define	KEY4_PRESS()		((M0P_GPIO->PBIN&KEY4)==0)
	#define	KEY4_RELEASE()		(M0P_GPIO->PBIN&KEY4)

	#define	KEY5_PRESS()		((M0P_GPIO->PBIN&KEY5)==0)
	#define	KEY5_RELEASE()		(M0P_GPIO->PBIN&KEY5)
	
	#define KEY5_PORT			GpioPortB
	#define	KEY4_PORT			GpioPortB
	#define	KEY3_PORT			GpioPortB
	#define	KEY2_PORT			GpioPortB	
	#define	KEY1_PORT			GpioPortB		

	#define	KEY5_PIN			GpioPin3
	#define	KEY4_PIN			GpioPin4
	#define	KEY3_PIN			GpioPin5
	#define	KEY2_PIN			GpioPin8
	#define	KEY1_PIN			GpioPin9
	
	#define	KEY_IRQn			PORTB_IRQn	
	
	//=======================Radio Interface=====================
	#define	RF_GPIO0_H()		(M0P_GPIO->PBIN&RF_GPIO0)
	#define	RF_GPIO0_L()		((M0P_GPIO->PBIN&RF_GPIO0)==0)
	
	#define	RF_GPIO1_H()		(M0P_GPIO->PBIN&RF_GPIO1)
	#define	RF_GPIO1_L()		((M0P_GPIO->PBIN&RF_GPIO1)==0)

	#define	RF_nIRQ_H()			(M0P_GPIO->PBIN&RF_nIRQ)
	#define	RF_nIRQ_L()			((M0P_GPIO->PBIN&RF_nIRQ)==0)

	#define	RF_GPIO4_H()		(M0P_GPIO->PCIN&RF_GPIO4)
	#define	RF_GPIO4_L()		((M0P_GPIO->PCIN&RF_GPIO4)==0)

	#define	RF_GPIO5_H()		(M0P_GPIO->PCIN&RF_GPIO4)
	#define	RF_GPIO5_L()		((M0P_GPIO->PCIN&RF_GPIO4)==0)


	#define RF_GPIO4_Output()	(M0P_GPIO->PCDIR &= (~RF_GPIO4))
	#define	RF_GPIO4_Input()  	(M0P_GPIO->PCDIR |= RF_GPIO4)

	#define RF_nIRQ_Output()	(M0P_GPIO->PBDIR &= (~RF_nIRQ))
	#define	RF_nIRQ_Input()  	(M0P_GPIO->PBDIR |= RF_nIRQ)

	#define	RF_TX_DAT_H()		(M0P_GPIO->PBOUT |= RF_nIRQ)  
	#define	RF_TX_DAT_L()		(M0P_GPIO->PBOUT &= (~RF_nIRQ))
	
	#define	RF_DCLK_H()			RF_GPIO1_H()
	#define	RF_DCLK_L()			RF_GPIO1_L()
		
	#define	RF_DATA_H()			RF_GPIO0_H()
	#define	RF_DATA_L()			RF_GPIO0_L()

/******************************************************************************/
//����
/******************************************************************************/
extern word 	systimer;
extern word 	keytimer;
extern byte 	lptimer;

extern byte     radio_tx_msg[UHF_LEN];
extern byte 	radio_tx_buf[250];
extern word 	g_tx_count;

extern byte 	uart_tx_buf[UART_TXD_LEN];
extern byte 	uart_rx_buf[UART_RXD_LEN];
extern word 	uart_tx_ind;
extern word 	uart_rx_ind;
extern word		uart_tx_length;


//radio.c
extern	CMT2310A_CFG	g_radio;

/******************************************************************************/
//����
/******************************************************************************/
//Main.c
extern byte bKeyScan(void);
extern void vGetRandomTxBuf(void);
extern void vBeep(void);
extern word wRadioAssmblePacket(byte *src_ptr, byte length, byte *dest_ptr);
extern void vRadioDirectSendPacket(byte *tx_buf, word pkt_len);
extern boolean_t bRadioDirectRecvCatchSync(void);
extern boolean_t bRadioDirectRecvPacket(byte *ptr, word length);

//Misc.c
extern void vMcuInit(void);
extern void vIOInit(void);

extern en_result_t vMcuClockInit(void);
extern en_result_t vMcuSwitchRCH(void);
extern en_result_t vMcuSwitchXtalH(void);
extern en_result_t vMcuSwitchPLL(void);

extern void vEnableTrngSrc(void);
extern void vDisableTrngSrc(void);
extern void vTrngGenerate(byte cnt, byte xor_en, byte t_rng);
extern void vUart0Cfg(void);
extern void vUart0SendString(byte *ptr);
extern void vUart0SendHex(byte *ptr, word len);
extern void vUart0SendRecvPayload(byte *ptr, word len);
extern void vUart0SendCounter(word cnt);
extern void vUart0NewLine(void);
extern byte bHex2Ascii(byte ch);

//timer.c
extern void vBaseTime0Init(uint16_t u16Period);
extern void vBaseTime1Init(uint16_t u16Period);
extern void vDelayNms(byte dly);
extern void vDelayNus(byte dly);

//interrupt.c
extern void TIM0_IRQHandler(void);
extern void PORTD_IRQHandler(void);
extern void LPTIM_IRQHandler(void);
extern void EnableNvic(IRQn_Type enIrq, en_irq_level_t enLevel, boolean_t bEn);


//lptimer.c
extern void vLpTimerInit(void);

//lcd.c
extern void vSendCmd(byte dat);
extern void vSendDBCmd(byte cmd,byte value);
extern void vSendData(byte dat);
extern void vBurstSendData(byte const ptr[], byte length);
extern void vLcdLight(byte on);
extern void vLcdInit(void);
extern void vLcdEnable(void);
extern void vLcdDisable(void) ;
extern void vLcdLocate(byte page, byte column);
extern void vLcdClearScreen(void);
extern void vLcdFullDisplay(byte on_off);

extern void vLcdPrintCapital(byte line, byte col, byte ind);
extern void vLcdPrintLowercase(byte line, byte col, byte ind);
extern void vLcdPrintNumber(byte line, byte col, byte ind);
extern void vLcdPrintOther(byte line, byte col, byte ind);
extern void vLcdDrawDoubleLine(byte line);
extern void vLcdPrintString(byte line, const byte ch[]);
extern void vLcdPrintTRxString(void);
extern void vLcdPrintCounter(byte line, byte num, word counter);
extern void vLcdClearCounter(byte line, byte num, byte cnt);


#endif
