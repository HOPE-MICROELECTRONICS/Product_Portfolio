

#ifndef __RADIO_H

	#define 	__RADIO_H
	
	#include "ddl.h"
	#include "radio_phy.h"
	#include "radio_mac.h"
	#include "CMT2310A_def.h"
	#include "CMT2310A_reg.h"	
	

	extern const unsigned char g_cmt2310a_page0[CMT2310A_PAGE0_SIZE];
	extern const unsigned char g_cmt2310a_page1[CMT2310A_PAGE1_SIZE];
	extern const unsigned char g_cmt2310a_page2[CMT2310A_PAGE2_SIZE];	
	
	extern void vRadioInit(void);
	extern void vRadioClearInterrupt(void);
	extern void vRadioReadAllStatus(void);
	extern void vRadioCmpReg(byte const wr_ptr[], byte rd_ptr[], byte cmp_ptr[], byte length);
	extern void vRadioGoTxInit(void);
	extern void vRadioGoRxInit(void);
	
	
#endif	




