#include "cmt2310a_eb.h"

//����ָ����ҪRS=0
#define		LCD_CMD_ON 			0xAF
#define		LCD_CMD_OFF			0xAE

#define		LCD_LINE_SET		0x40		//0x40|line, line��Χ��0x00-0x3F, ����0-63��

#define		LCD_ADDR_SET		0xB0		//0xB0|addr, addr��Χ��0xB0-0xB8, һ��1-9ҳ

#define		LCD_COL_H_SET		0x10		//0x10|col_h, col_h��Χ���е�ַ��4λ
#define		LCD_COL_L_SET		0x00		//0x00|col_l, col_l��Χ���е�ַ��4λ�����磺100�У���0x64����Ҫ��� col_h=0x06, col_l=0x04

#define		LCD_CMD_ADC_L2R		0xA0		//��ʾ�е�ַ����ߵ���
#define		LCD_CMD_ADC_R2L		0xA1		//��ʾ�е�ַ���ұߵ���

#define		LCD_CMD_DISP_NOR	0xA6		//��ʾΪ����ʾ
#define		LCD_CMD_DISP_INV	0xA7		//��ʾΪ����ʾ

#define		LCD_CMD_FULL_ON		0xA5		//����������ʾ
#define		LCD_CMD_FULL_OFF	0xA4		//������ʾ

#define		LCD_CMD_BIAS_1_9	0xA2		//ƫѹ��Ϊ1/9
#define		LCD_CMD_BIAS_1_7	0xA3		//ƫѹ��Ϊ1/7

#define		LCD_CMD_RESET		0xE2		//��λ

#define		LCD_COM_UP2DOWN		0xC0		//��ɨ��˳��Ϊ�ϵ���
#define		LCD_COM_DOWN2UP		0xC8		//��ɨ��˳��Ϊ�µ���

#define		LCD_RES_ADJ_SEL		0x20		//0x20|res, res��Χ��0-7�� ֵԽ��ԽŨ��ֵԽС��Խ��

#define		LCD_VOL_ADJ_SEL		0x81		//0x81 + val, �����ֽ�ָ�val��Χ��0-63, ֵԽ��ԽŨ��ֵԽС��Խ��

#define		LCD_STATIC_ON		0xAD		//��̬ͼ�꿪������ָ���ڽ��뼰�˳�˯��ģʽʱ������
#define		LCD_STATIC_OFF		0xAC		//��̬ͼ��رգ���ָ���ڽ��뼰�˳�˯��ģʽʱ������

#define		LCD_CMD_NOP			0xE3

byte const g_ascii_number_7x8[10][7] = {
	      {0x00, 0x3e, 0x51, 0x49, 0x45, 0x3e, 0x00}, //-0-
	      {0x00, 0x00, 0x42, 0x7f, 0x40, 0x00, 0x00}, //-1-
	      {0x00, 0x42, 0x61, 0x51, 0x49, 0x46, 0x00}, //-2-
	      {0x00, 0x21, 0x41, 0x45, 0x4b, 0x31, 0x00}, //-3-
	      {0x00, 0x18, 0x14, 0x12, 0x7f, 0x10, 0x00}, //-4-
	      {0x00, 0x27, 0x45, 0x45, 0x45, 0x39, 0x00}, //-5-
	      {0x00, 0x3c, 0x4a, 0x49, 0x49, 0x30, 0x00}, //-6-
	      {0x00, 0x01, 0x71, 0x09, 0x05, 0x03, 0x00}, //-7-
	      {0x00, 0x36, 0x49, 0x49, 0x49, 0x36, 0x00}, //-8-
	      {0x00, 0x06, 0x49, 0x49, 0x29, 0x1e, 0x00}, //-9-
                                       };

byte const g_ascii_capital_7x8[26][7] = {
    	  {0x00, 0x7e, 0x11, 0x11, 0x11, 0x7e, 0x00}, //-A-
		  {0x00, 0x7f, 0x49, 0x49, 0x49, 0x36, 0x00}, //-B-
		  {0x00, 0x3e, 0x41, 0x41, 0x41, 0x22, 0x00}, //-C-
		  {0x00, 0x7f, 0x41, 0x41, 0x22, 0x1c, 0x00}, //-D-
		  {0x00, 0x7f, 0x49, 0x49, 0x49, 0x41, 0x00}, //-E-
		  {0x00, 0x7f, 0x09, 0x09, 0x09, 0x01, 0x00}, //-F-
		  {0x00, 0x3e, 0x41, 0x49, 0x49, 0x7a, 0x00}, //-G-
		  {0x00, 0x7f, 0x08, 0x08, 0x08, 0x7f, 0x00}, //-H-
		  {0x00, 0x00, 0x41, 0x7f, 0x41, 0x00, 0x00}, //-I-
		  {0x00, 0x20, 0x40, 0x41, 0x3f, 0x01, 0x00}, //-J-
		  {0x00, 0x7f, 0x08, 0x14, 0x22, 0x41, 0x00}, //-K-
		  {0x00, 0x7f, 0x40, 0x40, 0x40, 0x40, 0x00}, //-L-
		  {0x00, 0x7f, 0x02, 0x0c, 0x02, 0x7f, 0x00}, //-M-
		  {0x00, 0x7f, 0x04, 0x08, 0x10, 0x7f, 0x00}, //-N-
		  {0x00, 0x3e, 0x41, 0x41, 0x41, 0x3e, 0x00}, //-O-
		  {0x00, 0x7f, 0x09, 0x09, 0x09, 0x06, 0x00}, //-P-
		  {0x00, 0x3e, 0x41, 0x51, 0x21, 0x5e, 0x00}, //-Q-
		  {0x00, 0x7f, 0x09, 0x19, 0x29, 0x46, 0x00}, //-R-
		  {0x00, 0x46, 0x49, 0x49, 0x49, 0x31, 0x00}, //-S-
		  {0x00, 0x01, 0x01, 0x7f, 0x01, 0x01, 0x00}, //-T-
		  {0x00, 0x3f, 0x40, 0x40, 0x40, 0x3f, 0x00}, //-U-
		  {0x00, 0x1f, 0x20, 0x40, 0x20, 0x1f, 0x00}, //-V-
		  {0x00, 0x3f, 0x40, 0x38, 0x40, 0x3f, 0x00}, //-W-
		  {0x00, 0x63, 0x14, 0x08, 0x14, 0x63, 0x00}, //-X-
		  {0x00, 0x07, 0x08, 0x70, 0x08, 0x07, 0x00}, //-Y-
		  {0x00, 0x61, 0x51, 0x49, 0x45, 0x43, 0x00}, //-Z-                                   
                                        };									   
									   
byte const g_ascii_lowercase_7x8[26][7] = {
	      {0x00, 0x20, 0x54, 0x54, 0x54, 0x78, 0x00}, //-a-
	      {0x00, 0x7f, 0x48, 0x48, 0x48, 0x30, 0x00}, //-b-
	      {0x00, 0x38, 0x44, 0x44, 0x44, 0x44, 0x00}, //-c-
	      {0x00, 0x30, 0x48, 0x48, 0x48, 0x7f, 0x00}, //-d-
	      {0x00, 0x38, 0x54, 0x54, 0x54, 0x58, 0x00}, //-e-
	      {0x00, 0x00, 0x08, 0x7e, 0x09, 0x02, 0x00}, //-f-
	      {0x00, 0x48, 0x54, 0x54, 0x54, 0x3c, 0x00}, //-g-
	      {0x00, 0x7f, 0x08, 0x08, 0x08, 0x70, 0x00}, //-h-
	      {0x00, 0x00, 0x00, 0x7a, 0x00, 0x00, 0x00}, //-i-
	      {0x00, 0x20, 0x40, 0x40, 0x3d, 0x00, 0x00}, //-j-
	      {0x00, 0x7f, 0x20, 0x28, 0x44, 0x00, 0x00}, //-k-
	      {0x00, 0x00, 0x41, 0x7f, 0x40, 0x00, 0x00}, //-l-
	      {0x00, 0x7c, 0x04, 0x38, 0x04, 0x7c, 0x00}, //-m-
	      {0x00, 0x7c, 0x08, 0x04, 0x04, 0x78, 0x00}, //-n-
	      {0x00, 0x38, 0x44, 0x44, 0x44, 0x38, 0x00}, //-o-
	      {0x00, 0x7c, 0x14, 0x14, 0x14, 0x08, 0x00}, //-p-
	      {0x00, 0x08, 0x14, 0x14, 0x14, 0x7c, 0x00}, //-q-
	      {0x00, 0x7c, 0x08, 0x04, 0x04, 0x08, 0x00}, //-r-
	      {0x00, 0x48, 0x54, 0x54, 0x54, 0x24, 0x00}, //-s-
	      {0x00, 0x04, 0x04, 0x3f, 0x44, 0x24, 0x00}, //-t-
	      {0x00, 0x3c, 0x40, 0x40, 0x40, 0x3c, 0x00}, //-u-
	      {0x00, 0x1c, 0x20, 0x40, 0x20, 0x1c, 0x00}, //-v-
	      {0x00, 0x3c, 0x40, 0x30, 0x40, 0x3c, 0x00}, //-w-
	      {0x00, 0x44, 0x28, 0x10, 0x28, 0x44, 0x00}, //-x-
	      {0x00, 0x04, 0x48, 0x30, 0x08, 0x04, 0x00}, //-y-
	      {0x00, 0x44, 0x64, 0x54, 0x4c, 0x44, 0x00}, //-z-	
                                        };

byte const g_ascii_other_7x8[33][7] = {
	      {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, //space  -0
	      {0x00, 0x00, 0x00, 0x4f, 0x00, 0x00, 0x00}, //-!-    -1 
	      {0x00, 0x00, 0x07, 0x00, 0x07, 0x00, 0x00}, //-"-    -2
	      {0x00, 0x14, 0x7f, 0x14, 0x7f, 0x14, 0x00}, //-#-    -3
	      {0x00, 0x24, 0x2a, 0x7f, 0x2a, 0x12, 0x00}, //-$-    -4
	      {0x00, 0x23, 0x13, 0x08, 0x64, 0x62, 0x00}, //-%-    -5
	      {0x00, 0x36, 0x49, 0x55, 0x22, 0x50, 0x00}, //-&-    -6
	      {0x00, 0x00, 0x05, 0x07, 0x00, 0x00, 0x00}, //-'-    -7
	      {0x00, 0x00, 0x1c, 0x22, 0x41, 0x00, 0x00}, //-(-    -8
	      {0x00, 0x00, 0x41, 0x22, 0x1c, 0x00, 0x00}, //-)-    -9
	      {0x00, 0x14, 0x08, 0x3e, 0x08, 0x14, 0x00}, //-*-    -10
	      {0x00, 0x08, 0x08, 0x3e, 0x08, 0x08, 0x00}, //-+-    -11
	      {0x00, 0x00, 0x50, 0x30, 0x00, 0x00, 0x00}, //-,-    -12
	      {0x00, 0x08, 0x08, 0x08, 0x08, 0x08, 0x00}, //---    -13
	      {0x00, 0x00, 0x60, 0x60, 0x00, 0x00, 0x00}, //-.-    -14
	      {0x00, 0x20, 0x10, 0x08, 0x04, 0x02, 0x00}, //-/-    -15
	      {0x00, 0x00, 0x36, 0x36, 0x00, 0x00, 0x00}, //-:-    -16
	      {0x00, 0x00, 0x56, 0x36, 0x00, 0x00, 0x00}, //-;-    -17
	      {0x00, 0x08, 0x14, 0x22, 0x41, 0x00, 0x00}, //-<-    -18
	      {0x00, 0x14, 0x14, 0x14, 0x14, 0x14, 0x00}, //-=-    -19
	      {0x00, 0x00, 0x41, 0x22, 0x14, 0x08, 0x00}, //->-    -20
	      {0x00, 0x02, 0x01, 0x51, 0x09, 0x06, 0x00}, //-?-    -21
	      {0x00, 0x32, 0x49, 0x79, 0x41, 0x3e, 0x00}, //-@-    -22
	      {0x00, 0x00, 0x7f, 0x41, 0x41, 0x00, 0x00}, //-[-    -23
	      {0x00, 0x02, 0x04, 0x08, 0x10, 0x20, 0x00}, //-\-    -24
	      {0x00, 0x00, 0x41, 0x41, 0x7f, 0x00, 0x00}, //-]-    -25
	      {0x00, 0x04, 0x02, 0x01, 0x02, 0x04, 0x00}, //-^-    -26
	      {0x00, 0x40, 0x40, 0x40, 0x40, 0x40, 0x00}, //-_-    -27
	      {0x00, 0x01, 0x02, 0x04, 0x00, 0x00, 0x00}, //-`-    -28
	      {0x00, 0x08, 0x36, 0x41, 0x41, 0x00, 0x00}, //-{-    -29
	      {0x00, 0x00, 0x00, 0x77, 0x00, 0x00, 0x00}, //-|-    -30
	      {0x00, 0x00, 0x41, 0x41, 0x36, 0x08, 0x00}, //-}-    -31
	      {0x00, 0x04, 0x02, 0x02, 0x02, 0x01}, //-~-    -32
                                        };   


/**********************************************************
**Name:     vSendCmd
**Function: send command to JLX12864
**Input:    dat for command value (8bits)
**Output:   none
**********************************************************/
void vSendCmd(byte dat) 
{ 
 	byte i;	
 	
 	LCD_SDA_Output();
 	CLR_LCD_SCK();
 	
 	CLR_LCD_CS();
 	CLR_LCD_RS();
 	
 	for(i=0; i<8; i++)
 		{
 		if(dat&0x80)
 			SET_LCD_SDA();
 		else
 			CLR_LCD_SDA();
	 	SET_LCD_SCK();
 		dat <<= 1;
 		CLR_LCD_SCK();
 		}
	
 	SET_LCD_RS();
 	SET_LCD_CS();
 	SET_LCD_SDA();
} 

/**********************************************************
**Name:     vSendDBCmd
**Function: send double byte command to JLX12864
**Input:    cmd & value == 16bits command
**Output:   none
**********************************************************/
void vSendDBCmd(byte cmd,byte value) 
{
	byte i;	
	word dat;
	
	dat = (((word)cmd<<8)|value);
 	
 	LCD_SDA_Output();
 	CLR_LCD_SCK();
 	
 	CLR_LCD_CS();
 	CLR_LCD_RS();
 	
 	for(i=0; i<16; i++)
 		{

 		if(dat&0x8000)
			SET_LCD_SDA();
 		else
 			CLR_LCD_SDA();
 		SET_LCD_SCK();
 		dat <<= 1;
  		CLR_LCD_SCK();
 		}
 	SET_LCD_RS();
 	SET_LCD_CS();
 	SET_LCD_SDA();
}

/**********************************************************
**Name:     vSendData
**Function: send data to JLX12864
**Input:    dat
**Output:   none
**********************************************************/
void vSendData(byte dat)
{
 	byte i;

 	LCD_SDA_Output();
	CLR_LCD_SCK();

 	SET_LCD_RS();	
 	CLR_LCD_CS();
	
	for(i=0; i<8; i++)
 		{
 		if(dat&0x80)
 			SET_LCD_SDA();
 		else
 			CLR_LCD_SDA();
		SET_LCD_SCK();
 		dat <<= 1;
  		CLR_LCD_SCK();
 		}
	SET_LCD_SDA();
}	

/**********************************************************
**Name:     vBurstSendData
**Function: continuous send data to JLX12864
**Input:    ptr & length
**Output:   none
**********************************************************/ 
void vBurstSendData(byte const ptr[], byte length)
{
	byte i, j;	
 	byte dat;
 	
 	if(length!=0)
 		{
 		LCD_SDA_Output();
		CLR_LCD_SCK();
 		
		SET_LCD_RS();			
		CLR_LCD_CS();
		
		for(j=0; j<length; j++)
			{
			dat = ptr[j];
 			for(i=0; i<8; i++)
 				{
				if(dat&0x80)
 					SET_LCD_SDA();
 				else
					CLR_LCD_SDA();
 				SET_LCD_SCK();
 				dat <<= 1;
				CLR_LCD_SCK();
 				}
 			}	
 		SET_LCD_CS();			//not need, for burst write mode
 		SET_LCD_SDA();
		}
}

/**********************************************************
**Name:     vLcdLight
**Function: turn on led for LED background
**Input:    on or off
**Output:   none
**********************************************************/ 
void vLcdLight(byte on)
{
	if(on)
		SET_LEDA();
	else
		CLR_LEDA();
}


/**********************************************************
**Name:     vLcdInit
**Function: Init. for JLX12864
**Input:    none
**Output:   none
**********************************************************/ 
void vLcdInit(void) 
{ 	
	CLR_LCD_RST();						//Hardware Reset
 	vDelayNus(100);
 	SET_LCD_RST();
 	vDelayNms(20);
 	vSendCmd(LCD_CMD_RESET);			//SoftReset
 	vDelayNms(5);

 	vSendCmd(0x2C);						//Set Power Control 3step or only set 0x2F
 	vDelayNus(20);
 	vSendCmd(0x2E);
 	vDelayNus(20);
 	vSendCmd(0x2F);
 	vDelayNus(20);

 	vSendCmd(LCD_RES_ADJ_SEL|0x06);		//Set Vlcd Resistor Ratio, range for 0x20~0x27
 	vSendDBCmd(LCD_VOL_ADJ_SEL, 5);		//Set Electronic volume, range for 0x00~0x3F
 	vSendCmd(LCD_CMD_BIAS_1_9);			//1/9 bias
 	vSendCmd(LCD_COM_DOWN2UP);			//Set COM Direction, from top to button
 	vSendCmd(LCD_CMD_ADC_L2R);			//Set SEG Direction, from left to right
	vSendCmd(LCD_CMD_DISP_NOR);
	vSendCmd(LCD_CMD_FULL_OFF);
	vSendCmd(LCD_LINE_SET|0);			//Set Scroll Line, for No.1 Line
 	vLcdEnable();						//Set Display enable, for 0xAE Disable
}	

/**********************************************************
**Name:     vLcdEnable
**Function: turn on LCD
**Input:    none
**Output:   none
**********************************************************/  
void vLcdEnable(void) 
{
 	vSendCmd(LCD_CMD_ON);
}

/**********************************************************
**Name:     vLcdDisable
**Function: turn off LCD
**Input:    none
**Output:   none
**********************************************************/   
void vLcdDisable(void)  
{
	vSendCmd(LCD_CMD_OFF);
}

/**********************************************************
**Name:     vLcdLocate
**Function: locate address for picture array
**Input:    page, column
**Output:   none
**********************************************************/   
void vLcdLocate(byte page, byte column)
{
	page -= 1;
	column -= 1;									//begin from 0
 	vSendCmd(LCD_ADDR_SET+page);					//full screen have 64lines, 8 pages, every page have 8lines
 	vSendCmd(((column>>4)&0x0F)|LCD_COL_H_SET);		//set column address for MSB
 	vSendCmd((column&0x0f)|LCD_COL_L_SET);			//set column address for LSB
}

/**********************************************************
**Name:     vLcdClearScreen
**Function: clear screen
**Input:    none
**Output:   none
**********************************************************/   	
void vLcdClearScreen(void)
{
 	byte i, j;
 	for(i=1;i<9;i++)								
 		{
 		vLcdLocate(i, 1);
			
 		for(j=0;j<128;j++)
 			vSendData(0);
 		SET_LCD_CS();	
 		}
}

/**********************************************************
**Name:     vLcdFullDisplay
**Function: show full display
**Input:    none
**Output:   none
**********************************************************/ 
void vLcdFullDisplay(byte on_off)
{
	if(on_off)
		vSendCmd(LCD_CMD_FULL_ON);
	else
		vSendCmd(LCD_CMD_FULL_OFF);
}

/**********************************************************
**Name:     vLcdPrintCapital
**Function: ��ӡ��д��ĸ
**Input:    line = 1-8ҳ������Ӧ����1-8��
**          col  = ��7x8�ַ�����ÿ�зֳ�18��������
**          cap  = ��ĸ���
**Output:   none
**********************************************************/ 
void vLcdPrintCapital(byte line, byte col, byte ind)			//ָ��λ�ô�ӡһ����д�ַ�             //ÿ���ַ���ʱ0.25ms
{
	col  = (col*7+1);
	vLcdLocate(line, col);					
	vBurstSendData(g_ascii_capital_7x8[ind], 7);
}

void vLcdPrintLowercase(byte line, byte col, byte ind)			//ָ��λ�ô�ӡһ��Сд�ַ� 
{
	col  = (col*7+1);
	vLcdLocate(line, col);					
	vBurstSendData(g_ascii_lowercase_7x8[ind], 7);
}

void vLcdPrintNumber(byte line, byte col, byte ind)				//ָ��λ�ô�ӡһ������������
{
	col  = (col*7+1);
	vLcdLocate(line, col);					
	vBurstSendData(g_ascii_number_7x8[ind], 7);
}

void vLcdPrintOther(byte line, byte col, byte ind)				//ָ��λ�ô�ӡһ���ض��ַ�
{
	col  = (col*7+1);
	vLcdLocate(line, col);					
	vBurstSendData(g_ascii_other_7x8[ind], 7);
}

void vLcdDrawDoubleLine(byte line)								//ָ���л�һ��˫����
{
	byte i;
	vLcdLocate(line, 1);
	for(i=0; i<128; i++)	
		vSendData(0x14);
	SET_LCD_CS();
}	

void vLcdPrintString(byte line, const byte ch[])				//ָ���д�ӡһ���ַ�����ע��ÿ��֧��18���ַ�
{
	byte i;	
	byte cht;
 
	for(i=0; ch[i]!='\0'; i++)
		{
		cht = ch[i]; 	
		if((cht>='a')&&(cht<='z'))
			vLcdPrintLowercase(line, i, (cht-'a'));
		else if((cht>='A')&&(cht<='Z'))
			vLcdPrintCapital(line, i, (cht-'A'));
		else if((cht>='0')&&(cht<='9'))
			vLcdPrintNumber(line, i, (cht-'0'));
		else
			{}
		}
}

void vLcdPrintTRxString(void)
{
	vLcdPrintCapital(7, 0, ('T'-'A'));
	vLcdPrintLowercase(7, 1, ('x'-'a'));
	vLcdPrintOther(7, 2, 16);					//':'

	vLcdPrintCapital(8, 0, ('R'-'A'));
	vLcdPrintLowercase(8, 1, ('x'-'a'));
	vLcdPrintOther(8, 2, 16);					//':'

	vLcdPrintLowercase(8, 15, ('d'-'a'));
	vLcdPrintCapital(8, 16, ('B'-'A'));
	vLcdPrintLowercase(8, 17, ('m'-'a'));		//':'
}	

void vLcdPrintCounter(byte line, byte num, word counter)
{
	byte i;
	word j;
	
	for(j=10000; j!=0; j/=10)
		{
		i = counter/j;
		counter %= j;
		vLcdPrintNumber(line, num++, i);
		}
}	

void vLcdClearCounter(byte line, byte num, byte cnt)
{
	byte i;
	
	for(i=0; i<cnt; i++)
		vLcdPrintOther(line, num++, 0);
}



