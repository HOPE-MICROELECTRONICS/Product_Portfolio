.\objects\radio.o: Source\radio.c
.\objects\radio.o: Source\radio.h
.\objects\radio.o: .\Driver\inc\ddl.h
.\objects\radio.o: .\Common\base_types.h
.\objects\radio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\radio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\radio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\radio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\radio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\radio.o: .\Common\board_stkhc32l13x.h
.\objects\radio.o: .\Common\hc32l13x.h
.\objects\radio.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\radio.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\radio.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\radio.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\radio.o: .\Common\system_hc32l13x.h
.\objects\radio.o: .\Driver\inc\sysctrl.h
.\objects\radio.o: .\Driver\inc\ddl.h
.\objects\radio.o: .\Common\interrupts_hc32l13x.h
.\objects\radio.o: .\Source\ddl_device.h
.\objects\radio.o: .\Radio\radio_phy.h
.\objects\radio.o: .\Radio\radio_hal.h
.\objects\radio.o: .\Radio\radio_spi.h
.\objects\radio.o: .\Driver\inc\spi.h
.\objects\radio.o: .\Radio\CMT2310A_def.h
.\objects\radio.o: .\Radio\CMT2310A_reg.h
.\objects\radio.o: .\Radio\radio_mac.h
