.\objects\sysctrl.o: Driver\src\sysctrl.c
.\objects\sysctrl.o: .\Driver\inc\sysctrl.h
.\objects\sysctrl.o: .\Driver\inc\ddl.h
.\objects\sysctrl.o: .\Common\base_types.h
.\objects\sysctrl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\sysctrl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\sysctrl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\sysctrl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\sysctrl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\sysctrl.o: .\Common\board_stkhc32l13x.h
.\objects\sysctrl.o: .\Common\hc32l13x.h
.\objects\sysctrl.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\sysctrl.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\sysctrl.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\sysctrl.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\sysctrl.o: .\Common\system_hc32l13x.h
.\objects\sysctrl.o: .\Driver\inc\sysctrl.h
.\objects\sysctrl.o: .\Common\interrupts_hc32l13x.h
.\objects\sysctrl.o: .\Driver\inc\ddl.h
.\objects\sysctrl.o: .\Source\ddl_device.h
