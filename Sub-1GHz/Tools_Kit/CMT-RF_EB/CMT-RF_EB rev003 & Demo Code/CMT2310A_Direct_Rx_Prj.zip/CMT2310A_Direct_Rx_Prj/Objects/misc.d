.\objects\misc.o: Source\misc.c
.\objects\misc.o: Source\cmt2310a_eb.h
.\objects\misc.o: .\Common\base_types.h
.\objects\misc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\misc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\misc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\misc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\misc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\misc.o: .\Driver\inc\adt.h
.\objects\misc.o: .\Driver\inc\ddl.h
.\objects\misc.o: .\Common\board_stkhc32l13x.h
.\objects\misc.o: .\Common\hc32l13x.h
.\objects\misc.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\misc.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\misc.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\misc.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\misc.o: .\Common\system_hc32l13x.h
.\objects\misc.o: .\Driver\inc\sysctrl.h
.\objects\misc.o: .\Driver\inc\ddl.h
.\objects\misc.o: .\Common\interrupts_hc32l13x.h
.\objects\misc.o: .\Source\ddl_device.h
.\objects\misc.o: .\Driver\inc\aes.h
.\objects\misc.o: .\Driver\inc\bt.h
.\objects\misc.o: .\Driver\inc\crc.h
.\objects\misc.o: .\Driver\inc\flash.h
.\objects\misc.o: .\Driver\inc\gpio.h
.\objects\misc.o: .\Driver\inc\lpm.h
.\objects\misc.o: .\Driver\inc\lptim.h
.\objects\misc.o: .\Driver\inc\trng.h
.\objects\misc.o: .\Driver\inc\uart.h
.\objects\misc.o: Source\radio.h
.\objects\misc.o: .\Radio\radio_phy.h
.\objects\misc.o: .\Radio\radio_hal.h
.\objects\misc.o: .\Radio\radio_spi.h
.\objects\misc.o: .\Driver\inc\spi.h
.\objects\misc.o: .\Radio\CMT2310A_def.h
.\objects\misc.o: .\Radio\CMT2310A_reg.h
.\objects\misc.o: .\Radio\radio_mac.h
