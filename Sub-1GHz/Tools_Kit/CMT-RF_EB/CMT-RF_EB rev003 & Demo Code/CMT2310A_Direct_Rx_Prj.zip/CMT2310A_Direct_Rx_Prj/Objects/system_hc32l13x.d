.\objects\system_hc32l13x.o: Common\system_hc32l13x.c
.\objects\system_hc32l13x.o: Common\base_types.h
.\objects\system_hc32l13x.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\system_hc32l13x.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\system_hc32l13x.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\system_hc32l13x.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\system_hc32l13x.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\system_hc32l13x.o: Common\hc32l13x.h
.\objects\system_hc32l13x.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\system_hc32l13x.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\system_hc32l13x.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\system_hc32l13x.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\system_hc32l13x.o: Common\system_hc32l13x.h
.\objects\system_hc32l13x.o: .\Driver\inc\sysctrl.h
.\objects\system_hc32l13x.o: .\Driver\inc\ddl.h
.\objects\system_hc32l13x.o: .\Common\board_stkhc32l13x.h
.\objects\system_hc32l13x.o: .\Driver\inc\sysctrl.h
.\objects\system_hc32l13x.o: .\Common\interrupts_hc32l13x.h
.\objects\system_hc32l13x.o: .\Driver\inc\ddl.h
.\objects\system_hc32l13x.o: .\Source\ddl_device.h
