.\objects\trng.o: Driver\src\trng.c
.\objects\trng.o: .\Driver\inc\trng.h
.\objects\trng.o: .\Driver\inc\ddl.h
.\objects\trng.o: .\Common\base_types.h
.\objects\trng.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\trng.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\trng.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\trng.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\trng.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\trng.o: .\Common\board_stkhc32l13x.h
.\objects\trng.o: .\Common\hc32l13x.h
.\objects\trng.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\trng.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\trng.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\trng.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\trng.o: .\Common\system_hc32l13x.h
.\objects\trng.o: .\Driver\inc\sysctrl.h
.\objects\trng.o: .\Driver\inc\ddl.h
.\objects\trng.o: .\Common\interrupts_hc32l13x.h
.\objects\trng.o: .\Source\ddl_device.h
