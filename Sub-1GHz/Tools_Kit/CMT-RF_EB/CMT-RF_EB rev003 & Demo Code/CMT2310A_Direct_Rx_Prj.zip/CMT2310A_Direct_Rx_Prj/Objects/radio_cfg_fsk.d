.\objects\radio_cfg_fsk.o: Source\radio_cfg_fsk.c
.\objects\radio_cfg_fsk.o: .\Radio\CMT2310A_reg.h
.\objects\radio_cfg_fsk.o: .\Radio\CMT2310A_def.h
