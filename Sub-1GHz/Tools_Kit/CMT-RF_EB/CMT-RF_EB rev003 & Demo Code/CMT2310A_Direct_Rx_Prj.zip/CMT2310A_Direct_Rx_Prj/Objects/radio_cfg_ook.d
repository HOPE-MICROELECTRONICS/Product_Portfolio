.\objects\radio_cfg_ook.o: Source\radio_cfg_ook.c
.\objects\radio_cfg_ook.o: .\Radio\CMT2310A_reg.h
.\objects\radio_cfg_ook.o: .\Radio\CMT2310A_def.h
