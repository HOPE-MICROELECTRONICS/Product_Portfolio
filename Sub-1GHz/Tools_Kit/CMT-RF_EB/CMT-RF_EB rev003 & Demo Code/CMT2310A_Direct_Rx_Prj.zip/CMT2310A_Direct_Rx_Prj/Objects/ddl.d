.\objects\ddl.o: Driver\src\ddl.c
.\objects\ddl.o: .\Driver\inc\ddl.h
.\objects\ddl.o: .\Common\base_types.h
.\objects\ddl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\ddl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\ddl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\ddl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\ddl.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\ddl.o: .\Common\board_stkhc32l13x.h
.\objects\ddl.o: .\Common\hc32l13x.h
.\objects\ddl.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\ddl.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\ddl.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\ddl.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\ddl.o: .\Common\system_hc32l13x.h
.\objects\ddl.o: .\Driver\inc\sysctrl.h
.\objects\ddl.o: .\Driver\inc\ddl.h
.\objects\ddl.o: .\Common\interrupts_hc32l13x.h
.\objects\ddl.o: .\Source\ddl_device.h
