.\objects\radio_cfg.o: Source\radio_cfg.c
.\objects\radio_cfg.o: .\Radio\CMT2310A_reg.h
.\objects\radio_cfg.o: .\Radio\CMT2310A_def.h
