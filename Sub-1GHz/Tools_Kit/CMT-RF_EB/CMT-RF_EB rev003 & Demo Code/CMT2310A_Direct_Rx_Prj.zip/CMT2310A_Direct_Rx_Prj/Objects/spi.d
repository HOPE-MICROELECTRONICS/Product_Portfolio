.\objects\spi.o: Driver\src\spi.c
.\objects\spi.o: .\Driver\inc\spi.h
.\objects\spi.o: .\Driver\inc\ddl.h
.\objects\spi.o: .\Common\base_types.h
.\objects\spi.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\spi.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\spi.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\spi.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\spi.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\spi.o: .\Common\board_stkhc32l13x.h
.\objects\spi.o: .\Common\hc32l13x.h
.\objects\spi.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\spi.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\spi.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\spi.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\spi.o: .\Common\system_hc32l13x.h
.\objects\spi.o: .\Driver\inc\sysctrl.h
.\objects\spi.o: .\Driver\inc\ddl.h
.\objects\spi.o: .\Common\interrupts_hc32l13x.h
.\objects\spi.o: .\Source\ddl_device.h
