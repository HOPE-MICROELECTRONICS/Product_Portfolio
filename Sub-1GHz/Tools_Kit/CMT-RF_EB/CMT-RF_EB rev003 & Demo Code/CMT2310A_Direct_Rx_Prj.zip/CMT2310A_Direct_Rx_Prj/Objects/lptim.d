.\objects\lptim.o: Driver\src\lptim.c
.\objects\lptim.o: .\Driver\inc\lptim.h
.\objects\lptim.o: .\Driver\inc\ddl.h
.\objects\lptim.o: .\Common\base_types.h
.\objects\lptim.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\lptim.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\lptim.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\lptim.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\lptim.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\lptim.o: .\Common\board_stkhc32l13x.h
.\objects\lptim.o: .\Common\hc32l13x.h
.\objects\lptim.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\lptim.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\lptim.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\lptim.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\lptim.o: .\Common\system_hc32l13x.h
.\objects\lptim.o: .\Driver\inc\sysctrl.h
.\objects\lptim.o: .\Driver\inc\ddl.h
.\objects\lptim.o: .\Common\interrupts_hc32l13x.h
.\objects\lptim.o: .\Source\ddl_device.h
