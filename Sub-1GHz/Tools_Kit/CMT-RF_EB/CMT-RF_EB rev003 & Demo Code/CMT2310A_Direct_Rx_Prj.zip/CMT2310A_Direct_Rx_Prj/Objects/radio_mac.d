.\objects\radio_mac.o: Radio\radio_mac.c
.\objects\radio_mac.o: Radio\radio_mac.h
.\objects\radio_mac.o: Radio\radio_hal.h
.\objects\radio_mac.o: .\Driver\inc\ddl.h
.\objects\radio_mac.o: .\Common\base_types.h
.\objects\radio_mac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\radio_mac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\radio_mac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\radio_mac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\radio_mac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\radio_mac.o: .\Common\board_stkhc32l13x.h
.\objects\radio_mac.o: .\Common\hc32l13x.h
.\objects\radio_mac.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\radio_mac.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\radio_mac.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\radio_mac.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\radio_mac.o: .\Common\system_hc32l13x.h
.\objects\radio_mac.o: .\Driver\inc\sysctrl.h
.\objects\radio_mac.o: .\Driver\inc\ddl.h
.\objects\radio_mac.o: .\Common\interrupts_hc32l13x.h
.\objects\radio_mac.o: .\Source\ddl_device.h
.\objects\radio_mac.o: Radio\radio_spi.h
.\objects\radio_mac.o: .\Driver\inc\spi.h
.\objects\radio_mac.o: Radio\CMT2310A_def.h
.\objects\radio_mac.o: Radio\CMT2310A_reg.h
