.\objects\gpio.o: Driver\src\gpio.c
.\objects\gpio.o: .\Driver\inc\gpio.h
.\objects\gpio.o: .\Driver\inc\ddl.h
.\objects\gpio.o: .\Common\base_types.h
.\objects\gpio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\gpio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\gpio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\gpio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\gpio.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\gpio.o: .\Common\board_stkhc32l13x.h
.\objects\gpio.o: .\Common\hc32l13x.h
.\objects\gpio.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\gpio.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\gpio.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\gpio.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\gpio.o: .\Common\system_hc32l13x.h
.\objects\gpio.o: .\Driver\inc\sysctrl.h
.\objects\gpio.o: .\Driver\inc\ddl.h
.\objects\gpio.o: .\Common\interrupts_hc32l13x.h
.\objects\gpio.o: .\Source\ddl_device.h
