.\objects\crc.o: Driver\src\crc.c
.\objects\crc.o: .\Driver\inc\crc.h
.\objects\crc.o: .\Driver\inc\ddl.h
.\objects\crc.o: .\Common\base_types.h
.\objects\crc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\crc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\crc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\crc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\crc.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\crc.o: .\Common\board_stkhc32l13x.h
.\objects\crc.o: .\Common\hc32l13x.h
.\objects\crc.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\crc.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\crc.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\crc.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\crc.o: .\Common\system_hc32l13x.h
.\objects\crc.o: .\Driver\inc\sysctrl.h
.\objects\crc.o: .\Driver\inc\ddl.h
.\objects\crc.o: .\Common\interrupts_hc32l13x.h
.\objects\crc.o: .\Source\ddl_device.h
