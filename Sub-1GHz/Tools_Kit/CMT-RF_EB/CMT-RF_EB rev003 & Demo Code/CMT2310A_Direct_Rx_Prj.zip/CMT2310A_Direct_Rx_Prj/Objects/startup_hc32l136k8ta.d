.\objects\startup_hc32l136k8ta.o: Common\startup_hc32l136k8ta.s
