.\objects\main.o: Source\main.c
.\objects\main.o: Source\cmt2310a_eb.h
.\objects\main.o: .\Common\base_types.h
.\objects\main.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\main.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\main.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\main.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\main.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\main.o: .\Driver\inc\adt.h
.\objects\main.o: .\Driver\inc\ddl.h
.\objects\main.o: .\Common\board_stkhc32l13x.h
.\objects\main.o: .\Common\hc32l13x.h
.\objects\main.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\main.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\main.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\main.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\main.o: .\Common\system_hc32l13x.h
.\objects\main.o: .\Driver\inc\sysctrl.h
.\objects\main.o: .\Driver\inc\ddl.h
.\objects\main.o: .\Common\interrupts_hc32l13x.h
.\objects\main.o: .\Source\ddl_device.h
.\objects\main.o: .\Driver\inc\aes.h
.\objects\main.o: .\Driver\inc\bt.h
.\objects\main.o: .\Driver\inc\crc.h
.\objects\main.o: .\Driver\inc\flash.h
.\objects\main.o: .\Driver\inc\gpio.h
.\objects\main.o: .\Driver\inc\lpm.h
.\objects\main.o: .\Driver\inc\lptim.h
.\objects\main.o: .\Driver\inc\trng.h
.\objects\main.o: .\Driver\inc\uart.h
.\objects\main.o: Source\radio.h
.\objects\main.o: .\Radio\radio_phy.h
.\objects\main.o: .\Radio\radio_hal.h
.\objects\main.o: .\Radio\radio_spi.h
.\objects\main.o: .\Driver\inc\spi.h
.\objects\main.o: .\Radio\CMT2310A_def.h
.\objects\main.o: .\Radio\CMT2310A_reg.h
.\objects\main.o: .\Radio\radio_mac.h
