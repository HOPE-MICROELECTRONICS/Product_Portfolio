.\objects\lpm.o: Driver\src\lpm.c
.\objects\lpm.o: .\Driver\inc\lpm.h
.\objects\lpm.o: .\Driver\inc\ddl.h
.\objects\lpm.o: .\Common\base_types.h
.\objects\lpm.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\lpm.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\lpm.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\lpm.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\lpm.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\lpm.o: .\Common\board_stkhc32l13x.h
.\objects\lpm.o: .\Common\hc32l13x.h
.\objects\lpm.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\lpm.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\lpm.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\lpm.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\lpm.o: .\Common\system_hc32l13x.h
.\objects\lpm.o: .\Driver\inc\sysctrl.h
.\objects\lpm.o: .\Driver\inc\ddl.h
.\objects\lpm.o: .\Common\interrupts_hc32l13x.h
.\objects\lpm.o: .\Source\ddl_device.h
