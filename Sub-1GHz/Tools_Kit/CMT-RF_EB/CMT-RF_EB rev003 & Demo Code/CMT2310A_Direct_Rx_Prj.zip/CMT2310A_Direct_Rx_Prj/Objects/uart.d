.\objects\uart.o: Driver\src\uart.c
.\objects\uart.o: .\Driver\inc\uart.h
.\objects\uart.o: .\Driver\inc\ddl.h
.\objects\uart.o: .\Common\base_types.h
.\objects\uart.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\uart.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\uart.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\uart.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\uart.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\uart.o: .\Common\board_stkhc32l13x.h
.\objects\uart.o: .\Common\hc32l13x.h
.\objects\uart.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\uart.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\uart.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\uart.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\uart.o: .\Common\system_hc32l13x.h
.\objects\uart.o: .\Driver\inc\sysctrl.h
.\objects\uart.o: .\Driver\inc\ddl.h
.\objects\uart.o: .\Common\interrupts_hc32l13x.h
.\objects\uart.o: .\Source\ddl_device.h
