
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'cmt2310a_direct_tx' 
 * Target:  'cmt2310a_direct_tx' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "HC32L136K8TA.h"



#endif /* RTE_COMPONENTS_H */
