#include "cmt2310a_eb.h"

#define		PREAMBLE_VALUE					0xAA
#define		TX_PREAMBLE_SEND_VALUE			16

#define		SYNC_LENGTH						3
#define		SYNC_WORD_VALUE					0xAA2DD4


word 		systimer;
word 		keytimer;
byte 		lptimer;
uint32_t 	g_chip_id;

//radio
byte    radio_tx_msg[UHF_LEN];
byte 	radio_tx_buf[250];
word 	g_tx_count;

//uart 
byte 	uart_tx_buf[UART_TXD_LEN];
byte 	uart_rx_buf[UART_RXD_LEN];
word 	uart_tx_ind;
word 	uart_rx_ind;
word	uart_tx_length;

const unsigned char g_title_string[] = {"2310A     DirectTx"};


int32_t main(void)
{
 byte i;
 word pkt_len;	

	
 vMcuInit();						//MCU�ײ��ʼ��	
 vBeep();
	
	
 vLcdLight(0);						//12864 LCD����ʼ��
 vLcdInit();
 vLcdClearScreen();
 vLcdPrintString(1, g_title_string);
 vLcdDrawDoubleLine(2); 	

 vSpiMasterInit();

 g_chip_id = lRadioChipVersion();
 	
 while(bRadioIsExist()==FALSE)	
	{
	vLcdPrintString(5, "not found CMT2310A");
	delay1ms(100);
	}

 vLcdPrintString(4, "Transmit Packet:  ");	
 
 g_tx_count  = 0;

 vRadioInit();

 while(1)
	{
	SET_LED1();	
	vGetRandomTxBuf();
	pkt_len = wRadioAssmblePacket(radio_tx_msg, UHF_LEN, radio_tx_buf);
	vRadioGoTxInit();
	RF_TX_DATA_Output();
	vRadioDirectSendPacket(radio_tx_buf, pkt_len);
	bRadioGoStandby();
	RF_TX_DATA_Input();
	CLR_LED1();
	g_tx_count++;	
	vLcdPrintCounter(6, 6, g_tx_count);		
	for(systimer=0; systimer<25; )
		{
		if(bKeyScan())
			{
			g_tx_count = 0;
			vLcdPrintCounter(6, 6, g_tx_count);	
			}
		}	
	}
}


byte bKeyScan(void)
{
	
 if(KEY1_PRESS())
	{
	keytimer = 0;
	do
		{
		if(KEY1_RELEASE())
			break;
		vDelayNms(5);
		}while(keytimer<5);
	if(keytimer>=5)
		{
		while(KEY1_PRESS());
		return(1);
		}	
	else
		return(0);
	}
 else
	return(0);
}

void vGetRandomTxBuf(void)										//��ȡ�����
{
 byte i;
 uint32_t trng_tmp;
	
 vEnableTrngSrc();
 for(i=0; i<UHF_LEN; i+=4)
	{	
	vTrngGenerate(6, 1, 1);	
	trng_tmp = Trng_GetData0();
	radio_tx_msg[i]   = (byte)trng_tmp;
	radio_tx_msg[i+1] = (byte)(trng_tmp>>8);
	radio_tx_msg[i+2] = (byte)(trng_tmp>>16);	
	radio_tx_msg[i+3] = (byte)(trng_tmp>>24);	
	}
 vDisableTrngSrc();
}	

void vBeep(void)
{
 SET_BUZZER();
 for(systimer=0; systimer<50; );
 CLR_BUZZER();	
}


word wRadioAssmblePacket(byte *src_ptr, byte length, byte *dest_ptr)
{
 word i;
 word ind;
 word crc_result;
	
 for(ind=0; ind<TX_PREAMBLE_SEND_VALUE; ind++)
	dest_ptr[ind] = PREAMBLE_VALUE;

 switch(SYNC_LENGTH)
	{
	case 4: dest_ptr[ind++] = (byte)(SYNC_WORD_VALUE>>24);
	case 3: dest_ptr[ind++] = (byte)(SYNC_WORD_VALUE>>16);
	case 2: dest_ptr[ind++] = (byte)(SYNC_WORD_VALUE>>8);
	case 1: dest_ptr[ind++] = (byte)SYNC_WORD_VALUE;		
	default: break;
	}
 
 for(i=0; i<length; i++)
	dest_ptr[ind++] = src_ptr[i];
 
 Sysctrl_SetPeripheralGate(SysctrlPeripheralCrc, TRUE); 	
 crc_result = CRC16_Get8(src_ptr, length);
 Sysctrl_SetPeripheralGate(SysctrlPeripheralCrc, FALSE); 
	
 dest_ptr[ind++] = (byte)(crc_result>>8);
 dest_ptr[ind++] = (byte)crc_result;
 return(ind);
}

void vRadioDirectSendPacket(byte *tx_buf, word pkt_len)
{
 word i;	
 byte j;

	for(i=0; i<pkt_len; i++)
	{
	for(j=0x80; j!=0; j>>=1)
		{
		if(tx_buf[i]&j)
			RF_TX_DAT_H();
		else
			RF_TX_DAT_L();			
		delay10us(9);
		}	
	}
}


/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/


