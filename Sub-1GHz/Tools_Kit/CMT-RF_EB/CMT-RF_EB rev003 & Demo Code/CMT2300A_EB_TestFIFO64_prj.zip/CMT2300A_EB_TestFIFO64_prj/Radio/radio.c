#include "radio.h"

unsigned short int	g_pkt_preamble_length;
unsigned char	 	g_pkt_payload_length;

unsigned char		g_trig_rssi;				//��ȡRSSI
unsigned char      	g_radio_rx_buf[1024];		//��Ƶ���ջ���
unsigned char		g_radio_tx_buf[1024];		//��Ƶ���仺��
unsigned short int	g_rx_count;					//�հ�����
unsigned short int  g_tx_count;					//��������


unsigned char 		g_rssi_trig_F;
unsigned char 		g_pkt_recv_error_F;
unsigned char 		g_int_polar_F;
unsigned char 		g_fixed_pkt_F;

unsigned char 		g_payload_length;


/**************************************************************************************************
State Ctrl
**************************************************************************************************/
/**********************************************************
**Name:     vRadioSoftReset
**Function: Software reset Chipset
**Input:    none
**Output:   none
**********************************************************/
void vRadioSoftReset(void)
{
	vSpiWrite(((unsigned short int)CUS_SOFTRST<<8)+0xFF); 
	delay1ms(20);							//wait >15ms
}

/**********************************************************
**Name:     bRadioGoSleep
**Function: Entry Sleep Mode
**Input:    none
**Output:   none
**********************************************************/
unsigned char bRadioGoSleep(void)
{
 	unsigned char tmp;
 
 	vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_SLEEP);	
 	delay10us(10);		
 	tmp = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));	
 
 	if(tmp==MODE_STA_SLEEP)
 		return(1);
 	else
 		return(0);
}

/**********************************************************
**Name:     bRadioGoStandby
**Function: Entry Standby Mode
**Input:    none
**Output:   none
**********************************************************/
unsigned char bRadioGoStandby(void)
{
 	unsigned char tmp, i;	
 
 	g_rssi_trig_F = 0;
 	g_pkt_recv_error_F = 0;
 
 	vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_STBY);	
	for(i=0; i<10; i++)
 		{
 		delay10us(10);	
		tmp = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));	
		if(tmp==MODE_STA_STBY)
			break;
		}
 
	if(i>=10)
 		return(0);
	else
 		return(1);
}

/**********************************************************
**Name:     bRadioGoTx
**Function: Entry Tx Mode
**Input:    none
**Output:   none
**********************************************************/
unsigned char bRadioGoTx(void)
{
	unsigned char tmp, i;		
 
 	vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_TFS);	
 
 	for(i=0; i<3; i++)
 		{
 		delay100us(10);	
		tmp = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));	
		if(tmp==MODE_STA_TFS)
			break;
		}
 
 	if(i>=3)
 		{
 		if(tmp==MODE_STA_UNLOCK)
 			{
			bRadioGoStandby();
			delay100us(30);		
			vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_TFS);	
			delay100us(30);	
			tmp = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));	
			if(tmp!=MODE_STA_TFS)
				return(0);
 			}	
 		else
 			return(0);
		}
	
 	vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_TX);		
 	for(i=0; i<3; i++)
 		{
 		delay100us(10);		
		tmp = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));	
		if(tmp==MODE_STA_TX)
			break;
		}
	 if(i>=3)
 		return(0);
 	else
 		return(1);
}

/**********************************************************
**Name:     bRadoiGoRx
**Function: Entry Rx Mode
**Input:    none
**Output:   none
**********************************************************/
unsigned char bRadioGoRx(void)
{
 	unsigned char tmp, i;
 
 	g_rssi_trig_F = 0;
	g_pkt_recv_error_F = 0;
 
 	vRadioSetPayloadLength(0, g_payload_length);				//Set traget reveive length

 	vRadioEnableRdFifo();										//when FIFO Merge Active, set fifo to Rd
 	vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_RFS);			

 	for(i=0; i<3; i++)
 		{
 		delay100us(10);		
		tmp = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));	
		if(tmp==MODE_STA_RFS)
			break;
		}

 	if(i>=3)
 		{
 		if(tmp==MODE_STA_UNLOCK)
 			{
			bRadioGoStandby();
			delay100us(30);	
			vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_RFS);
			delay100us(30);		
			tmp = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));	
			if(tmp!=MODE_GO_RFS)
				return(0);
 			}	
 		else
 			return(0);
 		}
 
 	vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_RX);		
 	for(i=0; i<3; i++)
 		{
		delay100us(10);	
		tmp = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));	
		if(tmp==MODE_STA_RX)
			break;
		}
 	if(i>=3)
 		return(0);
 	else
 		return(1);
}

/**********************************************************
**Name:     vRadioFastGoRx
**Function: Entry Rx Mode
**Input:    none
**Output:   none
**********************************************************/
void vRadioFastGoRx(void)
{
 	g_rssi_trig_F = 0;
	g_pkt_recv_error_F = 0;
 
 	vRadioSetPayloadLength(0, g_payload_length);					//Set traget reveive length
	vRadioEnableRdFifo();											//when FIFO Merge Active, set fifo to Rd
 
 	vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_RX);		
}

/**********************************************************
**Name:     vRadioFastGoTx
**Function: Entry Tx Mode
**Input:    none
**Output:   none
**********************************************************/
void vRadioFastGoTx(void)
{
 	vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_TX);		
}

/**********************************************************
**Name:     bGoSwitch
**Function: Tx to Rx  or  Rx to Tx, use for quick switch 
**Input:    none
**Output:   none
**********************************************************/
unsigned char bRadioGoSwitch(void)
{
 	unsigned char tmp, i, z;

 	tmp = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));	
  	if((tmp!=MODE_STA_RX)&&(tmp!=MODE_STA_TX))
 		return(0);
 
 	vSpiWrite(((unsigned short int)CUS_MODE_CTL<<8)+MODE_GO_SWITCH);	
 
 	for(i=0; i<3; i++)
 		{
 		delay100us(10);			
 		z = (MODE_MASK_STA & bSpiRead(CUS_MODE_STA));
 		if(tmp==MODE_STA_RX)
 			{
	 		if(z==MODE_STA_TX)
 				break;
 			}
 		else
 			{
 			if(z==MODE_STA_RX)	
 				break;
 			}
 		}
 	if(i>=3)
 		return(0);
 	else
 		return(1);
}	

/**********************************************************
**Name:     bRadioReadStatus
**Function: read chipset status
**Input:    none
**Output:   none
**********************************************************/
unsigned char bRadioReadStatus(void)
{
 	return(MODE_MASK_STA & bSpiRead(CUS_MODE_STA));		
}

/**********************************************************
**Name:     bRadioReadRssi
**Function: Read Rssi
**Input:    true------dBm;
            false-----Code;
**Output:   none
**********************************************************/
unsigned char bRadioReadRssi(unsigned char unit_dbm)
{
 	unsigned char readout;

 	switch(unit_dbm)
 		{
 		case 0: 
 			readout = bSpiRead(CUS_RSSI_CODE);			//code
 			break;
 		case 1:
 			readout = (bSpiRead(CUS_RSSI_DBM)-128);	//with sign
 			break;
 		default:
 			readout = bSpiRead(CUS_RSSI_DBM);			////without sign
 			break;
 		}
 	return(readout);
}

/**************************************************************************************************
GPIO & Interrupt CFG
**************************************************************************************************/
/**********************************************************
**Name:     vRadioGpioFuncCfg
**Function: GPIO Function config
**Input:    none
**Output:   none
**********************************************************/
void vRadioGpioFuncCfg(unsigned char io_cfg)
{
 	vSpiWrite(((unsigned short int)CUS_IO_SEL<<8)+io_cfg);
}

/**********************************************************
**Name:     vRadioIntSrcCfg
**Function: config interrupt source  
**Input:    int_1, int_2
**Output:   none
**********************************************************/
void vRadioIntSrcCfg(unsigned char int_1, unsigned char int_2)
{
 	unsigned char tmp;
 	
 	tmp = INT_MASK & bSpiRead(CUS_INT1_CTL);
 	vSpiWrite(((unsigned short int)CUS_INT1_CTL<<8)+(tmp|int_1));
 
 	tmp = INT_MASK & bSpiRead(CUS_INT2_CTL);
 	vSpiWrite(((unsigned short int)CUS_INT2_CTL<<8)+(tmp|int_2));
}

/**********************************************************
**Name:     vRadioInt1SrcCfg
**Function: config interrupt source 1
**Input:    int_1
**Output:   none
**********************************************************/
void vRadioInt1SrcCfg(unsigned char int_1)
{
 	unsigned char tmp;
 	
 	tmp = INT_MASK & bSpiRead(CUS_INT1_CTL);
	vSpiWrite(((unsigned short int)CUS_INT1_CTL<<8)+(tmp|int_1));
}


/**********************************************************
**Name:     vRadioInt2SrcCfg
**Function: config interrupt source 2 
**Input:    int_2
**Output:   none
**********************************************************/
void vRadioInt2SrcCfg(unsigned char int_2)
{
 	unsigned char tmp;
 	
 	tmp = INT_MASK & bSpiRead(CUS_INT2_CTL);
 	vSpiWrite(((unsigned short int)CUS_INT2_CTL<<8)+(tmp|int_2));
}

/**********************************************************
**Name:     vRadioIntSrcEnable
**Function: enable interrupt source 
**Input:    en_int
**Output:   none
**********************************************************/
void vRadioIntSrcEnable(unsigned char en_int)
{
	vSpiWrite(((unsigned short int)CUS_INT_EN<<8)+en_int);				
}

/**********************************************************
**Name:     vIntSrcFlagClr
**Function: clear flag
**Input:    none
**Output:   equ CMT23_INT_EN
**     .7      .6     .5        .4       .3       .2       .1       .0
**   SL_TMO  RX_TMO  TX_TMO  PREAM_OK  SYNC_OK  NODE_OK  CRC_OK  PKT_DONE
**********************************************************/
unsigned char bRadioIntSrcFlagClr(void)
{
 	unsigned char tmp;
 	unsigned char int_clr2 = 0;
 	unsigned char int_clr1 = 0;
 	unsigned char flg = 0;
 
 	tmp = bSpiRead(CUS_INT_FLAG);
 	
 	if(g_int_polar_F)
 		{
 		if(tmp&LBD_FLG)					//LBD_FLG_Active
 			int_clr2 |= LBD_CLR;
 		
 		if(tmp&PREAM_OK_FLG)			//Preamble Active
 			{
 			int_clr2 |= PREAM_OK_CLR;
 			flg |= PREAM_OK_EN;
			}
 		if(tmp&SYNC_OK_FLG)				//Sync Active
 			{
 			int_clr2 |= SYNC_OK_CLR;		
 			flg |= SYNC_OK_EN;		
 			}
 		if(tmp&NODE_OK_FLG)				//Node Addr Active
 			{
 			int_clr2 |= NODE_OK_CLR;	
 			flg |= NODE_OK_EN;
 			}
 		if(tmp&CRC_OK_FLG)				//Crc Pass Active
 			{
 			int_clr2 |= CRC_OK_CLR;
 			flg |= CRC_OK_EN;
 			}
 		if(tmp&PKT_OK_FLG)				//Rx Done Active
 			{
 			int_clr2 |= PKT_DONE_CLR;
 			flg |= PKT_DONE_EN;
 			}
 			
 		if(tmp&COL_ERR_FLG)				//������������ͨ��RX_DONE���
 			int_clr2 |= PKT_DONE_CLR;
 		if(tmp&PKT_ERR_FLG)
 			int_clr2 |= PKT_DONE_CLR;
 		}
 	else
 		{
 		if((tmp&LBD_FLG)==0)			//LBD_FLG_Active
 			int_clr2 |= LBD_CLR;
 		
 		if((tmp&PREAM_OK_FLG)==0)		//Preamble Active
 			{
 			int_clr2 |= PREAM_OK_CLR;
 			flg |= PREAM_OK_EN;
			}
 		if((tmp&SYNC_OK_FLG)==0)		//Sync Active
 			{
 			int_clr2 |= SYNC_OK_CLR;		
 			flg |= SYNC_OK_EN;		
 			}
 		if((tmp&NODE_OK_FLG)==0)		//Node Addr Active
 			{
 			int_clr2 |= NODE_OK_CLR;	
 			flg |= NODE_OK_EN;
 			}
 		if((tmp&CRC_OK_FLG)==0)			//Crc Pass Active
 			{
 			int_clr2 |= CRC_OK_CLR;
 			flg |= CRC_OK_EN;
 			}
 		if((tmp&PKT_OK_FLG)==0)			//Rx Done Active
 			{
 			int_clr2 |= PKT_DONE_CLR;
 			flg |= PKT_DONE_EN;
 			}
 			
 		if((tmp&COL_ERR_FLG)==0)		//������������ͨ��RX_DONE���
 			int_clr2 |= PKT_DONE_CLR;
 		if((tmp&PKT_ERR_FLG)==0)
 			int_clr2 |= PKT_DONE_CLR; 	
 		}
	
 	vSpiWrite(((unsigned short int)CUS_INT_CLR2<<8)+int_clr2);	//Clear flag
 
 
 	tmp = bSpiRead(CUS_INT_CLR1);
 
 	if(g_int_polar_F)
 		{
 	 	if(tmp&TX_DONE_FLG)
 			{
 			int_clr1 |= TX_DONE_CLR;
 			flg |= TX_DONE_EN;
 			}	
 		if(tmp&SL_TMO_FLG)
 			{
 			int_clr1 |= SL_TMO_CLR;
 			flg |= SL_TMO_EN;
 			} 
 		if(tmp&RX_TMO_FLG)
 			{
 			int_clr1 |= RX_TMO_CLR;
 			flg |= RX_TMO_EN;
 			}
 		}
 	else
 		{
 		if((tmp&TX_DONE_FLG)==0)
 			{
 			int_clr1 |= TX_DONE_CLR;
 			flg |= TX_DONE_EN;
 			}	
 		if((tmp&SL_TMO_FLG)==0)
 			{
 			int_clr1 |= SL_TMO_CLR;
 			flg |= SL_TMO_EN;
 			} 
 		if((tmp&RX_TMO_FLG)==0)
 			{
 			int_clr1 |= RX_TMO_CLR;
 			flg |= RX_TMO_EN;
 			} 	
 		}
 	
 	vSpiWrite(((unsigned short int)CUS_INT_CLR1<<8)+int_clr1);	//Clear flag 
 	
 	return(flg);
}

/**********************************************************
**Name:     vRadioEnableAntSwitch
**Function:  
**Input:    
**Output:   none
**********************************************************/
void vRadioEnableAntSwitch(unsigned char mode)
{
 	unsigned char tmp;
 	
 	tmp = bSpiRead(CUS_INT1_CTL);
 	tmp&= 0x3F;
 	
 	switch(mode)
 		{
 		case 1:
 			tmp |= RF_SWT1_EN; break;		//GPO1=RxActive; GPO2=TxActive	
 		case 2:
 			tmp |= RF_SWT2_EN; break;		//GPO1=RxActive; GPO2=!RxActive
 		case 0:
 		default:
 			break;							//Disable	
 		}
 	vSpiWrite(((unsigned short int)CUS_INT1_CTL<<8)+tmp);
}

/**************************************************************************************************
Fifo Packet Handle
**************************************************************************************************/
/**********************************************************
**Name:     vRadioClearFIFO
**Function: clear FIFO buffer
**Input:    none
**Output:   none
**********************************************************/
void vRadioClearFifo(void)
{
 	vSpiWrite(((unsigned short int)CUS_FIFO_CLR<<8)+FIFO_CLR_RX+FIFO_CLR_TX);
}

/**********************************************************
**Name:     bRadioReadFifoFlag
**Function: read fifo state flag
**Input:    none
**Output:   FIFO state
**********************************************************/
unsigned char bRadioReadFifoFlag(void)
{
 	return(bSpiRead(CUS_FIFO_FLAG));
}

/**********************************************************
**Name:     wRadioReadIntFlag
**Function: read interrupt flag
**Input:    none
**Output:   interrupt flag
**********************************************************/
unsigned short int wRadioReadIntFlag(void)
{
 	unsigned short int tmp;
 	
 	tmp = bSpiRead(CUS_INT_CLR1);
 	tmp<<=8;
 	tmp|= bSpiRead(CUS_INT_FLAG);
 	
 	return(tmp);	
}

/**********************************************************
**Name:     vRadioEnableRdFifo
**Function: set Fifo for read
**Input:    none
**Output:   none
**********************************************************/
void vRadioEnableRdFifo(void)
{
 	unsigned char tmp;
 	
 	tmp = bSpiRead(CUS_FIFO_CTL);
 	tmp &= (~(SPI_FIFO_RD_WR_SEL|FIFO_RX_TX_SEL));
 	//if(g_payload_length>31)
 	//	tmp |= FIFO_MERGE_EN;
 	//else
 	//	tmp &= (~FIFO_MERGE_EN);
 	vSpiWrite(((unsigned short int)CUS_FIFO_CTL<<8)+tmp);
}

/**********************************************************
**Name:     vRadioEnableWrFifo
**Function: set Fifo for wirte
**Input:    none
**Output:   none
**********************************************************/
void vRadioEnableWrFifo(void)
{
 	unsigned char tmp;
 	
 	tmp = bSpiRead(CUS_FIFO_CTL);
 	tmp |= (SPI_FIFO_RD_WR_SEL|FIFO_RX_TX_SEL);
// 	if(g_payload_length>31)
// 		tmp |= FIFO_MERGE_EN;
// 	else
// 		tmp &= (~FIFO_MERGE_EN);
 		
 	vSpiWrite(((unsigned short int)CUS_FIFO_CTL<<8)+tmp);
}

/**********************************************************
**Name:     vRadioSetPayloadLength
**Function: set Fifo length to used
**Input:    none
**Output:   none
**********************************************************/
void vRadioSetPayloadLength(unsigned char mode, unsigned char length)
{
 	unsigned char tmp;	
 	unsigned char len;
 	
 	bRadioGoStandby();
 	
 	tmp = bSpiRead(CUS_PKT14);
 	tmp&= 0x8F;					//length<256
 	tmp&= (~0x01);				//Packet Mode
 
 	if(length!=0)
 		{
 		if(mode)                //Tx
 			{
 			if(g_fixed_pkt_F)
				len = length-1;
 			else
				len = length;
 			}
 		else					//Rx
			len = length - 1;
 			
 		if(g_fixed_pkt_F)
			tmp |= PKT_TYPE_FIXED;
 		else
			tmp |= PKT_TYPE_VARIABLE;
		}
 	else
 		return;
 	
 	vSpiWrite(((unsigned short int)CUS_PKT14<<8)+tmp);
 	vSpiWrite(((unsigned short int)CUS_PKT15<<8)+len);	
}

/**********************************************************
**Name:     vRadioEnableAckPacket
**Function: Ack Packet
**Input:    [1] Enable; [0] Disable
**Output:   none
**********************************************************/
void vRadioEnableAckPacket(unsigned char en)
{
 	unsigned char tmp;		
 	
 	tmp = bSpiRead(CUS_PKT14);
 	if(en)
 	  	tmp|= AUTO_ACK_EN;
 	else
 		tmp&= (~AUTO_ACK_EN);
 	vSpiWrite(((unsigned short int)CUS_PKT14<<8)+tmp);
}

/**********************************************************
**�������ƣ�bReadFifo
**�������ܣ����ճ����õĶ�ȡFifo
**���������none
**���������none
**Note��    should be call vEnableRdFifo() at GoRx
**********************************************************/
unsigned char bRadioReadFifo(void)
{
 	return(bSpiReadFIFO());
}

/**********************************************************
**�������ƣ�vWriteFifo
**�������ܣ����ճ����õĶ�ȡFifo
**���������none
**���������none
**Note��    should be call  vEnableWrFifo() at first
**********************************************************/
void vRadioWriteFifo(unsigned char dat)
{
 	vSpiWriteFIFO(dat);
}	

/**************************************************************************************************
CFG
**************************************************************************************************/
/**********************************************************
**Name:     vInit
**Function: Init. CMT2300A
**Input:    none
**Output:   none
**********************************************************/
void vRadioInit(void)
{
	vSpiInit();
 	g_int_polar_F = 1;								//default is high_edge for interrupt

	vRadioSoftReset();
 	bRadioGoStandby();
}


void vRadioCfgBank(unsigned short int const *cfg, unsigned char length)
{
 	unsigned char i;
 
 	if(length!=0)
 		{	
 		for(i=0; i<length; i++)	
 			vSpiWrite((unsigned short int)cfg[i]);
 		}	
}

void vRadioAfterCfg(void)            //call after vCfgBank
{
 	unsigned char tmp;	
 	
 	tmp = bSpiRead(CUS_MODE_STA);
 	tmp|= CFG_RETAIN;
 	tmp&= (~RSTN_IN_EN);			//Disable RstPin	
 	vSpiWrite(((unsigned short int)CUS_MODE_STA<<8)+tmp);
 	
 	tmp = 0x00;                    //Disable All Calibration, when no need to use DutyCycleMode
 	vSpiWrite(((unsigned short int)CUS_SYS2<<8)+tmp);
 	
 	tmp  = bSpiRead(0x09);		//xosc_acc_code = 2;	
 	tmp &= 0xF8;
 	tmp |= 0x02;
 	vSpiWrite(0x0900+tmp);
 	
 	tmp  = bSpiRead(CUS_EN_CTL);
 	tmp |= UNLOCK_STOP_EN;			//enable pll unlock stop to shift status
 	vSpiWrite(((unsigned short int)CUS_EN_CTL<<8)+tmp);
 	
 	tmp  = bSpiRead(CUS_SYS10);
 	tmp &= (~RX_AUTO_EXIT_DIS);	//PktOk active, then auto go to stby
 	vSpiWrite(((unsigned short int)CUS_SYS10<<8)+tmp);
 	
 	bRadioIntSrcFlagClr();
}

void vRadioReadCfgBank(unsigned char sta_adr,  unsigned char *rd_cfg, unsigned char length)
{
 	unsigned char i, j;
 
 	if(length!=0)
 		{	
 		for(i=sta_adr, j=0; i<(sta_adr+length); i++, j++)	
 			rd_cfg[j] = bSpiRead(i);
 		}	
}

void vRadioSetIntPolar(unsigned char polar)
{
 	unsigned char tmp;
 	
 	g_int_polar_F = polar;
 	tmp = bSpiRead(CUS_INT1_CTL);
 	if(polar)
 		tmp &= (INT_POLAR^0xFF);
 	else
 		tmp |= INT_POLAR; 	
 	vSpiWrite(((unsigned short int)CUS_INT1_CTL<<8)+tmp);
}

/**************************************************************************************************
appliciation
**************************************************************************************************/
/**********************************************************
**�������ƣ�bRadioGetMessage
**�������ܣ�����һ������
**�����������
**�����������0�������ճɹ�
**            0��������ʧ��
**��ע:     ��Ҫ��GPO���жϴ���ʹ�ã�������MCU�жϳ���
**********************************************************/
unsigned char bRadioGetMessage(unsigned char *msg)
{
 	unsigned char i;	
 
 	if(g_fixed_pkt_F)
 		{
 		vSpiBurstReadFIFO(msg, g_payload_length);
		i = g_payload_length;
		}
 	else
 		{
		i = bRadioReadFifo();	
 		vSpiBurstReadFIFO(msg, i);
 		}
 	return(i);
}

/**********************************************************
**�������ƣ�vRadioSendMessage
**�������ܣ�����һ������
**���������none
**���������none
**��ע    ����Ҫ��GPO���жϴ���ʹ�ã�������MCU�жϳ���          
**********************************************************/
void vRadioSendMessage(unsigned char *msg, unsigned char length)
{
 	//mode1       
	bRadioIntSrcFlagClr();
	vRadioInt2SrcCfg(INT_TX_DONE);
 	vRadioSetPayloadLength(1, length);
 	vRadioClearFifo(); 
 	vRadioEnableWrFifo();	
 	vSpiBurstWriteFIFO(msg, length);
 	vRadioFastGoTx();
}

/**********************************************************
**�������ƣ�vRadioSetChannelOffset
**�������ܣ�������Ƶ���
**���������interval  unit:KHz
**���������none
**��ע    ��
**********************************************************/
void vRadioSetChannelOffset(unsigned short int interval)
{
 	unsigned char offset;
 	offset = (interval<<1)/5;			//unit:2.5KHz
 	vSpiWrite(((unsigned short int)CUS_FREQ_OFS<<8)+offset);
}

/**********************************************************
**�������ƣ�vRadioSetChannel
**�������ܣ�����Ƶ��
**���������channel
**���������none
**��ע    ��
**********************************************************/
void vRadioSetChannel(unsigned char channel)
{
	 vSpiWrite(((unsigned short int)CUS_FREQ_CHNL<<8)+channel);
}

/**********************************************************
**�������ƣ�vRadioSetTxPreamble
**�������ܣ����÷����Preamble����
**���������length
**���������none
**��ע    ��
**********************************************************/
void vRadioSetTxPreamble(unsigned short int length)
{
 	vSpiWrite(((unsigned short int)CUS_PKT3<<8)+(unsigned char)(length>>8));
 	vSpiWrite(((unsigned short int)CUS_PKT2<<8)+(unsigned char)length);
}

/**********************************************************
**�������ƣ�bRadioIsExist
**�������ܣ�Check radio is connect is ok
**���������none
**���������0=connect error,  1=connect is ok
**��ע    ��
**********************************************************/
unsigned char bRadioIsExist(void)
{
    unsigned char dat;

	dat = bSpiRead(0x01);
	if(dat!=0x66)
		return(0);
	else	
		return(1);
}

/******************************
**Name:  vRadioRssiUpdateSel
**Func:  Radio rssi update select
**Input: RSSI_DET_ALWAYS   ---- always
**       RSSI_DET_PREAM    ---- when preamble ok
**       RSSI_DET_SYNC     ---- when sync ok
**       RSSI_DET_PKT      ---- when pkt done
*Output: None
********************************/
void vRadioRssiUpdateSel(unsigned char sel)
{
	unsigned char tmp;
	
	tmp  = bSpiRead(CUS_SYS11);
	tmp &= (~(3<<3));
	tmp |= sel;
	vSpiWrite((((unsigned short int)CUS_SYS11)<<8)|tmp);
}


