
#ifndef		__RADIO_H__
	
	#define __RADIO_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif

	//#define		SEL_RAIDO_SPI3

	#include "ddl.h"
	#include "cmt2300a_reg.h"
	#include "radio_spi3.h"
	
	// vars

	extern unsigned short int	g_pkt_preamble_length;
	extern unsigned char	 	g_pkt_payload_length;

	extern unsigned char		g_trig_rssi;				//��ȡRSSI
	extern unsigned char      	g_radio_rx_buf[1024];		//��Ƶ���ջ���
	extern unsigned char		g_radio_tx_buf[1024];		//��Ƶ���仺��
	extern unsigned short int	g_rx_count;					//�հ�����
	extern unsigned short int  	g_tx_count;					//��������


	extern unsigned char g_rssi_trig_F;
	extern unsigned char g_pkt_recv_error_F;
	extern unsigned char g_int_polar_F;
	extern unsigned char g_fixed_pkt_F;
	
	extern unsigned char g_payload_length;
	

	// API
	extern void vRadioInit(void);
	extern void vRadioCfgBank(unsigned short int const *cfg, unsigned char length);
	extern void vRadioAfterCfg(void);
	extern void vRadioReadCfgBank(unsigned char sta_adr,  unsigned char *rd_cfg, unsigned char length);
	extern void vRadioSetIntPolar(unsigned char polar);
	extern unsigned char bRadioGetMessage(unsigned char *msg);
	extern void vRadioSendMessage(unsigned char *msg, unsigned char length);
	extern void vRadioSetChannelOffset(unsigned short int interval);
	extern void vRadioSetChannel(unsigned char channel);
	extern void vRadioSetTxPreamble(unsigned short int length);
	
	extern unsigned char bRadioIsExist(void);
	extern void vRadioRssiUpdateSel(unsigned char sel);
	

	extern void vRadioSoftReset(void);
	extern unsigned char bRadioGoSleep(void);
	extern unsigned char bRadioGoStandby(void);
	extern unsigned char bRadioGoTx(void);
	extern unsigned char bRadioGoRx(void);
	extern void vRadioFastGoRx(void);
	extern void vRadioFastGoTx(void);
	extern unsigned char bRadioGoSwitch(void);
	extern unsigned char bRadioReadStatus(void);
	extern unsigned char bRadioReadRssi(unsigned char unit_dbm);
	
	
	extern void vRadioGpioFuncCfg(unsigned char io_cfg);
	extern void vRadioIntSrcCfg(unsigned char int_1, unsigned char int_2);
	extern void vRadioInt1SrcCfg(unsigned char int_1);
	extern void vRadioInt2SrcCfg(unsigned char int_2);
	extern void vRadioIntSrcEnable(unsigned char en_int);
	extern unsigned char bRadioIntSrcFlagClr(void);
	extern void vRadioEnableAntSwitch(unsigned char mode);	


	extern void vRadioClearFifo(void);
	extern unsigned char bRadioReadFifoFlag(void);
	extern unsigned short int wRadioReadIntFlag(void);
	extern void vRadioEnableRdFifo(void);
	extern void vRadioEnableWrFifo(void);
	extern void vRadioSetPayloadLength(unsigned char mode, unsigned char length);
	extern void vRadioEnableAckPacket(unsigned char en);	
	
	
	extern unsigned char bRadioReadFifo(void);
	extern void vRadioWriteFifo(unsigned char dat);
	

	
	#ifdef	__cplusplus
		}
	#endif

#endif 		

