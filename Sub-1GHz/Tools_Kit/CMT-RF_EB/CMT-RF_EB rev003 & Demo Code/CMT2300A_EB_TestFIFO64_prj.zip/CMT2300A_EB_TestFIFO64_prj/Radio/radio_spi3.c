#include "radio_spi3.h"

#define		RF_SDA_IN		1
#define		RF_SDA_OUT		0

/**********************************************************
**Name: 	vSpiInit
**Func: 	Init Spi-3 Config
**Note: 	
**********************************************************/
void vSpiInit(void)
{
	
	SET_RF_CSB();
	SET_RF_FCSB();
	CLR_RF_SCK();	
	
	RF_SDA_Output();
	SET_RF_SDA();
}

/**********************************************************
**Name: 	vSpi3WriteByte
**Func: 	SPI-3 send one byte
**Input:
**Output:  
**********************************************************/
void vSpiWriteByte(unsigned char dat, unsigned char sda_in)
{

 	unsigned char bitcnt;	
 
 	SET_RF_FCSB();					//FCSB = 1;
 	RF_SDA_Output();				//SDA output mode
 	SET_RF_SDA();					
	CLR_RF_SCK();	
	CLR_RF_CSB(); 
 
	for(bitcnt=8; bitcnt!=0; bitcnt--)
 		{
		CLR_RF_SCK();	
		if(dat&0x80)
 			SET_RF_SDA();
 		else
 			CLR_RF_SDA();
		SET_RF_SCK();	
 		dat <<= 1; 		
 		}
 	if(sda_in)
 		{
 		RF_SDA_Input();				//shift to input for read
 		CLR_RF_SCK();	
 		}	
 	else
 		{
 		CLR_RF_SCK();	
 		SET_RF_SDA();
 		}
}

/**********************************************************
**Name: 	bSpiReadByte
**Func: 	SPI-3 read one byte
**Input:
**Output:  
**********************************************************/
unsigned char bSpiReadByte(void)
{
	unsigned char RdPara = 0;
 	unsigned char bitcnt;
 
 	CLR_RF_SCK();	
 	RF_SDA_Input();
	CLR_RF_CSB();
   	
 	for(bitcnt=8; bitcnt!=0; bitcnt--)
 		{
 	 	SET_RF_SCK();	
 		RdPara <<= 1;
 		if(RF_SDA_H())
 			RdPara |= 0x01;
 		else
 			RdPara |= 0x00;
 	 	CLR_RF_SCK();	
 		} 
 	return(RdPara);	
}

/**********************************************************
**Name:	 	vSpiWrite
**Func: 	SPI Write One word
**Input: 	Write word
**Output:	none
**********************************************************/
void vSpiWrite(unsigned short int dat)
{
 	vSpiWriteByte(((unsigned char)(dat>>8)&0x7F), RF_SDA_OUT);
 	vSpiWriteByte(((unsigned char)dat), RF_SDA_OUT);
	SET_RF_CSB();
}

/**********************************************************
**Name:	 	bSpiRead
**Func: 	SPI-3 Read One byte
**Input: 	readout addresss
**Output:	readout byte
**********************************************************/
unsigned char bSpiRead(unsigned char addr)
{
	unsigned char dat;
  	vSpiWriteByte((addr|0x80), RF_SDA_IN);
  	dat = bSpiReadByte();
	RF_SDA_Output();
 	SET_RF_SDA();
	SET_RF_CSB();
  	return(dat);
}

/**********************************************************
**Name:	 	vSpiWriteFIFO
**Func: 	SPI-3 send one byte to FIFO
**Input: 	one byte buffer
**Output:	none
**********************************************************/
void vSpiWriteFIFO(unsigned char dat)
{
 	unsigned char bitcnt;	
 
	SET_RF_CSB();
	RF_SDA_Output();
	CLR_RF_SCK();
 	CLR_RF_FCSB();					//FCSB = 0

	//_delay_us(1);
	
	for(bitcnt=8; bitcnt!=0; bitcnt--)
 		{
		CLR_RF_SCK();
 		if(dat&0x80)
			SET_RF_SDA();		
		else
			CLR_RF_SDA();
		SET_RF_SCK();
 		dat <<= 1;
 		}
 	CLR_RF_SCK();
	//_delay_us(3);					//Time-Critical 	
	SET_RF_FCSB();
	SET_RF_SDA();
	//_delay_us(4);					//Time-Critical
}

void vSpiWriteRotateFIFO(unsigned char dat)
{
 	unsigned char bitcnt;	
 
	SET_RF_CSB();	
	RF_SDA_Output();
	CLR_RF_SCK();
 	CLR_RF_FCSB();					//FCSB = 0

	//_delay_us(1);
	
	for(bitcnt=8; bitcnt!=0; bitcnt--)
 		{
		CLR_RF_SCK();
 		
 		if(dat&0x01)
			SET_RF_SDA();
		else
			CLR_RF_SDA();
			
		SET_RF_SCK();

 		dat >>= 1;
 		}
	CLR_RF_SCK();
 	//_delay_us(3);					//Time-Critical		
	SET_RF_FCSB();
	SET_RF_SDA();
	//_delay_us(4);					//Time-Critical		
}


/**********************************************************
**Name:	 	bSpiReadFIFO
**Func: 	SPI-3 read one byte to FIFO
**Input: 	none
**Output:	one byte buffer
**********************************************************/
unsigned char bSpiReadFIFO(void)
{
	unsigned char RdPara;
 	unsigned char bitcnt;	

	SET_RF_CSB();	
	RF_SDA_Input();
	CLR_RF_SCK();
 	CLR_RF_FCSB();	
	
	//_delay_us(1);
		
 	for(bitcnt=8; bitcnt!=0; bitcnt--)
 		{
		SET_RF_SCK();
 		RdPara <<= 1;
 		if(RF_SDA_H())
 			RdPara |= 0x01;			//NRZ MSB
 		else
 		 	RdPara |= 0x00;			//NRZ MSB
 		CLR_RF_SCK();

		#if (SPI3_SPEED!=0)
		    _delay_us(SPI3_SPEED);
		#endif

 		}
 	
 	CLR_RF_SCK();
 	//_delay_us(3);					//Time-Critical		
 	SET_RF_FCSB();	
	RF_SDA_Output();
	SET_RF_SDA();
	//_delay_us(4);					//Time-Critical		

 	return(RdPara);
}

unsigned char bSpiReadRotateFIFO(void)
{
	unsigned char RdPara;
 	unsigned char bitcnt;	

	SET_RF_CSB();
	RF_SDA_Input();
	CLR_RF_SCK();
	CLR_RF_FCSB();
	
 	//_delay_us(1);
		
 	for(bitcnt=8; bitcnt!=0; bitcnt--)
 		{
		SET_RF_SCK();
 		RdPara >>= 1;
 		if(RF_SDA_H())
 			RdPara |= 0x80;			//NRZ MSB
 		else
 		 	RdPara |= 0x00;			//NRZ MSB
		CLR_RF_SCK();
 		}
 	
	CLR_RF_SCK();
 	//_delay_us(3);					//Time-Critical		
	SET_RF_FCSB();
	RF_SDA_Output();
	SET_RF_SDA();
	//_delay_us(4);					//Time-Critical		
	
 	return(RdPara);
}

/**********************************************************
**Name:	 	vSpiBurstWriteFIFO
**Func: 	burst wirte N byte to FIFO
**Input: 	array length & head pointer
**Output:	none
**********************************************************/
void vSpiBurstWriteFIFO(unsigned char *ptr, unsigned char length)
{
 	unsigned char i;
 	
 	if(length!=0x00)
	 	{
 		for(i=0;i<length;i++)
 			vSpiWriteFIFO(ptr[i]);
 		}
 	return;
}

/**********************************************************
**Name:	 	vSpiBurstRead
**Func: 	burst wirte N byte to FIFO
**Input: 	array length  & head pointer
**Output:	none
**********************************************************/
void vSpiBurstReadFIFO(unsigned char *ptr, unsigned char length)
{
	unsigned char i;
	
 	if(length!=0)
 		{
 		for(i=0;i<length;i++)
 			ptr[i] = bSpiReadFIFO();
 		}	
 	return;
}

