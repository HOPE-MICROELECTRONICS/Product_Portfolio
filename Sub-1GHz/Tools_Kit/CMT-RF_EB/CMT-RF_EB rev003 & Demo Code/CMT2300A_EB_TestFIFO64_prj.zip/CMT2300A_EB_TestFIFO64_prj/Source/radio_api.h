
#ifndef		__RADIO_API_H__

	#define	__RADIO_API_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif
	#include 	"CMT2300A_EB.h"
	#include 	"radio_cfg.h"
	#include 	"radio.h"
	
	#define		PREAMBLE_VALUE			0xAA
	#define		RX_DET_PREAMBLE_LEN		4
	#define		PREAMBLE_NIBBLE			0			//0=8bit, 1=4bit
	
	#define		SYNC_LEN				5			//n+1, n=0~7
	#define		SYNC_1_VAL				0x2D
	#define		SYNC_2_VAL				0xD4
	#define		SYNC_3_VAL				0x2D
	#define		SYNC_4_VAL				0xD4
	#define		SYNC_5_VAL				0x2D
	#define		SYNC_6_VAL				0xD4
	#define		SYNC_7_VAL				0x00
	#define		SYNC_8_VAL				0x00

	#define		CRC_16_SEED_VAL			0x0000	
	#define		WHITEN_SEED_VAL			0x01FF
	
	#define		FIFO_TH_VALUE			50		

	
	#define		RADIO_CDR_TRACING		(0<<0)
	#define		RADIO_CDR_COUNTING		(1<<0)
	#define		RADIO_CDR_MANCHESTER	(2<<0)
	#define		RADIO_RAWDATA			(3<<0)
	
	#define		RADIO_DR_6				(0<<2)
	#define		RADIO_DR_9				(1<<2)
	#define		RADIO_DR_12				(2<<2)	
	#define		RADIO_DR_15				(3<<2)



	//-------api--------
	extern void vRadioInitCfg(void);

	
	extern void vRadioInitBank(unsigned char addr, unsigned char length, unsigned char const array[]);
	extern void vRadioTxPowerCfg(void);
	extern void vRadioTxGaussianCfg(unsigned char gauss_sel);

	extern void vRadioPreambleCfg(void);
	extern void vRadioSyncWordCfg(void);	
	extern void vRadioPayloadLengthCfg(void);
	extern void vRadioNodeAddrCfg(void);
	extern void vRadioCodeFormatCfg(void);
	extern void vRadioCdrTypeCfg(unsigned char mod, unsigned char range);
	extern void vRadioRssiCalibCfg(void);
	extern void vRadioRampCfg(unsigned char on_off);
	extern void vRadioDirectRxEnable(void);
	
	#ifdef	__cplusplus
		}
	#endif

#endif 
	

	
