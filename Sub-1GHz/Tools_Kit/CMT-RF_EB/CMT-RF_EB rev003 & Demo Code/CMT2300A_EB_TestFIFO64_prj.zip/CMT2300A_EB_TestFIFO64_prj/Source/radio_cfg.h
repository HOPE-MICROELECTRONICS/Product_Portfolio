

#ifndef		__RADIO_CFG_H__

	#define	__RADIO_CFG_H__

	#ifdef 	__cplusplus
		extern "C" {
	#endif

	
	#define		CMT_BANK_STR_ADR_VAL		0x00
	#define		CMT_BANK_CFG_LEN			12
	
	#define		SYSTEM_BANK_STR_ADR_VAL		0x0C
	#define		SYSTEM_BANK_CFG_LEN			12
	
	#define		FREQ_BANK_STR_ADR_VAL		0x18
	#define		FREQ_BANK_CFG_LEN			8
	
	#define		DATARATE_BANK_STR_ADR_VAL	0x20
	#define		DATARATE_BANK_CFG_LEN		24
	
	#define		BASEBAND_BANK_STR_ADR_VAL	0x38
	#define		BASEBAND_BANK_CFG_LEN		29

	#define		TX_BANK_STR_ADR_VAL			0x55
	#define		TX_BANK_CFG_LEN				11	
	
	extern unsigned char const CMTBank[12];
	extern unsigned char const SystemBank[12];
	extern unsigned char const FrequencyBank[8];
	extern unsigned char const DataRateBank[24];
	extern unsigned char const BasebandBank[29];
	extern unsigned char const TxBank[11];

	#ifdef	__cplusplus
		}
	#endif

#endif 
	


