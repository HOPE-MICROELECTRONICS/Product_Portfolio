#include "radio_api.h"


void vRadioInitCfg(void)
{
	g_fixed_pkt_F = 1;						//fixed packet length	
	
 	vRadioInit();
 	
 	vRadioInitBank(CMT_BANK_STR_ADR_VAL,     CMT_BANK_CFG_LEN,      CMTBank);
 	vRadioInitBank(SYSTEM_BANK_STR_ADR_VAL,  SYSTEM_BANK_CFG_LEN,   SystemBank);
	vRadioInitBank(BASEBAND_BANK_STR_ADR_VAL,BASEBAND_BANK_CFG_LEN, BasebandBank);	
	vRadioInitBank(FREQ_BANK_STR_ADR_VAL,    FREQ_BANK_CFG_LEN,     FrequencyBank);
	vRadioInitBank(DATARATE_BANK_STR_ADR_VAL, DATARATE_BANK_CFG_LEN,DataRateBank);
	vRadioInitBank(TX_BANK_STR_ADR_VAL,       TX_BANK_CFG_LEN,      TxBank);

	vRadioAfterCfg();

	//##	
	vRadioEnableAntSwitch(0);
 	vRadioGpioFuncCfg(GPIO1_INT1+GPIO2_INT2+GPIO3_DATA+GPIO4_DOUT);  
	vRadioIntSrcEnable(PKT_DONE_EN+CRC_OK_EN+PREAM_OK_EN+SYNC_OK_EN+TX_DONE_EN); 
	bRadioIntSrcFlagClr();
	vRadioClearFifo();
	vRadioSetIntPolar(1);					//normal output for low
	bRadioGoSleep();
}

//## 
void vRadioInitBank(unsigned char addr, unsigned char length, unsigned char const array[])
{
 	unsigned char i;
 
 	if(length!=0)
 		{	
 		for(i=0; i<length; i++)	
 			{
 			vSpiWrite(((unsigned short int)addr<<8)|array[i]);
 			addr++;
 			}
 		}	 	
}






