//*********************************************************************************************************
//Change List
//
//2022-09-06 
//	1. init version
//*********************************************************************************************************

#include "CMT2300A_EB.h"
#include "radio_api.h"

const unsigned char g_firmware_string[] = {"SW 20220906M      "};


word 			g_systimer;						//ϵͳ��ʱ��
word 			g_keytimer;						//����ʶ��ʱ��
word			g_uhf_timer;					//��Ƶ����/���տ��Ƴ�ʱ��ʱ��	
byte 			g_lptimer;

int32_t main(void)
{
 byte i;
 byte tmp;
	
 vMcuInit();							//MCU�ײ��ʼ��	

 for(g_systimer=0; g_systimer<25; );	

 vRadioInit();
 vRadioInitCfg();
 tmp = bSpiRead(CUS_FIFO_CTL);			//merge FIFO to 64Byte
 tmp |= FIFO_MERGE_EN;
 vSpiWrite(((unsigned short int)CUS_FIFO_CTL<<8)+tmp);		
 bRadioGoSleep();

// //test for Tx 64 FIFO	
// g_pkt_payload_length = 64;	
// vRadioSetPayloadLength(1, g_pkt_payload_length);
// vGetRandomTxBuffer();
// vActiveTransmit();		
// while(1);
	
 //test for Rx 64 FIFO		
 g_pkt_payload_length = 64;	
 vRadioSetPayloadLength(0, g_pkt_payload_length); 
 vRadioInt1SrcCfg(INT_PKT_DONE);	
 vRadioInt2SrcCfg(INT_RX_FIFO_WBYTE);	 
 bRadioGoRx();
 while(1)
	{
	if(RF_GPIO1_H())
		{
		SET_LED3();
		g_trig_rssi = bRadioReadRssi(TRUE);	
		bRadioGoStandby();
		vSpiBurstReadFIFO(g_radio_rx_buf, g_pkt_payload_length);

		i  = bRadioIntSrcFlagClr();
		i &= 0x03;
		switch(i)
			{
			case 0x03:  SET_LED2(); break;		//CRC pass
			case 0x01:  						//CRC error	
			default:   break;
			}	
		vRadioClearFifo();	
		for(g_systimer=0; g_systimer<5; );
			
		bRadioGoRx();
		CLR_LED2();
		CLR_LED3();
		} 	
	}
}


void vBeep(void)
{
 SET_BUZZER();
 for(g_systimer=0; g_systimer<50; );
 CLR_BUZZER();	
}

void vGetRandomTxBuffer(void)	
{
 	word i=0;
 	uint32_t trng_tmp;
		
 	vEnableTrngSrc();
 	for(i=0; i<g_pkt_payload_length; )
		{	
		vTrngGenerate(6, 1, 1);	
		trng_tmp = Trng_GetData0();
		g_radio_tx_buf[i++] = (byte)trng_tmp;
		g_radio_tx_buf[i++] = (byte)(trng_tmp>>8);
		g_radio_tx_buf[i++] = (byte)(trng_tmp>>16);	
		g_radio_tx_buf[i++] = (byte)(trng_tmp>>24);	
		}
 	vDisableTrngSrc();
}	

void vActiveTransmit(void)										//���䷢�ͻ��壬�ȴ��������
{
	byte tmp;
	
 	SET_LED1();	 

	vRadioClearFifo(); 	
	bRadioIntSrcFlagClr(); 		
	
 	//enable wr fifo
	tmp = bSpiRead(CUS_FIFO_CTL);
 	tmp |= (SPI_FIFO_RD_WR_SEL|FIFO_RX_TX_SEL);
  	vSpiWrite(((unsigned short int)CUS_FIFO_CTL<<8)+tmp);	

	vRadioInt1SrcCfg(INT_TX_DONE);	
	vRadioInt2SrcCfg(INT_TX_FIFO_TH);	
	
	vSpiBurstWriteFIFO(g_radio_tx_buf, (byte)g_pkt_payload_length); 	
	bRadioGoTx();
	
 	for(g_systimer=0; g_systimer<100; )
		{
		if(RF_GPIO1_H())
			{
			g_tx_count++;
			bRadioGoStandby();
			vRadioClearFifo();
			bRadioIntSrcFlagClr();
			break;
			}
		}
	bRadioGoStandby();	
 	CLR_LED1();
}	

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/


