.\objects\radio_cfg.o: Source\radio_cfg.c
.\objects\radio_cfg.o: Source\radio_cfg.h
