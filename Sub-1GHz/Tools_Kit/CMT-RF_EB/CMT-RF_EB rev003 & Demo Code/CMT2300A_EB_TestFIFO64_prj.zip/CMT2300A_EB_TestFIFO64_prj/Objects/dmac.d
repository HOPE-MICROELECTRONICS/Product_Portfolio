.\objects\dmac.o: Driver\src\dmac.c
.\objects\dmac.o: .\Driver\inc\dmac.h
.\objects\dmac.o: .\Driver\inc\ddl.h
.\objects\dmac.o: .\Common\base_types.h
.\objects\dmac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\dmac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\dmac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\dmac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\dmac.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\dmac.o: .\Common\board_stkhc32l13x.h
.\objects\dmac.o: .\Common\hc32l13x.h
.\objects\dmac.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\dmac.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\dmac.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\dmac.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\dmac.o: .\Common\system_hc32l13x.h
.\objects\dmac.o: .\Driver\inc\sysctrl.h
.\objects\dmac.o: .\Driver\inc\ddl.h
.\objects\dmac.o: .\Common\interrupts_hc32l13x.h
.\objects\dmac.o: .\Source\ddl_device.h
