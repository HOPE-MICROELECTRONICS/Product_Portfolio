
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'cmt2300a_eb_function' 
 * Target:  'cmt2300a_eb_function' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "HC32L136J8TA.h"



#endif /* RTE_COMPONENTS_H */
