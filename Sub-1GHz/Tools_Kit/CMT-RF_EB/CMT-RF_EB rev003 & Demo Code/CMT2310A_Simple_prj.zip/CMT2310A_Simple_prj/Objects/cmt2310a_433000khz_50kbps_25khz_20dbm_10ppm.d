.\objects\cmt2310a_433000khz_50kbps_25khz_20dbm_10ppm.o: Source\CMT2310A_433000kHz_50kbps_25kHz_20dBm_10ppm.c
.\objects\cmt2310a_433000khz_50kbps_25khz_20dbm_10ppm.o: .\Radio\CMT2310A_reg.h
.\objects\cmt2310a_433000khz_50kbps_25khz_20dbm_10ppm.o: .\Radio\CMT2310A_def.h
