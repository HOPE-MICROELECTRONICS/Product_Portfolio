.\objects\cmt2310a_865000khz_20kbps_10khz_20dbm_10ppm.o: Source\CMT2310A_865000kHz_20kbps_10kHz_20dBm_10ppm.c
.\objects\cmt2310a_865000khz_20kbps_10khz_20dbm_10ppm.o: .\Radio\CMT2310A_reg.h
.\objects\cmt2310a_865000khz_20kbps_10khz_20dbm_10ppm.o: .\Radio\CMT2310A_def.h
