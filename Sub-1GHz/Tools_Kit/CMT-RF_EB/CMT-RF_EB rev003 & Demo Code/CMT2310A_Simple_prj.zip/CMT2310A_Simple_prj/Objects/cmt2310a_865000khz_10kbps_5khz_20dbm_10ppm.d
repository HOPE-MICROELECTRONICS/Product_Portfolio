.\objects\cmt2310a_865000khz_10kbps_5khz_20dbm_10ppm.o: Source\CMT2310A_865000kHz_10kbps_5kHz_20dBm_10ppm.c
.\objects\cmt2310a_865000khz_10kbps_5khz_20dbm_10ppm.o: .\Radio\CMT2310A_reg.h
.\objects\cmt2310a_865000khz_10kbps_5khz_20dbm_10ppm.o: .\Radio\CMT2310A_def.h
