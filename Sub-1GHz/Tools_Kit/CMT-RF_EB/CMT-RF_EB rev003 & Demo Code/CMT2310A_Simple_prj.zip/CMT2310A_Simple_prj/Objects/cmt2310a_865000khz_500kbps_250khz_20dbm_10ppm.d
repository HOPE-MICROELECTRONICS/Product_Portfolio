.\objects\cmt2310a_865000khz_500kbps_250khz_20dbm_10ppm.o: Source\CMT2310A_865000kHz_500kbps_250kHz_20dBm_10ppm.c
.\objects\cmt2310a_865000khz_500kbps_250khz_20dbm_10ppm.o: .\Radio\CMT2310A_reg.h
.\objects\cmt2310a_865000khz_500kbps_250khz_20dbm_10ppm.o: .\Radio\CMT2310A_def.h
