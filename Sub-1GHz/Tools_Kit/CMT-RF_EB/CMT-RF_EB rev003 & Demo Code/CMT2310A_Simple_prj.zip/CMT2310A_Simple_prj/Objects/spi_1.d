.\objects\spi_1.o: Source\spi.c
.\objects\spi_1.o: Source\cmt2310a_eb.h
.\objects\spi_1.o: .\Common\base_types.h
.\objects\spi_1.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
.\objects\spi_1.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\spi_1.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
.\objects\spi_1.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\spi_1.o: D:\Program Files (x86)\Keil_v5\ARM\ARMCC\Bin\..\include\assert.h
.\objects\spi_1.o: .\Driver\inc\adt.h
.\objects\spi_1.o: .\Driver\inc\ddl.h
.\objects\spi_1.o: .\Common\board_stkhc32l13x.h
.\objects\spi_1.o: .\Common\hc32l13x.h
.\objects\spi_1.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\core_cm0plus.h
.\objects\spi_1.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_version.h
.\objects\spi_1.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\spi_1.o: D:\Program Files (x86)\Keil_v5\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\spi_1.o: .\Common\system_hc32l13x.h
.\objects\spi_1.o: .\Driver\inc\sysctrl.h
.\objects\spi_1.o: .\Driver\inc\ddl.h
.\objects\spi_1.o: .\Common\interrupts_hc32l13x.h
.\objects\spi_1.o: .\Source\ddl_device.h
.\objects\spi_1.o: .\Driver\inc\aes.h
.\objects\spi_1.o: .\Driver\inc\bt.h
.\objects\spi_1.o: .\Driver\inc\crc.h
.\objects\spi_1.o: .\Driver\inc\flash.h
.\objects\spi_1.o: .\Driver\inc\gpio.h
.\objects\spi_1.o: .\Driver\inc\lpm.h
.\objects\spi_1.o: .\Driver\inc\lptim.h
.\objects\spi_1.o: .\Driver\inc\trng.h
.\objects\spi_1.o: .\Driver\inc\uart.h
.\objects\spi_1.o: .\Radio\radio.h
.\objects\spi_1.o: .\Radio\radio_phy.h
.\objects\spi_1.o: .\Radio\radio_hal.h
.\objects\spi_1.o: .\Radio\radio_spi.h
.\objects\spi_1.o: .\Driver\inc\spi.h
.\objects\spi_1.o: .\Radio\CMT2310A_def.h
.\objects\spi_1.o: .\Radio\CMT2310A_reg.h
.\objects\spi_1.o: .\Radio\radio_mac.h
