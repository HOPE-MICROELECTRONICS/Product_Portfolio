#include "cmt2310a_eb.h"

word 	systimer;
word 	keytimer;

byte 	lptimer;

//radio
byte    radio_rx_buf[UHF_LEN];
byte 	radio_tx_buf[UHF_LEN];
word 	g_rx_count;
word 	g_tx_count;

const unsigned char g_title_string[] = {"2310A   SimpleCode"};

#define		WORK_MODE		2		// 3 = transmit zero
									// 2 = receive mode for sensisity test
									// 1 = transmit packet test
									// 0 = receive packet test								

int32_t main(void)
{
 byte i;
	
 vMcuInit();						//MCU init
 vBeep();
	
	
 vLcdLight(0);						//12864 LCD init
 vLcdInit();
 vLcdClearScreen();
 vLcdPrintString(1, g_title_string);
 vLcdDrawDoubleLine(2); 	

 vSpiMasterInit();
 g_chip_id = 0x00000000;
 while(1)	
	{
	vRadioSoftReset();
	vRadioPowerUpBoot();				
	delay1ms(10);
	g_chip_id = lRadioChipVersion();	
	if(0x00231000==(g_chip_id&0x00FFFF00))
		break;
	vLcdPrintString(5, "not found CMT2310A");
	delay1ms(100);
	}
	
 g_rx_count  = 0;
 g_tx_count  = 0;


 #if (WORK_MODE==3)							//test base tx prefix	
	vLcdPrintString(4, "Transmit Tx-Zero");	
	vRadioInit();
	g_radio.word_mode_cfg.WORK_MODE_CFG1_u._BITS.TX_EXIT_STATE = EXIT_TO_TX;	//exit Tx mode for transmit prefix 
	vRadioCfgWorkMode(&g_radio.word_mode_cfg);	
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_TX_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_TX_FIFO_NMTY);
	vGetRandomTxBuf();
	vRadioWriteFifo(radio_tx_buf, UHF_LEN);
	bRadioGoTx();
	while(RF_GPIO4_L());
	vRadioClearInterrupt(); 
	while(1);
 #endif	

 #if (WORK_MODE==2)		   								//test base rx mode
	vLcdPrintString(4, "Receiving      ");
	vRadioInit();
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_WBYTE);
	bRadioGoRx();
	SET_LED2();
	while(1)
		{
		if(RF_GPIO4_H())
			{
			SET_LED3();	
			vRadioClearRxFifo();	
			vRadioClearInterrupt(); 
			bRadioGoRx();
			CLR_LED3();
			}
		}
 #endif

 #if (WORK_MODE==1)										//test transmit packet mode
	vLcdPrintString(4, "Transmit Packet:  ");
	vRadioInit();
	while(1)
		{
		SET_LED1();
		vRadioSetInt1Sel(CMT2310A_INT_TX_DONE);
		vRadioSetInt2Sel(CMT2310A_INT_TX_FIFO_NMTY);	
		g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
		vRadioSetPayloadLength(&g_radio.frame_cfg);
		vGetRandomTxBuf();
		vRadioWriteFifo(radio_tx_buf, UHF_LEN);
		vRadioReadTxFifo(radio_rx_buf, UHF_LEN);		
		vRadioManualResetTxFifoPointer();				//because readout tx fifo, so that need to reset tx_fifo_ptr
		for(i=0; i<UHF_LEN; i++)
			{
			if(radio_tx_buf[i]!=radio_rx_buf[i])
				break;
			}
		if(i<UHF_LEN)
			SET_LED3();
		bRadioGoTx();
		for(systimer=0; systimer<LIMIT_TIMER_TX_CNT; )
			{
			if(RF_GPIO4_H())
				{
				bRadioGoStandby();
				vRadioClearTxFifo();
				vRadioClearInterrupt();
				g_tx_count++;
				vLcdPrintCounter(6, 6, g_tx_count);	
				break;
				}
			}
		if(systimer>=LIMIT_TIMER_TX_CNT)
			bRadioGoStandby();
		CLR_LED1();
		CLR_LED3();
		for(systimer=0; systimer<25; )
			{
			if(bKeyScan())
				{
				g_tx_count = 0;
				vLcdPrintCounter(6, 6, g_tx_count);	
				}
			}
		}
 #endif


 #if (WORK_MODE==0)										//test receive packet mode
	vLcdPrintString(4, "Receive Packet:   ");
	vRadioInit();
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
	vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_WBYTE);
	bRadioGoRx();	
	while(1)
		{
		if(RF_GPIO4_H())
			{
			SET_LED3();
			if(g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_EN==1)
				{
				vRadioInterruptSoucreFlag(&g_radio.int_src_flag);
				if(g_radio.int_src_flag._BITS.CRC_PASS_FLG==1)
					{
					SET_LED2();
					g_rx_count++;
					}
				}
			else
				g_rx_count++;
			vRadioReadFifo(radio_rx_buf, UHF_LEN);
			vRadioClearRxFifo();	
			vRadioClearInterrupt(); 
			bRadioGoRx();	
			vLcdPrintCounter(6, 6, g_rx_count);	
			CLR_LED2();
			CLR_LED3();
			}
		if(bKeyScan())
			{
			g_rx_count = 0;
			vLcdPrintCounter(6, 6, g_rx_count);	
			}
		}

 #endif

}


byte bKeyScan(void)
{
	
 if(KEY1_PRESS())
	{
	keytimer = 0;
	do
		{
		if(KEY1_RELEASE())
			break;
		vDelayNms(5);
		}while(keytimer<5);
	if(keytimer>=5)
		{
		while(KEY1_PRESS());
		return(1);
		}	
	else
		return(0);
	}
 else
	return(0);
}

void vGetRandomTxBuf(void)										//��ȡ�����
{
 byte i;
 uint32_t trng_tmp;
	
 vEnableTrngSrc();
 for(i=0; i<UHF_LEN; i+=4)
	{	
	vTrngGenerate(6, 1, 1);	
	trng_tmp = Trng_GetData0();
	radio_tx_buf[i]   = (byte)trng_tmp;
	radio_tx_buf[i+1] = (byte)(trng_tmp>>8);
	radio_tx_buf[i+2] = (byte)(trng_tmp>>16);	
	radio_tx_buf[i+3] = (byte)(trng_tmp>>24);	
	}
 vDisableTrngSrc();
}	

void vBeep(void)
{
 SET_BUZZER();
 for(systimer=0; systimer<50; );
 CLR_BUZZER();	
}



/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/


