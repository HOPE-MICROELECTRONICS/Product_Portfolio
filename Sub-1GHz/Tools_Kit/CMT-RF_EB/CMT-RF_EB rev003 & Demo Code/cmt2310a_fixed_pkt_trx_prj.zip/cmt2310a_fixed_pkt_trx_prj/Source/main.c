#include "cmt2310a_eb.h"

word 	g_systimer;
word 	g_lptimer;
word 	g_uhf_timer;



int32_t main(void)
{
 byte key_tmp;	
	
 vMcuInit();									//MCU�ײ��ʼ��	
 vBeep();
	
 vLcdLight(0);									//12864 LCD����ʼ��
 vLcdInit();
 vLcdClearScreen();
 vLcdPrintString(1, g_title_string);
 vLcdDrawDoubleLine(2); 	
 vLcdDrawDoubleLine(7); 
 vDispOp1Menu();
	
 vSpiMasterInit();
	
 while(bRadioIsExist()==FALSE)	
	{
	vLcdPrintString(5, "not found CMT2310A");
	delay1ms(100);
	}
	
 g_rx_count  = 0;
 g_tx_count  = 0;

 g_work_mode_F	= FALSE;

 while(1)
	{
	key_tmp = bKeyScan();	
	if(!g_work_mode_F)
		{
		vMeumStandby(key_tmp);
		}	
	else
		{
		if(g_trx_master_F)
			{
			vMeumMasterSending(key_tmp);
			}
		else
			{
			vMenuSlaveReceiving(key_tmp);
			}		
		}
		
	if(g_menu_change_F)
		{
		g_menu_change_F = FALSE;
		vLcdClearScreen();
		vLcdPrintString(1, g_title_string);
		vLcdDrawDoubleLine(2); 	
		vLcdDrawDoubleLine(7); 			
		if(g_work_mode_F)	
			{
			vRadioInit();	
			if(!g_trx_master_F)
				{
				vDispOp6Menu();	
				g_rx_ptr = 0;
				vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
				vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_TH);	
				vRadioSetPayloadLength(&g_radio.frame_cfg);
				vRadioRssiUpdateSel(CMT2310A_RSSI_UPDATE_SYNC_OK);
				bRadioGoRx();
				}
			else
				{
				if(g_menu_pause_F)
					vDispOpTxStopMenu();
				else
					vDispOp6Menu();		
				}
			}	
		else
			vDispOp1Menu();
		}
	}
	
}


void vGetRandomTxBuf(void)										//��ȡ�����
{
 word i;
 uint32_t trng_tmp;
	
 vEnableTrngSrc();
 for(i=0; i<UHF_LEN; i+=4)
	{	
	vTrngGenerate(6, 1, 1);	
	trng_tmp = Trng_GetData0();
	g_radio_tx_buf[i]   = (byte)trng_tmp;
	g_radio_tx_buf[i+1] = (byte)(trng_tmp>>8);
	g_radio_tx_buf[i+2] = (byte)(trng_tmp>>16);	
	g_radio_tx_buf[i+3] = (byte)(trng_tmp>>24);	
	}
 vDisableTrngSrc();
}	

void vBeep(void)
{
 SET_BUZZER();
 for(g_systimer=0; g_systimer<50; );
 CLR_BUZZER();	
}



/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/


