#include "cmt2310a_eb.h"

#define		CLOCK_MODE				2	//0=RCH,  24MHz, 
										//1=XTAL, 32MHz
										//2=PLL(base on RCH), 40MHz


/********************************
**Name: vMcuInit
**Func: Initial uC Control
*Input: None
Output: None
********************************/
void vMcuInit(void)
{
    vIOInit();                  			//IO
	vMcuClockInit();

	switch(CLOCK_MODE)
		{
		case 2:
			delay1ms(10);
			vMcuSwitchPLL();
			delay1ms(10);
			vBaseTime0Init(6250);   		//T0,  @40MHz = 10ms 	
			break;
		case 1:
			delay1ms(10);
			vMcuSwitchXtalH();				//switch to xtal_h_32M
			delay1ms(10);
			vBaseTime0Init(5000);   		//T0,  @32MHz = 10ms 	
			break;
		case 0:
		default:
			vBaseTime0Init(3750);   		//T0,  @24MHz = 10ms  
			break;
		}	
	
	vBaseTime1Init(12500);					//T1,  @24MHz
}

/******************************
**Name: vIOInit
**Func: ��ʼ��MCU IO
*Input: None
Output: None
********************************/
void vIOInit(void)
{
	Sysctrl_SetPeripheralGate(SysctrlPeripheralGpio, TRUE);  	//����ʱ��	
	
	M0P_GPIO->PADIR = PA_DIR_VALUE;
    M0P_GPIO->PBDIR = PB_DIR_VALUE;
    M0P_GPIO->PCDIR = PC_DIR_VALUE;
    M0P_GPIO->PDDIR = PD_DIR_VALUE;
    
    M0P_GPIO->PAOUT = PA_OUT_VALUE;
    M0P_GPIO->PBOUT = PB_OUT_VALUE;
    M0P_GPIO->PCOUT = PC_OUT_VALUE;
    M0P_GPIO->PDOUT = PD_OUT_VALUE;
	
	M0P_GPIO->PAADS = PA_ADS_VALUE;
	M0P_GPIO->PBADS = PB_ADS_VALUE;
	M0P_GPIO->PCADS = PC_ADS_VALUE;
	M0P_GPIO->PDADS = PD_ADS_VALUE;
	
	M0P_GPIO->PADR  = PA_DR_VALUE;
	M0P_GPIO->PBDR  = PB_DR_VALUE;
	M0P_GPIO->PCDR  = PC_DR_VALUE;
	M0P_GPIO->PDDR  = PD_DR_VALUE;    
	
    M0P_GPIO->PAPU  = PA_PU_VALUE;
    M0P_GPIO->PBPU  = PB_PU_VALUE;
    M0P_GPIO->PCPU  = PC_PU_VALUE;
    M0P_GPIO->PDPU  = PD_PU_VALUE;
	
    M0P_GPIO->PAPD  = PA_PD_VALUE;
    M0P_GPIO->PBPD  = PB_PD_VALUE;
    M0P_GPIO->PCPD  = PC_PD_VALUE;
    M0P_GPIO->PDPD  = PD_PD_VALUE;
	
	M0P_GPIO->PAOD  = PA_OD_VALUE;
	M0P_GPIO->PBOD  = PB_OD_VALUE;
	M0P_GPIO->PCOD  = PC_OD_VALUE;
	M0P_GPIO->PDOD  = PD_OD_VALUE;	
	
	M0P_GPIO->PAHIE = PA_HIE_VALUE;
	M0P_GPIO->PBHIE = PB_HIE_VALUE;
	M0P_GPIO->PCHIE = PC_HIE_VALUE;
	M0P_GPIO->PDHIE = PD_HIE_VALUE;	
	
	M0P_GPIO->PALIE = PA_LIE_VALUE;
	M0P_GPIO->PBLIE = PB_LIE_VALUE;
	M0P_GPIO->PCLIE = PC_LIE_VALUE;
	M0P_GPIO->PDLIE = PD_LIE_VALUE;	

	M0P_GPIO->PARIE = PA_RIE_VALUE;
	M0P_GPIO->PBRIE = PB_RIE_VALUE;
	M0P_GPIO->PCRIE = PC_RIE_VALUE;
	M0P_GPIO->PDRIE = PD_RIE_VALUE;	
	
	M0P_GPIO->PAFIE = PA_FIE_VALUE;
	M0P_GPIO->PBFIE = PB_FIE_VALUE;
	M0P_GPIO->PCFIE = PC_FIE_VALUE;
	M0P_GPIO->PDFIE = PD_FIE_VALUE;	
	
	M0P_GPIO->PA00_SEL = PA0_SEL_VALUE;
	M0P_GPIO->PA01_SEL = PA1_SEL_VALUE;
	M0P_GPIO->PA02_SEL = PA2_SEL_VALUE;
	M0P_GPIO->PA03_SEL = PA3_SEL_VALUE;
	M0P_GPIO->PA04_SEL = PA4_SEL_VALUE;
	M0P_GPIO->PA05_SEL = PA5_SEL_VALUE;
	M0P_GPIO->PA06_SEL = PA6_SEL_VALUE;	
	M0P_GPIO->PA07_SEL = PA7_SEL_VALUE;	
	M0P_GPIO->PA08_SEL = PA8_SEL_VALUE;	
	M0P_GPIO->PA09_SEL = PA9_SEL_VALUE;	
	M0P_GPIO->PA10_SEL = PA10_SEL_VALUE;	
	M0P_GPIO->PA11_SEL = PA11_SEL_VALUE;		
	M0P_GPIO->PA12_SEL = PA12_SEL_VALUE;		
	M0P_GPIO->PA13_SEL = PA13_SEL_VALUE;		
	M0P_GPIO->PA14_SEL = PA14_SEL_VALUE;			
	M0P_GPIO->PA15_SEL = PA15_SEL_VALUE;			

	M0P_GPIO->PB00_SEL = PB0_SEL_VALUE;
	M0P_GPIO->PB01_SEL = PB1_SEL_VALUE;
	M0P_GPIO->PB02_SEL = PB2_SEL_VALUE;
	M0P_GPIO->PB03_SEL = PB3_SEL_VALUE;
	M0P_GPIO->PB04_SEL = PB4_SEL_VALUE;
	M0P_GPIO->PB05_SEL = PB5_SEL_VALUE;
	M0P_GPIO->PB06_SEL = PB6_SEL_VALUE;	
	M0P_GPIO->PB07_SEL = PB7_SEL_VALUE;	
	M0P_GPIO->PB08_SEL = PB8_SEL_VALUE;	
	M0P_GPIO->PB09_SEL = PB9_SEL_VALUE;	
	M0P_GPIO->PB10_SEL = PB10_SEL_VALUE;	
	M0P_GPIO->PB11_SEL = PB11_SEL_VALUE;		
	M0P_GPIO->PB12_SEL = PB12_SEL_VALUE;		
	M0P_GPIO->PB13_SEL = PB13_SEL_VALUE;		
	M0P_GPIO->PB14_SEL = PB14_SEL_VALUE;			
	M0P_GPIO->PB15_SEL = PB15_SEL_VALUE;	

	M0P_GPIO->PC00_SEL = PC0_SEL_VALUE;
	M0P_GPIO->PC01_SEL = PC1_SEL_VALUE;
	M0P_GPIO->PC02_SEL = PC2_SEL_VALUE;
	M0P_GPIO->PC03_SEL = PC3_SEL_VALUE;
	M0P_GPIO->PC04_SEL = PC4_SEL_VALUE;
	M0P_GPIO->PC05_SEL = PC5_SEL_VALUE;
	M0P_GPIO->PC06_SEL = PC6_SEL_VALUE;	
	M0P_GPIO->PC07_SEL = PC7_SEL_VALUE;	
	M0P_GPIO->PC08_SEL = PC8_SEL_VALUE;	
	M0P_GPIO->PC09_SEL = PC9_SEL_VALUE;	
	M0P_GPIO->PC10_SEL = PC10_SEL_VALUE;	
	M0P_GPIO->PC11_SEL = PC11_SEL_VALUE;		
	M0P_GPIO->PC12_SEL = PC12_SEL_VALUE;		
	M0P_GPIO->PC13_SEL = PC13_SEL_VALUE;		
	M0P_GPIO->PC14_SEL = PC14_SEL_VALUE;			
	M0P_GPIO->PC15_SEL = PC15_SEL_VALUE;	

	M0P_GPIO->PD00_SEL = PD0_SEL_VALUE;
	M0P_GPIO->PD01_SEL = PD1_SEL_VALUE;
	M0P_GPIO->PD02_SEL = PD2_SEL_VALUE;
	M0P_GPIO->PD03_SEL = PD3_SEL_VALUE;
	M0P_GPIO->PD04_SEL = PD4_SEL_VALUE;
	M0P_GPIO->PD05_SEL = PD5_SEL_VALUE;
	M0P_GPIO->PD06_SEL = PD6_SEL_VALUE;	
	M0P_GPIO->PD07_SEL = PD7_SEL_VALUE;	
}	

/******************************
**Name: vMcuClockInit
**Func: ��ʼ������MCU 24M
*Input: None
Output: None
********************************/
en_result_t vMcuClockInit(void)
{
	en_result_t enRet = Ok;
  	stc_sysctrl_clk_cfg_t clk_sel;
	
	Flash_WaitCycle(FlashWaitCycle1);							//Flash_CR->WAIT 24-48MHz
	
	Sysctrl_ClkSourceEnable(SysctrlClkRCH, TRUE);    			//enable RCH Clock	
    Sysctrl_SetRCHTrim(SysctrlRchFreq24MHz);					//����24MHz RCH

	clk_sel.enClkSrc  = SysctrlClkRCH;
	clk_sel.enHClkDiv = SysctrlHclkDiv1;
	clk_sel.enPClkDiv = SysctrlPclkDiv1;
	enRet = Sysctrl_ClkInit(&clk_sel);	
	
	Sysctrl_ClkSourceEnable(SysctrlClkXTH, FALSE);    			//disable XTH Clock
    Sysctrl_ClkSourceEnable(SysctrlClkPLL, FALSE);				//disable PLL

	// ## enable XTL, 32768Hz
	//Sysctrl_XTLDriverCfg(SysctrlXtlAmp3, SysctrlXtalDriver3);
    //Sysctrl_SetXTLStableTime(SysctrlXtlStableCycle16384);	
	//Sysctrl_ClkSourceEnable(SysctrlClkXTL, TRUE);				//enable XTL

	// ## disable XTL
    Sysctrl_ClkSourceEnable(SysctrlClkXTL, FALSE);	
	
	// ## enable RCL, 32kHz	
	Sysctrl_SetRCLStableTime(SysctrlRclStableCycle256);
	Sysctrl_SetRCLTrim(SysctrlRclFreq32768);                	//�����ڲ�����ʱ��32.768kHz
	Sysctrl_ClkSourceEnable(SysctrlClkRCL, TRUE);				//enable RCL

	// ## disable RCL
	//Sysctrl_ClkSourceEnable(SysctrlClkRCL, FALSE);

	return(enRet);
}

en_result_t vMcuSwitchXtalH(void)
{
	en_result_t enRet = Ok;
	stc_sysctrl_clk_cfg_t clk_sel;
	
	Flash_WaitCycle(FlashWaitCycle1);							//Flash_CR->WAIT 24-48MHz

	Sysctrl_ClkSourceEnable(SysctrlClkXTH, TRUE);    			//enable XTH Clock	
	Sysctrl_SetXTHFreq(SysctrlXthFreq20_32MHz);
	
	clk_sel.enClkSrc  = SysctrlClkXTH;
	clk_sel.enHClkDiv = SysctrlHclkDiv1;
	clk_sel.enPClkDiv = SysctrlPclkDiv1;

	enRet = Sysctrl_ClkInit(&clk_sel);	

	Sysctrl_ClkSourceEnable(SysctrlClkRCH, FALSE);    			//disable RCH Clock	
	return(enRet);
}	


en_result_t vMcuSwitchRCH(void)
{
	en_result_t enRet = Ok;
	stc_sysctrl_clk_cfg_t clk_sel; 

	Flash_WaitCycle(FlashWaitCycle1);							//Flash_CR->WAIT 24-48MHz

	Sysctrl_ClkSourceEnable(SysctrlClkRCH, TRUE);    			//enable RCH Clock	
    Sysctrl_SetRCHTrim(SysctrlRchFreq24MHz);					//����24MHz RCH

	clk_sel.enClkSrc  = SysctrlClkRCH;
	clk_sel.enHClkDiv = SysctrlHclkDiv1;
	clk_sel.enPClkDiv = SysctrlPclkDiv1;
	enRet = Sysctrl_ClkInit(&clk_sel);	
	
	Sysctrl_ClkSourceEnable(SysctrlClkXTH, FALSE);    			//disable XTH Clock
	
	return(enRet);
}

en_result_t vMcuSwitchPLL(void)
{
	en_result_t enRet = Ok;
	
	stc_sysctrl_clk_cfg_t stcCfg;
    stc_sysctrl_pll_cfg_t stcPLLCfg;    
    
    Sysctrl_SetPeripheralGate(SysctrlPeripheralFlash, TRUE);
    
    Flash_WaitCycle(FlashWaitCycle2);
    
    Sysctrl_SetRCHTrim(SysctrlRchFreq4MHz);             
    
    stcPLLCfg.enInFreq    = SysctrlPllInFreq4_6MHz;     //RCH 4MHz
    stcPLLCfg.enOutFreq   = SysctrlPllOutFreq36_48MHz;  //PLL Range 36-48MHz
    stcPLLCfg.enPllClkSrc = SysctrlPllRch;              //
    stcPLLCfg.enPllMul    = SysctrlPllMul10;            //4MHz x 10 = 40MHz
    Sysctrl_SetPLLFreq(&stcPLLCfg);       
    
    stcCfg.enClkSrc  = SysctrlClkPLL;
    stcCfg.enHClkDiv = SysctrlHclkDiv1;
    stcCfg.enPClkDiv = SysctrlPclkDiv1;
    enRet = Sysctrl_ClkInit(&stcCfg);     
	return(enRet);
}

/******************************
**Name: vTrngGenerate
**Func: ���������
**Input: None
*Output: None
********************************/
void vEnableTrngSrc(void)
{
 Sysctrl_SetPeripheralGate(SysctrlPeripheralRng, TRUE);	
 M0P_TRNG->CR_f.RNGCIR_EN = 1;
}	

void vDisableTrngSrc(void)
{
 M0P_TRNG->CR_f.RNGCIR_EN = 0;
 Sysctrl_SetPeripheralGate(SysctrlPeripheralRng, FALSE);	
}	

void vTrngGenerate(byte cnt, byte xor_en, byte t_rng)
{	
	if(t_rng!=0)
		M0P_TRNG->MODE_f.LOAD    = 1;		//�����
    else
		M0P_TRNG->MODE_f.LOAD    = 0;		//α���
		
	if(xor_en!=0)
		M0P_TRNG->MODE_f.FDBK    = 1;		//���
    else
		M0P_TRNG->MODE_f.FDBK    = 0;		//�����
	
	if(cnt<=6)
		M0P_TRNG->MODE_f.CNT     = cnt;
	else
		M0P_TRNG->MODE_f.CNT     = 6;
	
    M0P_TRNG->CR_f.RNG_RUN   = 1;
    while(M0P_TRNG->CR_f.RNG_RUN);
}


