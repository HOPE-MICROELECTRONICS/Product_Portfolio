#include "cmt2310a_eb.h"

/*******************************************************************************
 * TIM0 interrupt
 ******************************************************************************/
void TIM0_IRQHandler(void)
{
 if(TRUE == Bt_GetIntFlag(TIM0, BtUevIrq))
	{
	g_systimer++;	
	g_keytimer++;
	g_uhf_timer++;
    Bt_ClearIntFlag(TIM0,BtUevIrq); 				
	}
}

/*******************************************************************************
 * PORT D
 ******************************************************************************/
void PORTD_IRQHandler(void)
{
 Gpio_ClearIrq(STK_USER_PORT, STK_USER_PIN);	
}

/******************************************************************************
 * LP Timer 
******************************************************************************/
void LPTIM_IRQHandler(void)
{
 g_lptimer++;	
 Lptim_ClrItStatus(M0P_LPTIMER);
}


/*****************************************************************************
 ** \brief NVIC
 ** \param [in]  enIrq         
 ** \param [in]  enLevel  
 ** \param [in]  bEn      
 ** \retval      Ok      
 ******************************************************************************/
void EnableNvic(IRQn_Type enIrq, en_irq_level_t enLevel, boolean_t bEn)
{
 NVIC_ClearPendingIRQ(enIrq);
 NVIC_SetPriority(enIrq, enLevel);
 if (TRUE == bEn)
  	NVIC_EnableIRQ(enIrq);
 else
    NVIC_DisableIRQ(enIrq);
}

