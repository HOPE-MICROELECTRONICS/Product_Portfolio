#include "cmt2310a_eb.h"

const unsigned char g_title_string[] = {"2310A  FixedPktTRx"};


boolean_t 	g_key_press_F;
boolean_t	g_menu_change_F;				//menu ative flag: 0=none,     1=changed
boolean_t	g_trx_master_F;					//run mode flag:   0=Master,   1=Slave
boolean_t	g_work_mode_F;					//work ative flag: 0=Standby,  1=Running	
boolean_t	g_menu_pause_F;					//
boolean_t	g_tx_finish_F;
boolean_t	g_master_wait_respond_F;

word 		g_keytimer;
byte		g_key_value;
byte 		g_trig_rssi;

void vDispClearLine(byte line)
{
	byte i;
	for(i=0; i<18; i++)
		vLcdPrintOther(line, i, 0);
}

void vDispRssi(byte rssi)
{
	byte i;
	byte num;
	byte j;
	
	if(rssi&0x80)
		{
		vLcdPrintOther(6, 11, 13);				//'-'
		rssi ^= 0xFF;
		rssi += 1;
		}
	else
		vLcdPrintOther(6, 11, 11);				//'+'
 		
	for(i=100, num=12; i!=0; i/=10)
		{
		j = rssi/i;
		rssi %= i;
		vLcdPrintNumber(6, num++, j);
		}
	vLcdPrintLowercase(6, num++, 'd'-'a');
	vLcdPrintCapital(6, num++,  'B'-'A');	
	vLcdPrintLowercase(6, num++, 'm'-'a');	
}

void vDispRxCounter(void)
{
	vDispClearLine(6);
	vLcdPrintLowercase(6, 0, ('r'-'a'));	
	vLcdPrintLowercase(6, 1, ('x'-'a'));
	vLcdPrintOther(6, 2, 16);					//':'										
	vLcdPrintCounter(6, 3, g_rx_count);	
}

void vDispTxCounter(void)
{
	vDispClearLine(5);
	vLcdPrintLowercase(5, 0, ('t'-'a'));	
	vLcdPrintLowercase(5, 1, ('x'-'a'));
	vLcdPrintOther(5, 2, 16);					//':'						
	vLcdPrintCounter(5, 3, g_tx_count);	
}


//*************************************************************************************************
//Menu Api
//*************************************************************************************************
void vDispOp1Menu(void)							
{
	vDispClearLine(8);
	vLcdPrintCapital(8, 0, ('T'-'A'));
	vLcdPrintLowercase(8, 1, ('x'-'a'));

	vLcdPrintCapital(8, 4, ('R'-'A'));
	vLcdPrintLowercase(8, 5, ('x'-'a'));

	vLcdPrintOther(8, 8, 34); 							//back
    vLcdPrintCapital(8, 14, ('R'-'A'));
	vLcdPrintLowercase(8, 15, ('s'-'a'));
	vLcdPrintLowercase(8, 16, ('s'-'a'));
	vLcdPrintLowercase(8, 17, ('i'-'a'));
}

void vDispOpRxStopMenu(void)
{
	vDispClearLine(8);
	vLcdPrintOther(8, 0, 38); 							//stop	
	vLcdPrintOther(8, 4, 34); 							//back
	vLcdPrintCapital(8, 14, ('R'-'A'));					//Rssi
	vLcdPrintLowercase(8, 15, ('s'-'a'));
	vLcdPrintLowercase(8, 16, ('s'-'a'));
	vLcdPrintLowercase(8, 17, ('i'-'a'));
}

void vDispOp6Menu(void)								
{
	vDispClearLine(8);
	if(g_trx_master_F)
		vLcdPrintOther(8, 0, 38); 						//when it is Master, it can be Pause
	vLcdPrintOther(8, 4, 34); 							//back
	vLcdPrintCapital(8, 14, ('R'-'A'));
	vLcdPrintLowercase(8, 15, ('s'-'a'));
	vLcdPrintLowercase(8, 16, ('s'-'a'));
	vLcdPrintLowercase(8, 17, ('i'-'a'));		
}

void vDispOpTxStopMenu(void)
{
	vDispClearLine(8);
	vLcdPrintOther(8, 0, 38); 							//stop	
	vLcdPrintOther(8, 4, 34); 							//back
}	

void vMeumStandby(byte key)
{
	switch(key)
		{
		case 1:
			switch(g_key_value)
				{
				case 0x01:								//enter to tx
					g_work_mode_F   = TRUE;
					g_menu_change_F = TRUE;
					g_trx_master_F  = TRUE;
					g_menu_pause_F  = FALSE;
					g_tx_finish_F   = FALSE;
					g_tx_count = 0;
					g_rx_count = 0;
					break;
				case 0x02:								//enter to rx
					g_work_mode_F   = TRUE;
					g_menu_change_F = TRUE;
					g_trx_master_F  = FALSE;
					g_menu_pause_F  = FALSE;
					g_tx_count   = 0;
					g_rx_count   = 0;
					break;
				case 0x04:
					g_work_mode_F = FALSE;				//return to main menu
					g_menu_change_F = TRUE;
					bRadioGoStandby();
					break;
				default:
					break;
				}
			break;
		default:
			break;
		}	
}

void vMeumMasterSending(byte key)
{
	switch(key)
		{
		case 1:
			switch(g_key_value)
				{
				case 0x01:								//pause/start
					if(!g_menu_pause_F)
						g_menu_pause_F = TRUE;
					else
						g_menu_pause_F = FALSE;
					break;
				case 0x02:
					g_work_mode_F   = FALSE;			//back to 2nd menu
					g_menu_change_F = TRUE;
					vDispClearLine(5);				
					break;
				default:
					break;
				}
			break;
		default:
			break;
		}
 	
	if(g_tx_count>=9999)									//max. times 
		{
		if(!g_tx_finish_F)
			{
			g_tx_finish_F = TRUE;	
			vBeep();
			vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
			vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_TH);				
			vRadioClearTxFifo();	
			bRadioGoStandby();		
			}
		}	
	else
		{
		if(!g_menu_pause_F)
			{
			if(!g_master_wait_respond_F)
				{	
				vGetRandomTxBuf();
				vActiveTransmit();
				vDispTxCounter();
				g_master_wait_respond_F = TRUE;				//Master switch to rx_mode for receive Slave return back packet
				vRadioSetPayloadLength(&g_radio.frame_cfg);		
				vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
				vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_TH);	
				vRadioClearRxFifo();	
				vRadioRssiUpdateSel(CMT2310A_RSSI_UPDATE_SYNC_OK);	
				bRadioGoRx();	
				g_rx_ptr = 0;
				g_uhf_timer = 0;
				}
			else
				{
				if(g_uhf_timer<500)							//receive limit for 5s
					{
					if(RF_GPIO4_H())
						{
						SET_LED3();							//indicate one packet was received
						g_trig_rssi = bRadioGetRssi();		//when PKT_DONE_EXIT_EN=0, it is still in RxMode, so that Rssi can be readout 
						bRadioGoStandby();
						vRadioReadAllStatus();
						if(g_radio.frame_cfg.PAYLOAD_LENGTH>=UHF_FIFO_TH)
							vRadioReadFifo(&g_radio_rx_buf[g_rx_ptr], (g_radio.frame_cfg.PAYLOAD_LENGTH-g_rx_ptr));
						else
							vRadioReadFifo(g_radio_rx_buf, g_radio.frame_cfg.PAYLOAD_LENGTH);
						if(bCmpTRxBuffer())
							{
							SET_LED2();						//indicate packet return from Slave is right
							g_rx_count++;
							}
						vRadioClearRxFifo();								
						vRadioClearInterrupt();
						vDispRxCounter();	
						vDispRssi(g_trig_rssi);
						vDelayNms(5);
						g_master_wait_respond_F = FALSE;
						CLR_LED2();
						CLR_LED3();
						}
				
					if(RF_GPIO1_H()&&((g_radio.frame_cfg.PAYLOAD_LENGTH-g_rx_ptr)>UHF_FIFO_TH))					//Rx FIFO reach threshold
						{
						SET_LED3();	
						vRadioReadFifo(&g_radio_rx_buf[g_rx_ptr], UHF_FIFO_TH);
						g_rx_ptr += UHF_FIFO_TH;	
						}
					}
				else
					g_master_wait_respond_F = FALSE;						
				}	
			}
		}			
}

void vMenuSlaveReceiving(byte key)
{

	switch(key)
		{
		case 1:
			switch(g_key_value)
				{
				case 0x01:								//pause/start
					if(!g_menu_pause_F)
						{
						g_menu_pause_F = TRUE;
						bRadioGoStandby();
						}
					else
						{
						g_menu_pause_F = FALSE;
						}
					break;	
				case 0x02:
					g_work_mode_F = FALSE;				//back to 2nd menu
					g_menu_change_F = TRUE;
					bRadioGoStandby();
					return;
				default:
					break;
				}
			break;
		case 3:											//holding press
			switch(g_key_value)
				{
				case 0x10:
					if(g_rx_count==0)
						{	
						vRadioRssiUpdateSel(CMT2310A_RSSI_UPDATE_ALWAYS);							
						vDispRssi(bRadioGetRssi());
						vRadioRssiUpdateSel(CMT2310A_RSSI_UPDATE_SYNC_OK);							
						}
					break;
				default:
					break;
				}
			break;			
		default:
			break;
		}
	
	if(RF_GPIO4_H())
		{
		SET_LED3();										//indicate one packet was received
		g_trig_rssi = bRadioGetRssi();					//when PKT_DONE_EXIT_EN=0, it is still in RxMode, so that Rssi can be readout 
		bRadioGoStandby();
		vRadioReadAllStatus();

		if(g_radio.frame_cfg.PAYLOAD_LENGTH>=UHF_FIFO_TH)
			vRadioReadFifo(&g_radio_rx_buf[g_rx_ptr], (g_radio.frame_cfg.PAYLOAD_LENGTH-g_rx_ptr));
		else
			vRadioReadFifo(g_radio_rx_buf, g_radio.frame_cfg.PAYLOAD_LENGTH);
			
		if(g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_EN==1)
			{
			vRadioInterruptSoucreFlag(&g_radio.int_src_flag);
			if(g_radio.int_src_flag._BITS.CRC_PASS_FLG==1)
				vRespondTransmit();
			}
		else
			vRespondTransmit();

		vRadioClearRxFifo();	
		vRadioClearInterrupt(); 
		vRadioSetInt1Sel(CMT2310A_INT_PKT_DONE);
		vRadioSetInt2Sel(CMT2310A_INT_RX_FIFO_TH);	
		vRadioRssiUpdateSel(CMT2310A_RSSI_UPDATE_SYNC_OK);	
		vDispRxCounter();	
		vDispRssi(g_trig_rssi);
		g_rx_ptr = 0;
		bRadioGoRx();
		CLR_LED2();
		CLR_LED3();
		} 	
	
	if(RF_GPIO1_H()&&((g_radio.frame_cfg.PAYLOAD_LENGTH-g_rx_ptr)>UHF_FIFO_TH))					//Rx FIFO reach threshold
		{
		SET_LED3();	
		vRadioReadFifo(&g_radio_rx_buf[g_rx_ptr], UHF_FIFO_TH);
		g_rx_ptr += UHF_FIFO_TH;	
		}
}

void vActiveTransmit(void)								
{
	word rd_ptr;
	
	SET_LED1();
	vRadioSetInt1Sel(CMT2310A_INT_TX_DONE);
	vRadioSetInt2Sel(CMT2310A_INT_TX_FIFO_TH);	
	g_radio.frame_cfg.PAYLOAD_LENGTH = UHF_LEN;
	vRadioSetPayloadLength(&g_radio.frame_cfg);
 
	if(g_radio.frame_cfg.PAYLOAD_LENGTH>=UHF_FIFO_TH)	
		vRadioWriteFifo(g_radio_tx_buf, UHF_FIFO_TH);	
	else
		vRadioWriteFifo(g_radio_tx_buf, g_radio.frame_cfg.PAYLOAD_LENGTH);
	rd_ptr	= UHF_FIFO_TH;
	bRadioGoTx();
 
	for(g_systimer=0; g_systimer<LIMIT_TIMER_TX_CNT; )
		{
		if(RF_GPIO4_H())
			{
			bRadioGoStandby();
			vRadioClearTxFifo();
			vRadioClearInterrupt();
			g_tx_count++;
			break;
			}
		while(RF_GPIO1_L()&&(rd_ptr<g_radio.frame_cfg.PAYLOAD_LENGTH))
			bRadioWriteReg(CMT2310A_FIFO_RW_PORT, g_radio_tx_buf[rd_ptr++]);		
		}
	if(g_systimer>=LIMIT_TIMER_TX_CNT)
		bRadioGoStandby();
	CLR_LED1();
}	

void vRespondTransmit(void)										
{
 	word i;

	SET_LED2();	
	for(i=0; i<g_radio.frame_cfg.PAYLOAD_LENGTH; i++)			
		g_radio_tx_buf[i] = g_radio_rx_buf[i];	
	g_rx_count++;
 	vDelayNms(5);
 	vActiveTransmit();
}	

boolean_t bCmpTRxBuffer(void)
{
	word i;

	if(g_radio.crc_cfg.CRC_CFG_u._BITS.CRC_EN==1)
		{
		if(g_radio.int_src_flag._BITS.CRC_PASS_FLG==1)	
			{
			for(i=0; i<g_radio.frame_cfg.PAYLOAD_LENGTH; i++)
				{
				if(g_radio_tx_buf[i]!=g_radio_rx_buf[i])	
					break;
				}
			if(i>=g_radio.frame_cfg.PAYLOAD_LENGTH)	
				return(TRUE);
			else
				return(FALSE);		
			}
		else
			return(FALSE);
		}
	else
		{
		for(i=0; i<g_radio.frame_cfg.PAYLOAD_LENGTH; i++)
			{
			if(g_radio_tx_buf[i]!=g_radio_rx_buf[i])	
				break;
			}
		if(i>=g_radio.frame_cfg.PAYLOAD_LENGTH)	
			return(TRUE);
		else
			return(FALSE);		
		}
}	


//*************************************************************************************************
//keyboard
//*************************************************************************************************
byte bKeyScan(void)										//return: 1=single short press, 2=holding, 3=long press, 0=none
{											
	byte key = 0;

	key = bReadKey();
 
	if(key!=0)
		{
		if(g_key_press_F==0)							//first trigger
			{
			g_keytimer = 0;
			do
				{
				if(bReadKey()==0)
					break;
				vDelayNms(5);
				}while(g_keytimer<5);
			if(g_keytimer>=5)
				{
				g_key_press_F = 1;
				g_key_value = bReadKey();
				return(1);								//first trigger confirm
				}	
			else
				{
				g_key_press_F = 0;	
				return(0);
				}
			}
		else											//keep press
			{
			if(key==g_key_value)						//holding
				{
				if(g_keytimer>=200)
					{
					g_keytimer = 200;	
					return(3);							//confirm to long press
					}
				else
					return(2);							//holding
				}
			else										//change press
				{	
				g_keytimer = 0;							
				g_key_value = key;
				return(1);	
				}
			}
		}
	else												//none press
		{
		g_key_press_F = 0;
		return(0);	
		}
}

byte bReadKey(void)
{
	byte key = 0;

	if(KEY1_PRESS())
		key |= 0x01;
	if(KEY2_PRESS())
		key |= 0x02;
	if(KEY3_PRESS())
		key |= 0x04;
	if(KEY4_PRESS())
		key |= 0x08;
	if(KEY5_PRESS())
		key |= 0x10;

	return(key);
}

