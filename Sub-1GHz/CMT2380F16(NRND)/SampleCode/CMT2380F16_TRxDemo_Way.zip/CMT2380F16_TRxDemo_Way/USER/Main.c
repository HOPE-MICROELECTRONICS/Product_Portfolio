#include "CMT2380F16_TRxDemo.h"

void main(void)
{
    MCU_Init();
    for(SysTime=0;SysTime<30;);

    CMT2300Iint();              //��ʼ��2300
    GO_RX();

    if(!TestKey1())             //����ģʽ
    {
        for(SysTime=0;SysTime<30;)
        {
            if(TestKey1())
            break;
        }
        if(SysTime>=30)
        TestMode();
    }


    while(1)
    {
        KeyScan();          
        if(Key_OK)
        {
            KeyDelay();
        }
        else if(Pack_OK)
        {
            RxOKDelay();
        }
        if(ResetTime>20000)
        {
            CMT2300Iint();
            GO_RX();
        }
    }  
}

