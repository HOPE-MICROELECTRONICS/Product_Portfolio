/************************************************************************************************
���ܣ� ����K1�ϵ�������ģʽ��LED���������뵥�ز����䣬���ڲ��Է��书�ʡ�
       �ٴΰ��°�����LED��˸���������״̬,GPIO3ӳ�����ݣ����ڲ��������ȡ�
       ��̬����Ϊ����״̬���յ���Ч��ʱ�������һش�ͬ����Ϣ��
       ��̬����ʱ���°������������ݰ���Ȼ��ȴ����ն˻�Ӧ���ɹ��õ���Ӧ����������5�Ρ�
*************************************************************************************************/

#ifndef	_CMT2380F16_TRxDemo_H
#define	_CMT2380F16_TRxDemo._H
#include <intrins.h>
#include "CMT2380F16.h"
#include "CMT2300A_Register.h"
typedef unsigned char byte;
typedef unsigned int  word;
typedef unsigned long lword;

typedef union 				
{
 struct 
 	{
 	byte  _FlagBit0:1;		
 	byte  _FlagBit1:1;	 		
 	byte  _FlagBit2:1;			
 	byte  _FlagBit3:1;			
 	byte  _FlagBit4:1;			
 	byte  _FlagBit5:1;		
 	byte  _FlagBit6:1;			
 	byte  _FlagBit7:1;			
 	}BBITS;
 byte BBYTE;
}FlagSTR;

/***********************************************************
**ϵͳ����
***********************************************************/
#define SFR_IAP_Read()      (IFMT=0x01)
#define SFR_IAP_Write()     (IFMT=0x02)
#define SFR_IAP_ClrBank()   (IFMT=0x03)
#define SFR_Read()          (IFMT=0x05)
#define SFR_Write()         (IFMT=0x04)         
#define SFR_STB()           (IFMT=0x00)
#define Bank0()             (SFRPI=0x00)
#define Bank1()             (SFRPI=0x01)
#define Bank2()             (SFRPI=0x02)
#define Bank3()             (SFRPI=0x03)
#define CLRWDT()            (WDTCR|=CLRW) //ι��

//RF��
#define CMT_Bank_Origin     0x00     //CMT�������
#define CMT_Bank_End        0x0B     //CMT�����յ�

#define System_Origin       0x0C    //System�������
#define System_End          0x17    //System�����յ�

#define Frequency_Origin    0x18    //Frequency�������
#define Frequency_End       0x1F    //Frequency�����յ�

#define Data_Rete_Origin    0x20    //Data_Rete�������
#define Data_Rete_End       0x37    //Data_Rete�����յ�

#define Baseband_Origin     0x38    //Baseband�������
#define Baseband_End        0x54    //Baseband�����յ�

#define TX_Origin           0x55    //TX�������
#define TX_End              0x5F    //TX�����յ�

#define PackNum_N            0x56
#define SyncNum_N            0x23
/***********************************************************
**���Ŷ���	 					   	 				
***********************************************************/
//P1                            //  P1   PxM0.y  PxM1.y 
  #define KEY1      0x01        //  1       1        1   
  #define KEY2      0x02        //  1       1        1   
  #define KEY3     	0x04        //  1       1        1   
  #define FCSB      0x08        //  1       1        0   
  #define CSB       0x10        //  1       1        0  
  #define SDIO      0x20        //  0       1        0	 
//#define           0x40        //  0       1        0  
  #define SCLK      0x80        //  0       1        0

//P2                            //  P2   PxM0.y  PxM1.y 
//#define           0x01        //  0       1        0  
//#define           0x02        //  0       1        0   
  #define GPIO1     0x04        //  1       0        0   
//#define         	0x08        //  0       1        0   
  #define GPIO2     0x10        //  1       0        0  
//#define        	0x20        	//  0       1        0	  
  #define LED1      0x40        //  0       1        0   
//#define           0x80        //  0       1        0 

//P3                            //  P3   PxM0.y  PxM1.y 
//#define           0x01        //  0       0        1   
//#define           0x02        //  0       0        1   
//#define          	0x04        //  0       0        1   
  #define LED2      0x08        //  0       0        1   
//#define           0x10        //  0       0        1  
//#define           0x20        //  0       0        1	
//#define           0x40        //  0       0        1   
//#define           0x80        //  0       0        1

//P4                            //  P4   PxM0.y  PxM1.y 
//#define           0x01        //  0       1        0  
//#define           0x02        //  0       1        0  
//#define          	0x04        //  0       1        0   
//#define         	0x08        //  0       1        0   
//#define           0x10        //  0       1        0  
//#define        	0x20        	//  0       1        0	  
//#define           0x40        //  0       1        0   
//#define           0x80        //  0       1        0

//P6                            //  P6   PxM0.y  PxM1.y 
//#define           0x01        //  0       1        0   
  #define BUZZ      0x02        //  0       1        0

#define	FCSB_H()    (P1|=FCSB)
#define	FCSB_L()    (P1&=(~FCSB))

#define	CSB_H()	    (P1|=CSB)
#define	CSB_L()	    (P1&=(~CSB))

#define	SCLK_H()	(P1|=SCLK)
#define	SCLK_L()	(P1&=(~SCLK))

#define	SDIO_H()	(P1|=SDIO)
#define	SDIO_L()	(P1&=(~SDIO))

#define	SetLed1()	(P2|=LED1)
#define	ClrLed1()	(P2&=(~LED1))

#define	SetLed2()	(P3|=LED2)
#define	ClrLed2()	(P3&=(~LED2))

#define	SetBuzz()	(P6|=BUZZ)
#define	ClrBuzz()	(P6&=(~BUZZ))

#define SDIO_Oput() (P1&=(~SDIO)); \
                    (P1M0|=SDIO)
 
#define	SDIO_Intput() (P1M0&=(~SDIO)); \
                      (P1|=SDIO)

#define Test_SDIO() (P1&SDIO)
#define Test_GPIO1()(P2&GPIO1)
#define Test_GPIO2()(P2&GPIO2)
#define TestKey1()  (P1&KEY1)
#define TestKey2()  (P1&KEY2)
#define TestKey3()  (P1&KEY3)



#define P1_Data     0x3F
#define P2_Data     0x14
#define P3_Data     0x00
#define P4_Data     0x00
#define P6_Data     0x00

#define P1M0_Data   0xFF      
#define P2M0_Data   0xEB      
#define P3M0_Data   0x00      
#define P4M0_Data   0xFF
#define P6M0_Data   0xFF

#define P1M1_Data   0x07      
#define P2M1_Data   0x00      
#define P3M1_Data   0xFF      
#define P4M1_Data   0x00      
#define P6M1_Data   0x00


extern  FlagSTR  _System_F; 			
#define System_F        _System_F.BBYTE
#define Key_OK			_System_F.BBITS._FlagBit0     
#define Key_Lost        _System_F.BBITS._FlagBit1
#define Pack_OK         _System_F.BBITS._FlagBit2
#define Sync_OK         _System_F.BBITS._FlagBit3

extern  FlagSTR  _LedTime; 				
#define LedTime        _LedTime.BBYTE
#define LedTime0	   _LedTime.BBITS._FlagBit0
#define LedTime1	   _LedTime.BBITS._FlagBit1
#define LedTime2	   _LedTime.BBITS._FlagBit2
#define LedTime3	   _LedTime.BBITS._FlagBit3
#define LedTime4	   _LedTime.BBITS._FlagBit4
#define LedTime5	   _LedTime.BBITS._FlagBit5
#define LedTime6	   _LedTime.BBITS._FlagBit6
#define LedTime7	   _LedTime.BBITS._FlagBit7
     

//����
extern word SysTime;
extern byte xdata CMT_Bank[12];
extern byte xdata System_Bank[12];
extern byte xdata Frequency_Bank[8];
extern byte xdata Data_Rate_Bank[24];
extern byte xdata Baseband_Bank[29];
extern byte xdata TX_Bank[11];
extern byte TXCode;
extern byte KeyCode;
extern byte WorkTime;
extern byte TX_Buf[2];
extern byte CompareBuf;
extern word BuzzTime;
extern word ResetTime;

//KeyScan.c
extern byte ReadKey(void);
extern void KeyDelay(void);
extern void KeyScan(void);
extern void TestMode(void);
extern void RxOKDelay(void);

//CMT2300_Config.c
extern void CMT2300Iint(void);
extern void Write_SPI8Bit(byte Data);
extern void SPI_Write(byte adder,byte Data);
extern byte Read_SPI8Bit(void);
extern byte SPI_Read(byte Data);
extern void Reset(void);
extern void GO_SLEEP(void);
extern void GO_STBY(void);
extern void GO_RX(void);
extern void GO_TX(void);
extern void Clr_FIFO(void);
extern void Clr_INT(void);
extern byte Read_FIFO(void);
extern void Write_FIFO(byte date);
extern void Send_Pack(byte Str[],byte length,byte Pack_Cnt);
//Base.c
extern void Write_P_Register(byte Adder,byte Data);
extern void MCU_Config(void);
extern void IO_Init(void);
extern void Time0_Init(void);
extern void MCU_Init(void);
extern void Delay(word Cont);   
extern void BuzzLoop(byte cnt);


#endif
