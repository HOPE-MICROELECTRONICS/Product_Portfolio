#include "spi3.h"
#include "gpio_def.h"

void SPI_delay(void)
{
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_(); 
}

void SPI3_Init(void)
{
	SPI_CSB_H(); 
	SPI_SDA_H();  
	SPI_SCK_L();
	SPI_FCSB_H();
	
	SPI_CSB_PUSH_PULL();
	SPI_SCK_PUSH_PULL();
	SPI_SDA_PUSH_PULL();
	SPI_FCSB_PUSH_PULL();

	SPI_CSB_H(); 
	SPI_SDA_H();
	SPI_SCK_L();
	SPI_FCSB_H();
}
 
U8 SPI_SendByte_3lin(U8 m_data)
{
	U8 i;
	U8 spiData = m_data; 
 
	for (i = 0; i < 8; i++)
	{ 
		SPI_SCK_L();
		if(spiData & 0x80)
		{
			SPI_SDA_H();
		}
		else
		{
			SPI_SDA_L();
		}
		spiData <<= 1;
		
		SPI_delay(); 
		SPI_SCK_H(); 
		SPI_delay();
	}
	
	return(spiData);
}
 
U8 SPI_ReadByte_3lin()
{
	U8 i;
	U8 spiData = 0xFF;
 
	for (i = 0; i < 8; i++)
	{ 
		SPI_SCK_L();
		spiData = spiData << 1;
		SPI_delay();

		SPI_SCK_H();

		if (SPI_GET_SDA())
		{
			spiData |= 1;
		}
		else
		{
			spiData &= 0xFE;
		} 
		SPI_delay();
	} 


	return(spiData);
}
 
U8 SPI3_ReadByte(U8 ReadAddress, U8* pBuffer, U8 len)
{
	U8 length = len;

	ReadAddress |= 0x80;

	SPI_SDA_H();
	SPI_SDA_PUSH_PULL();
	
	SPI_SCK_L();
	SPI_SCK_PUSH_PULL();
	SPI_SCK_L();
	
	SPI_FCSB_H();
	SPI_FCSB_PUSH_PULL();
	SPI_FCSB_H();
	
	SPI_CSB_L();
	SPI_delay();
	SPI_delay();
	SPI_SendByte_3lin(ReadAddress);
	SPI_SDA_H();
	SPI_SDA_OPEN_DRAIN();
	
	while(length)
	{ 
		*pBuffer = SPI_ReadByte_3lin();
		pBuffer++;
		length--;
	}

	SPI_SCK_L();
	SPI_delay();
	SPI_delay();

	SPI_CSB_H();
	SPI_delay();
 
	SPI_SDA_H();
	SPI_SDA_OPEN_DRAIN();
	
	SPI_FCSB_H();
	SPI_FCSB_OPEN_DRAIN();
	
	return 1;
}

U8 SPI3_WriteByte(U8 WriteAddress, U8 SendByte)
{
	WriteAddress |= 0x00;

	SPI_SDA_H();
	SPI_SDA_PUSH_PULL();
	
	SPI_SCK_L();
	SPI_SCK_PUSH_PULL();
	SPI_SCK_L();
	
	SPI_FCSB_H();
	SPI_FCSB_PUSH_PULL();
	SPI_FCSB_H();
	
	SPI_CSB_L();
	SPI_delay();
	SPI_delay();
	SPI_SendByte_3lin(WriteAddress); 
	SPI_SendByte_3lin(SendByte);
	
	SPI_SCK_L();
	SPI_delay();
	
	SPI_delay();
	SPI_CSB_H();
	
	SPI_SDA_H();
	SPI_SDA_OPEN_DRAIN();
	
	SPI_FCSB_H();
	SPI_FCSB_OPEN_DRAIN();
	
	return 1;
}

