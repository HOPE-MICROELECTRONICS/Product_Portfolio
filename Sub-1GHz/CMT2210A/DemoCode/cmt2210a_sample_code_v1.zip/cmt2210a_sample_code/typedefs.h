/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * \file        typedefs.c
 * \brief       datatype related functions
 *
 * \version     1.0
 * \date        Mar 26 2013
 * \author     CMOSTEK R@D
 */



#ifndef __CMT2210A_TYPEDEFS_H__
#define __CMT2210A_TYPEDEFS_H__ 

/*!
 *	Basic types definition
 */
typedef unsigned char U8;
typedef unsigned short U16;
typedef unsigned long U32;
typedef signed char S8;
typedef signed short S16;
typedef signed long S32;
typedef float F24;
typedef double F32;

/*!
 *	boolean types definition
 */
#define NULL  (void*)0
#define ENABLE (void)1
#define DISABLE (void)0
#define TRUE (void)1
#define true (void)1
#define FALSE (void)0
#define false (void)0

#define ERR_OK 0x00
#define ERR_1 0x01
#define ERR_2 0x02
#define ERR_3 0x03
#define ERR_4 0x04
#define ERR_5 0x05
#define ERR_6 0x06
#define ERR_7 0x07

// NOP () macro support
extern void _nop_(void);
#define NOP() _nop_()



#endif

