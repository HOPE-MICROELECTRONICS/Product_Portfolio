/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file    CMT2210A.h
 * @brief   CMT2210A receiver RF chip driver
 *
 * @version 1.0
 * @date    Mar 17 2014
 * @author  CMOSTEK R@D
 */

#ifndef __CMT2210A_H
#define __CMT2210A_H

#include "typedefs.h"
#include "spi3.h"


/* Control bank registers address */ 
#define REG_OP_CTRL              0x47
#define REG_SOFTRST              0x4F 

/* Define the chip operating states */
#define OP_STATUS_SLEEP          1
#define OP_STATUS_STBY           2
#define OP_STATUS_RX             4

/* Switch the chip operating states */
#define OP_SWITCH_STBY           0x02
#define OP_SWITCH_RX             0x08
#define OP_SWITCH_SLEEP          0x10
 

void Cmt2210a_Init(void);
void Cmt2210a_SoftReset(void); 

/* Switch to STBY/RX/SLEEP state */
void Cmt2210a_GoStby(void);
void Cmt2210a_GoRx(void);
void Cmt2210a_GoSleep(void);

/* Get the current operating state of the CMT2210A */
U8 Cmt2210a_GetOpStatus(void);


#endif //__CMT2210A_H__
