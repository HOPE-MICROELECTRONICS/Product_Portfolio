#include "cmt2210a.h"

/* Init SPI */
void Cmt2210a_Init(void)
{
	SPI3_Init(); 
}


/*! ********************************************************
* @desc:
*     Writing 0xFF into this register will generate a soft_reset command to the device.
*     Setting this register to any values other than 0xFF will not take any effect.
*     The soft reset has the same effect of POR.
*     After the soft reset, the chip will go through the power-up sequence and then enter the SLEEP Mode.
*     After soft resetting the chip, the MCU shall wait 10 ms before performing any other controls to the chip.
* *********************************************************/
void Cmt2210a_SoftReset(void)
{
	SPI3_WriteByte(REG_SOFTRST, 0xFF);
} 

/*! ********************************************************
* @desc:
*     Read out the chip operating state.
* @return:
*     OP_STATUS_SLEEP(1):  SLEEP state (Default). 
*     OP_STATUS_STBY(2):   STBY state. 
*     OP_STATUS_RX(4):     RX state. 
* *********************************************************/
U8 Cmt2210a_GetOpStatus(void)
{
	U8 tempdat;

	SPI3_ReadByte(REG_OP_CTRL, &tempdat, 1);
	tempdat = tempdat >> 5;

	return tempdat;
}


/*! ********************************************************
* @desc:
*     Switch to STBY state.. 
* *********************************************************/
void Cmt2210a_GoStby(void)
{
	SPI3_WriteByte(REG_OP_CTRL, OP_SWITCH_STBY);
}


/*! ********************************************************
* @desc:
*     Switch to RX state.. 
* *********************************************************/
void Cmt2210a_GoRx(void)
{
	SPI3_WriteByte(REG_OP_CTRL, OP_SWITCH_RX);
}


/*! ********************************************************
* @desc:
*     Switch to SLEEP state.
* *********************************************************/
void Cmt2210a_GoSleep(void)
{
	SPI3_WriteByte(REG_OP_CTRL, OP_SWITCH_SLEEP);
}



