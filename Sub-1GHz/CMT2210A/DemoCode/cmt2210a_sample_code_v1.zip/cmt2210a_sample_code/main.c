/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * \file        main.c
 *
 * \version     1.0
 * \date        Mar 17 2015
 * \author      CMOSTEK R@D
 */

#include "typedefs.h"

#include "gpio_def.h"
#include "hal.h"
#include "cmt2210a.h"

/*
 * Main application
 */
void main(void)
{
    /* Initializes the status of SPI pins */
	Cmt2210a_Init();		
	Delay_Ms(10);

	Cmt2210a_SoftReset();	
	Delay_Ms(10);

	/* start to receives data */
	Cmt2210a_GoRx();
	Delay_Ms(10);

	while (1)
	{

	} // while (1)
}

