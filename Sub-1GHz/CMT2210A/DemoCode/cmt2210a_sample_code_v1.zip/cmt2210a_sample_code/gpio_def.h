/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * \file        gpio_def.h
 * \brief       MCU and Hardware related functions
 *
 * \version     1.0
 * \date        Mar 26 2013
 * \author      CMOSTEK R@D
 */

#ifndef __CMT221XA_GPIO_DEF_H__
#define __CMT221XA_GPIO_DEF_H__

#include "local_C8051F930_defs.h"


/* ----------------------- CSB/SDA/SCL/FCSB Defines --------------------- */
#define SPI_CSB_PIN                     0         // P2.0
#define SPI_SDA_PIN                     3         // P2.3
#define SPI_SCL_PIN                     2         // P2.2
#define SPI_FCSB_PIN                    1         // P2.1

sbit SPI_CSB     = P2 ^ SPI_CSB_PIN;
sbit SPI_SCK     = P2 ^ SPI_SCL_PIN;
sbit SPI_SDA     = P2 ^ SPI_SDA_PIN;
sbit SPI_FCSB    = P2 ^ SPI_FCSB_PIN;

#define SPI_IO_DIR_REG                  P2MDOUT
#define SPI_FCSB_IO_DIR_REG             P2MDOUT

#define SPI_CSB_PUSH_PULL()             (SPI_IO_DIR_REG |= (1 << SPI_CSB_PIN))
#define SPI_SCK_PUSH_PULL()             (SPI_IO_DIR_REG |= (1 << SPI_SCL_PIN))
#define SPI_SDA_OPEN_DRAIN()            (SPI_IO_DIR_REG &= ~(1 << SPI_SDA_PIN))
#define SPI_SDA_PUSH_PULL()             (SPI_IO_DIR_REG |= (1 << SPI_SDA_PIN))
#define SPI_FCSB_PUSH_PULL()            (SPI_FCSB_IO_DIR_REG |= (1 << SPI_FCSB_PIN))
#define SPI_FCSB_OPEN_DRAIN()           (SPI_FCSB_IO_DIR_REG &= ~(1 << SPI_FCSB_PIN))


#define SPI_CSB_L()                     SPI_CSB = 0
#define SPI_CSB_H()                     SPI_CSB = 1

#define SPI_SCK_L()                     SPI_SCK = 0
#define SPI_SCK_H()                     SPI_SCK = 1

#define SPI_SDA_L()                     SPI_SDA = 0 
#define SPI_SDA_H()                     SPI_SDA = 1 

#define SPI_GET_SDA()                   SPI_SDA 

#define SPI_FCSB_L()                    SPI_FCSB = 0
#define SPI_FCSB_H()                    SPI_FCSB = 1


#endif


