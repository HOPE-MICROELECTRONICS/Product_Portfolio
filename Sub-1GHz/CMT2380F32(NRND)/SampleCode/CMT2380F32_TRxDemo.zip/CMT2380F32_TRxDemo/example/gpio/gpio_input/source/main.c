#include "CMT2380F32_Demo.h"

int32_t main(void)
{
		MCU_Init();
    for(SysTime=0;SysTime<30;);

    CMT2300Iint();              //初始化2300
    GO_RX();
	
		if(!TestKey2())             //测试模式
		{
				for(SysTime=0;SysTime<30;)
        {
            if(TestKey2())
            break;
        }
				if(SysTime>=30)
        TestMode();
		}
		
		while(1)
    {
        KeyScan();     					     
        if(Key_OK)
        {
            KeyDelay();
        }
        else if(Pack_OK)
        {
            RxOKDelay();
        }
        if(ResetTime>20000)
        {
            CMT2300Iint();
            GO_RX();
        }
    }  
}
