/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file        hal.h
 * @brief       MCU and Hardware related functions
 *
 * @version     1.0
 * @date        Mar 17 2015
 * @author      CMOSTEK R@D
 */

#ifndef __CMT221XA_HAL_H__
#define __CMT221XA_HAL_H__

#include "typedefs.h"
#include "local_C8051F930_defs.h"
#include "local_compiler_defs.h"

#define PACKET_TYPE_FIXED		0
#define PACKET_TYPE_VARIABLE	1

#define NODEID_OPTION_NONE		0 
#define NODEID_OPTION_ID		1
#define NODEID_OPTION_ID00		2
#define NODEID_OPTION_ID00FF	3

#define CRC_OPTION_NONE			0
#define CRC_OPTION_CCITT		1
#define CRC_OPTION_IBM			2

#define POLYNOMIAL_CCITT        0x1021
#define POLYNOMIAL_IBM          0x8005 

#define CRC_IBM_SEED            0xFFFF
#define CRC_CCITT_SEED          0x1D0F

/* Cmt2219a parameters config structure */
typedef struct _T_strCmt2219aConfig{
	U16 nSymbolRate;       // SymbolRate as 500Hz to 30000Hz

	U8 nPacketType;
	U8 nFifoThreshold;
	U8 nDataMode;
}T_strCmt2219aConfig;


/* Cmt2219a packet structure */
typedef struct _T_strRxPacket{
	U8 nPreambleSize;
	U8 preambleBuf[4];

	U8 nSyncWordSize;
	U8 syncWordBuf[4];

	U8 nNodeIdOption;
	U8 nNodeIdValue;

	U8 nDataSize;
	U8 dataBuf[32];

	U8 nCrcOption; 
	U16 nCrc;

}T_strRxPacket;

 
extern xdata T_strCmt2219aConfig g_tstrCmt2219aConfig;
extern xdata T_strRxPacket g_tstrRxPacket;
extern xdata U8 g_frameBuf[];

extern data bit g_bFrameBufUsing;
extern data bit g_bFrameRecvDone;
extern data bit g_bEnableBitReceive;

/* Timer and Interrupt handling functions */
#define TIMER_CLK                                  (U32)24000000 	// CPU clk at 24M
#define TIMER_PRESCALER_VALUE                      (U32)12   		// 1:1 prescaler

#define TX_SYMBOL_RATE_1000  (U16)1000
#define TX_SYMBOL_RATE_1200  (U16)1200
#define TX_SYMBOL_RATE_2400  (U16)2400
#define TX_SYMBOL_RATE_4800  (U16)4800
#define TX_SYMBOL_RATE_9600  (U16)9600
#define TX_SYMBOL_RATE_19200  (U16)19200 


/* Implements 'dUs' microseconds delay */ 
void Hal_delayUs(U8 dUs);

/* Implements 'd10UsCnt' ten microseconds delay */ 
void Hal_delay10Us(U16 d10UsCnt);

/* Implements 'd100UsCnt' hundreds microseconds delay */ 
void Hal_delay100Us(U16 d100UsCnt);

/* Implements 'dMs' milliseconds delay */ 
void Hal_delayMs(U16 dMs);

/* This function sets status of all MCU pins */
void Hal_SetMcuIO(void);

/* This function enables internal oscillator and 
sets MCU system clock at about 24 MHz.*/
void Hal_SetSysClock();

/* This function initializes MCU, such as status of 
all MCU pins and MCU system clock.*/
void Hal_McuInit(void);

/* This function initializes the status of LED pins */
void Hal_LEDInit(void);

/* Enable which interrupt is observable on the C8051 INT0 */
void Hal_InitExt0(U8 nGPIOx); 

/* Initializes timer0 by CMT2219A symbol rate(direct mode) */
void Hal_InitTimer0(U16 dSymbolRate);

/* Start/stop timer0 to receives RF data(direct mode) */
void Hal_Timer0Restart(void);
void Hal_Timer0Stop(void);

/* CMT2219A paramters config */
void Hal_InitCMT221XAConfig(void);	   

/* CMT2219A packet paramters config */
void Hal_InitRxPacket(T_strRxPacket xdata * strRxPacket);

/* Analyzes the data received and fills in the packet */
U8 Hal_FillRxPacket(U8 xdata * pFifo, T_strRxPacket xdata * pstrRxPacket);

/* CRC16 calculation */
U16 Hal_PacketComputeCrc16(U8 nCrcOption, U8 *pBuf,U8 bLen);


#endif  // __MCU_HAL_H__

