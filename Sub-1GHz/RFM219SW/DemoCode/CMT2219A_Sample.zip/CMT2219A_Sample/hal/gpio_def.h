/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file        gpio_def.h
 * @brief       MCU and Hardware related functions
 *
 * @version     1.0
 * @date        Mar 17 2015
 * @author      CMOSTEK R@D
 */

#ifndef __CMT221XA_GPIO_DEF_H__
#define __CMT221XA_GPIO_DEF_H__

#include "..\\local_C8051F930_defs.h"


/* ----------------------- CSB/SDA/SCL/FCSB Defines --------------------- */
#define SPI_CSB_PIN                     0         // P2.0
#define SPI_SDA_PIN                     3         // P2.3
#define SPI_SCL_PIN                     2         // P2.2
#define SPI_FCSB_PIN                    1         // P2.1

sbit SPI_CSB     = P2 ^ SPI_CSB_PIN;
sbit SPI_SCK     = P2 ^ SPI_SCL_PIN;
sbit SPI_SDA     = P2 ^ SPI_SDA_PIN;
sbit SPI_FCSB    = P2 ^ SPI_FCSB_PIN;

#define SPI_IO_DIR_REG                  P2MDOUT
#define SPI_FCSB_IO_DIR_REG             P2MDOUT

#define SPI_CSB_PUSH_PULL()             (SPI_IO_DIR_REG |= (1 << SPI_CSB_PIN))
#define SPI_SCK_PUSH_PULL()             (SPI_IO_DIR_REG |= (1 << SPI_SCL_PIN))
#define SPI_SDA_OPEN_DRAIN()            (SPI_IO_DIR_REG &= ~(1 << SPI_SDA_PIN))
#define SPI_SDA_PUSH_PULL()             (SPI_IO_DIR_REG |= (1 << SPI_SDA_PIN))
#define SPI_FCSB_PUSH_PULL()            (SPI_FCSB_IO_DIR_REG |= (1 << SPI_FCSB_PIN))
#define SPI_FCSB_OPEN_DRAIN()           (SPI_FCSB_IO_DIR_REG &= ~(1 << SPI_FCSB_PIN))


#define SPI_CSB_L()                     SPI_CSB = 0
#define SPI_CSB_H()                     SPI_CSB = 1

#define SPI_SCK_L()                     SPI_SCK = 0
#define SPI_SCK_H()                     SPI_SCK = 1

#define SPI_SDA_L()                     SPI_SDA = 0 
#define SPI_SDA_H()                     SPI_SDA = 1 

#define SPI_GET_SDA()                   SPI_SDA 

#define SPI_FCSB_L()                    SPI_FCSB = 0
#define SPI_FCSB_H()                    SPI_FCSB = 1


/* ----------------------- GPO1/2/3/4 Defines --------------------- */
sbit GPO1_IO    = P0 ^ 7;
sbit GPO2_IO    = P0 ^ 0;
sbit GPO3_IO    = P0 ^ 1;
sbit GPO4_IO    = P2 ^ 4;

#define GPOx_DIR_REG                    P0MDOUT
#define GPO4_DIR_REG                    P2MDOUT
#define GPO1_PIN                        7         // P0.7
#define GPO2_PIN                        0         // P0.0
#define GPO3_PIN                        1         // P0.1
#define GPO4_PIN                        4         // P2.4

#define GPO1_PUSH_PULL()                GPOx_DIR_REG |= (1<<GPO1_PIN)
#define GPO1_OPEN_DRAIN()               GPOx_DIR_REG &= ~(1<<GPO1_PIN)
#define GPO2_PUSH_PULL()                GPOx_DIR_REG |= (1<<GPO2_PIN)
#define GPO2_OPEN_DRAIN()               GPOx_DIR_REG &= ~(1<<GPO2_PIN)
#define GPO3_PUSH_PULL()                GPOx_DIR_REG |= (1<<GPO3_PIN)
#define GPO3_OPEN_DRAIN()               GPOx_DIR_REG &= ~(1<<GPO3_PIN)
#define GPO4_PUSH_PULL()                GPO4_DIR_REG |= (1<<GPO4_PIN)
#define GPO4_OPEN_DRAIN()               GPO4_DIR_REG &= ~(1<<GPO4_PIN) 


/* ------------------------- LED1/2/3 Defines ----------------------- */
sbit LED1_IO    = P0 ^ 6;     //P0.6
sbit LED2_IO    = P1 ^ 0;     //P1.0
sbit LED3_IO   = P1 ^ 1;      //P1.1

#define LED_ON                          0
#define LED_OFF                         1

#define LED1_PIN                        6 //P0.6
#define LED2_PIN                        0 //P1.0
#define LED3_PIN                        1 //P1.1

#define LED1_DIR_REG                    P0MDOUT
#define LED2_DIR_REG                    P1MDOUT
#define LED3_DIR_REG                    P1MDOUT

#define LED1_PUSH_PULL()                LED1_DIR_REG |= (1 << LED1_PIN)
#define LED2_PUSH_PULL()                LED2_DIR_REG |= (1 << LED2_PIN)
#define LED3_PUSH_PULL()                LED3_DIR_REG |= (1 << LED3_PIN)

#define LED1_ON()                       LED1_IO = LED_ON
#define LED1_OFF()                      LED1_IO = LED_OFF
#define LED2_ON()                       LED2_IO = LED_ON
#define LED2_OFF()                      LED2_IO = LED_OFF
#define LED3_ON()                       LED3_IO = LED_ON
#define LED3_OFF()                      LED3_IO = LED_OFF


#endif


