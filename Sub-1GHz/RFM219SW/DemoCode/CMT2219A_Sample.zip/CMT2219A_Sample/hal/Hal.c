/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */
/*!
 * \file        hal.c
 * \brief       Hardware dependant functions
 *
 * \version     1.0
 * \date        Mar 26 2013
 * \author      CMOSTEK R@D
 */

#include "hal.h"
#include "gpio_def.h"
#include "API\\cmt2219a.h"

 
xdata T_strCmt2219aConfig g_tstrCmt2219aConfig; 
xdata T_strRxPacket g_tstrRxPacket;
xdata U8 g_frameBuf[64];

data bit g_bEnableBitReceive    = 0;
data bit g_bFrameRecvDone       = FALSE;
data bit g_bFrameBufUsing       = FALSE;
data bit g_bFrameRecvPreambleOk = FALSE;
data bit g_bFrameRecvSyncWordOk = FALSE;

xdata U8 g_recevingBuf[64];
xdata U8 g_nNeedRecvCnt          = 0;
xdata U8 g_nRecevingCnt          = 0;
xdata U8 g_nRecevingByte         = 0;
xdata U8 g_nRecevingBitCnt       = 0;

xdata U32 g_nRecevingPreamble    = 0;
xdata U32 g_nRecevingSyncWord    = 0;


xdata U8 g_TIME0_HALF_TH = 0;
xdata U8 g_TIME0_HALF_TL = 0;
xdata U8 g_TIME0_TH = 0;
xdata U8 g_TIME0_TL = 0;


void Hal_delayUs(U8 dUs)
{
	// delay 1us at Mcu Clock as 24M
	//U8 nTick;    //1:1.6us,5:3.7us; 10:6.2us; 20:9.2; 22:10us

	do
	{
		//21 nops : minimal 1.48us
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
		NOP();
	} while (--dUs);
}


void Hal_delay10Us(U16 d10UsCnt)
{
	// delay 10us at  Mcu Clock as 24M
	U8 nTick; //5:3.7us; 10:6.2us; 20:9.2; 22:10us

	while (d10UsCnt--)
	{
		nTick = 25;
		while (nTick--);
	}
}


void Hal_delay100Us(U16 d100UsCnt)
{
	// delay 100us at Mcu Clock as 24M
	U16 nTick; //

	while (d100UsCnt--)
	{
		nTick = 188;
		while (nTick--);
	}
}


void Hal_delayMs(U16 dMs)
{
	//delay 1MS at Mcu Clock as 24M
	U16 nTick;

	while (dMs--)
	{
		nTick = 1895;
		while (nTick--);
	}
}



void Hal_SetMcuIO(void)
{
	XBR0 = 0x00; //DISABLE ALL FUNCTION CONTROLLER
	XBR1 = 0x00;
	XBR2 = 0x00;

	P0 = 0xFF;
	P1 = 0xFF;
	P2 = 0xFF;

	P0MDOUT = 0x00; //P0 all as In
	P1MDOUT = 0x00; //P1 all as In
	P2MDOUT = 0x00; //P1 all as In

	XBR2 |= 0x40; // XBRE

}


void Hal_SetSysClock()
{ 
	OSCICN |= 0x80;                        //enable internal oscillator 
	RSTSRC = 0x06;
	while ((OSCICN & 0x40) == 0);          //wait for internal oscillator frequency ready

	CLKSEL = 0x00;                         //select precision internal clock,system clock divided by 1
	while ((CLKSEL & 0x80) == 0);          //wait for system clock divider clock ready
}
void Hal_McuInit(void)
{
	Hal_SetSysClock();
	Hal_SetMcuIO();
}

void Hal_LEDInit(void)
{
	LED1_OFF();
	LED2_OFF();
	LED3_OFF();

	LED1_PUSH_PULL();
	LED2_PUSH_PULL();
	LED3_PUSH_PULL();

	LED1_OFF();
	LED2_OFF();
	LED3_OFF();
}

void Hal_InitExt0(U8 nGPIOx)
{ 
	IT0 = 1;
	IT01CF = (1<<3) | (nGPIOx<<0);          // P0.1 INT0    // INT 0 is edge triggered,TCON^1 = 0x01;
	EX0 = 1;                                // Enable the Ext0
}

/* The INT0 interrupt handler(CMT2219A receives data) */
void Hal_INT0_ISR() interrupt 0 
{
	if(!g_bEnableBitReceive) return;

	LED1_ON();

	/* Direct Mode Handler */
	if(DIRECT_MODE == g_tstrCmt2219aConfig.nDataMode)
	{
		TR0 = 0;
		Hal_Timer0Restart();
	} 
	
	/* Buffer Mode Handler */
	else if(BUFFER_MODE == g_tstrCmt2219aConfig.nDataMode)
	{
		if(Cmt2219a_GetFifoThresholdFlag())
		{
			Cmt2219a_GoTune();
			SPI3_ReadNByteFifo(&g_recevingBuf[g_nRecevingCnt], g_tstrCmt2219aConfig.nFifoThreshold);
			Cmt2219a_ClearFifoContent(1);

			g_nRecevingCnt += g_tstrCmt2219aConfig.nFifoThreshold;

			if(g_nRecevingCnt >= g_nNeedRecvCnt)
			{ 
				g_nRecevingCnt -= g_nNeedRecvCnt;
				if(g_bFrameBufUsing == FALSE)
				{ 
					memcpy(g_frameBuf, g_recevingBuf, g_nNeedRecvCnt);
					memcpy(g_recevingBuf, &g_recevingBuf[g_nNeedRecvCnt], g_nRecevingCnt);
					g_bFrameRecvDone = TRUE;
				}
				
			}

			Cmt2219a_GoRx();
		}

		LED1_OFF();
	}
	
	/* Packet Mode Handler */
	else if(PACKET_MODE == g_tstrCmt2219aConfig.nDataMode)
	{
		if((g_tstrRxPacket.nCrcOption==CRC_OPTION_NONE) ?Cmt2219a_GetPacketDoneFlag() :Cmt2219a_GetCrcPassFlag())
		{
			if(g_tstrRxPacket.nCrcOption==CRC_OPTION_NONE)
			{
				Cmt2219a_ClearPacketDoneInt(1);
			}
			else
			{
				Cmt2219a_ClearCrcPassInt(1); 
			}
			
			Cmt2219a_GoTune();
			SPI3_ReadNByteFifo(g_recevingBuf, 32);
			Cmt2219a_ClearFifoContent(1);

			if(g_bFrameBufUsing == FALSE)
			{
				memcpy(g_frameBuf, g_recevingBuf, 32);
				g_bFrameRecvDone = TRUE;
			}

			Cmt2219a_GoRx();
		}
		LED1_OFF();
	} 
}


void Hal_InitTimer0(U16 dSymbolRate)
{
	U16 dT_SymbolRateFlowvalue = 0;
	if(dSymbolRate > (0x8000))
	{
		while(1)
		{
			LED3_ON();
		}
	}
	dT_SymbolRateFlowvalue = ( U16 )((U32)0x10000 - (TIMER_CLK / TIMER_PRESCALER_VALUE / (dSymbolRate * 2))); //half an Tbitrate

	g_TIME0_HALF_TH = (dT_SymbolRateFlowvalue >> 8) & 0x00FF; //time for others bit receive,the Time is T(bitrate)
	g_TIME0_HALF_TL = dT_SymbolRateFlowvalue & 0x00FF;

	dT_SymbolRateFlowvalue = ( U16 )((U32)0x10000 - (TIMER_CLK / TIMER_PRESCALER_VALUE / dSymbolRate));

	g_TIME0_TH = (dT_SymbolRateFlowvalue >> 8) & 0x00FF; //time for others bit receive,the Time is T(bitrate)
	g_TIME0_TL = dT_SymbolRateFlowvalue & 0x00FF;

	TR0 = 0;      // don't start if not ready
	TMOD &= ~0x0F;
	TMOD |= 0x01;
	TH0 = g_TIME0_TH;
	TL0 = g_TIME0_TL;
	ET0 = 1;

	TR0 = 0;      // don't start if not ready
}


void Hal_Timer0Restart(void)
{
	TH0 = g_TIME0_HALF_TH;  //time for others bit receive,the Time is T(bitrate)
	TL0 = g_TIME0_HALF_TL;
	TR0 = 1;
}


void Hal_Timer0Stop(void)
{
	TR0 = 0;
}

/* The Timer0 interrupt handler(Using timer0 to receives data if you choice the direct mode) */
void Hal_Timer0_ISR(void) interrupt 1
{
	static bit bitDataIn;
	static bit isInit = 0;
	static U32 nPreamble, nSyncWord;
	static U8  nPreamSize, nSyncSize;
	static U32 nPreamMask = 0xFFFFFFFF;
	static U32 nSyncMask  = 0xFFFFFFFF;
	
	TH0 = g_TIME0_TH;    //time for others bit receive,the Time is T(bitrate)
	TL0 = g_TIME0_TL;

	LED1_OFF();
	bitDataIn = GPO1_IO;	// Read DOUT pin

	if(0 == isInit)
	{
		isInit     = 1;

		nPreamSize = g_tstrRxPacket.nPreambleSize;
		nSyncSize  = g_tstrRxPacket.nSyncWordSize;
		memcpy(&nPreamble, g_tstrRxPacket.preambleBuf, 4);
		memcpy(&nSyncWord, g_tstrRxPacket.syncWordBuf, 4);

		nPreamble >>= (32 - 8 * nPreamSize);
		nSyncWord >>= (32 - 8 * nSyncSize);
		nPreamMask >>= (32 - 8 * nPreamSize);
		nSyncMask >>= (32 - 8 * nSyncSize);
	}

	/* Detect Preamble */
	if(FALSE == g_bFrameRecvPreambleOk && nPreamSize > 0)
	{
		g_nRecevingPreamble <<= 1;
		g_nRecevingPreamble |=  bitDataIn;

		if(nPreamble == (g_nRecevingPreamble & nPreamMask))
		{
			g_bFrameRecvPreambleOk = TRUE;
		}
	}
	
	/* Detect Sync Word */
	else if(FALSE == g_bFrameRecvSyncWordOk && nSyncSize > 0)
	{
		g_nRecevingSyncWord <<= 1;
		g_nRecevingSyncWord |=  bitDataIn;

		if(nSyncWord == (g_nRecevingSyncWord & nSyncMask))
		{
			g_bFrameRecvSyncWordOk = TRUE;
		}
	}

	/* Receive Data */
	else
	{
		g_nRecevingByte <<= 1;
		g_nRecevingByte |=	bitDataIn;
		g_nRecevingBitCnt++;
		
		if(8 == g_nRecevingBitCnt)
		{
			g_nRecevingBitCnt = 0;
			g_recevingBuf[g_nRecevingCnt++] = g_nRecevingByte;
			if(g_nRecevingCnt == g_nNeedRecvCnt)
			{
				g_bFrameRecvPreambleOk = FALSE;
				g_bFrameRecvSyncWordOk = FALSE;
				g_nRecevingPreamble    = 0;
				g_nRecevingSyncWord    = 0;
				g_nRecevingCnt         = 0;

				if(g_bFrameBufUsing == FALSE)
				{ 
					memcpy(g_frameBuf, g_recevingBuf, g_nNeedRecvCnt); 
					g_bFrameRecvDone = TRUE;
				}	
			}
		}	 
	}

	// read Ex0_Port Level and shift to register
}


/*!
 * CRC 16 bits algorithm implementation
 *
 * @param[IN] crc Previous CRC value
 * @param[IN] data New data to be added to the CRC
 * @param[IN] polynomial CRC polynomial selection [CRC_TYPE_CCITT, CRC_TYPE_IBM]
 *
 * @retval crc New computed CRC
 */
U16 Hal_ComputeCrc16(U16 dCrc, U8 bDat, U16 dPolynomial)
{
	U8 i;

	for (i = 0; i < 8; i++)
	{
		if ((((dCrc & 0x8000) >> 8) ^ (bDat & 0x80)) != 0)
		{
			dCrc <<= 1;  // shift left once
			dCrc ^= dPolynomial; // XOR with polynomial
		}
		else
		{
			dCrc <<= 1;  // shift left once
		}
		bDat <<= 1;         // Next data bit
	}
	return dCrc;
}

/*!
 * Packet data CRC computation
 *
 * @param[IN] radioPacket Radio packet structure containing all information
 * @retval crc Packet computed CRC
 */
U16 Hal_PacketComputeCrc16(U8 nCrcOption, U8 *pBuf, U8 bLen)
{
	U8 i; 
	U16 nCrc;
	U16 nPolynomial;  

	if(CRC_OPTION_IBM == nCrcOption)
	{
		nCrc = CRC_IBM_SEED;
		nPolynomial = POLYNOMIAL_IBM;
	}
	else if(CRC_OPTION_CCITT == nCrcOption)
	{
		nCrc = CRC_CCITT_SEED;
		nPolynomial = POLYNOMIAL_CCITT;
	}
 
	for (i = 0; i < bLen; i++)
	{
		nCrc = Hal_ComputeCrc16(nCrc, *pBuf, nPolynomial);
		pBuf++;
	} 

	return (nCrcOption==CRC_OPTION_CCITT) ?(nCrc) :(nCrc);
}

/*!
* @desc Using the received data, fills in the packet and check the Node ID, CRC
* @param0 pFifo is received data
* @param1 pstrRxPacket is the packet
*/
U8 Hal_FillRxPacket(U8 xdata * pFifo, T_strRxPacket xdata * pstrRxPacket)
{
	U8 nBufSize    = g_nNeedRecvCnt;
	U8 nNodeOption = pstrRxPacket->nNodeIdOption;
	U8 nNodeValue  = pstrRxPacket->nNodeIdValue;
	U8 nDataAddr   = (NODEID_OPTION_NONE==nNodeOption) ?0 :1;

	/* Check Node ID */
	if( (NODEID_OPTION_ID==nNodeOption && pFifo[0]!=nNodeValue) || 
	    (NODEID_OPTION_ID00==nNodeOption && pFifo[0]!=nNodeValue && pFifo[0]!=0x00) ||
		(NODEID_OPTION_ID00FF==nNodeOption && pFifo[0]!=nNodeValue && pFifo[0]!=0x00 && pFifo[0]!=0xFF))
	{
		return FALSE;
	}

	/* Check CRC */
	if(g_tstrCmt2219aConfig.nDataMode !=PACKET_MODE && pstrRxPacket->nCrcOption !=CRC_OPTION_NONE)
	{
		pstrRxPacket->nCrc = (U16)pFifo[nBufSize-2] << 8 | (U16)pFifo[nBufSize-1];
		if(pstrRxPacket->nCrc != Hal_PacketComputeCrc16(pstrRxPacket->nCrcOption, pFifo, nBufSize-2))
		{
			return FALSE;
		}
	}

	if(g_tstrCmt2219aConfig.nPacketType==PACKET_TYPE_VARIABLE)
	{
		pstrRxPacket->nDataSize = pFifo[nDataAddr++];
	}

	memcpy(pstrRxPacket->dataBuf, &pFifo[nDataAddr], pstrRxPacket->nDataSize);
	
	return TRUE;
}

void Hal_InitCMT221XAConfig(void)
{ 
	g_tstrCmt2219aConfig.nSymbolRate    = TX_SYMBOL_RATE_9600; // 9.6k 
	g_tstrCmt2219aConfig.nPacketType    = PACKET_TYPE_FIXED; // PACKET_TYPE_VARIABLE | PACKET_TYPE_FIXED;
	g_tstrCmt2219aConfig.nFifoThreshold = 16;
	g_tstrCmt2219aConfig.nDataMode	    = PACKET_MODE;	// DIRECT_MODE | BUFFER_MODE | PACKET_MODE; 
}

void Hal_InitRxPacket(T_strRxPacket xdata * strRxPacket)
{
	/* Config the packet by RFPDK settings. */
	memset(strRxPacket, 0, sizeof(T_strRxPacket));
	memset(g_frameBuf, 0, sizeof(g_frameBuf));
	memset(g_recevingBuf, 0, sizeof(g_recevingBuf));

	strRxPacket->nPreambleSize  = 4;
	strRxPacket->preambleBuf[0] = 0xAA; 
	strRxPacket->preambleBuf[1] = 0xAA;
	strRxPacket->preambleBuf[2] = 0xAA;
	strRxPacket->preambleBuf[3] = 0xAA;

	strRxPacket->nSyncWordSize  = 4;
	strRxPacket->syncWordBuf[0] = 0x86; 	//0x4D; 
	strRxPacket->syncWordBuf[1] = 0x86; 	//0x75;
	strRxPacket->syncWordBuf[2] = 0x86;
	strRxPacket->syncWordBuf[3] = 0x86;
 
	strRxPacket->nNodeIdOption  = NODEID_OPTION_ID00FF; 
	strRxPacket->nNodeIdValue   = 0x3A;
	
	strRxPacket->nDataSize      = 4;
	strRxPacket->nCrcOption     = CRC_OPTION_NONE; // CRC_OPTION_NONE | CRC_OPTION_CCITT | CRC_OPTION_IBM;


/*	strRxPacket->nPreambleSize  = 4;
	strRxPacket->preambleBuf[0] = 0xAA; 
	strRxPacket->preambleBuf[1] = 0xAA;
	strRxPacket->preambleBuf[2] = 0xAA;
	strRxPacket->preambleBuf[3] = 0xAA;
	strRxPacket->nSyncWordSize  = 1;
	strRxPacket->syncWordBuf[0] = 0x55;
	strRxPacket->nNodeIdOption  = NODEID_OPTION_NONE; 
	strRxPacket->nDataSize      = 10;
	strRxPacket->nCrcOption     = CRC_OPTION_NONE;	 */

	g_nRecevingCnt    = 0;
	g_nRecevingByte   = 0;
	g_nRecevingBitCnt = 0;
	g_nNeedRecvCnt    = 0;

	g_nNeedRecvCnt   += (strRxPacket->nNodeIdOption==NODEID_OPTION_NONE) ?0 :1;
	g_nNeedRecvCnt   += strRxPacket->nDataSize;
	
    if(g_tstrCmt2219aConfig.nDataMode !=PACKET_MODE && strRxPacket->nCrcOption !=CRC_OPTION_NONE)
	{ 
		g_nNeedRecvCnt += 2;
	}	
}

