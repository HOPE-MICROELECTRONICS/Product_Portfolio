/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file        main.c
 * @brief       Main application for micrf220
 *
 * @version     1.0
 * @date        Mar 17 2015
 * @author      CMOSTEK R@D
 */

#include "typedefs.h"

#include "hal\\gpio_def.h"
#include "hal\\hal.h"
#include "API\\cmt2219a.h"
#include "API\\REG_CONFIG.h"


/*
 * Main application
 */
void main(void)
{  
	/* Close watchdog */
	PCA0MD &= ~0x40;  

	/* Initializes the MCU registers */
	Hal_McuInit();

	/* Diable all interrupt */
	EA = 0;	

	/* Initializes the status of LED pins */
	Hal_LEDInit();

	/* CMT2219A parameters config, such as data mode, packet type, symbol rate etc. */
	Hal_InitCMT221XAConfig();

	/* setting the CMT2219A data packet parameters */
	Hal_InitRxPacket(&g_tstrRxPacket);

	LED1_ON();
	LED2_ON();
	LED3_ON();
	Hal_delayMs(200);
	LED1_OFF();
	LED2_OFF();
	LED3_OFF();

    /* Initializes the status of SPI pins */
	Cmt2219a_Init();		
	Hal_delayMs(100);

	Cmt2219a_SoftReset();	
	Hal_delayMs(5);

	/* Initializes the status of GPO pins */
	GPO1_OPEN_DRAIN();
	GPO2_OPEN_DRAIN();
	GPO3_OPEN_DRAIN();
	GPO4_OPEN_DRAIN();

	/* Direct mode GPO config */
	if(DIRECT_MODE == g_tstrCmt2219aConfig.nDataMode)
	{
		/* DOUT is output via GPO1 */
		Cmt2219a_SetGpo1Sel(GPO1_SEL_DOUT);

		/* Timer0 config (receive data by Timer0) */
		Hal_InitTimer0(g_tstrCmt2219aConfig.nSymbolRate);
		Hal_InitExt0(GPO1_PIN);
	}

	/* Buffer mode GPO config */
	else if(BUFFER_MODE == g_tstrCmt2219aConfig.nDataMode)
	{
		/* INT1 is output via GPO1 */
		Cmt2219a_SetGpo1Sel(GPO1_SEL_INT1);

		/* Select the FIFO_TH interrupt */
		Cmt2219a_SetInt1(BUFFER_FIFO_TH); 
		Hal_InitExt0(GPO1_PIN);
	}

	/* Packet mode GPIO config */
	else if(PACKET_MODE == g_tstrCmt2219aConfig.nDataMode)
	{
		/* INT1 is output via GPO1 */
		Cmt2219a_SetGpo1Sel(GPO1_SEL_INT1);

		/* No CRC */
		if(g_tstrRxPacket.nCrcOption==CRC_OPTION_NONE)
		{
			/* Select the PKT_DONE interrupt */
			Cmt2219a_SetInt1(PACKET_PKT_DONE);
			Cmt2219a_EnablePacketDoneInt(ENABLE);
		}
		else
		{
			/* Select the CRC_PS interrupt */
			Cmt2219a_SetInt1(PACKET_CRC_PS);
			Cmt2219a_EnableCrcPassInt(ENABLE);
		}

		Hal_InitExt0(GPO1_PIN);
	}

	/* update the cmt2219a settings */
	Cmt2219a_UpdateConfigs();

	/* start to receives data */
	Cmt2219a_GoRx();
	Hal_delayMs(20);

	if(OP_STATUS_RX != Cmt2219a_GetOpStatus())
	{
		/* CMT2219A operating state error */
		LED3_ON();
	} 
	
	g_bFrameRecvDone    = FALSE;
	g_bFrameBufUsing    = FALSE;	
	g_bEnableBitReceive = TRUE;	
	
	/* Enable all interrupt */
	EA = 1; 	
	
	while (true)
	{
		if(TRUE == g_bFrameRecvDone && TRUE == Hal_FillRxPacket(g_frameBuf, &g_tstrRxPacket))
		{	
			/* The packet are received */
			g_bFrameRecvDone = FALSE;
			LED2_ON();
			Hal_delayMs(100);
			LED2_OFF();
		}

	} // while (true)
}

