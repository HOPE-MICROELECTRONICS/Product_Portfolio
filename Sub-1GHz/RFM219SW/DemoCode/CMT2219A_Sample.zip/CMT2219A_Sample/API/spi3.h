#ifndef _SPI3_H_
#define _SPI3_H_
#include "local_compiler_defs.h"
#include "local_C8051F930_defs.h"
#include <stdio.h>
#include <string.h>


void SPI3_Init(void);
U8 SPI3_ReadByte(U8 ReadAddress, U8* pBuffer, U8 len);
U8 SPI3_WriteByte(U8 WriteAddress, U8 SendByte);
U8 SPI3_ReadNByteFifo(U8 xdata* pBuffer, U8 len);
U8 SPI_WriteNByteFifo(const U8 xdata* pBuffer, U8 len);

#endif



