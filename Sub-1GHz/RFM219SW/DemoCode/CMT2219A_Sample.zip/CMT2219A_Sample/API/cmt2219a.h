/*
 * THE FOLLOWING FIRMWARE IS PROVIDED: (1) "AS IS" WITH NO WARRANTY; AND
 * (2)TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
 * CONSEQUENTLY, CMOSTEK SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
 * OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
 * CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * Copyright (C) CMOSTEK SZ.
 */

/*!
 * @file    CMT2219A.h
 * @brief   CMT2219A transmitter RF chip driver
 *
 * @version 1.0
 * @date    Mar 17 2015
 * @author  CMOSTEK R@D
 */

#ifndef __CMT2219A_H
#define __CMT2219A_H

#include "typedefs.h"
#include "spi3.h"

/* Sync word registers address */
#define REG_SYNC_A               0x16
#define REG_SYNC_B               0x17
#define REG_SYNC_C               0x18
#define REG_SYNC_D               0x19
#define REG_DC_CTL               0x1F
#define REG_SL_CTL               0x23
#define REG_RX_CTL               0x25

/* Control bank registers address */ 
#define REG_INT_EN               0x3F
#define REG_IO_SEL               0x40
#define REG_INTCTL_A             0x41
#define REG_INTCTL_B             0x42
#define REG_INTCTL_C             0x43
#define REG_INTCTL_D             0x44
#define REG_RSSI                 0x45
#define REG_FUNC_EN              0x46
#define REG_OP_CTRL              0x47
#define REG_SOFTRST              0x4F 

/* Define those signals can be assigned to GPO4 */
#define GPO4_SEL_DOUT            0
#define GPO4_SEL_INT1            1
#define GPO4_SEL_INT2            2
#define GPO4_SEL_DCLK            3

/* Define those signals can be assigned to GPO3 */
#define GPO3_SEL_CLKO            0
#define GPO3_SEL_INT1            1
#define GPO3_SEL_INT2            2
#define GPO3_SEL_DOUT            3

/* Define those signals can be assigned to GPO2 */
#define GPO2_SEL_INT1            0
#define GPO2_SEL_INT2            1
#define GPO2_SEL_DCLK            2
#define GPO2_SEL_LOGIC_ZERO      3

/* Define those signals can be assigned to GPO1 */
#define GPO1_SEL_NRSTO           0
#define GPO1_SEL_INT1            1
#define GPO1_SEL_INT2            2
#define GPO1_SEL_DOUT            3

/* Define the interrupts of direct mode */
#define DIRECT_RSSI_VLD          1
#define DIRECT_PREAM_PS          2
#define DIRECT_SYNC_PS           3
#define DIRECT_SL_TMO            4
#define DIRECT_RX_TMO            5
#define DIRECT_RSSI_INDI         6

/* Define the interrupts of buffer mode */
#define BUFFER_RSSI_VLD          1
#define BUFFER_PREAM_PS          2
#define BUFFER_SYNC_PS           3
#define BUFFER_SL_TMO            4
#define BUFFER_RX_TMO            5
#define BUFFER_FIFO_NMTY         6
#define BUFFER_FIFO_TH           7
#define BUFFER_FIFO_FULL         8
#define BUFFER_FIFO_WBYTE        9
#define BUFFER_FIFO_OVF          10
#define BUFFER_RSSI_INDI         11

/* Define the interrupts of packet mode */
#define PACKET_RSSI_VLD          1
#define PACKET_PREAM_PS          2
#define PACKET_SYNC_PS           3
#define PACKET_NODE_PS           4
#define PACKET_CRC_PS            5
#define PACKET_PKT_DONE          6
#define PACKET_SL_TMO            7
#define PACKET_RX_TMO            8
#define PACKET_FIFO_NMTY         9
#define PACKET_FIFO_TH           10
#define PACKET_FIFO_FULL         11
#define PACKET_FIFO_WBYTE        12
#define PACKET_FIFO_OVF          13
#define PACKET_RSSI_INDI         14

/* Define the chip operating states */
#define OP_STATUS_PUP            0
#define OP_STATUS_SLEEP          1
#define OP_STATUS_STBY           2
#define OP_STATUS_TUNE           3
#define OP_STATUS_RX             4
#define OP_STATUS_EEPROM         5

/* Switch the chip operating states */
#define OP_SWITCH_EEPROM         0x01
#define OP_SWITCH_STBY           0x02
#define OP_SWITCH_TUNE           0x04
#define OP_SWITCH_RX             0x08
#define OP_SWITCH_SLEEP          0x10

/* Define the chip data mode */
#define DIRECT_MODE              0
#define BUFFER_MODE              1
#define PACKET_MODE              2 

 

void Cmt2219a_Init(void);
void Cmt2219a_SoftReset(void); 

/*Select which signal(INT1,INT2,DOUT etc.) is assigned to GPO1/2/3/4 */
U8 Cmt2219a_SetGpo1Sel(U8 dat);
U8 Cmt2219a_SetGpo2Sel(U8 dat);
U8 Cmt2219a_SetGpo3Sel(U8 dat);
U8 Cmt2219a_SetGpo4Sel(U8 dat);

/* Switch to EEPROM/STBY/TUNE/RX/SLEEP state */
void Cmt2219a_GoEeprom(void);
void Cmt2219a_GoStby(void);
void Cmt2219a_GoTune(void);
void Cmt2219a_GoRx(void);
void Cmt2219a_GoSleep(void);

/* Get the current operating state of the CMT2219A */
U8 Cmt2219a_GetOpStatus(void);

/* Get the current RSSI value */
U8 Cmt2219a_GetRssiValue(void);

/* Set the sync word of the CMT2219A(Buffer and Packet mode) */
U8 Cmt2219a_SetSyncWord(U32 dat);

/* Turn on/off duty cycle mode */
U8 Cmt2219a_EnableDutyCycle(U8 dat);
U8 Cmt2219a_SetLfoscMode(U8 dat);

/* Turn on/off sleep timer */
U8 Cmt2219a_EnableSleepTimer(U8 dat);

/* Turn on/off receiver timer */
U8 Cmt2219a_EnableRecvTimer(U8 dat);

/* Select which interrupt is observable on the INT1/INT2 */
U8 Cmt2219a_SetInt1(U8 dat);
U8 Cmt2219a_SetInt2(U8 dat);

/* Enable interrupt */
U8 Cmt2219a_EnableSleepTimeoutInt(U8 dat);
U8 Cmt2219a_EnableRecvTimeoutInt(U8 dat);
U8 Cmt2219a_EnableRssiValidInt(U8 dat);
U8 Cmt2219a_EnablePreamblePassInt(U8 dat);
U8 Cmt2219a_EnableSyncWordPassInt(U8 dat);
U8 Cmt2219a_EnableNodeIdPassInt(U8 dat);
U8 Cmt2219a_EnableCrcPassInt(U8 dat);
U8 Cmt2219a_EnablePacketDoneInt(U8 dat);

/* Clear the interrupt flag */
U8 Cmt2219a_ClearSleepTimeoutInt(U8 dat);
U8 Cmt2219a_ClearRecvTimeoutInt(U8 dat);
U8 Cmt2219a_ClearRssiValidInt(U8 dat);
U8 Cmt2219a_ClearPreamblePassInt(U8 dat);
U8 Cmt2219a_ClearSyncWordPassInt(U8 dat);
U8 Cmt2219a_ClearNodeIdPassInt(U8 dat);
U8 Cmt2219a_ClearCrcPassInt(U8 dat);
U8 Cmt2219a_ClearPacketDoneInt(U8 dat);

/* Get the interrupt flag */
U8 Cmt2219a_GetSleepTimeoutFlag();
U8 Cmt2219a_GetRecvTimeoutFlag();
U8 Cmt2219a_GetRssiValidFlag();
U8 Cmt2219a_GetPreamblePassFlag();
U8 Cmt2219a_GetSyncWordPassFlag();
U8 Cmt2219a_GetNodeIdPassFlag();
U8 Cmt2219a_GetCrcPassFlag();
U8 Cmt2219a_GetPacketDoneFlag();

U8 Cmt2219a_GetFifoFullFlag();
U8 Cmt2219a_GetFifoNotEmptyFlag();
U8 Cmt2219a_GetFifoThresholdFlag();
U8 Cmt2219a_GetFifoOverflowFlag(); 
U8 Cmt2219a_ClearFifoContent(U8 dat);

U8 Cmt2219a_StopSleepTimer(U8 dat);
U8 Cmt2219a_EnableManuTestMode(U8 dat);
U8 Cmt2219a_EnableHighSpeedSpi(U8 dat);

U8 Cmt2219a_ReadReg(U8 addr);
U8 Cmt2219a_WriteReg(U8 addr, U8 value);

U8 Cmt2219a_WriteNReg(U8 addr, U8 xdata *dat, U8 len);
U8 Cmt2219a_ReadNReg(U8 addr, U8 xdata *dat, U8 len);


#endif //__CMT2219A_H__
