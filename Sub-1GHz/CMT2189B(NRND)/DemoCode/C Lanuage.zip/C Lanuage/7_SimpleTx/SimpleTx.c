//******************************************************************************
// THE FOLLOWING FIRMWARE IS PROVIDED: 
//  (1) "AS IS" WITH NO WARRANTY; 
//  (2) TO ENABLE ACCESS TO CODING INFORMATION TO GUIDE AND FACILITATE CUSTOMER.
// CONSEQUENTLY, HopeRF SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR
// CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT
// OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION
// CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
// 
// Copyright (C) HopeRF
// website: www.HopeRF.com
//          www.HopeRF.cn
//******************************************************************************

//******************************************************************************
//   CMT2189B DEMO
//******************************************************************************
//Schematic:         --------------
//               1-|VDD        PA7|-14-KEY1
//          LED--2-|PC6        PA1|-13
//           |---3-|PC4        PA0|-12
//           |   4-|XTAL       PA2|-11-KEY4
//           |---5-|RFCTRL     PA3|-10-KEY5
//          VDD--6-|VDD        PA4|-9--KEY6
//          GND--7-|GND        RFO|-8
//                  --------------
//
//Function: 
//1. Press KEY1��4��5��6��and send packet
//******************************************************************************

#include "CMT.h"     
#include "CMT60F02X.h"

typedef  unsigned char byte;
typedef  unsigned int  word;

											//    mode   dat  pull-up  ioc
//#define	Unused    	RA0					//		0     0     0       0
//#define 	Unused      RA1					//		0     0     0       0
#define		KEY4		RA2					//		1     1     1       1
#define		KEY5		RA3					//		1     1     1       1
#define		KEY6		RA4					//		1     1     1       1 
//#define	Unused		RA5					//		1     1     1       0
//#define 	Unused		RA6					//		1	  1	    1       0
#define		KEY7		RA7					//      1     1     1       1

										 	//    moode  dat   
#define		RF_Dat		RC0					//      1     0             
#define		RF_SDIO		RC1					//      0     0
#define 	RF_SCLK		RC2 				//      1     0
#define 	RF_CSB 		RC3					//      1     1
#define 	RF_CTRL		RC4					//      0     1
//#define 	Unused		RC5					//      0     0
#define   	LED			RC6					//      0     0 
//#define 	Unused		RC7					//      0     0

#define		PORTA_DEF	0b11111100
#define		PORTC_DEF	0b00011000
                                             
#define		TRISA_DEF	0b11111100  
#define		TRISC_DEF	0b00001101
                                             
#define		WPUA_DEF	0b11011100
#define		IOCA_DEF	0b10011100

//******************
//Constant Define
//******************
#define		INTCON_DEF          0b00000000  //Disable GIE, TMR0IE etc.

#define		OPTION_DEF          0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV1_DEF     0b00000000  //PORTA pull-ups are enable;Timer0 1:2
#define		OPTION_DIV2_DEF		0b00000001	//PORTA pull-ups are enable;Timer0 1:4
#define		OPTION_DIV3_DEF		0b00000010	//PORTA pull-ups are enable;Timer0 1:8
#define		OPTION_DIV4_DEF		0b00000011	//PORTA pull-ups are enable;Timer0 1:16
#define		OPTION_DIV5_DEF		0b00000100	//PORTA pull-ups are enable;Timer0 1:32
#define		OPTION_DIV6_DEF		0b00000101	//PORTA pull-ups are enable;Timer0 1:64
#define		OPTION_DIV7_DEF		0b00000110	//PORTA pull-ups are enable;Timer0 1:128
#define		OPTION_DIV8_DEF		0b00000111	//PORTA pull-ups are enable;Timer0 1:256

#define		OSCCON_16M_DEF      0b01110101  //16MHz INTERNAL OSC
#define		OSCCON_8M_DEF       0b01100101  //8MHz INTERNAL OSC
#define		OSCCON_4M_DEF       0b01010101  //4MHz INTERNAL OSC
#define		OSCCON_2M_DEF       0b01000101  //2MHz INTERNAL OSC
#define		OSCCON_1M_DEF       0b00110101  //1MHz INTERNAL OSC
#define		OSCCON_0M5_DEF      0b00100101  //500KHz INTERNAL OSC
#define		OSCCON_250K_DEF     0b00010101  //250KHz INTERNAL OSC
#define		OSCCON_32K_DEF      0b00010101  //32KHz INTERNAL OSC
#define		CMCON0_DEF			0b00000111	//all for digtal IO

#define		WDTCON_DIV5_DEF		0b00000000
#define		WDTCON_DIV6_DEF		0b00000010
#define		WDTCON_DIV7_DEF		0b00000100
#define		WDTCON_DIV8_DEF		0b00000110
#define		WDTCON_DIV9_DEF		0b00001000
#define		WDTCON_DIV10_DEF	0b00001010
#define		WDTCON_DIV11_DEF	0b00001100
#define		WDTCON_DIV12_DEF	0b00001110
#define		WDTCON_DIV13_DEF	0b00010000
#define		WDTCON_DIV14_DEF	0b00010010
#define		WDTCON_DIV15_DEF	0b00010100
#define		WDTCON_DIV16_DEF	0b00010110

#define		TOUTPS_DIV1_DEF		0b00000000		//TOUTPS 1:1
#define		TOUTPS_DIV2_DEF		0b00001000		//TOUTPS 1:2
#define		TOUTPS_DIV3_DEF		0b00010000		//TOUTPS 1:3
#define		TOUTPS_DIV4_DEF		0b00011000		//TOUTPS 1:4
#define		TOUTPS_DIV5_DEF		0b00100000		//TOUTPS 1:5
#define		TOUTPS_DIV6_DEF		0b00101000		//TOUTPS 1:6
#define		TOUTPS_DIV7_DEF		0b00110000		//TOUTPS 1:7
#define		TOUTPS_DIV8_DEF		0b00111000		//TOUTPS 1:8
#define		TOUTPS_DIV9_DEF		0b01000000		//TOUTPS 1:9
#define		TOUTPS_DIV10_DEF	0b01001000		//TOUTPS 1:10
#define		TOUTPS_DIV11_DEF	0b01010000		//TOUTPS 1:11
#define		TOUTPS_DIV12_DEF	0b01011000		//TOUTPS 1:12
#define		TOUTPS_DIV13_DEF	0b01100000		//TOUTPS 1:13
#define		TOUTPS_DIV14_DEF	0b01101000		//TOUTPS 1:14
#define		TOUTPS_DIV15_DEF	0b01110000		//TOUTPS 1:15
#define		TOUTPS_DIV16_DEF	0b01111000		//TOUTPS 1:16

#define		T2CKPS_DIV0_DEF		0b00000000		//T2CKPS 1:1
#define		T2CKPS_DIV2_DEF		0b00000001		//T2CKPS 1:4
#define		T2CKPS_DIV4_DEF		0b00000010		//T2CKPS 1:16

//******************
//Global Variable
//******************
volatile  bit	KeyPre_F;

byte KeyTimer;
byte SysTimer;
byte KeyCode;
byte KeyData;

byte TxBuf[3];

byte Timer0Cnout;

const byte IdTable[3] @0x08 = {'\1', '\2', '\3'};

void Timer0Irq(void)
{
 if(T0IF)	
 	{
 	T0IF = 0;
 	SysTimer++;
 	KeyTimer++;
 	}
}

byte ReadKey(void)
{
 return((PORTA^0x9C)&0x9C);
}

void AssemblePacket(void)
{
 byte tmp;
 
 TxBuf[0] = IdTable[0];
 TxBuf[1] = IdTable[1];
 TxBuf[2] = IdTable[2];
 TxBuf[2] <<= 4;
 TxBuf[2] &= 0xF0;
 
 tmp = (KeyCode>>1);
 if(tmp&0x40)
 	tmp |= 0x01;
 tmp &= 0x0F;
 TxBuf[2] |= tmp;
}

void KeyScan(void)
{
 byte tmp;
 
 Timer0Irq();
 tmp = ReadKey();
 
 if(!KeyPre_F)
 	{
 	if(tmp!=0)
 		{
 		for(KeyTimer=0; KeyTimer<4; )
 			{
 			CLRWDT();	
 			Timer0Irq();
 			if(tmp!=ReadKey())
 				break;
 			}
 		if(KeyTimer>=4)
 			{
 			KeyCode  = tmp;
 			KeyPre_F = 1;
 			AssemblePacket();
 			return;
 			}
		}
	KeyPre_F = 0;
 	KeyCode  = 0;
 	}	
 else
 	{
 	if(tmp!=KeyCode)
 		{
 		KeyCode  = tmp;
 		KeyPre_F = 1;
 		AssemblePacket();
 		return;
 		}
 	else if(tmp==0)
 		{
 		KeyTimer = 0;
 		for(KeyTimer=0; KeyTimer<2; )
 			{
 			CLRWDT();
 			Timer0Irq();
 			if(0!=ReadKey())
 				break;
 			}
 		if(KeyTimer>=2)
 			{
 			KeyPre_F = 0;
 			KeyCode  = 0;
 			}
 		else
 			{
 			KeyCode  = tmp;
 			KeyPre_F = 1;
 			AssemblePacket();
 			}
 		}
 	else
 		return;
 	}
 	
}

void UnitDelay(void)
{
 byte i;
 for(i=135; i!=0; i--)
 	{
	CLRWDT();  		
	Timer0Irq();
	}
}

void SendPacket(void)
{
 byte i, z;
 
 LED     = 1;
 RF_SDIO = 1;
 UnitDelay();
 
 LED     = 0;
 RF_SDIO = 0;
 for(i=31; i!=0; i--)
 	UnitDelay();
 
 for(i=0; i<3; i++)
 	{
 	for(z=0x80; z!=0; z>>=1)	
 		{
 		LED     = 1;
 		RF_SDIO = 1;
 		UnitDelay();
 		
 		if(TxBuf[i]&z)
 			{
 			LED     = 1;
 			RF_SDIO = 1;
 			}
 		else
 			{
 			LED     = 0;
 			RF_SDIO = 0;
 			}
 		UnitDelay();
 		UnitDelay();
 	
 		LED     = 0;
 		RF_SDIO = 0;
		UnitDelay();
		}
 	}
}



void Initial(void)
{
 OSCCON = OSCCON_8M_DEF;		

 PORTA  = PORTA_DEF;    		//Port initial
 TRISA  = TRISA_DEF;    
 WPUA   = WPUA_DEF;    	
 IOCA	= IOCA_DEF;

 PORTC  = PORTC_DEF;
 TRISC  = TRISC_DEF;

 OPTION = OPTION_DIV6_DEF;  	//
 INTCON = INTCON_DEF;          	//Disable interrutp
 
 CMCON0 = CMCON0_DEF;
 
 WDTCON = WDTCON_DIV16_DEF;
}



void main(void)
{
 byte i;
 Initial();
 
 for(SysTimer=0; SysTimer<4; ) 
 	Timer0Irq();
 
 while(1)
 	{
	KeyScan();
	if(KeyPre_F)
		SendPacket();
	else
		{
		KeyCode = 0;
		LED     = 0;
		PAIF	= 0;
		PEIE    = 1;
		PAIE    = 1;
		PORTA   = PORTA;
		
		SLEEP();
		
		for(i=100; i!=0; i--)
			CLRWDT();
		
		PEIE    = 0;
		PAIE    = 0;
		PAIF    = 0;
		}
 	}
}
