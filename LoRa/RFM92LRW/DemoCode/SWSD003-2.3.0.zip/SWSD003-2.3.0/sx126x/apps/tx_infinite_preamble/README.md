# SX126x TX infinite preamble example

## Description

The application will automatically configure the device to transmit an infinite preamble.

## Configuration

The common configuration can be found in [../../common/apps_configuration.h](../../common/apps_configuration.h).

There is no configuration specific to this example.
