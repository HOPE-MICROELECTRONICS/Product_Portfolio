# Notice related to STM32CubeL4

This project uses STM32CubeL4 from STMicroelectronics.

Here only a subset of the STM32CubeL4 is included to reduce the folder size.
The complete project is available [here](https://github.com/STMicroelectronics/STM32CubeL4).
