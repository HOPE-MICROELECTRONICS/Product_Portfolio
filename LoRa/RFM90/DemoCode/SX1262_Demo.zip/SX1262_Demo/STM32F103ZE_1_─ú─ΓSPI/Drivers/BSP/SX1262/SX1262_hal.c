/*!
 * \file      sx1262dvk1cas-board.c
 *
 * \brief     Target board SX1262DVK1CAS shield driver implementation
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2013-2017 Semtech
 *
 * \endcode
 *
 * \author    Miguel Luis ( Semtech )
 *
 * \author    Gregory Cristian ( Semtech )
 */
#include "./BSP/SX1262/SX1262_hal.h"

void SX1262Hal_SPIWrite( uint8_t Data )
{
	uint8_t bitcnt;	

	ClrSX1262Nss();			
 
 	for(bitcnt=8; bitcnt!=0; bitcnt--)
 		{
		
 		if(Data&0x80)
 			SetSX1262MOSI();
 		else
 			ClrSX1262MOSI();
 		Data <<= 1; 		
 		delay_us(2);
 			
		SetSX1262SCK();
 		delay_us(2);
		ClrSX1262SCK();	
 		}
}

uint8_t SX1262Hal_SPIWriteRead( uint8_t dataTX )
{
	uint8_t	bitcnt;	
	uint8_t	dataRX;

	ClrSX1262Nss();
 	dataRX=0;
 	for(bitcnt=8; bitcnt!=0; bitcnt--)
	{
		dataRX <<= 1;
		if(dataTX&0x80)
			SetSX1262MOSI();
		else
			ClrSX1262MOSI();
		dataTX <<= 1; 		
	  delay_us(2);
		SetSX1262SCK();
	  delay_us(2);
		if(SX1262MISO())
			dataRX |= 0x01;
		ClrSX1262SCK();
	}
	return dataRX;
}

void SX1262Hal_Init(void)
{
	GPIO_InitTypeDef gpio_init_struct;
	
	SX1262_GPIO_CLK_ENABLE();
	
	gpio_init_struct.Pin = SX1262POR_Pin;                /* POR���� */
	gpio_init_struct.Mode = GPIO_MODE_OUTPUT_PP;         /* ������� */
	gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;       /* ���� */
	HAL_GPIO_Init(SX1262_Port1, &gpio_init_struct);           

	gpio_init_struct.Pin = SX1262Nss_Pin;                /* Nss���� */
	HAL_GPIO_Init(SX1262_Port1, &gpio_init_struct);       /* ������� */  

	gpio_init_struct.Pin = SX1262MOSI_Pin;               /* MOSI���� */
	HAL_GPIO_Init(SX1262_Port2, &gpio_init_struct);       /* ������� */
		
  gpio_init_struct.Pin = SX1262SCK_Pin;                /* SCK���� */
	HAL_GPIO_Init(SX1262_Port2, &gpio_init_struct);       /* ������� */
	
	gpio_init_struct.Pin = SX1262Busy_Pin;               /* Busy���� */
	gpio_init_struct.Mode = GPIO_MODE_INPUT;             /* �������� */
	gpio_init_struct.Pull = GPIO_NOPULL;                  
	HAL_GPIO_Init(SX1262_Port1, &gpio_init_struct);    
	
	gpio_init_struct.Pin = SX1262MISO_Pin;                /* MISO���� */
	HAL_GPIO_Init(SX1262_Port2, &gpio_init_struct);        /* �������� */  
	
	gpio_init_struct.Pin = SX1262Dio1_Pin;                /* Dio1���� */
	gpio_init_struct.Mode = GPIO_MODE_IT_RISING;          /* �������ж� */   
	gpio_init_struct.Pull = GPIO_PULLDOWN;    	
	HAL_GPIO_Init(SX1262_Port1, &gpio_init_struct);         
	HAL_NVIC_SetPriority(Dio1_INT_IRQn, 0, 2);             /* ��ռ0�������ȼ�2 */
	HAL_NVIC_EnableIRQ(Dio1_INT_IRQn);                     /* ʹ���ж���1 */
		
  ClrSX1262POR();	
	SetSX1262Nss();
	SetSX1262MOSI();
	ClrSX1262SCK();
}

void SX1262Hal_Reset( void )
{
	GPIO_InitTypeDef gpio_init_struct;
	
  __disable_irq();
  wait_ms( 20 );
	
	gpio_init_struct.Pin = SX1262POR_Pin;                /* POR���� */
	gpio_init_struct.Mode = GPIO_MODE_OUTPUT_PP;         /* ������� */
	gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;       /* ���� */
	HAL_GPIO_Init(SX1262_Port1, &gpio_init_struct);    
	
	ClrSX1262POR();
  wait_ms( 50 );
	SetSX1262POR();
	
	gpio_init_struct.Pin = SX1262POR_Pin;               /* Busy���� */
	gpio_init_struct.Mode = GPIO_MODE_INPUT;            /* �������� */
	gpio_init_struct.Pull = GPIO_NOPULL;                  
	HAL_GPIO_Init(SX1262_Port1, &gpio_init_struct);    
	
  wait_ms( 20 );
  __enable_irq();
}

void SX1262Hal_GetStatus( void )
{
	  ClrSX1262Nss();
    SX1262Hal_SPIWrite( RADIO_GET_STATUS );
    SX1262Hal_SPIWrite( 0 );
    SetSX1262Nss();
}

void SX1262Hal_Wakeup( void )
{
    __disable_irq();
	SX1262Hal_GetStatus();
	wait_ms( 20 );
	SX1262Hal_GetStatus();
  WaitOnBusy( );
  __enable_irq();
}


void SX1262Hal_WriteCommand( RadioCommands_t command,uint8_t *buffer,uint16_t size )
{
	uint16_t i;
	SX1262_CheckDeviceReady();
	WaitOnBusy( );

	ClrSX1262Nss();
	SX1262Hal_SPIWrite( ( uint8_t )command );
	for( i = 0; i < size; i++ )
	{
		SX1262Hal_SPIWrite( buffer[i] );
	}
	SetSX1262Nss();
	if( command != RADIO_SET_SLEEP )
	{
			WaitOnBusy( );
	}
}

void SX1262Hal_ReadCommand( RadioCommands_t command, uint8_t *buffer, uint16_t size )
{
  uint16_t i;
	SX1262_CheckDeviceReady();
	ClrSX1262Nss();
	if( command == RADIO_GET_STATUS )
	{
		SX1262Hal_SPIWrite( ( uint8_t )command );
		buffer[0] = SX1262Hal_SPIWriteRead( 0 );
	}
	else
	{
		SX1262Hal_SPIWrite( ( uint8_t )command );
		SX1262Hal_SPIWrite( 0 );
		for(  i = 0; i < size; i++ )
		{
			 buffer[i] = SX1262Hal_SPIWriteRead( 0 );
		}
	}
	SetSX1262Nss();
  WaitOnBusy( );
}

void SX1262Hal_WriteRegister( uint16_t address, uint8_t *buffer, uint16_t size )
{
  uint16_t i;
	SX1262_CheckDeviceReady();
	WaitOnBusy( );

	ClrSX1262Nss();
	SX1262Hal_SPIWrite( RADIO_WRITE_REGISTER );
	SX1262Hal_SPIWrite( ( address & 0xFF00 ) >> 8 );
	SX1262Hal_SPIWrite( address & 0x00FF );
	for( i = 0; i < size; i++ )
	{
		SX1262Hal_SPIWrite( buffer[i] );
	}
	SetSX1262Nss();
  WaitOnBusy( );
}

void SX1262Hal_WriteReg( uint16_t address, uint8_t value )
{
   SX1262Hal_WriteRegister( address, &value, 1 );
}

void SX1262Hal_ReadRegister( uint16_t address, uint8_t *buffer, uint16_t size )
{
  uint16_t i;
	SX1262_CheckDeviceReady();
	WaitOnBusy( );

	ClrSX1262Nss();
	SX1262Hal_SPIWrite( RADIO_READ_REGISTER );
	SX1262Hal_SPIWrite( ( address & 0xFF00 ) >> 8 );
	SX1262Hal_SPIWrite( address & 0x00FF );
	SX1262Hal_SPIWrite( 0 );
	for(  i = 0; i < size; i++ )
	{
		buffer[i] = SX1262Hal_SPIWriteRead( 0 );
	}
	SetSX1262Nss();
  WaitOnBusy( );
}

uint8_t SX1262Hal_ReadReg( uint16_t address )
{
	uint8_t data;

	SX1262Hal_ReadRegister( address, &data, 1 );
	return data;
}

void SX1262Hal_WriteBuffer( uint8_t offset, uint8_t *buffer, uint8_t size )
{
  uint16_t i;
	SX1262_CheckDeviceReady();
	WaitOnBusy( );

	ClrSX1262Nss();
	SX1262Hal_SPIWrite( RADIO_WRITE_BUFFER );
	SX1262Hal_SPIWrite( offset );
	for(  i = 0; i < size; i++ )
	{
		SX1262Hal_SPIWrite( buffer[i] );
	}
	SetSX1262Nss();
  WaitOnBusy( );
}

void SX1262Hal_ReadBuffer( uint8_t offset, uint8_t *buffer, uint8_t size )
{
  uint16_t i;
	SX1262_CheckDeviceReady();
	WaitOnBusy( );

	ClrSX1262Nss();
	SX1262Hal_SPIWrite( RADIO_READ_BUFFER );
	SX1262Hal_SPIWrite( offset );
	SX1262Hal_SPIWrite( 0 );
	for(  i = 0; i < size; i++ )
	{
		buffer[i] = SX1262Hal_SPIWriteRead( 0 );
	}
	SetSX1262Nss();
  WaitOnBusy( );
}

uint8_t SX1262Hal_GetDioStatus( void )
{
  uint8_t	temp=0;
	if (SX1262Dio3()) temp|=8;
	if (SX1262Dio2()) temp|=4;
	if (SX1262Dio1()) temp|=2;
	if (SX1262Busy()) temp|=1;
		
  return temp;
}

