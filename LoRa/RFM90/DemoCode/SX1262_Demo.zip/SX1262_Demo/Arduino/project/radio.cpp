#include <math.h>
#include <Arduino.h>
#include <string.h>
#include "radio.h"
#include "SX1262.h"
#include "SX1262_hal.h"

int RadioInit( RadioEvents_t *events );
RadioState_t RadioGetStatus( void );
void RadioSetModem( RadioModems_t modem );
void RadioSetChannel( uint32_t freq );
void RadioSetRxConfig( RadioModems_t modem, uint32_t bandwidth,
                          uint32_t datarate, uint8_t coderate,
                          uint32_t bandwidthAfc, uint16_t preambleLen,
                          uint16_t symbTimeout, bool fixLen,
                          uint8_t payloadLen,
                          bool crcOn, bool FreqHopOn, uint8_t HopPeriod,
                          bool iqInverted, bool rxContinuous );

void RadioSetTxConfig( RadioModems_t modem, int8_t power, uint32_t fdev,
                          uint32_t bandwidth, uint32_t datarate,
                          uint8_t coderate, uint16_t preambleLen,
                          bool fixLen, bool crcOn, bool FreqHopOn,
                          uint8_t HopPeriod, bool iqInverted, uint32_t timeout );
                          
double RadioSymbTime(uint8_t bw, uint8_t sf);
void RadioSend( uint8_t *buff, uint8_t Size );
void RadioSleep( void );
void RadioStandby( void );
void RadioRx( uint32_t timeout );
void RadioStartCad( uint8_t symbols );
int16_t RadioRssi( RadioModems_t modem );
void RadioSetPublicNetwork( bool enable );
void RadioIrqProcess( void );
void RadioRxBoosted( uint32_t timeout );
void RadioSetRxDutyCycle( uint32_t rxTime, uint32_t sleepTime );

const struct Radio_s Radio =
{
    RadioInit,
    RadioGetStatus,
    RadioSetModem,
    RadioSetChannel,
    RadioSetRxConfig,
    RadioSetTxConfig,
    RadioSend,
    RadioSleep,
    RadioStandby,
    RadioRx,
    RadioStartCad,
    RadioRssi,
    RadioSetPublicNetwork,
    RadioIrqProcess,
    RadioRxBoosted,
    RadioSetRxDutyCycle
};

 /*!
 * FSK bandwidth definition
 */
typedef struct
{
    uint32_t bandwidth;
    uint8_t  RegValue;
}FskBandwidth_t;

/*!
 * Precomputed FSK bandwidth registers values
 */
const FskBandwidth_t FskBandwidths[] =
{
    { 4800  , 0x1F },
    { 5800  , 0x17 },
    { 7300  , 0x0F },
    { 9700  , 0x1E },
    { 11700 , 0x16 },
    { 14600 , 0x0E },
    { 19500 , 0x1D },
    { 23400 , 0x15 },
    { 29300 , 0x0D },
    { 39000 , 0x1C },
    { 46900 , 0x14 },
    { 58600 , 0x0C },
    { 78200 , 0x1B },
    { 93800 , 0x13 },
    { 117300, 0x0B },
    { 156200, 0x1A },
    { 187200, 0x12 },
    { 234300, 0x0A },
    { 312000, 0x19 },
    { 373600, 0x11 },
    { 467000, 0x09 },
    { 500000, 0x00 }, // Invalid Bandwidth
};

const RadioLoRaBandwidths_t Bandwidths[] = { LORA_BW_125, LORA_BW_250, LORA_BW_500, LORA_BW_062,LORA_BW_041, LORA_BW_031, LORA_BW_020, LORA_BW_015, LORA_BW_010, LORA_BW_007 };

#if 0
//                                          SF12    SF11    SF10    SF9    SF8    SF7
static double RadioLoRaSymbTime[3][6] = {{ 32.768, 16.384, 8.192, 4.096, 2.048, 1.024 },  // 125 KHz
                                         { 16.384, 8.192,  4.096, 2.048, 1.024, 0.512 },  // 250 KHz
                                         { 8.192,  4.096,  2.048, 1.024, 0.512, 0.256 }}; // 500 KHz
#endif

uint8_t MaxPayloadLength = 0xFF;

uint32_t TxTimeout = 0;
uint32_t RxTimeout = 0;

bool RxContinuous = false;

PacketStatus_t RadioPktStatus;
uint8_t RadioRxPayload[255];

bool IrqFired = false;
uint16_t irqRegs;

/*!
 * \brief DIO 0 IRQ callback
 */
void RadioOnDioIrq( void );

/*!
 * \brief Tx timeout timer callback
 */
void RadioOnTxTimeoutIrq( void );

/*!
 * \brief Rx timeout timer callback
 */
void RadioOnRxTimeoutIrq( void );

/*!
 * \brief Cad timeout timer callback
 */
void RadioOnCadTimeoutIrq( void );

/*!
 * Holds the current network type for the radio
 */
typedef struct
{
    bool Previous;
    bool Current;
}RadioPublicNetwork_t;

static RadioPublicNetwork_t RadioPublicNetwork = { false };

/*!
 * Radio callbacks variable
 */
static RadioEvents_t* RadioEvents;

/*!
 * Returns the known FSK bandwidth registers value
 *
 * \param [IN] bandwidth Bandwidth value in Hz
 * \retval regValue Bandwidth register value.
 */
static uint8_t RadioGetFskBandwidthRegValue( uint32_t bandwidth )
{
    uint8_t i;

    if( bandwidth == 0 )
    {
        return( 0x1F );
    }

    for( i = 0; i < ( sizeof( FskBandwidths ) / sizeof( FskBandwidth_t ) ) - 1; i++ )
    {
        if( ( bandwidth >= FskBandwidths[i].bandwidth ) && ( bandwidth < FskBandwidths[i + 1].bandwidth ) )
        {
            return FskBandwidths[i+1].RegValue;
        }
    }
    // ERROR: Value not found
    while( 1 );
}

int RadioInit( RadioEvents_t *events )
{
    RadioEvents = events;

    SX1262_Init( );
    SX1262_SetStandby( STDBY_RC );
    SX1262_SetRegulatorMode( USE_DCDC );
    SX1262_SetDio2AsRfSwitchCtrl(true);//打开射频开关
    
    SX1262_SetBufferBaseAddresses( 0x00, 0x00 );
    SX1262_SetTxParams( 0, RADIO_RAMP_200_US );
    SX1262_SetDioIrqParams( IRQ_RADIO_NONE, IRQ_RADIO_NONE, IRQ_RADIO_NONE, IRQ_RADIO_NONE );
 
    return 0;
}

RadioState_t RadioGetStatus( void )
{
    switch( SX1262_GetOperatingMode( ) )
    {
        case MODE_TX:
            return RF_TX_RUNNING;
        case MODE_RX:
            return RF_RX_RUNNING;
        case RF_CAD:
            return RF_CAD;
        default:
            return RF_IDLE;
    }
}

void RadioSetModem( RadioModems_t modem )
{
    switch( modem )
    {
    default:
    case MODEM_FSK:
        SX1262_SetPacketType( PACKET_TYPE_GFSK );
        // When switching to GFSK mode the LoRa SyncWord register value is reset
        // Thus, we also reset the RadioPublicNetwork variable
        RadioPublicNetwork.Current = false;
        break;
    case MODEM_LORA:
        SX1262_SetPacketType( PACKET_TYPE_LORA );
        // Public/Private network register is reset when switching modems
        if( RadioPublicNetwork.Current != RadioPublicNetwork.Previous )
        {
            RadioPublicNetwork.Current = RadioPublicNetwork.Previous;
            RadioSetPublicNetwork( RadioPublicNetwork.Current );
        }
        break;
    }
}

void RadioSetChannel( uint32_t freq )
{
    SX1262_SetRfFrequency( freq );
}

void RadioSetRxConfig( RadioModems_t modem, uint32_t bandwidth,
                         uint32_t datarate, uint8_t coderate,
                         uint32_t bandwidthAfc, uint16_t preambleLen,
                         uint16_t symbTimeout, bool fixLen,
                         uint8_t payloadLen,
                         bool crcOn, bool freqHopOn, uint8_t hopPeriod,
                         bool iqInverted, bool rxContinuous )
{
    uint8_t SyncWord[8] = { 0xC1, 0x94, 0xC1, 0x00, 0x00, 0x00, 0x00, 0x00 };
    RxContinuous = rxContinuous;

    if( rxContinuous == true )
    {
        symbTimeout = 0;
    }
    if( fixLen == true )
    {
        MaxPayloadLength = payloadLen;
    }
    else
    {
        MaxPayloadLength = 0xFF;
    }

    switch( modem )
    {
        case MODEM_FSK:
            SX1262_SetStopRxTimerOnPreambleDetect( false );
            SX1262_ModulationParams.PacketType = PACKET_TYPE_GFSK;

            SX1262_ModulationParams.Params.Gfsk.BitRate = datarate;
            SX1262_ModulationParams.Params.Gfsk.ModulationShaping = MOD_SHAPING_G_BT_1;
            SX1262_ModulationParams.Params.Gfsk.Bandwidth = RadioGetFskBandwidthRegValue( bandwidth );

            SX1262_PacketParams.PacketType = PACKET_TYPE_GFSK;
            SX1262_PacketParams.Params.Gfsk.PreambleLength = ( preambleLen << 3 ); // convert byte into bit
            SX1262_PacketParams.Params.Gfsk.PreambleMinDetect = RADIO_PREAMBLE_DETECTOR_08_BITS;
            SX1262_PacketParams.Params.Gfsk.SyncWordLength = 3 << 3; // convert byte into bit
            SX1262_PacketParams.Params.Gfsk.AddrComp = RADIO_ADDRESSCOMP_FILT_OFF;
            SX1262_PacketParams.Params.Gfsk.HeaderType = ( fixLen == true ) ? RADIO_PACKET_FIXED_LENGTH : RADIO_PACKET_VARIABLE_LENGTH;
            SX1262_PacketParams.Params.Gfsk.PayloadLength = MaxPayloadLength;
            if( crcOn == true )
            {
                SX1262_PacketParams.Params.Gfsk.CrcLength = RADIO_CRC_2_BYTES_CCIT;
            }
            else
            {
                SX1262_PacketParams.Params.Gfsk.CrcLength = RADIO_CRC_OFF;
            }
            SX1262_PacketParams.Params.Gfsk.DcFree = RADIO_DC_FREEWHITENING;

            RadioStandby( );
            RadioSetModem( ( SX1262_ModulationParams.PacketType == PACKET_TYPE_GFSK ) ? MODEM_FSK : MODEM_LORA );
            SX1262_SetModulationParams( &SX1262_ModulationParams );
            SX1262_SetPacketParams( &SX1262_PacketParams );
            SX1262_SetSyncWord( SyncWord );
            SX1262_SetWhiteningSeed( 0x01FF );

            //RxTimeout = ( uint32_t )( symbTimeout * ( ( 1.0 / ( double )datarate ) * 8.0 ) * 1000 );
            break;

        case MODEM_LORA:
            SX1262_SetStopRxTimerOnPreambleDetect( false );
            SX1262_SetLoRaSymbNumTimeout( symbTimeout );
            SX1262_ModulationParams.PacketType = PACKET_TYPE_LORA;
            SX1262_ModulationParams.Params.LoRa.SpreadingFactor = ( RadioLoRaSpreadingFactors_t )datarate;
            SX1262_ModulationParams.Params.LoRa.Bandwidth = Bandwidths[bandwidth];
            SX1262_ModulationParams.Params.LoRa.CodingRate = ( RadioLoRaCodingRates_t )coderate;

            if( ( ( bandwidth == 0 ) && ( ( datarate == 11 ) || ( datarate == 12 ) ) ) ||
            ( ( bandwidth == 1 ) && ( datarate == 12 ) ) || (RadioSymbTime(Bandwidths[bandwidth], datarate) >= 16.38) )
            {
                SX1262_ModulationParams.Params.LoRa.LowDatarateOptimize = 0x01;
            }
            else
            {
                SX1262_ModulationParams.Params.LoRa.LowDatarateOptimize = 0x00;
            }

            SX1262_PacketParams.PacketType = PACKET_TYPE_LORA;

            if( ( SX1262_ModulationParams.Params.LoRa.SpreadingFactor == LORA_SF5 ) ||
                ( SX1262_ModulationParams.Params.LoRa.SpreadingFactor == LORA_SF6 ) )
            {
                if( preambleLen < 12 )
                {
                    SX1262_PacketParams.Params.LoRa.PreambleLength = 12;
                }
                else
                {
                    SX1262_PacketParams.Params.LoRa.PreambleLength = preambleLen;
                }
            }
            else
            {
                SX1262_PacketParams.Params.LoRa.PreambleLength = preambleLen;
            }

            SX1262_PacketParams.Params.LoRa.HeaderType = ( RadioLoRaPacketLengthsMode_t )fixLen;

            SX1262_PacketParams.Params.LoRa.PayloadLength = MaxPayloadLength;
            SX1262_PacketParams.Params.LoRa.CrcMode = ( RadioLoRaCrcModes_t )crcOn;
            SX1262_PacketParams.Params.LoRa.InvertIQ = ( RadioLoRaIQModes_t )iqInverted;

            RadioSetModem( ( SX1262_ModulationParams.PacketType == PACKET_TYPE_GFSK ) ? MODEM_FSK : MODEM_LORA );
            SX1262_SetModulationParams( &SX1262_ModulationParams );
            SX1262_SetPacketParams( &SX1262_PacketParams );
            
            // WORKAROUND - Optimizing the Inverted IQ Operation, see DS_SX1261-2_V1.2 datasheet chapter 15.4
            if( SX1262_PacketParams.Params.LoRa.InvertIQ == LORA_IQ_INVERTED )
            {
                // RegIqPolaritySetup = @address 0x0736
                SX1262Hal_WriteReg( 0x0736, SX1262Hal_ReadReg( 0x0736 ) & ~( 1 << 2 ) );
            }
            else
            {
                // RegIqPolaritySetup @address 0x0736
                SX1262Hal_WriteReg( 0x0736, SX1262Hal_ReadReg( 0x0736 ) | ( 1 << 2 ) );
            }
            // WORKAROUND END
            
            // Timeout Max, Timeout handled directly in SetRx function
            // RxTimeout = 0xFFFF;
            break;
    }
}

void RadioSetTxConfig( RadioModems_t modem, int8_t power, uint32_t fdev,
                        uint32_t bandwidth, uint32_t datarate,
                        uint8_t coderate, uint16_t preambleLen,
                        bool fixLen, bool crcOn, bool freqHopOn,
                        uint8_t hopPeriod, bool iqInverted, uint32_t timeout )
{

    uint8_t SyncWord[8] = { 0xC1, 0x94, 0xC1, 0x00, 0x00, 0x00, 0x00, 0x00 };
    switch( modem )
    {
        case MODEM_FSK:
            SX1262_ModulationParams.PacketType = PACKET_TYPE_GFSK;
            SX1262_ModulationParams.Params.Gfsk.BitRate = datarate;

            SX1262_ModulationParams.Params.Gfsk.ModulationShaping = MOD_SHAPING_G_BT_1;
            SX1262_ModulationParams.Params.Gfsk.Bandwidth = RadioGetFskBandwidthRegValue( bandwidth );
            SX1262_ModulationParams.Params.Gfsk.Fdev = fdev;

            SX1262_PacketParams.PacketType = PACKET_TYPE_GFSK;
            SX1262_PacketParams.Params.Gfsk.PreambleLength = ( preambleLen << 3 ); // convert byte into bit
            SX1262_PacketParams.Params.Gfsk.PreambleMinDetect = RADIO_PREAMBLE_DETECTOR_08_BITS;
            SX1262_PacketParams.Params.Gfsk.SyncWordLength = 3 << 3 ; // convert byte into bit
            SX1262_PacketParams.Params.Gfsk.AddrComp = RADIO_ADDRESSCOMP_FILT_OFF;
            SX1262_PacketParams.Params.Gfsk.HeaderType = ( fixLen == true ) ? RADIO_PACKET_FIXED_LENGTH : RADIO_PACKET_VARIABLE_LENGTH;

            if( crcOn == true )
            {
                SX1262_PacketParams.Params.Gfsk.CrcLength = RADIO_CRC_2_BYTES_CCIT;
            }
            else
            {
                SX1262_PacketParams.Params.Gfsk.CrcLength = RADIO_CRC_OFF;
            }
            SX1262_PacketParams.Params.Gfsk.DcFree = RADIO_DC_FREEWHITENING;

            RadioStandby( );
            RadioSetModem( ( SX1262_ModulationParams.PacketType == PACKET_TYPE_GFSK ) ? MODEM_FSK : MODEM_LORA );
            SX1262_SetModulationParams( &SX1262_ModulationParams );
            SX1262_SetPacketParams( &SX1262_PacketParams );
            SX1262_SetSyncWord(SyncWord);
            SX1262_SetWhiteningSeed( 0x01FF );
            break;

        case MODEM_LORA:
            SX1262_ModulationParams.PacketType = PACKET_TYPE_LORA;
            SX1262_ModulationParams.Params.LoRa.SpreadingFactor = ( RadioLoRaSpreadingFactors_t ) datarate;
            SX1262_ModulationParams.Params.LoRa.Bandwidth =  Bandwidths[bandwidth];
            SX1262_ModulationParams.Params.LoRa.CodingRate= ( RadioLoRaCodingRates_t )coderate;

            if( ( ( bandwidth == 0 ) && ( ( datarate == 11 ) || ( datarate == 12 ) ) ) ||
            ( ( bandwidth == 1 ) && ( datarate == 12 ) ) || (RadioSymbTime(Bandwidths[bandwidth], datarate) >= 16.38) )
            {
                SX1262_ModulationParams.Params.LoRa.LowDatarateOptimize = 0x01;
            }
            else
            {
                SX1262_ModulationParams.Params.LoRa.LowDatarateOptimize = 0x00;
            }

            SX1262_PacketParams.PacketType = PACKET_TYPE_LORA;

            if( ( SX1262_ModulationParams.Params.LoRa.SpreadingFactor == LORA_SF5 ) ||
                ( SX1262_ModulationParams.Params.LoRa.SpreadingFactor == LORA_SF6 ) )
            {
                if( preambleLen < 12 )
                {
                    SX1262_PacketParams.Params.LoRa.PreambleLength = 12;
                }
                else
                {
                    SX1262_PacketParams.Params.LoRa.PreambleLength = preambleLen;
                }
            }
            else
            {
                SX1262_PacketParams.Params.LoRa.PreambleLength = preambleLen;
            }

            SX1262_PacketParams.Params.LoRa.HeaderType = ( RadioLoRaPacketLengthsMode_t )fixLen;
            SX1262_PacketParams.Params.LoRa.PayloadLength = MaxPayloadLength;
            SX1262_PacketParams.Params.LoRa.CrcMode = ( RadioLoRaCrcModes_t )crcOn;
            SX1262_PacketParams.Params.LoRa.InvertIQ = ( RadioLoRaIQModes_t )iqInverted;

            RadioStandby( );
            RadioSetModem( ( SX1262_ModulationParams.PacketType == PACKET_TYPE_GFSK ) ? MODEM_FSK : MODEM_LORA );
            SX1262_SetModulationParams( &SX1262_ModulationParams );
            SX1262_SetPacketParams( &SX1262_PacketParams );
            break;
    }
    
    
    // WORKAROUND - Modulation Quality with 500 kHz LoRa Bandwidth, see DS_SX1261-2_V1.2 datasheet chapter 15.1
    if( ( modem == MODEM_LORA ) && ( SX1262_ModulationParams.Params.LoRa.Bandwidth == LORA_BW_500 ) )
    {
        // RegTxModulation = @address 0x0889
        SX1262Hal_WriteReg( 0x0889, SX1262Hal_ReadReg( 0x0889 ) & ~( 1 << 2 ) );
    }
    else
    {
        // RegTxModulation = @address 0x0889
        SX1262Hal_WriteReg( 0x0889, SX1262Hal_ReadReg( 0x0889 ) | ( 1 << 2 ) );
    }
    // WORKAROUND END
    
    SX1262_SetRfTxPower( power );
    //TxTimeout = timeout;
}

void RadioSetPublicNetwork( bool enable )
{
    RadioPublicNetwork.Current = RadioPublicNetwork.Previous = enable;

    RadioSetModem( MODEM_LORA );
    if( enable == true )
    {
        // Change LoRa modem SyncWord
        SX1262Hal_WriteReg( REG_LR_SYNCWORD, ( LORA_MAC_PUBLIC_SYNCWORD >> 8 ) & 0xFF );
        SX1262Hal_WriteReg( REG_LR_SYNCWORD + 1, LORA_MAC_PUBLIC_SYNCWORD & 0xFF );
    }
    else
    {
        // Change LoRa modem SyncWord
        SX1262Hal_WriteReg( REG_LR_SYNCWORD, ( LORA_MAC_PRIVATE_SYNCWORD >> 8 ) & 0xFF );
        SX1262Hal_WriteReg( REG_LR_SYNCWORD + 1, LORA_MAC_PRIVATE_SYNCWORD & 0xFF );
    }
}

void RadioSend( uint8_t *buff, uint8_t Size )
{   
   SX1262_SetDioIrqParams( IRQ_TX_DONE | IRQ_RX_TX_TIMEOUT,
                       IRQ_TX_DONE | IRQ_RX_TX_TIMEOUT,
                       IRQ_RADIO_NONE,
                       IRQ_RADIO_NONE );
 
    if( SX1262_GetPacketType( ) == PACKET_TYPE_LORA )
    {
        SX1262_PacketParams.Params.LoRa.PayloadLength = Size;
    }
    else
    {
        SX1262_PacketParams.Params.Gfsk.PayloadLength = Size;
    }

    SX1262_SetPacketParams( &SX1262_PacketParams );
    
    SX1262_SendPayload( buff, Size, 0 );
}

void RadioSleep( void )
{
    SleepParams_t params = { 0 };

    params.Fields.WarmStart = 1;
    SX1262_SetSleep( params );
}

void RadioStandby( void )
{
    SX1262_SetStandby( STDBY_RC );
}

void RadioRx( uint32_t timeout )
{
    SX1262_SetDioIrqParams( IRQ_RX_DONE | IRQ_CRC_ERROR| IRQ_RX_TX_TIMEOUT,
                           IRQ_RX_DONE | IRQ_CRC_ERROR| IRQ_RX_TX_TIMEOUT,
                           IRQ_RADIO_NONE,
                           IRQ_RADIO_NONE );

    if( RxContinuous == true )
    {
        SX1262_SetRx( 0xFFFFFF ); // Rx Continuous
    }
    else
    {
        SX1262_SetRx( timeout);
    }
}

void RadioRxBoosted( uint32_t timeout )
{
    SX1262_SetDioIrqParams( IRQ_RX_DONE,
                           IRQ_RX_DONE,
                           IRQ_RADIO_NONE,
                           IRQ_RADIO_NONE );

    if( RxContinuous == true )
    {
        SX1262_SetRxBoosted( 0xFFFFFF ); // Rx Continuous
    }
    else
    {
        SX1262_SetRxBoosted( RxTimeout );
    }
}

void RadioSetRxDutyCycle( uint32_t rxTime, uint32_t sleepTime )
{
    SX1262_SetRxDutyCycle( rxTime, sleepTime );
}

void RadioStartCad( uint8_t symbols )
{
    uint8_t cadDetPeak = SX1262_ModulationParams.Params.LoRa.SpreadingFactor + 13;
    uint8_t cadDetMin = 10;
    RadioLoRaCadSymbols_t cadSymbolNum = LORA_CAD_16_SYMBOL;
    
    if(symbols>=16)
        cadSymbolNum = LORA_CAD_16_SYMBOL;
    else if(symbols>=8)
        cadSymbolNum = LORA_CAD_08_SYMBOL;
    else if(symbols>=4)
        cadSymbolNum = LORA_CAD_04_SYMBOL;
    else if(symbols>=2)
        cadSymbolNum = LORA_CAD_02_SYMBOL;
    else
        cadSymbolNum = LORA_CAD_01_SYMBOL;
    
    SX1262_SetDioIrqParams( IRQ_CAD_DONE | IRQ_CAD_ACTIVITY_DETECTED,
                           IRQ_CAD_DONE | IRQ_CAD_ACTIVITY_DETECTED,
                           IRQ_RADIO_NONE,
                           IRQ_RADIO_NONE );
    SX1262_SetCadParams( cadSymbolNum, cadDetPeak, cadDetMin, LORA_CAD_ONLY, 0 );
    
    SX1262_SetCad( );
}

double RadioSymbTime(uint8_t bw, uint8_t sf)
{
    double bw_khz = 0;
    switch(bw) {
        case LORA_BW_007: bw_khz = 7.81; break;
        case LORA_BW_010: bw_khz = 10.42; break;
        case LORA_BW_015: bw_khz = 15.63; break;
        case LORA_BW_020: bw_khz = 20.83; break;
        case LORA_BW_031: bw_khz = 31.25; break;
        case LORA_BW_041: bw_khz = 41.67; break;
        case LORA_BW_062: bw_khz = 62.5; break;
        case LORA_BW_125: bw_khz = 125; break;
        case LORA_BW_250: bw_khz = 250; break;
        case LORA_BW_500: bw_khz = 500; break;
        default: break;
    }
    
    return (1<<sf)/bw_khz;
}

void RadioTx( uint32_t timeout )
{
    SX1262_SetTx( timeout);
}

int16_t RadioRssi( RadioModems_t modem )
{
    return SX1262_GetRssiInst( );
}

extern uint8_t   dio1_ClearInterrupt(void);

void RadioOnDioIrq( void )
{
    IrqFired = true;
    irqRegs = SX1262_GetIrqStatus( );
    SX1262_ClearIrqStatus( IRQ_RADIO_ALL );
}

void RadioIrqProcess( void )
{
    if( IrqFired == true )
    {
        __disable_irq( );
        IrqFired = false;
        __enable_irq( );    

        if( ( irqRegs & IRQ_TX_DONE ) == IRQ_TX_DONE )
        {
            // TimerStop( &TxTimeoutTimer );
            //!< Update operating mode state to a value lower than \ref MODE_STDBY_XOSC
             SX1262_SetOperatingMode( MODE_STDBY_RC );
            if( ( RadioEvents != NULL ) && ( RadioEvents->TxDone != NULL ) )
             {
                RadioEvents->TxDone( );
             }
        }

        if( ( irqRegs & IRQ_RX_DONE ) == IRQ_RX_DONE )
        {
             uint8_t size;

            // TimerStop( &RxTimeoutTimer );
             if( RxContinuous == false )
             {
              //!< Update operating mode state to a value lower than \ref MODE_STDBY_XOSC
                SX1262_SetOperatingMode( MODE_STDBY_RC );
               //WORKAROUND - Implicit Header Mode Timeout Behavior, see DS_SX1261-2_V1.2 datasheet chapter 15.3
                //RegRtcControl = @address 0x0902
                 SX1262Hal_WriteReg( 0x0902, 0x00 );
                //RegEventMask = @address 0x0944
                 SX1262Hal_WriteReg( 0x0944, SX1262Hal_ReadReg( 0x0944 ) | ( 1 << 1 ) );
                //WORKAROUND END
             }
            SX1262_GetPayload( RadioRxPayload, &size , 255 );
            SX1262_GetPacketStatus( &RadioPktStatus );
            if( ( RadioEvents != NULL ) && ( RadioEvents->RxDone != NULL ) && ( ( irqRegs & IRQ_CRC_ERROR ) != IRQ_CRC_ERROR ) )
            {
                RadioEvents->RxDone( RadioRxPayload, size, RadioPktStatus.Params.LoRa.RssiPkt+RadioPktStatus.Params.LoRa.SnrPkt, RadioPktStatus.Params.LoRa.SnrPkt );
            }
        }

        if( ( irqRegs & IRQ_CRC_ERROR ) == IRQ_CRC_ERROR )
        {
            if( RxContinuous == false )
            {
                //!< Update operating mode state to a value lower than \ref MODE_STDBY_XOSC
                SX1262_SetOperatingMode( MODE_STDBY_RC );
            }
            if( ( RadioEvents != NULL ) && ( RadioEvents->RxError ) )
            {
                RadioEvents->RxError( );
            }
        }

        if( ( irqRegs & IRQ_CAD_DONE ) == IRQ_CAD_DONE )
        {
            // TimerStop( &CadTimeoutTimer );
            //!< Update operating mode state to a value lower than \ref MODE_STDBY_XOSC
            SX1262_SetOperatingMode( MODE_STDBY_RC );
            if( ( RadioEvents != NULL ) && ( RadioEvents->CadDone != NULL ) )
            {
                RadioEvents->CadDone( ( ( irqRegs & IRQ_CAD_ACTIVITY_DETECTED ) == IRQ_CAD_ACTIVITY_DETECTED ) );
            }
        }

        if( ( irqRegs & IRQ_RX_TX_TIMEOUT ) == IRQ_RX_TX_TIMEOUT )
        {
            if( SX1262_GetOperatingMode( ) == MODE_TX )
            {
                // TimerStop( &TxTimeoutTimer );
                //!< Update operating mode state to a value lower than \ref MODE_STDBY_XOSC
                SX1262_SetOperatingMode( MODE_STDBY_RC );
                if( ( RadioEvents != NULL ) && ( RadioEvents->TxTimeout != NULL ) )
                {
                    RadioEvents->TxTimeout( );
                }
            }
            else if( SX1262_GetOperatingMode( ) == MODE_RX )
            {
                // TimerStop( &RxTimeoutTimer );
                //!< Update operating mode state to a value lower than \ref MODE_STDBY_XOSC
                SX1262_SetOperatingMode( MODE_STDBY_RC );
                if( ( RadioEvents != NULL ) && ( RadioEvents->RxTimeout != NULL ) )
                {
                    RadioEvents->RxTimeout( );
                }
            }
        }

        if( ( irqRegs & IRQ_PREAMBLE_DETECTED ) == IRQ_PREAMBLE_DETECTED )
        {
            //__NOP( );
        }

        if( ( irqRegs & IRQ_SYNCWORD_VALID ) == IRQ_SYNCWORD_VALID )
        {
            //__NOP( );
        }

        if( ( irqRegs & IRQ_HEADER_VALID ) == IRQ_HEADER_VALID )
        {
            //__NOP( );
        }

        if( ( irqRegs & IRQ_HEADER_ERROR ) == IRQ_HEADER_ERROR )
        {
            // TimerStop( &RxTimeoutTimer );
            if( RxContinuous == false )
            {
                //!< Update operating mode state to a value lower than \ref MODE_STDBY_XOSC
                SX1262_SetOperatingMode( MODE_STDBY_RC );
            }
            if( ( RadioEvents != NULL ) && ( RadioEvents->RxTimeout != NULL ) )
            {
                RadioEvents->RxTimeout( );
            }
        }
    }
}
