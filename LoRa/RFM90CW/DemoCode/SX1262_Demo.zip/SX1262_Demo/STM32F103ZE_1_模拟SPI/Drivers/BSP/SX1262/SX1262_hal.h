#ifndef __SX1262_HAL_H__
#define __SX1262_HAL_H__

#include <stdbool.h>
#include <stdint.h>
#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/SX1262/SX1262.h"

#define SX1262_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOF_CLK_ENABLE(); __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)   /* PA PF口时钟使能 */

#define	SX1262_Port1	    GPIOF

#define SX1262Dio1_Pin	GPIO_PIN_1
#define SX1262POR_Pin	  GPIO_PIN_2
#define SX1262Nss_Pin	  GPIO_PIN_3
#define SX1262Busy_Pin	GPIO_PIN_7

#define	SX1262_Port2	   GPIOA
#define SX1262SCK_Pin	   GPIO_PIN_5
#define SX1262MISO_Pin	 GPIO_PIN_6
#define SX1262MOSI_Pin	 GPIO_PIN_7  

//#define SX1262Dio2_Pin	
//#define SX1262Dio3_Pin	

#define	SetSX1262SCK()	(SX1262_Port2->BSRR = SX1262SCK_Pin)
#define	ClrSX1262SCK()	(SX1262_Port2->BRR = SX1262SCK_Pin)
#define	SetSX1262MOSI()	(SX1262_Port2->BSRR = SX1262MOSI_Pin)
#define	ClrSX1262MOSI()	(SX1262_Port2->BRR = SX1262MOSI_Pin)

#define	SetSX1262POR()	(SX1262_Port1->BSRR = SX1262POR_Pin)
#define	ClrSX1262POR()	(SX1262_Port1->BRR = SX1262POR_Pin)
#define	SetSX1262Nss()	(SX1262_Port1->BSRR = SX1262Nss_Pin)
#define	ClrSX1262Nss()	(SX1262_Port1->BRR = SX1262Nss_Pin)

//引脚判断
#define	SX1262Busy()		(SX1262_Port1->IDR & SX1262Busy_Pin)
#define	SX1262Dio1()		(SX1262_Port1->IDR & SX1262Dio1_Pin)
#define	SX1262MISO()		(SX1262_Port2->IDR & SX1262MISO_Pin)
#define	SX1262Dio2()		0x00
#define	SX1262Dio3()		0x00

#define Dio1_INT_IRQn        EXTI1_IRQn
#define Dio1_INT_IRQHandler  EXTI1_IRQHandler


//define _delay_ms		delay
#define WaitOnBusy()    while(SX1262Busy()){ }	
#define	wait_ms			    delay_ms

typedef enum RadioCommands_e
{
    RADIO_GET_STATUS                        = 0xC0,
    RADIO_WRITE_REGISTER                    = 0x0D,
    RADIO_READ_REGISTER                     = 0x1D,
    RADIO_WRITE_BUFFER                      = 0x0E,
    RADIO_READ_BUFFER                       = 0x1E,
    RADIO_SET_SLEEP                         = 0x84,
    RADIO_SET_STANDBY                       = 0x80,
    RADIO_SET_FS                            = 0xC1,
    RADIO_SET_TX                            = 0x83,
    RADIO_SET_RX                            = 0x82,
    RADIO_SET_RXDUTYCYCLE                   = 0x94,
    RADIO_SET_CAD                           = 0xC5,
    RADIO_SET_TXCONTINUOUSWAVE              = 0xD1,
    RADIO_SET_TXCONTINUOUSPREAMBLE          = 0xD2,
    RADIO_SET_PACKETTYPE                    = 0x8A,
    RADIO_GET_PACKETTYPE                    = 0x11,
    RADIO_SET_RFFREQUENCY                   = 0x86,
    RADIO_SET_TXPARAMS                      = 0x8E,
    RADIO_SET_PACONFIG                      = 0x95,
    RADIO_SET_CADPARAMS                     = 0x88,
    RADIO_SET_BUFFERBASEADDRESS             = 0x8F,
    RADIO_SET_MODULATIONPARAMS              = 0x8B,
    RADIO_SET_PACKETPARAMS                  = 0x8C,
    RADIO_GET_RXBUFFERSTATUS                = 0x13,
    RADIO_GET_PACKETSTATUS                  = 0x14,
    RADIO_GET_RSSIINST                      = 0x15,
    RADIO_GET_STATS                         = 0x10,
    RADIO_RESET_STATS                       = 0x00,
    RADIO_CFG_DIOIRQ                        = 0x08,
    RADIO_GET_IRQSTATUS                     = 0x12,
    RADIO_CLR_IRQSTATUS                     = 0x02,
    RADIO_CALIBRATE                         = 0x89,
    RADIO_CALIBRATEIMAGE                    = 0x98,
    RADIO_SET_REGULATORMODE                 = 0x96,
    RADIO_GET_ERROR                         = 0x17,
    RADIO_SET_TCXOMODE                      = 0x97,
    RADIO_SET_TXFALLBACKMODE                = 0x93,
    RADIO_SET_RFSWITCHMODE                  = 0x9D,
    RADIO_SET_STOPRXTIMERONPREAMBLE         = 0x9F,
    RADIO_SET_LORASYMBTIMEOUT               = 0xA0,
	RADIO_CLEAR_ERROR						= 0x07,
}RadioCommands_t;

void SX1262Hal_Init(void);

void SX1262Hal_Reset(void);

void SX1262Hal_GetStatus(void);

void SX1262Hal_Wakeup(void);

/*!
 * \brief Send a command that write data to the radio
 *
 * \param [in]  opcode        Opcode of the command
 * \param [in]  buffer        Buffer to be send to the radio
 * \param [in]  size          Size of the buffer to send
 */
void SX1262Hal_WriteCommand(RadioCommands_t opcode,uint8_t *buffer,uint16_t size);

/*!
 * \brief Send a command that read data from the radio
 *
 * \param [in]  opcode        Opcode of the command
 * \param [out] buffer        Buffer holding data from the radio
 * \param [in]  size          Size of the buffer
 */
void SX1262Hal_ReadCommand( RadioCommands_t opcode, uint8_t *buffer, uint16_t size );

/*!
 * \brief Write data to the radio memory
 *
 * \param [in]  address       The address of the first byte to write in the radio
 * \param [in]  buffer        The data to be written in radio's memory
 * \param [in]  size          The number of bytes to write in radio's memory
 */
void SX1262Hal_WriteRegister( uint16_t address, uint8_t *buffer, uint16_t size );

/*!
 * \brief Write a single byte of data to the radio memory
 *
 * \param [in]  address       The address of the first byte to write in the radio
 * \param [in]  value         The data to be written in radio's memory
 */
void SX1262Hal_WriteReg( uint16_t address, uint8_t value );

/*!
 * \brief Read data from the radio memory
 *
 * \param [in]  address       The address of the first byte to read from the radio
 * \param [out] buffer        The buffer that holds data read from radio
 * \param [in]  size          The number of bytes to read from radio's memory
 */
void SX1262Hal_ReadRegister( uint16_t address, uint8_t *buffer, uint16_t size );

/*!
 * \brief Read a single byte of data from the radio memory
 *
 * \param [in]  address       The address of the first byte to write in the
 *                            radio
 *
 * \retval      value         The value of the byte at the given address in
 *                            radio's memory
 */
uint8_t SX1262Hal_ReadReg( uint16_t address );

/*!
 * \brief Write data to the buffer holding the payload in the radio
 *
 * \param [in]  offset        The offset to start writing the payload
 * \param [in]  buffer        The data to be written (the payload)
 * \param [in]  size          The number of byte to be written
 */
void SX1262Hal_WriteBuffer( uint8_t offset, uint8_t *buffer, uint8_t size );

/*!
 * \brief Read data from the buffer holding the payload in the radio
 *
 * \param [in]  offset        The offset to start reading the payload
 * \param [out] buffer        A pointer to a buffer holding the data from the radio
 * \param [in]  size          The number of byte to be read
 */
void SX1262Hal_ReadBuffer( uint8_t offset, uint8_t *buffer, uint8_t size );

/*!
 * \brief Returns the status of DIOs pins
 *
 * \retval      dioStatus     A byte where each bit represents a DIO state:
 *                            [ DIO3 | DIO2 | DIO1 | BUSY ]
 */
uint8_t SX1262Hal_GetDioStatus( void );


#endif 
