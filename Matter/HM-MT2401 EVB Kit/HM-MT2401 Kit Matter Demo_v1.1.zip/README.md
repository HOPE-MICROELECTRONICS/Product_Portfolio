# Matter application firmware for HOPERF HM-MT2401 EVB development board

HM-MT2401 EVB development board provides an easy-to-use evaluation platform for Matter over Thread devices
The development board integrates the HOPERF HM-MT2401 module and the EVB baseboard. The EVB baseboard contains a rich array of sensor peripherals, including temperature and humidity sensors, pressure sensors, door sensors, PIR sensors, an RGB tri-color light and two monochrome LED lights, as well as four keys and a 1 MB external SPI FlashFlash that supports OTA upgrades using external Flash.

## Requement

* HM-MT2401 EVB board
* Jlink debugger

## Firmware list

| Firmware Name                                 |   Device Type   |   Description   |
| --------------------------------------------- | :-------------: | :-------------: |
| bootloader-storage-internal-single-1536k.s37  |                 |  Bootloader     |
| matter_light_thread_mt2401_kit.s37            |  Router Device  |  Color light    |
| matter_plug_thread_mt2401_kit.s37             |  Router Device  |  Plug-in        |
| matter_windowcover_thread_mt2401_kit.s37      |  Router Device  |  Window Cover   |
| matter_pir_thread_mt2401_kit.s37              |  Sleepy Device  |  PIR sensor     |
| matter_switch_thread_mt2401_kit.s37           |  Sleepy Device  |  Light switch   |
| matter_thermostat_demo_mt2401_kit.s37         |  Sleepy Device  |  Thermostat     |


> Note: The application binary must be burn into module with bootloader to work

User can burn firmware over `Simplicity Commander` tool. 
* [Simplicity Commander for Windows](https://www.silabs.com/documents/login/software/SimplicityCommander-Windows.zip)
* [Simplicity Commander for MAC](https://www.silabs.com/documents/public/software/SimplicityCommander-Mac.zip)
* [Simplicity Commander for Linux](https://www.silabs.com/documents/public/software/SimplicityCommander-Linux.zip)

-------

## Common Function

DAC credentials

* The HM-MT2401 module has pre-burned the DAC certificate. When the user gets the development board, do not perform a full erase operation.

During the development and test phase, to prevent the DAC certificate from being lost due to Flash erasure, user can back up the Module flash data to file.


```shell
commander readmem --device EFR32MG24 --range 0x08000000:+0x180000 --outfile mainflash-backup.hex
```

Button BTN1

* Press and Release : Start, or restart, BLE advertisement in fast mode. It will advertise in this mode for 30 seconds. The device will then switch to a slower interval advertisement. After 15 minutes, the advertisement stops.
* Pressed and hold for 6 s : Initiates the factory reset of the device. Releasing the button within the 6-second window cancels the factory reset procedure. LED0 **Green** blink in unison when the factory reset procedure is initiated.

Matter Shell

* All router device built-in the matter shell function. Users can connect the development board to the computer through the Type-C cable, and operate the shell through the serial port

Power Level report:

* Sleepy device build-in Power Source Cluster to report Battery(CR2032) level


-------

## Color light 

Button BTN1:

* Toggle the RGB light

## Light switch

Button BTN2

* Sends a Toggle command to bound light app

## PIR sensor

Occupancy Sensor

* Human detection

## Plug-in

Button BTN2

* Turn on or turn off the power supply

## Window Cover

LED 1

* Solid On : The window cover if fully open Off ; The window cover if fully closed 
* Blinking slowly : The window cover is half-open, either by tilt, or lift
* Blinking quickly ; The window cover is being automatically open or closed

Button BTN1

* Pressed and release: The lift/tilt increases by 10%

* Pressed and hold for 6 s: Initiates the factory reset of the device.
Releasing the button within the 6-second window cancels the factory reset
procedure. LEDs blink in unison when the factory reset procedure is
initiated.

Push Button 2

* Pressed and release: The lift/tilt decreases by 10%
* Press and hold for 3 s: Cycle between window covering type (Rollershade, Drapery, Tilt Blind - Lift and Tilt).

Push Button0 and Button1

* Pressing and release both buttons at the same time: switches between lift and tilt modes. Most window covering types support either lift only, or tilt only, but type 0x08 support both (default)
* Pressing and hold both buttons at the same time: Cycles between window covering 1, and window covering 2.


## Thermostat

* Control thermostat device over APP
  