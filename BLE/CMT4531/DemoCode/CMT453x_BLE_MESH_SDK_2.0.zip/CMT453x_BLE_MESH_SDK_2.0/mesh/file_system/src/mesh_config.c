#include <stddef.h>
#include <string.h>
#include "mesh_config.h"
#include "utils.h"
#include "mesh_error.h"
#include "mesh_config_entry.h"
#include "mesh_section.h"
#include "mesh_config_backend.h"
#include "mesh_events.h"
#include "stdio.h"
#include "event.h"
#include "mesh_config_listener.h"


#define CONFIG_ENTRY_COUNT    (MESH_SECTION_ITEM_COUNT(mesh_config_entries, const mesh_config_entry_params_t))
#define CONFIG_FILE_COUNT     (MESH_SECTION_ITEM_COUNT(mesh_config_files, const mesh_config_file_params_t))

#define FOR_EACH_FILE(P_FILE)                                                                      \
    MESH_SECTION_FOR_EACH(mesh_config_files, const mesh_config_file_params_t, P_FILE)
#define FOR_EACH_ENTRY(P_ENTRY)                                                                    \
    MESH_SECTION_FOR_EACH(mesh_config_entries, const mesh_config_entry_params_t, P_ENTRY)
#define FOR_EACH_LISTENER(P_LISTENER)                                                              \
    MESH_SECTION_FOR_EACH(mesh_config_entry_listeners, const mesh_config_listener_t, P_LISTENER)

MESH_SECTION_DEF_FLASH(mesh_config_files, const mesh_config_file_params_t);
MESH_SECTION_DEF_FLASH(mesh_config_entries, const mesh_config_entry_params_t);
MESH_SECTION_DEF_FLASH(mesh_config_entry_listeners, const mesh_config_listener_t);
    
static bool m_emergency_action;    

static const mesh_config_file_params_t * file_params_get(uint32_t i)
{  
    return MESH_SECTION_ITEM_GET(mesh_config_files, const mesh_config_file_params_t, i);
}    
static const mesh_config_entry_params_t * entry_params_get(uint32_t i)
{
    return MESH_SECTION_ITEM_GET(mesh_config_entries, const mesh_config_entry_params_t, i);
}    
static const mesh_config_file_params_t * file_params_find(uint16_t id)
{
    FOR_EACH_FILE(p_file)
    {
        if (id == p_file->id)
        {
            return p_file;
        }
    }
    return NULL;
}
static void dirty_entries_process(void)
{
//   LOG_PRINTF("dirty_entries_process\r\n");
    FOR_EACH_ENTRY(p_params)
    {
        const mesh_config_file_params_t * p_file = file_params_find(p_params->p_id->file);
        if (p_file->strategy == MESH_CONFIG_STRATEGY_CONTINUOUS ||
           (p_file->strategy == MESH_CONFIG_STRATEGY_ON_POWER_DOWN && m_emergency_action))
        {
            for (uint32_t j = 0; j < p_params->max_count; ++j)
            {
                if ((p_params->p_state[j] & MESH_CONFIG_ENTRY_FLAG_DIRTY) &&
                   !(p_params->p_state[j] & MESH_CONFIG_ENTRY_FLAG_BUSY))
                {
                    mesh_config_entry_id_t id = *p_params->p_id;
                    id.record += j;
                    uint32_t status;

                    if (p_params->p_state[j] & MESH_CONFIG_ENTRY_FLAG_ACTIVE)
                    {
                        uint8_t buf[MESH_CONFIG_ENTRY_MAX_SIZE] __attribute__((aligned(WORD_SIZE)));

                        p_params->callbacks.getter(id, buf);

                        status = mesh_config_backend_store(id, buf, p_params->entry_size);
                    }
                    else
                    {
                        status = mesh_config_backend_erase(id);
                    }

                    switch (status)
                    {
                        case MESH_SUCCESS:
                            p_params->p_state[j] &= (mesh_config_entry_flags_t)~MESH_CONFIG_ENTRY_FLAG_DIRTY;
                            p_params->p_state[j] |= MESH_CONFIG_ENTRY_FLAG_BUSY;
                            break;
                        case MESH_ERROR_NOT_FOUND:
                            p_params->p_state[j] &= (mesh_config_entry_flags_t)~MESH_CONFIG_ENTRY_FLAG_DIRTY;
                            break;
                        default:
                            return;
                    }
                }
            }
        }
    }

}    
static mesh_config_entry_flags_t * entry_flags_get(const mesh_config_entry_params_t * p_params, mesh_config_entry_id_t id)
{
    uint32_t index = id.record - p_params->p_id->record;
    return &p_params->p_state[index];
}
static bool contains_entry(const mesh_config_entry_params_t * p_params, mesh_config_entry_id_t id)
{
    return (id.file == p_params->p_id->file &&
            IS_IN_RANGE(id.record, p_params->p_id->record, p_params->p_id->record + p_params->max_count - 1));
}    
    
static const mesh_config_entry_params_t * entry_params_find(mesh_config_entry_id_t id)
{
    FOR_EACH_ENTRY(p_params)
    {
        if (contains_entry(p_params, id))
        {
            return p_params;
        }
    }
    return NULL;
}

static void backend_evt_handler(const mesh_config_backend_evt_t * p_evt)
{
    const mesh_config_entry_params_t * p_params = entry_params_find(p_evt->id);
    mesh_config_entry_flags_t * p_flags = entry_flags_get(p_params, p_evt->id);
    *p_flags &= (mesh_config_entry_flags_t)~MESH_CONFIG_ENTRY_FLAG_BUSY;

    if (p_evt->type == MESH_CONFIG_BACKEND_EVT_TYPE_STORAGE_MEDIUM_FAILURE)
    {
        const mesh_evt_t evt = {
            .type = MESH_EVT_CONFIG_STORAGE_FAILURE,
            .params.config_storage_failure = {
                .id = p_evt->id, /*lint !e64 Type mismatch */
            }
        };
        event_handle(&evt);
    }

    if (mesh_config_is_busy())
    {
        dirty_entries_process();
    }
    else
    {
        m_emergency_action = false;
        mesh_evt_t evt = {.type = MESH_EVT_CONFIG_STABLE};
        event_handle(&evt);
    }
}
static void entry_validation(void)
{
    FOR_EACH_ENTRY(p_params_1)
    {
        FOR_EACH_ENTRY(p_params_2)
        {
            if (p_params_1 == p_params_2)
            {
                break;
            }
            if (p_params_1->p_id->file == p_params_2->p_id->file)
            {

            }
        }
    }
}

void mesh_config_init(void)
{
    entry_validation();
    mesh_config_backend_init(entry_params_get(0), CONFIG_ENTRY_COUNT, file_params_get(0), CONFIG_FILE_COUNT, backend_evt_handler);
}


static mesh_config_backend_iterate_action_t restore_callback(mesh_config_entry_id_t id, const uint8_t * p_entry, uint32_t entry_len)
{
    const mesh_config_entry_params_t * p_params = entry_params_find(id);
    mesh_config_load_failure_t load_failure;

    if (p_params == NULL)
    {
        load_failure = MESH_CONFIG_LOAD_FAILURE_INVALID_ID;
    }
    else if (entry_len < p_params->entry_size)
    {
        load_failure = MESH_CONFIG_LOAD_FAILURE_INVALID_LENGTH;
    }
    else if (p_params->callbacks.setter(id, p_entry) != MESH_SUCCESS)
    {
        load_failure = MESH_CONFIG_LOAD_FAILURE_INVALID_DATA;
    }
    else
    {
        *entry_flags_get(p_params, id) = MESH_CONFIG_ENTRY_FLAG_ACTIVE;
        return MESH_CONFIG_BACKEND_ITERATE_ACTION_CONTINUE;
    }

    const mesh_evt_t load_failure_event = {
        .type = MESH_EVT_CONFIG_LOAD_FAILURE,
        .params.config_load_failure = {
            .p_data = p_entry,
            .id = id, 
            .data_len = entry_len,
            .reason = load_failure
        }
    };
    event_handle(&load_failure_event);

    return MESH_CONFIG_BACKEND_ITERATE_ACTION_CONTINUE;
}
void mesh_config_load(void)
{
    mesh_config_backend_read_all(restore_callback);   
}



bool mesh_config_is_busy(void)
{
    FOR_EACH_ENTRY(p_params)
    {
        for (uint32_t j = 0; j < p_params->max_count; ++j)
        {
            if (p_params->p_state[j] &
               (mesh_config_entry_flags_t)(MESH_CONFIG_ENTRY_FLAG_DIRTY | MESH_CONFIG_ENTRY_FLAG_BUSY))
            {
                return true;
            }
        }
    }
    return false;
}

static void listeners_notify(const mesh_config_entry_params_t * p_params,
                             mesh_config_change_reason_t reason,
                             mesh_config_entry_id_t id,
                             const void * p_entry)
{
    FOR_EACH_LISTENER(p_listener)
    {
        if (contains_entry(p_params, *p_listener->p_id))
        {
            p_listener->callback(reason, id, p_entry);
        }
    }
}
static uint32_t entry_store(const mesh_config_entry_params_t * p_params, mesh_config_entry_id_t id, const void * p_entry)
{
//    LOG_PRINTF("entry_store\r\n");
    uint32_t status = p_params->callbacks.setter(id, p_entry);
    if (status == MESH_SUCCESS)
    {
        mesh_config_entry_flags_t * p_flags = entry_flags_get(p_params, id);
        *p_flags |= (mesh_config_entry_flags_t)(MESH_CONFIG_ENTRY_FLAG_DIRTY | MESH_CONFIG_ENTRY_FLAG_ACTIVE);
        const mesh_config_file_params_t * p_file = file_params_find(p_params->p_id->file);
        dirty_entries_process();
        listeners_notify(p_params, MESH_CONFIG_CHANGE_REASON_SET, id, p_entry);
    }

    return status;
}
uint32_t mesh_config_entry_set(mesh_config_entry_id_t id, const void * p_entry)
{
    if (p_entry == NULL)
    {
        return MESH_ERROR_NULL;
    }

    const mesh_config_entry_params_t * p_params = entry_params_find(id);
    if (p_params)
    {
        return entry_store(p_params, id, p_entry);
    }
    else
    {
        return MESH_ERROR_NOT_FOUND;
    }
}
uint32_t mesh_config_entry_get(mesh_config_entry_id_t id, void * p_entry)
{
    if (p_entry == NULL)
    {
        return MESH_ERROR_NULL;
    }

    const mesh_config_entry_params_t * p_params = entry_params_find(id);
    if (p_params)
    {
        if (p_params->has_default || *entry_flags_get(p_params, id) & MESH_CONFIG_ENTRY_FLAG_ACTIVE)
        {
            p_params->callbacks.getter(id, p_entry);
        }
        else
        {
            return MESH_ERROR_INVALID_STATE;
        }
        return MESH_SUCCESS;
    }
    return MESH_ERROR_NOT_FOUND;
}
uint32_t mesh_config_entry_delete(mesh_config_entry_id_t id)
{
    const mesh_config_entry_params_t * p_params = entry_params_find(id);
    if (p_params)
    {
        mesh_config_entry_flags_t * p_flags = entry_flags_get(p_params, id);
        if (*p_flags & MESH_CONFIG_ENTRY_FLAG_ACTIVE)
        {
            *p_flags &= (mesh_config_entry_flags_t)~MESH_CONFIG_ENTRY_FLAG_ACTIVE;
            *p_flags |= MESH_CONFIG_ENTRY_FLAG_DIRTY;

            if (p_params->callbacks.deleter)
            {
                p_params->callbacks.deleter(id);
            }

            dirty_entries_process();
            return MESH_SUCCESS;
        }
        else
        {
            return MESH_ERROR_INVALID_STATE;
        }
    }
    return MESH_ERROR_NOT_FOUND;
}




