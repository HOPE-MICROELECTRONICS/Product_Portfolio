#ifndef MESH_CONFIG_LISTENER_H__
#define MESH_CONFIG_LISTENER_H__

#include "mesh_section.h"
#include "mesh_config_entry.h"


#define MESH_CONFIG_LISTENER(NAME, ID, CALLBACK)                                                   \
    NRF_MESH_SECTION_ITEM_REGISTER_FLASH(mesh_config_entry_listeners,                              \
                                         const mesh_config_listener_t NAME) = {&(ID), CALLBACK}

typedef enum
{
    MESH_CONFIG_CHANGE_REASON_SET, 
    MESH_CONFIG_CHANGE_REASON_DELETE,
} mesh_config_change_reason_t;

typedef void (*mesh_config_listener_on_change_t)(mesh_config_change_reason_t reason, mesh_config_entry_id_t id, const void * p_entry);

typedef struct
{
    const mesh_config_entry_id_t * p_id; 
    mesh_config_listener_on_change_t callback; 
} mesh_config_listener_t;


#endif /* MESH_CONFIG_LISTENER_H__ */
