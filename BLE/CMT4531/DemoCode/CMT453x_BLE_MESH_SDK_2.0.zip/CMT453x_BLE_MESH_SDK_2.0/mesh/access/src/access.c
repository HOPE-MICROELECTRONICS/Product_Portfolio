#include "access.h"
#include "access_config.h"
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "access.h"
#include "access_publish.h"
#include "access_internal.h"
#include "mesh_events.h"
#include "mesh_utils.h"
#include "mesh.h"
#include "device_state_manager.h"
#include "bitfield.h"
#include "toolchain.h"
#include "event.h"
#include "bearer_event.h"
#include "mesh_config_app.h"
#include "mesh_config_entry.h"
#include "mesh_opt_access.h"
#include "stdio.h"
#include "access_utils.h"
#include "packet_mesh.h"
#include "mesh.h"
#include "access_publish_retransmission.h"
#include "access_reliable.h"
#include "bsp_lpuart.h"





static mesh_evt_handler_t m_evt_handler;




static bool element_has_model_id(uint16_t element_index, access_model_id_t model_id, access_model_handle_t * p_model_handle)
{
    if ((access_element_pool[element_index].sig_model_count +
         access_element_pool[element_index].vendor_model_count) > 0)
    {
        for (access_model_handle_t i = 0; i < ACCESS_MODEL_COUNT; ++i)
        {
            if (access_model_pool[i].model_info.element_index       == element_index &&
                access_model_pool[i].model_info.model_id.model_id   == model_id.model_id &&
                access_model_pool[i].model_info.model_id.company_id == model_id.company_id)
            {
                *p_model_handle = i;
                return true;
            }
        }
    }
    return false;
}


static bool opcodes_are_valid(const access_opcode_handler_t * p_opcode_handlers, uint32_t opcode_count)
{
    for (uint32_t i = 0; i < opcode_count; ++i)
    {
        if (!is_valid_opcode(p_opcode_handlers[i].opcode))
        {
            return false;
        }
    }
    return true;
}
static inline access_model_handle_t find_available_model(void)
{
    for (unsigned i = 0; i < ACCESS_MODEL_COUNT; ++i)
    {
        if (!ACCESS_INTERNAL_STATE_IS_ALLOCATED(access_model_pool[i].internal_state))
        {
            return i;
        }
    }
    return ACCESS_HANDLE_INVALID;
}
static void increment_model_count(uint16_t element_index, uint16_t model_company_id)
{
    if (model_company_id == ACCESS_COMPANY_ID_NONE)
    {
        access_element_pool[element_index].sig_model_count++;
    }
    else
    {
        access_element_pool[element_index].vendor_model_count++;
    }
}
uint32_t access_model_add(const access_model_add_params_t * p_model_params,
                          access_model_handle_t * p_model_handle)
{
    if (NULL == p_model_params ||
        NULL == p_model_handle ||
        (0 != p_model_params->opcode_count && NULL == p_model_params->p_opcode_handlers))
    {
        return MESH_ERROR_NULL;
    }
    *p_model_handle = ACCESS_HANDLE_INVALID;

    if (0 == p_model_params->opcode_count && NULL != p_model_params->p_opcode_handlers)
    {
        return MESH_ERROR_INVALID_LENGTH;
    }
    else if (p_model_params->element_index >= ACCESS_ELEMENT_COUNT)
    {
        return MESH_ERROR_NOT_FOUND;
    }
    else if (mesh_is_device_provisioned() ||
             (element_has_model_id(p_model_params->element_index, p_model_params->model_id, p_model_handle) &&
             ACCESS_INTERNAL_STATE_IS_ALLOCATED(access_model_pool[*p_model_handle].internal_state)))
    {
        return MESH_ERROR_FORBIDDEN;
    }
    else if (!opcodes_are_valid(p_model_params->p_opcode_handlers, p_model_params->opcode_count))
    {
        return MESH_ERROR_INVALID_PARAM;
    }
    else if (*p_model_handle == ACCESS_HANDLE_INVALID) 
    {
        *p_model_handle = find_available_model();
        if (ACCESS_HANDLE_INVALID == *p_model_handle)
        {
            return MESH_ERROR_NO_MEM;
        }
        access_model_pool[*p_model_handle].model_info.publish_address_handle = DSM_HANDLE_INVALID;
        access_model_pool[*p_model_handle].model_info.publish_appkey_handle = DSM_HANDLE_INVALID;
        access_model_pool[*p_model_handle].model_info.element_index = p_model_params->element_index;
        access_model_pool[*p_model_handle].model_info.model_id.model_id = p_model_params->model_id.model_id;
        access_model_pool[*p_model_handle].model_info.model_id.company_id = p_model_params->model_id.company_id;
        access_model_pool[*p_model_handle].model_info.publish_ttl = ACCESS_TTL_USE_DEFAULT;
        increment_model_count(p_model_params->element_index, p_model_params->model_id.company_id);
        ACCESS_INTERNAL_STATE_ALLOCATED_SET(access_model_pool[*p_model_handle].internal_state);
        model_store(*p_model_handle);
    }
    access_model_pool[*p_model_handle].p_args = p_model_params->p_args;
    access_model_pool[*p_model_handle].p_opcode_handlers = p_model_params->p_opcode_handlers;
    access_model_pool[*p_model_handle].opcode_count = p_model_params->opcode_count;
    access_model_pool[*p_model_handle].publication_state.publish_timeout_cb = p_model_params->publish_timeout_cb;
    access_model_pool[*p_model_handle].publication_state.model_handle = *p_model_handle;
    return MESH_SUCCESS;
}




static inline access_opcode_t opcode_get(const uint8_t * p_buffer)
{
    access_opcode_t opcode = {0};
    switch (p_buffer[0] & ACCESS_PACKET_OPCODE_FORMAT_MASK)
    {
        case ACCESS_PACKET_OPCODE_FORMAT_1BYTE0:
        case ACCESS_PACKET_OPCODE_FORMAT_1BYTE1:
            opcode.opcode = p_buffer[0];
            opcode.company_id = ACCESS_COMPANY_ID_NONE;
            break;
        case ACCESS_PACKET_OPCODE_FORMAT_2BYTE:
            opcode.opcode = ((uint16_t) p_buffer[0] << 8) | (p_buffer[1]);
            opcode.company_id = ACCESS_COMPANY_ID_NONE;
            break;
        case ACCESS_PACKET_OPCODE_FORMAT_3BYTE:
            opcode.opcode = p_buffer[0];
            opcode.company_id = (p_buffer[1]) | ((uint16_t) p_buffer[2] << 8);
            break;
    }
    return opcode;
}
static inline bool model_subscribes_to_addr(const access_common_t * p_model, dsm_handle_t address_handle)
{
    return (p_model->model_info.subscription_pool_index < ACCESS_SUBSCRIPTION_LIST_COUNT &&
            bitfield_get(access_subscription_list_pool[p_model->model_info.subscription_pool_index].bitfield,
                         address_handle));
}
static inline bool is_opcode_of_model(access_common_t * p_model, access_opcode_t opcode, uint32_t * p_opcode_index)
{
    for (uint32_t i = 0; i < p_model->opcode_count; ++i)
    {
        if (p_model->p_opcode_handlers[i].opcode.opcode     == opcode.opcode     &&
            p_model->p_opcode_handlers[i].opcode.company_id == opcode.company_id)
        {
            *p_opcode_index = i;
            return true;
        }
    }
    return false;
}
static void access_incoming_handle(const access_message_rx_t * p_message)
{
    const mesh_address_t * p_dst = &p_message->meta_data.dst;

    if (mesh_is_address_rx(p_dst))
    {
        uint16_t element_index;
        dsm_handle_t address_handle = DSM_HANDLE_INVALID;
        bool is_element_message = is_element_rx_address(p_dst, &element_index);

        if (!is_element_message)
        {
            dsm_address_handle_get(p_dst, &address_handle);
        }

        for (int i = 0; i < ACCESS_MODEL_COUNT; ++i)
        {
            access_common_t * p_model = &access_model_pool[i];
            uint32_t opcode_index;
            bool address_match = (is_element_message ? (p_model->model_info.element_index == element_index) : (model_subscribes_to_addr(p_model, address_handle)));
            bool model_allocated = ACCESS_INTERNAL_STATE_IS_ALLOCATED(p_model->internal_state);
            bool appkey_bound = bitfield_get(p_model->model_info.application_keys_bitfield, p_message->meta_data.appkey_handle);
            bool valid_opcode = is_opcode_of_model(p_model, p_message->opcode, &opcode_index);
            LOG_PRINTF("cmp_id: 0x%04x mdl_id: 0x%04x  alloc? %d  addr_match? %d  key_bound? %d  opcode? %d\n",
                  p_model->model_info.model_id.company_id, p_model->model_info.model_id.model_id,
                  model_allocated, address_match, appkey_bound, valid_opcode);            
            if (model_allocated && address_match && appkey_bound && valid_opcode)
            {
                if (p_dst->type == MESH_ADDRESS_TYPE_UNICAST)
                {
                    access_reliable_message_rx_cb(i, p_message, p_model->p_args);
                }                
                p_model->p_opcode_handlers[opcode_index].handler(i, p_message, p_model->p_args);
            }
        }
    }
}
static void mesh_msg_handle(const mesh_evt_message_t * p_evt)
{
    access_opcode_t opcode = opcode_get(p_evt->p_buffer);
    if (opcode.opcode == ACCESS_OPCODE_INVALID)
    {
        return;
    }
    LOG_PRINTF("RX: [aop: 0x%04x]\n", opcode.opcode);
    dsm_handle_t appkey_handle = dsm_appkey_handle_get(p_evt->secmat.p_app);
    dsm_handle_t subnet_handle = dsm_subnet_handle_get(p_evt->secmat.p_net);
    access_message_rx_t message =
    {
        .opcode = opcode,
        .p_data = &p_evt->p_buffer[access_utils_opcode_size_get(opcode)],
        .length = p_evt->length - access_utils_opcode_size_get(opcode),
        .meta_data.src.type = p_evt->src.type,
        .meta_data.src.value = p_evt->src.value,
        .meta_data.src.p_virtual_uuid = p_evt->src.p_virtual_uuid,
        .meta_data.dst.type = p_evt->dst.type,
        .meta_data.dst.value = p_evt->dst.value,
        .meta_data.dst.p_virtual_uuid = p_evt->dst.p_virtual_uuid,
        .meta_data.ttl = p_evt->ttl,
        .meta_data.appkey_handle = appkey_handle,
        .meta_data.p_core_metadata = p_evt->p_metadata,
        .meta_data.subnet_handle = subnet_handle,
    };
//    LOG_HEXDUMP(message.p_data, message.length);
    access_incoming_handle(&message);
}

static void mesh_evt_cb(const mesh_evt_t * p_evt)
{
    switch (p_evt->type)
    {
        case MESH_EVT_MESSAGE_RECEIVED:
            mesh_msg_handle(&p_evt->params.message);
            break;
        case MESH_EVT_CONFIG_LOAD_FAILURE:

            break;
        default:
            break;
    }

}


static void access_state_clear(void)
{
    memset(&access_model_pool[0], 0, sizeof(access_model_pool));
    memset(&access_element_pool[0], 0, sizeof(access_element_pool));
    memset(&access_subscription_list_pool[0], 0, sizeof(access_subscription_list_pool));
    for (uint16_t i = 0; i < ARRAY_SIZE(access_model_pool); ++i)
    {
        access_model_pool[i].model_info.publish_address_handle = DSM_HANDLE_INVALID;
        access_model_pool[i].model_info.publish_appkey_handle = DSM_HANDLE_INVALID;
        access_model_pool[i].model_info.subscription_pool_index = ACCESS_SUBSCRIPTION_LIST_COUNT;
        access_model_pool[i].model_info.element_index = ACCESS_ELEMENT_INDEX_INVALID;
        access_model_pool[i].publish_divisor = 1;
    }
}



static void divide_publish_interval(access_publish_resolution_t input_resolution, uint8_t input_steps,
        access_publish_resolution_t * p_output_resolution, uint8_t * p_output_steps, uint16_t divisor)
{
    uint32_t ms100_value = input_steps;
    switch (input_resolution)
    {
        case ACCESS_PUBLISH_RESOLUTION_100MS:
            break;
        case ACCESS_PUBLISH_RESOLUTION_1S:
            ms100_value *= 10;
            break;
        case ACCESS_PUBLISH_RESOLUTION_10S:
            ms100_value *= 100;
            break;
        case ACCESS_PUBLISH_RESOLUTION_10MIN:
            ms100_value *= 6000;
            break;
        default:break;
            
    }
    ms100_value /= divisor;
    if (ms100_value < 10)
    {
        *p_output_resolution = ACCESS_PUBLISH_RESOLUTION_100MS;
        if (input_steps == 0)
        {
            *p_output_steps = 0;
        }
        else
        {
            *p_output_steps = MAX(1, ms100_value);
        }
    }
    else if (ms100_value < 100)
    {
        *p_output_resolution = ACCESS_PUBLISH_RESOLUTION_1S;
        *p_output_steps = ms100_value / 10;
    }
    else if (ms100_value < 6000)
    {
        *p_output_resolution = ACCESS_PUBLISH_RESOLUTION_10S;
        *p_output_steps = ms100_value / 100;
    }
    else
    {
        *p_output_resolution = ACCESS_PUBLISH_RESOLUTION_10MIN;
        *p_output_steps = ms100_value / 6000;
    }

}
static void access_publish_timing_update(access_model_handle_t handle)
{
    access_publish_resolution_t reg_res, fast_res;
    uint8_t reg_steps, fast_steps;

    access_model_publish_period_get(handle, &reg_res, &reg_steps);
    divide_publish_interval(reg_res, reg_steps, &fast_res, &fast_steps, access_model_pool[handle].publish_divisor);
    access_publish_period_set(&access_model_pool[handle].publication_state, fast_res, fast_steps);
}


void access_init(void)
{
    access_state_clear();
    m_evt_handler.evt_cb = mesh_evt_cb;
    mesh_evt_handler_add(&m_evt_handler);
    access_publish_init();
    access_publish_retransmission_init();
    access_reliable_init();

    access_status.is_metadata_stored = 0;
    access_status.is_load_failed = 0;
    access_status.is_restoring_ended = 0;
}



uint32_t access_model_p_args_get(access_model_handle_t handle, void ** pp_args)
{
    if (NULL == pp_args)
    {
        return MESH_ERROR_NULL;
    }
    else if (!model_handle_valid_and_allocated(handle))
    {
        return MESH_ERROR_NOT_FOUND;
    }
    else
    {
        *pp_args = access_model_pool[handle].p_args;
        return MESH_SUCCESS;
    }
}

static uint32_t packet_tx(access_model_handle_t handle,
                          const access_message_tx_t * p_tx_message,
                          const access_message_rx_t * p_rx_message,
                          const uint8_t *p_access_payload,
                          uint16_t access_payload_len)
{
    uint32_t status = MESH_SUCCESS;

    dsm_local_unicast_address_t local_addresses;
    dsm_local_unicast_addresses_get(&local_addresses);
    if (access_model_pool[handle].model_info.element_index >= local_addresses.count)
    {
        return MESH_ERROR_INVALID_ADDR;
    }

    uint16_t src_address = local_addresses.address_start + access_model_pool[handle].model_info.element_index;

    mesh_address_t dst_address;
    dsm_handle_t appkey_handle;
    dsm_handle_t subnet_handle = DSM_HANDLE_INVALID;
    if (p_rx_message != NULL)
    {
        appkey_handle = p_rx_message->meta_data.appkey_handle;
        subnet_handle = p_rx_message->meta_data.subnet_handle;
        dst_address = p_rx_message->meta_data.src;
    }
    else
    {
        appkey_handle = access_model_pool[handle].model_info.publish_appkey_handle;
        if (dsm_address_get(access_model_pool[handle].model_info.publish_address_handle, &dst_address) != MESH_SUCCESS)
        {
            return MESH_ERROR_NOT_FOUND;
        }
        if  (dst_address.value == MESH_ADDR_UNASSIGNED)
        {
            return MESH_ERROR_INVALID_ADDR;
        }
    }

    uint8_t ttl;
    if (p_rx_message != NULL && p_rx_message->meta_data.ttl == 0)
    {
        ttl = 0;
    }
    else if (access_model_pool[handle].model_info.publish_ttl == ACCESS_TTL_USE_DEFAULT)
    {
        ttl = access_default_ttl;
    }
    else
    {
        ttl = access_model_pool[handle].model_info.publish_ttl;
    }
    mesh_tx_params_t tx_params;
    memset(&tx_params, 0, sizeof(tx_params));

//    LOG_PRINTF("ttl : %d\r\n",ttl);
    
//    LOG_PRINTF("subnet_handle : %d\r\n",subnet_handle);
//    LOG_PRINTF("appkey_handle : %d\r\n",appkey_handle);
    {
        status = dsm_tx_secmat_get(subnet_handle, appkey_handle, &tx_params.security_material);
    }
//    LOG_PRINTF("aid : %d\r\n",tx_params.security_material.p_app->aid);
//    LOG_HEXDUMP(tx_params.security_material.p_app->key,16);

    if (status != MESH_SUCCESS)
    {
        return status;
    }

    tx_params.dst = dst_address;
    tx_params.src = src_address;
    tx_params.ttl = ttl;
    tx_params.force_segmented = p_tx_message->force_segmented;
    tx_params.transmic_size = p_tx_message->transmic_size;
    tx_params.p_data = p_access_payload;
    tx_params.data_len = access_payload_len;
    tx_params.tx_token = p_tx_message->access_token;

    
    LOG_PRINTF("dst type : %d\r\n",tx_params.dst.type);
    LOG_PRINTF("tx dst addr : %X\r\n",tx_params.dst.value);
    LOG_PRINTF("tx src addr : %X\r\n",tx_params.src);       
    LOG_PRINTF("ttl : %d\r\n",tx_params.ttl);
    LOG_PRINTF("force_segmented : %d\r\n",tx_params.force_segmented);
    LOG_PRINTF("transmic_size : %d\r\n",tx_params.transmic_size);
    LOG_PRINTF("tx_token : %X\r\n",tx_params.tx_token);
    
    
    status = mesh_packet_send(&tx_params, NULL);
    if (status == MESH_SUCCESS)
    {
        LOG_PRINTF("TX: [aop: 0x%04x] \n", p_tx_message->opcode.opcode);
//        LOG_HEXDUMP(tx_params.p_data, tx_params.data_len);
    }

    return status;
}
uint32_t access_packet_tx(access_model_handle_t handle,
                          const access_message_tx_t * p_tx_message,
                          const uint8_t *p_access_payload,
                          uint16_t access_payload_len)
{
    LOG_PRINTF("access_packet_tx\n");
    uint32_t status;
    if (NULL == p_tx_message || NULL == p_access_payload || 0 == access_payload_len)
    {
        return MESH_ERROR_NULL;
    }
    else if (!check_tx_params(handle, p_tx_message, NULL, &status))
    {
        return status;
    }

    return packet_tx(handle, p_tx_message, NULL, p_access_payload,
                     access_payload_len);
}
static inline void opcode_set(access_opcode_t opcode, uint8_t * p_buffer)
{
    if (opcode.company_id != ACCESS_COMPANY_ID_NONE)
    {
        p_buffer[0] = opcode.opcode & 0x00FF;
        p_buffer[1] = opcode.company_id & 0x00FF;
        p_buffer[2] = (opcode.company_id >> 8) & 0x00FF;
    }
    else if ((opcode.opcode & 0xFF00) > 0)
    {
        p_buffer[0] = (opcode.opcode >> 8) & 0x00FF;
        p_buffer[1] = opcode.opcode & 0x00FF;
    }
    else
    {
        p_buffer[0] = opcode.opcode & 0x00FF;
    }
}
static uint32_t packet_alloc_and_tx(access_model_handle_t handle,
                                    const access_message_tx_t * p_tx_message,
                                    const access_message_rx_t * p_rx_message,
                                    uint8_t **pp_access_payload,
                                    uint16_t *p_access_payload_len)
{
    LOG_PRINTF("packet_alloc_and_tx\n");
    uint32_t status;

    if (!check_tx_params(handle, p_tx_message, p_rx_message, &status))
    {
        return status;
    }

    uint16_t opcode_length = access_utils_opcode_size_get(p_tx_message->opcode);
    uint16_t payload_length = opcode_length + p_tx_message->length;

    uint8_t *p_payload = (uint8_t *) malloc(payload_length);
    if (NULL == p_payload)
    {
        return MESH_ERROR_NO_MEM;
    }

    opcode_set(p_tx_message->opcode, p_payload);
    memcpy(&p_payload[opcode_length], p_tx_message->p_buffer, p_tx_message->length);

    LOG_PRINTF("p_payload : ");
    LOG_HEXDUMP(p_payload, payload_length);    
    
    
    
    status = packet_tx(handle, p_tx_message, p_rx_message, p_payload, payload_length);
    if (MESH_SUCCESS != status || NULL == pp_access_payload || NULL == p_access_payload_len)
    {
        free(p_payload);
        return status;
    }

    *pp_access_payload = p_payload;
    *p_access_payload_len = payload_length;

    return MESH_SUCCESS;
}
uint32_t access_model_publish(access_model_handle_t handle, const access_message_tx_t * p_message)
{
    DEBUG_PRINTF("%s\r\n",__FUNCTION__);
    uint32_t status;

    if (p_message == NULL)
    {
        return MESH_ERROR_NULL;
    }

    uint16_t payload_length = 0;
    uint8_t *p_payload;

//    LOG_PRINTF("p_message : ");
//    LOG_HEXDUMP(p_message, sizeof(access_message_tx_t));
    
    
    status = packet_alloc_and_tx(handle, p_message, NULL, &p_payload, &payload_length);
    LOG_PRINTF("packet_alloc_and_tx : %d\r\n",status);
    if (MESH_SUCCESS != status)
    {
        return status;
    }
    
    if (access_model_pool[handle].model_info.publication_retransmit.count > 0)
    {
        access_publish_retransmission_message_add(handle,
                                                  &access_model_pool[handle].model_info.publication_retransmit,
                                                  p_message,
                                                  p_payload,
                                                  payload_length);
    }
    else
    {
        free(p_payload);
    }    
    
    
    return MESH_SUCCESS;
}

uint32_t access_model_reply(access_model_handle_t handle,
                            const access_message_rx_t * p_message,
                            const access_message_tx_t * p_reply)
{
    DEBUG_PRINTF("%s\r\n",__FUNCTION__);
    if (p_message == NULL || p_reply == NULL)
    {
        return MESH_ERROR_NULL;
    }

    return packet_alloc_and_tx(handle, p_reply, p_message, NULL, NULL);
}


uint32_t access_model_publication_by_appkey_stop(dsm_handle_t appkey_handle)
{
    dsm_handle_t local_handle;

    if (DSM_APP_MAX + DSM_DEVICE_MAX <= appkey_handle)
    {
        return MESH_ERROR_INVALID_PARAM;
    }

    for (access_model_handle_t i = 0; i < ACCESS_MODEL_COUNT; i++)
    {
        if (MESH_SUCCESS == access_model_publish_application_get(i, &local_handle))
        {
            if (local_handle == appkey_handle)
            {
                (void) access_model_publication_stop(i);
            }
        }
    }

    return MESH_SUCCESS;
}


uint32_t access_model_publish_period_divisor_set(access_model_handle_t handle, uint16_t publish_divisor)
{

    if (ACCESS_MODEL_COUNT <= handle ||
        !ACCESS_INTERNAL_STATE_IS_ALLOCATED(access_model_pool[handle].internal_state))
    {
        return MESH_ERROR_NOT_FOUND;
    }
    else if (access_model_pool[handle].publication_state.publish_timeout_cb == NULL)
    {
        return MESH_ERROR_NOT_SUPPORTED;
    }
    else if (publish_divisor == 0)
    {
        return MESH_ERROR_INVALID_PARAM;
    }

    access_model_pool[handle].publish_divisor = publish_divisor;
    access_publish_timing_update(handle);

    return MESH_SUCCESS;
}

