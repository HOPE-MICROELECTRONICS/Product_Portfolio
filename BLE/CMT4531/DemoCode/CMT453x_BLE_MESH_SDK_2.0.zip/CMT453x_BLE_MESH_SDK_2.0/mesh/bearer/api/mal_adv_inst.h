#ifndef __MAL_ADV_INST_H__
#define __MAL_ADV_INST_H__



#include "mal_adv.h"
#include "mal_bearer_adv.h"
#include "mal_djob.h"















#endif //__MAL_ADV_INST_H__
