#include "scanner.h"
#include <string.h>
#include <stdio.h>
#include "app_task.h"
#include "gapm_task.h"
#include "rwip.h"
#include "co_bt_defines.h"
#include "gapc_task.h"  
#include "mesh_error.h" 
#include "packet_buffer.h"
#include "bearer_event.h"
#include "filter_engine.h"
#include "bearer_handler.h"
#include "ke_timer.h"
#include "app_task.h"
#include "bsp_lpuart.h"


#define RADIO_CONFIG_ADV_MAX_PAYLOAD_SIZE 37
#define LNA_SETUP_OVERHEAD_US 1


#define SCANNER_TIMER_INDEX_TIMESTAMP   (TS_TIMER_INDEX_RADIO)
#define SCANNER_TIMER_INDEX_LNA_SETUP   (1)
#define SCANNER_PPI_CH                  (TS_TIMER_PPI_CH_START + TS_TIMER_INDEX_RADIO)
#define SCANNER_TIMER_LNA_INTERRUPT_Msk (1UL << (TIMER_INTENSET_COMPARE0_Pos + SCANNER_TIMER_INDEX_LNA_SETUP))

#define SCANNER_PACKET_OVERHEAD (offsetof(scanner_packet_t, packet.addr))




typedef enum
{
    SCANNER_STATE_UNINITIALIZED,
    SCANNER_STATE_IDLE,
    SCANNER_STATE_RUNNING,
    SCANNER_STATE_PAUSE,
} scanner_state_t;


typedef struct
{
    scanner_state_t          state;    
    packet_buffer_packet_t * p_buffer_packet;
    scanner_stats_t          stats;
    bearer_event_flag_t      mesh_process_flag;
    packet_buffer_t          packet_buffer;
    uint8_t                  packet_buffer_data[SCANNER_BUFFER_SIZE];
    scanner_rx_callback_t    rx_callback;
} scanner_t;


static scanner_t m_scanner;

static void (*m_packet_process_cb)(void);


extern uint8_t m_scan_actv_idx;
static void radio_create_scan(void)
{
    struct gapm_activity_create_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_CREATE_CMD,
                                                              TASK_GAPM, TASK_APP,
                                                              gapm_activity_create_cmd);

    p_cmd->operation = GAPM_CREATE_SCAN_ACTIVITY;
    p_cmd->own_addr_type = GAPM_STATIC_ADDR;
    ke_msg_send(p_cmd);   
    
}



static void radio_start(void)
{
    struct gapm_activity_start_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_START_CMD,
                                                         TASK_GAPM, TASK_APP,
                                                         gapm_activity_start_cmd);
    p_cmd->operation = GAPM_START_ACTIVITY;
    p_cmd->actv_idx = m_scan_actv_idx;
    p_cmd->u_param.scan_param.type = GAPM_SCAN_TYPE_OBSERVER;
    p_cmd->u_param.scan_param.prop = GAPM_SCAN_PROP_PHY_1M_BIT|GAPM_SCAN_PROP_FILT_TRUNC_BIT;
    p_cmd->u_param.scan_param.dup_filt_pol = GAPM_DUP_FILT_DIS;
    p_cmd->u_param.scan_param.scan_param_1m.scan_intv = 0x40;
    p_cmd->u_param.scan_param.scan_param_1m.scan_wd  = 0x30;
    p_cmd->u_param.scan_param.duration = 0; 
    p_cmd->u_param.scan_param.period = 0;
    ke_msg_send(p_cmd);
}

static void radio_stop_scan(void)
{  
    LOG_PRINTF("radio_stop_scan\r\n");
    struct gapm_activity_stop_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_STOP_CMD,
                                                      TASK_GAPM, TASK_APP,
                                                      gapm_activity_stop_cmd);
    p_cmd->operation = GAPM_STOP_ACTIVITY;
    p_cmd->actv_idx = m_scan_actv_idx;
    ke_msg_send(p_cmd);    
}

static void radio_delete_scan(void)
{
    struct gapm_activity_delete_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_DELETE_CMD,
                                                              TASK_GAPM, TASK_APP,
                                                              gapm_activity_delete_cmd);
    p_cmd->operation = GAPM_DELETE_ACTIVITY;
    p_cmd->actv_idx = m_scan_actv_idx;
    ke_msg_send(p_cmd);
}



void scanner_packet_release(const scanner_packet_t * p_packet)
{
    packet_buffer_free(&m_scanner.packet_buffer, PARENT_BY_FIELD_GET(packet_buffer_packet_t, packet, p_packet));
}


void scanner_handle_end_event(mesh_rx_metadata_scanner_t *metadata, uint8_t *adv_pdu, uint16_t len)
{
    if(m_scanner.state == SCANNER_STATE_PAUSE)
        return;
    bool got_packet = (MESH_SUCCESS == packet_buffer_reserve(&m_scanner.packet_buffer,
                                                            &m_scanner.p_buffer_packet,
                                                            sizeof(scanner_packet_t)));    
    if(got_packet){
    
        bool successful_receive = false;
        scanner_packet_t * p_packet = (scanner_packet_t *) m_scanner.p_buffer_packet->packet;

        if (p_packet->packet.header.length > RADIO_CONFIG_ADV_MAX_PAYLOAD_SIZE)
        {
            m_scanner.stats.length_out_of_bounds++;
        }
        else
        {
            successful_receive = true;
        }

        if (successful_receive)
        {
            m_scanner.stats.successful_receives++;
            p_packet->metadata.adv_addr.addr[0] = metadata->adv_addr.addr[0];
            p_packet->metadata.adv_addr.addr[1] = metadata->adv_addr.addr[1];
            p_packet->metadata.adv_addr.addr[2] = metadata->adv_addr.addr[2];
            p_packet->metadata.adv_addr.addr[3] = metadata->adv_addr.addr[3];
            p_packet->metadata.adv_addr.addr[4] = metadata->adv_addr.addr[4];
            p_packet->metadata.adv_addr.addr[5] = metadata->adv_addr.addr[5];    
            p_packet->metadata.rssi = metadata->rssi;
            memcpy(p_packet->packet.payload,adv_pdu,len);
            p_packet->packet.header.length = len + 6;
            p_packet->packet.header.type = metadata->adv_type;            
            
            
            if (!fen_filters_apply(FILTER_TYPE_PRE_PROC, p_packet))
            {
                packet_buffer_commit(&m_scanner.packet_buffer, m_scanner.p_buffer_packet, SCANNER_PACKET_OVERHEAD + p_packet->packet.header.length);
                m_packet_process_cb();
            }
            else
            {
                packet_buffer_free(&m_scanner.packet_buffer, m_scanner.p_buffer_packet);
            }
        }
        else
        {
            packet_buffer_free(&m_scanner.packet_buffer, m_scanner.p_buffer_packet);
        }

        m_scanner.p_buffer_packet = NULL;    
    
    }

}
bool scanner_radio_is_idle(void)
{
    return m_scanner.state == SCANNER_STATE_IDLE;
}
void scanner_radio_stop(void)
{
    if(m_scanner.state == SCANNER_STATE_RUNNING){
        m_scanner.state = SCANNER_STATE_IDLE;
        radio_stop_scan();    
    }

}

void scanner_radio_delete(void)
{
    radio_delete_scan();

}

void scanner_radio_start(void)
{
    m_scanner.state = SCANNER_STATE_RUNNING;
    radio_start();

}


void scanner_init(void (*packet_process_cb)(void))
{
    radio_create_scan();
    memset(&m_scanner, 0, sizeof(m_scanner));
    packet_buffer_init(&m_scanner.packet_buffer, m_scanner.packet_buffer_data, SCANNER_BUFFER_SIZE);
    m_scanner.state = SCANNER_STATE_IDLE;
    m_packet_process_cb = packet_process_cb;
}
const scanner_packet_t * scanner_rx(void)
{
    packet_buffer_packet_t * p_packet;

    while (packet_buffer_pop(&m_scanner.packet_buffer, &p_packet) == MESH_SUCCESS)
    {
        if (fen_filters_apply(FILTER_TYPE_POST_PROC, (scanner_packet_t *)p_packet->packet))
        {
            scanner_packet_release((scanner_packet_t *)p_packet->packet);
        }
        else
        {
            return (scanner_packet_t *)p_packet->packet;
        }
    }

    return NULL;
}

bool scanner_rx_pending(void)
{
    return packet_buffer_can_pop(&m_scanner.packet_buffer);
}



void scanner_pause(void)
{
    m_scanner.state = SCANNER_STATE_PAUSE;
}


void scanner_resume(void)
{
    m_scanner.state = SCANNER_STATE_RUNNING;
}



