#include "broadcast.h"
#include "packet.h"
#include "stdio.h"
#include "bsp_lpuart.h"
#include "bearer_event.h"
#include "app.h"
#include "app_task.h"
#include "gap.h"                     
#include "gapm_task.h"               
#include "gapc_task.h"               
#include "gapm_int.h"
#include "rwip.h"
#include "ke_timer.h"
#include "mesh_app_task.h"
#include "bsp_led.h"
#include "mal_adv_inst.h"
#include "reg_ipcore.h"


extern uint8_t m_actv_idx;
static bearer_event_sequential_t m_bearer_event_seq;
static broadcast_t * mp_broadcast;
extern mal_adv_env_t mal_adv_env;


static void broadcast_start(void* p_args)
{
    LOG_PRINTF("broadcast_start\r\n");
    mp_broadcast = (broadcast_t *) p_args;
    mal_adv_bearer_param_t param = {
          .chlmap = mp_broadcast->params.chlmap,
          .interval = mp_broadcast->params.interval,
          .duration = mp_broadcast->params.duration,
          .adv_len = mp_broadcast->params.p_packet->header.length-BLE_ADV_PACKET_OVERHEAD,
          .p_data = mp_broadcast->params.p_packet->payload,       
    };
    LOG_PRINTF("duration --> %d\r\n",param.duration);
    LOG_PRINTF("chlmap --> %d\r\n",param.chlmap);
    LOG_PRINTF("interval --> %d\r\n",param.interval);
    LOG_PRINTF("adv_len --> %d\r\n",param.adv_len);
	if(MESH_SUCCESS != mal_adv_bearer_send(&param, MAL_ADV_BEARER_SRCINFO_BROADCAST, NULL)){
        mp_broadcast->params.tx_complete_cb(&mp_broadcast->params, 0);
        bearer_handler_action_end();
        mp_broadcast->active = false;   
        mp_broadcast = NULL;    
    }
}




void broadcast_stop(uint8_t actv_idx)
{
    if(mp_broadcast != NULL && mp_broadcast->active && actv_idx == mal_adv_env.p_adv_env->adv_idx){
        mp_broadcast->params.tx_complete_cb(&mp_broadcast->params, 0);
        bearer_handler_action_end();
        mp_broadcast->active = false;   
        mp_broadcast = NULL;
    }
}

void broadcast_stop_with_error(void)
{
    if(mp_broadcast != NULL && mp_broadcast->active){
        mp_broadcast->params.tx_complete_cb(&mp_broadcast->params, 0);
        bearer_handler_action_end();
        mp_broadcast->active = false;   
        mp_broadcast = NULL;
    }

}


void broadcast_init(void)
{

}





uint32_t broadcast_send(broadcast_t * p_broadcast)
{
    LOG_PRINTF("broadcast_send\r\n");
    if (mp_broadcast != NULL || p_broadcast->active)
    {
        return MESH_ERROR_BUSY;
    }
    p_broadcast->action.start_cb = broadcast_start;
    p_broadcast->action.p_args = p_broadcast;
    p_broadcast->active = true;
    bearer_handler_action_enqueue(&p_broadcast->action);

    return MESH_SUCCESS;
}




