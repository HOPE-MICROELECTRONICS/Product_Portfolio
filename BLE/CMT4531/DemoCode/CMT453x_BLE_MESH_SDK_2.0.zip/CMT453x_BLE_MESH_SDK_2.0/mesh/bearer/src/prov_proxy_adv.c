#include "prov_proxy_adv.h"
#include "rwip.h"
#include "gattc.h"
#include "attc.h"
#include "gap.h"                     
#include "gapm_task.h"               
#include "gapc_task.h"               
#include "gapm_int.h"
#include "co_math.h" 
#include "string.h" 
#include "app_task.h" 
#include "bsp_lpuart.h"
#include "stdio.h"
#include "mesh_gatt.h"
#include "global_var.h"

static uint8_t m_adv_idx = 0;
extern uint8_t m_actv_idx;

uint8_t prov_proxy_adv_adv_idx_get(void)
{
    return m_adv_idx;
}
static __inline void app_build_adv_data(uint16_t *p_length, uint8_t *p_buf, const uint8_t * m_service_data, uint8_t m_service_data_len)
{
	uint8_t uuid[] = {3,0x03,0x27,0x18};
    memcpy(p_buf, (uint8_t *)&uuid, sizeof(uuid));
    *p_length += sizeof(uuid);
    p_buf += sizeof(uuid);	
    
    *p_buf++ = m_service_data_len + 1 + 2;
    *p_buf++ = 0x16;
    *p_buf++ = 0x27;
    *p_buf++ = 0x18;
    memcpy(p_buf, m_service_data, m_service_data_len);
    *p_length += m_service_data_len + 4;

}
static __inline void app_build_adv_data_proxy(uint16_t *p_length, uint8_t *p_buf, const uint8_t * m_service_data, uint8_t m_service_data_len)
{
	uint8_t uuid[] = {3,0x03,0x28,0x18};
    memcpy(p_buf, (uint8_t *)&uuid, sizeof(uuid));
    *p_length += sizeof(uuid);
    p_buf += sizeof(uuid);	
    
    *p_buf++ = m_service_data_len + 1 + 2;
    *p_buf++ = 0x16;
    *p_buf++ = 0x28;
    *p_buf++ = 0x18;
    memcpy(p_buf, m_service_data, m_service_data_len);
    *p_length += m_service_data_len + 4;

}

void prov_proxy_adv_data_set(uint16_t service_uuid, const uint8_t * p_service_data, uint8_t length)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
	struct gapm_set_adv_data_cmd *p_adv_cmd = KE_MSG_ALLOC_DYN(GAPM_SET_ADV_DATA_CMD,
                                                             TASK_GAPM, TASK_APP,
                                                             gapm_set_adv_data_cmd,
                                                             ADV_DATA_LEN);
	p_adv_cmd->operation = GAPM_SET_ADV_DATA;
    p_adv_cmd->actv_idx = m_adv_idx;
    if(service_uuid == MESH_PB_GATT_SERVICE_UUID){
        app_build_adv_data(&p_adv_cmd->length, &p_adv_cmd->data[0],p_service_data, length);       
    }else if(service_uuid == PROXY_UUID_SERVICE){
        app_build_adv_data_proxy(&p_adv_cmd->length, &p_adv_cmd->data[0],p_service_data, length); 
    }
	ke_msg_send(p_adv_cmd);     
	struct gapm_set_adv_data_cmd *p_rsp_cmd = KE_MSG_ALLOC_DYN(GAPM_SET_ADV_DATA_CMD,
                                                         TASK_GAPM, TASK_APP,
                                                         gapm_set_adv_data_cmd,
                                                         ADV_DATA_LEN);
	p_rsp_cmd->operation = GAPM_SET_SCAN_RSP_DATA;
    p_rsp_cmd->actv_idx = m_adv_idx;
	p_rsp_cmd->length = 0;   
    uint8_t *p_buf = p_rsp_cmd->data; 
    char name[20];
    memset(name,0,sizeof(name));
    sprintf(name,"MESH_%02X%02X",g_co_default_bdaddr.addr[4],g_co_default_bdaddr.addr[5]);
    *p_buf = strlen(name) + 1;
    *(p_buf + 1) = '\x09';//full device name
    memcpy(p_rsp_cmd->data + 2, name, strlen(name));
    p_rsp_cmd->length += strlen(name) + 2;
	ke_msg_send(p_rsp_cmd);  
}
 


void prov_proxy_adv_params_set(uint32_t timeout_ms, uint32_t interval_units)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    struct gapm_activity_create_adv_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_CREATE_CMD,
                                                            TASK_GAPM, TASK_APP,
                                                            gapm_activity_create_adv_cmd);
    p_cmd->operation = GAPM_CREATE_ADV_ACTIVITY;
    p_cmd->own_addr_type = GAPM_STATIC_ADDR;
    p_cmd->adv_param.type = GAPM_ADV_TYPE_LEGACY;
    p_cmd->adv_param.prop = GAPM_ADV_PROP_UNDIR_CONN_MASK;
    p_cmd->adv_param.filter_pol = ADV_ALLOW_SCAN_ANY_CON_ANY;
    p_cmd->adv_param.prim_cfg.chnl_map = ADV_ALL_CHNLS_EN;
    p_cmd->adv_param.prim_cfg.phy = GAP_PHY_LE_1MBPS;
    p_cmd->adv_param.disc_mode = GAPM_ADV_MODE_GEN_DISC;
    p_cmd->adv_param.prim_cfg.adv_intv_min = interval_units; 
    p_cmd->adv_param.prim_cfg.adv_intv_max = interval_units; 
    ke_msg_send(p_cmd);    
    rwip_schedule();
    m_adv_idx = m_actv_idx; 
}

void prov_proxy_adv_delete(void)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    struct gapm_activity_delete_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_DELETE_CMD,
                                                              TASK_GAPM, TASK_APP,
                                                              gapm_activity_delete_cmd);
    p_cmd->operation = GAPM_DELETE_ACTIVITY;
    p_cmd->actv_idx = m_adv_idx;
    ke_msg_send(p_cmd);
    rwip_schedule();
    m_adv_idx = 0xff;
}

void prov_proxy_adv_start(void)
{
    LOG_PRINTF("%s %d\r\n",__FUNCTION__, m_adv_idx);
    struct gapm_activity_start_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_START_CMD,
                                                         TASK_GAPM, TASK_APP,
                                                         gapm_activity_start_cmd);

    p_cmd->operation = GAPM_START_ACTIVITY;
    p_cmd->actv_idx = m_adv_idx;
    p_cmd->u_param.adv_add_param.duration = 0;
    p_cmd->u_param.adv_add_param.max_adv_evt = 0;
    ke_msg_send(p_cmd);
}
void prov_proxy_adv_stop(void)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    struct gapm_activity_stop_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_STOP_CMD,
                                                      TASK_GAPM, TASK_APP,
                                                      gapm_activity_stop_cmd);
    p_cmd->operation = GAPM_STOP_ACTIVITY;
    p_cmd->actv_idx = m_adv_idx;  
    ke_msg_send(p_cmd);    
}
