#include "advertiser.h"
#include "broadcast.h"
#include "packet_buffer.h"
#include "timer_scheduler.h"
#include "rand.h"
#include "toolchain.h"
#include "mesh_config_core.h"
#include "stdio.h"
#include "bearer_defines.h"
#include <stdlib.h>
#include "bsp_lpuart.h"
#include "mesh_app.h"
#include "core_tx_adv.h"
#include "core_tx.h"



extern mesh_dynamic_param_t mesh_dynamic_param;


static inline packet_buffer_packet_t * get_packet_buffer_from_adv_packet(adv_packet_t * p_packet)
{
    return PARENT_BY_FIELD_GET(packet_buffer_packet_t, packet, p_packet);
}
static inline bool is_tx_complete_event_pending(advertiser_t * p_adv)
{
    return ((p_adv->tx_complete_callback != NULL) &&
            bearer_event_sequential_pending(&p_adv->tx_complete_event));
}

static void broadcast_complete_cb(broadcast_params_t * p_broadcast, timestamp_t timestamp)
{
    advertiser_t * p_adv = PARENT_BY_FIELD_GET(advertiser_t, broadcast.params, p_broadcast);

    if ((p_adv->p_packet->config.repeats == 0 ||
         p_adv->p_packet->config.repeats == ADVERTISER_REPEAT_INFINITE) &&
        p_adv->tx_complete_callback != NULL)
    {
        p_adv->tx_complete_params.token = p_adv->p_packet->token;
        p_adv->tx_complete_params.timestamp = timestamp;
        bearer_event_sequential_post(&p_adv->tx_complete_event);
    }
    LOG_PRINTF("repeat --> %d\r\n",p_adv->p_packet->config.repeats);
    if (p_adv->p_packet->config.repeats == 0)
    {
        packet_buffer_packet_t * p_buf_packet = get_packet_buffer_from_adv_packet(p_adv->p_packet);
        p_adv->p_packet = NULL;
        packet_buffer_free(&p_adv->buf, p_buf_packet);
    }
}
static bool should_free_current_packet(advertiser_t * p_adv)
{
    bool should_replace_infinite_packet =
        (p_adv->p_packet->config.repeats == ADVERTISER_REPEAT_INFINITE &&
         packet_buffer_packets_ready_to_pop(&p_adv->buf));
    bool packet_has_no_repeats = (p_adv->p_packet->config.repeats == 0);
    return (should_replace_infinite_packet || packet_has_no_repeats);
}
static bool next_packet_fetch(advertiser_t * p_adv)
{
    while (p_adv->p_packet == NULL || should_free_current_packet(p_adv))
    {
        if (p_adv->p_packet != NULL)
        {
            packet_buffer_free(&p_adv->buf, get_packet_buffer_from_adv_packet(p_adv->p_packet));
            p_adv->p_packet = NULL;
        }
        packet_buffer_packet_t * p_packet_buf;
        if (packet_buffer_pop(&p_adv->buf, &p_packet_buf) == MESH_SUCCESS)  
        {
            p_adv->p_packet = (adv_packet_t *) p_packet_buf->packet;
            p_adv->broadcast.params.p_packet = &p_adv->p_packet->packet;
        }
        else
        {
            return false;
        }        

    }
    return true;
}

static inline void update_repeat_count(advertiser_t * p_adv, adv_packet_t * p_adv_packet)
{
    if (p_adv_packet->config.repeats != ADVERTISER_REPEAT_INFINITE)
    {
        p_adv_packet->config.repeats--;
    }
}



static void schedule_broadcast(advertiser_t * p_adv)
{
    update_repeat_count(p_adv, p_adv->p_packet);
    LOG_PRINTF("repeats --> %d\r\n",p_adv->p_packet->config.repeats);
    if(check_ke_mem_used_size() < 10000){
        
        p_adv->broadcast.params.chlmap = 7;
        p_adv->broadcast.params.interval = 4;          
        #ifdef ALEXA
        p_adv->broadcast.params.duration = p_adv->p_packet->config.duration==0?10:p_adv->p_packet->config.duration;
        #else
        p_adv->broadcast.params.duration = 20;
        #endif
        broadcast_send(&p_adv->broadcast);
    }else{
        p_adv->p_packet->config.repeats = 0;
        if(p_adv->broadcast.params.tx_complete_cb)p_adv->broadcast.params.tx_complete_cb(&p_adv->broadcast.params,0);
    }

   
    
    
}
static inline void setup_next_timeout(timer_event_t * p_timer_evt, uint32_t base_interval)
{
    p_timer_evt->interval = base_interval;
}

static void timeout_event(timestamp_t timestamp, void * p_context)
{
    advertiser_t * p_adv = (advertiser_t *) p_context;
    p_adv->timer.interval = 0;
    if (p_adv->enabled)
    {
        bool has_packet;
        if (p_adv->broadcast.active || is_tx_complete_event_pending(p_adv))
        {
            has_packet = true;
        }
        else
        {
            has_packet = next_packet_fetch(p_adv);
            LOG_PRINTF("has_packet --> %d\r\n",has_packet);
            if (has_packet)
            {
                schedule_broadcast(p_adv);
            }
        } 
        if (has_packet)
        {
            uint32_t timeout = 0;
            if(p_adv->role == CORE_TX_ROLE_RELAY){
                timeout = (rand_hw_get()%20)*1000;
            }else{
                timeout = (rand()%15+20)*1000;
            }            
            setup_next_timeout(&p_adv->timer, timeout);
        }        
    }
}
static void tx_complete_event_callback(void * p_context)
{
    advertiser_t * p_adv = (advertiser_t *)p_context;
    if(p_adv->tx_complete_callback)p_adv->tx_complete_callback(p_adv, p_adv->tx_complete_params.token, p_adv->tx_complete_params.timestamp);
}
static inline void schedule_first_time(timer_event_t * p_timer_evt, uint32_t max_delay)
{
    timer_sch_reschedule(p_timer_evt, bsp_time_now() + max_delay);
}
static inline bool is_active(const advertiser_t * p_adv)
{
    return (p_adv->timer.state != TIMER_EVENT_STATE_UNUSED);
}


void advertiser_instance_init(advertiser_t * p_adv,
                              advertiser_tx_complete_cb_t tx_complete_cb,
                              uint8_t * p_buffer,
                              uint32_t buffer_size)
{
    packet_buffer_init(&p_adv->buf, p_buffer, buffer_size);
    p_adv->broadcast.params.tx_complete_cb = broadcast_complete_cb;
    p_adv->broadcast.params.p_packet = NULL;
    p_adv->tx_complete_callback = tx_complete_cb;
    p_adv->timer.cb = timeout_event;
    p_adv->timer.p_context = p_adv;
    p_adv->enabled = false;

    if (tx_complete_cb != NULL)
    {
        bearer_event_sequential_add(&p_adv->tx_complete_event, tx_complete_event_callback, p_adv);
    }
}

void advertiser_enable(advertiser_t * p_adv)
{
    if (!p_adv->enabled)
    {
        p_adv->enabled = true;
        if (p_adv->p_packet != NULL || packet_buffer_can_pop(&p_adv->buf))
        {
            schedule_first_time(&p_adv->timer, p_adv->config.advertisement_interval_us + ADVERTISER_INTERVAL_RANDOMIZATION_US);
        }
    }
}
void advertiser_disable(advertiser_t * p_adv)
{
    p_adv->enabled = false;
    timer_sch_abort(&p_adv->timer);
}

void advertiser_packet_send(advertiser_t * p_adv, adv_packet_t * p_packet)
{
    packet_buffer_packet_t * p_buf_packet = get_packet_buffer_from_adv_packet(p_packet);
    packet_buffer_commit(&p_adv->buf, p_buf_packet, p_buf_packet->size);
    if (p_adv->enabled && !is_active(p_adv))
    {
        uint32_t timeout = 0;
        if(p_adv->role == CORE_TX_ROLE_RELAY){
            timeout = (rand_hw_get()%10)*1000;
        }else{
            timeout = (rand()%15+20)*1000;
        }
        schedule_first_time(&p_adv->timer, timeout);
    }
    else{
        packet_buffer_free(&p_adv->buf, p_buf_packet); 
    }
}

adv_packet_t * advertiser_packet_alloc(advertiser_t * p_adv, uint32_t adv_payload_size)
{
    packet_buffer_packet_t * p_buf_packet;
    uint32_t status = packet_buffer_reserve(&p_adv->buf, &p_buf_packet, sizeof(adv_packet_t) - BLE_ADV_PACKET_PAYLOAD_MAX_LENGTH + adv_payload_size);
    if (MESH_SUCCESS == status)
    {
        adv_packet_t * p_adv_packet  = (adv_packet_t *) p_buf_packet->packet;
        packet_payload_size_set(&p_adv_packet->packet, adv_payload_size);
        p_adv_packet->packet.header.type = BLE_PACKET_TYPE_ADV_NONCONN_IND;
        p_adv_packet->token = MESH_INITIAL_TOKEN;
        return p_adv_packet;
    }
    else
    {
        packet_buffer_flush(&p_adv->buf);
        return NULL;
    }
}
void advertiser_packet_discard(advertiser_t * p_adv, adv_packet_t * p_packet)
{
    packet_buffer_packet_t * p_buf_packet = get_packet_buffer_from_adv_packet(p_packet);
    packet_buffer_free(&p_adv->buf, p_buf_packet);
}




void advertiser_interval_set(advertiser_t * p_adv, uint32_t interval_ms)
{
    p_adv->config.advertisement_interval_us = MS_TO_US(interval_ms);
}












