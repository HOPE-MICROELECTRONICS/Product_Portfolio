#include "mal_bearer_adv.h"
#include "mesh_error.h"
#include "co_utils.h"
#include "gapm_task.h" 
#include "gapc_task.h" 
#include "string.h" 
#include "stdio.h" 
#include "bsp_lpuart.h" 



static adv_env_t m_adv_env;

void mal_activity_cmd_exec(void)
{
    if ((m_adv_env.cmd_src == MAL_ACT_NONE) &&  !co_list_is_empty(&(m_adv_env.cmd_queue)))
    {
//        LOG_PRINTF("%s\r\n",__FUNCTION__);
        struct ke_msg *p_cmd = (struct ke_msg *)co_list_pop_front(&(m_adv_env.cmd_queue));
        m_adv_env.cmd_src = (uint8_t)p_cmd->src_id;
        p_cmd->src_id = TASK_APP;
        ke_msg_send(ke_msg2param(p_cmd));
    }
}


void mal_activity_cmd_send(uint8_t src, void *p_param)
{
    struct ke_msg *p_cmd = ke_param2msg(p_param);
    p_cmd->src_id = src;
    co_list_push_back(&(m_adv_env.cmd_queue), &(p_cmd->hdr));
    mal_activity_cmd_exec();
}




void mal_adv_continue(uint16_t status)
{
    bool finished = false;

    if(status != MESH_SUCCESS)
    {
        finished = true;
    }
    else
    {
        switch(m_adv_env.state)
        {
            case MAL_ADV_RELOAD: 
            {
                struct gapm_activity_delete_cmd *p_delete_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_DELETE_CMD, TASK_GAPM, TASK_APP,
                                                                             gapm_activity_delete_cmd);
                p_delete_cmd->operation  = GAPM_DELETE_ACTIVITY;
                p_delete_cmd->actv_idx   = m_adv_env.adv_idx;
                m_adv_env.adv_idx = 0xff;
                mal_activity_cmd_send(MAL_ACT_ADV, p_delete_cmd);
                m_adv_env.state = MAL_ADV_OFF;
            } break;
            case MAL_ADV_OFF: 
            {
                struct gapm_activity_create_adv_cmd *p_create_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_CREATE_CMD, TASK_GAPM, TASK_APP, gapm_activity_create_adv_cmd);
                p_create_cmd->operation                       = GAPM_CREATE_ADV_ACTIVITY;
                p_create_cmd->own_addr_type                   = GAPM_STATIC_ADDR;
                p_create_cmd->adv_param.type                  = GAPM_ADV_TYPE_LEGACY;
                p_create_cmd->adv_param.prop                  = GAPM_ADV_PROP_NON_CONN_NON_SCAN_MASK;
                p_create_cmd->adv_param.filter_pol            = ADV_ALLOW_SCAN_ANY_CON_ANY;
//                p_create_cmd->adv_param.max_tx_pwr            = -70; // TODO [FBE] use a define
                p_create_cmd->adv_param.disc_mode             = GAPM_ADV_MODE_BEACON;
                p_create_cmd->adv_param.prim_cfg.adv_intv_min = m_adv_env.interval;
                p_create_cmd->adv_param.prim_cfg.adv_intv_max = m_adv_env.interval;
                p_create_cmd->adv_param.prim_cfg.chnl_map     = m_adv_env.chlmap;
                p_create_cmd->adv_param.prim_cfg.phy          = GAP_PHY_LE_1MBPS;
                mal_activity_cmd_send(MAL_ACT_ADV, p_create_cmd);
                m_adv_env.state = MAL_ADV_ACT_CREATE;
            } break;

            case MAL_ADV_ACT_CREATE:
            case MAL_ADV_STOPPED:          
            {
                struct gapm_set_adv_data_cmd *p_set_data_cmd = KE_MSG_ALLOC_DYN(GAPM_SET_ADV_DATA_CMD, TASK_GAPM, TASK_APP,
                                                                                gapm_set_adv_data_cmd, m_adv_env.data_len);
                p_set_data_cmd->operation  = GAPM_SET_ADV_DATA;
                p_set_data_cmd->length     = m_adv_env.data_len;
                p_set_data_cmd->actv_idx   = m_adv_env.adv_idx;
                memcpy(p_set_data_cmd->data, m_adv_env.p_data, m_adv_env.data_len);
                mal_activity_cmd_send(MAL_ACT_ADV, p_set_data_cmd);
                m_adv_env.state = MAL_ADV_SET_DATA;               
            } break;
            case MAL_ADV_SET_DATA:  
            {
                struct gapm_activity_start_cmd *p_start_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_START_CMD, TASK_GAPM, TASK_APP,
                                                                           gapm_activity_start_cmd);
                p_start_cmd->operation                         = GAPM_START_ACTIVITY;
                p_start_cmd->actv_idx                          = m_adv_env.adv_idx;
                p_start_cmd->u_param.adv_add_param.duration    = m_adv_env.duration;
                p_start_cmd->u_param.adv_add_param.max_adv_evt = 0;
                mal_activity_cmd_send(MAL_ACT_ADV, p_start_cmd);
                m_adv_env.state = MAL_ADV_IN_TX;
                
            } break;

            case MAL_ADV_IN_TX:  
            {
                m_adv_env.state = MAL_ADV_STOPPED;
                finished = true;
            } break;
        }
    }
    if(finished)
    {
        if(m_adv_env.sent_cb != NULL)
        {
            m_adv_env.sent_cb( status);
        }
    }
}


void mal_bearer_adv_stop(void)
{
    struct gapm_activity_stop_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_STOP_CMD,
                                                      TASK_GAPM, TASK_APP,
                                                      gapm_activity_stop_cmd);
    p_cmd->operation = GAPM_STOP_ACTIVITY;
    p_cmd->actv_idx = m_adv_env.adv_idx;
    ke_msg_send(p_cmd);  
}

void mal_bearer_adv_delete(void)
{
    struct gapm_activity_delete_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_DELETE_CMD, TASK_GAPM, TASK_APP,
                                                                 gapm_activity_delete_cmd);
    p_cmd->operation  = GAPM_DELETE_ACTIVITY;
    p_cmd->actv_idx   = m_adv_env.adv_idx;
    ke_msg_send(p_cmd);  
}




uint16_t mal_adv_send(mal_adv_bearer_param_t *p_param)
{
    uint16_t status = MESH_ERROR_FORBIDDEN;
    
    if(p_param->adv_len > ADV_DATA_LEN)
    {
         status = MESH_ERROR_INVALID_PARAM;
    }
    else if((m_adv_env.state == MAL_ADV_OFF) || (m_adv_env.state == MAL_ADV_STOPPED))
    {
        if((m_adv_env.state == MAL_ADV_STOPPED) && (m_adv_env.interval != p_param->interval || m_adv_env.chlmap != p_param->chlmap))
        {
            m_adv_env.state = MAL_ADV_RELOAD;
        }
        
        m_adv_env.chlmap     = p_param->chlmap;
        m_adv_env.duration   = p_param->duration;
        m_adv_env.interval   = p_param->interval;
        m_adv_env.p_data     = p_param->p_data;
        m_adv_env.data_len   = p_param->adv_len;
        mal_adv_continue(MESH_SUCCESS);
        status = MESH_SUCCESS;
    }
    return (status);
}



void bearer_adv_init(mal_adv_env_t * p_mal_adv_env, adv_sent_cb sent_cb)
{
    m_adv_env.adv_idx         = 0xff;
    m_adv_env.state           = MAL_ADV_OFF; 
    m_adv_env.sent_cb         = sent_cb;
    m_adv_env.cmd_src         = MAL_ACT_NONE;
    co_list_init(&(m_adv_env.cmd_queue));
    p_mal_adv_env->p_adv_env = &m_adv_env;
}









