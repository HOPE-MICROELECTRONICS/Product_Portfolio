#ifndef __MAL_ADV_H__
#define __MAL_ADV_H__





#include <stdint.h>
#include "mal_bearer_adv.h"




void mal_adv_created_ind_handler(uint8_t actv_type, uint8_t actv_idx);
void mal_adv_init(void);
uint32_t mal_adv_bearer_send(mal_adv_bearer_param_t *param, uint8_t srcinfo, mal_adv_bearer_callback cb);
void mal_activity_cmp_evt_handler(uint8_t operation, uint8_t status, uint8_t act_idx);
void mal_adv_stopped_ind_handler(uint8_t actv_type, uint8_t reason, uint8_t actv_idx);




#endif //__MAL_ADV_H__

