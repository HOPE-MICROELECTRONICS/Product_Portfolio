#ifndef __MAL_DJOB_H__
#define __MAL_DJOB_H__



#include <stdint.h>
#include <stdbool.h>
#include "co_list.h"
#include "mal_bearer_adv.h"





void mal_djob_init(mal_adv_env_t * p_mal_adv_env);
void mal_djob_reg(mal_djob_t* p_djob);










#endif //__MAL_DJOB_H__
