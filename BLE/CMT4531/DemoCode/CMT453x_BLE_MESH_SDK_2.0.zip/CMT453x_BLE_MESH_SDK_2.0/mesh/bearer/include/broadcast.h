#ifndef BROADCAST_H__
#define BROADCAST_H__

#include <stdint.h>
#include "bearer_handler.h"
#include "packet.h"
#include "co_timer_schedule.h"

typedef struct broadcast_params broadcast_params_t;

typedef void (*broadcast_complete_cb_t) (broadcast_params_t * p_broadcast, timestamp_t timestamp);

struct broadcast_params
{
    packet_t * p_packet;
    uint32_t access_address;
    uint8_t duration;
    uint8_t interval;
    uint8_t chlmap;    
    broadcast_complete_cb_t tx_complete_cb;
};

typedef struct
{
    bearer_action_t action; 
    broadcast_params_t params; 
    bool active; 
} broadcast_t;

uint32_t broadcast_send(broadcast_t * p_broadcast);
void broadcast_init(void);
void broadcast_stop(uint8_t actv_idx);
void broadcast_stop_with_error(void);
#endif /* BROADCAST_H__ */
