#ifndef __MAL_BEARER_ADV_H__
#define __MAL_BEARER_ADV_H__




#include <stdint.h>
#include "co_list.h"
#include "co_math.h"
#include "packet_buffer.h"
#include "co_bt_defines.h"

enum m_bearer_state
{
    M_BEARER_OPEN_POS     = 0,
    M_BEARER_OPEN_BIT     = CO_BIT(M_BEARER_OPEN_POS),
    M_BEARER_PAUSE_POS    = 1,
    M_BEARER_PAUSE_BIT    = CO_BIT(M_BEARER_PAUSE_POS),
    M_BEARER_TX_POS       = 2,
    M_BEARER_TX_BIT       = CO_BIT(M_BEARER_TX_POS),
};


enum mal_adv_state
{
    MAL_ADV_OFF = 0,
    MAL_ADV_ACT_CREATE,
    MAL_ADV_SET_DATA,
    MAL_ADV_IN_TX,
    MAL_ADV_STOPPED,
    MAL_ADV_RELOAD,
};


enum mal_act_type
{
    MAL_ACT_NONE,
    MAL_ACT_ADV,
};


typedef void (*adv_sent_cb) (uint16_t status);



typedef struct
{
    const uint8_t*           p_data;
    uint16_t                 data_len;
    uint16_t                 interval;
    uint8_t                  chlmap;
    uint8_t                  duration;
    uint8_t                  state;
    adv_sent_cb              sent_cb;
    uint8_t                  adv_idx; 
    co_list_t                cmd_queue;
    uint8_t                  cmd_src;
} adv_env_t;


typedef void (*mal_djob_cb)(void* p_env);


typedef struct mal_djob
{
    co_list_hdr_t hdr;
    void*         p_env;
    mal_djob_cb   cb;
} mal_djob_t;

typedef struct mal_djob_env
{
    co_list_t             job_queue;
    
} mal_djob_env_t;

#define MAL_ADV_TX_BUFFER_SIZE     1000

typedef struct
{
    adv_env_t *           p_adv_env;
    co_list_t             tx_queue;
    mal_djob_env_t *      p_djob_env;
    uint8_t               state;
    
    packet_buffer_t       packet_buffer;
    uint8_t               packet_buffer_data[MAL_ADV_TX_BUFFER_SIZE];    
    packet_buffer_packet_t * p_buffer_packet;
} mal_adv_env_t;



#define MAL_ADV_BEARER_SRCINFO_BROADCAST   1
#define MAL_ADV_BEARER_SRCINFO_CUSTOM      2
#define MAL_ADV_BEARER_SRCINFO_NET_BEACON  3

typedef struct{
    uint8_t chlmap;
    uint16_t interval;
    uint8_t duration;
    uint16_t adv_len; 
    uint8_t *p_data;
}mal_adv_bearer_param_t;

typedef void (*mal_adv_bearer_callback)(uint8_t srcinfo);


void mal_adv_continue(uint16_t status);
void mal_activity_cmd_send(uint8_t src, void *p_param);
void mal_activity_cmd_exec(void);
void bearer_adv_init(mal_adv_env_t * p_mal_adv_env, adv_sent_cb sent_cb);
uint16_t mal_adv_send(mal_adv_bearer_param_t *p_param);
void mal_bearer_adv_stop(void);
void mal_bearer_adv_delete(void);
#endif //__MAL_BEARER_ADV_H__

