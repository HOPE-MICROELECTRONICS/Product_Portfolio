#include "cmt453x.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "rand.h"
#include "enc.h"

#include "prov_utils.h"
#include "prov_pdu.h"
#include "utils.h"
#include "uECC.h"

#define CONFIRMATION_KEY_INFO        (const uint8_t *) "prck"
#define CONFIRMATION_KEY_INFO_LENGTH 4
#define SESSION_KEY_INFO             (const uint8_t *) "prsk"
#define SESSION_KEY_INFO_SIZE        4
#define DATA_NONCE_INFO              (const uint8_t *) "prsn"
#define DATA_NONCE_INFO_SIZE         4
#define DEVICE_KEY_INFO              (const uint8_t *) "prdk"
#define DEVICE_KEY_INFO_SIZE         4

#define CONFIRMATION_INPUTS_SIZE     (PROV_CONFIRMATION_INPUT_LEN + 2 * MESH_PROV_PUBKEY_SIZE)

#define PDU_VALID_PROVISIONER 0x40
#define PDU_VALID_PROVISIONEE 0x80


uint32_t prov_utils_keys_generate(uint8_t * p_public, uint8_t * p_private)
{
    return uECC_make_key(p_public, p_private, uECC_secp256r1()) == 1 ? MESH_SUCCESS : MESH_ERROR_INTERNAL;
}

bool prov_utils_is_valid_pdu(mesh_prov_role_t role, mesh_prov_state_t state, prov_pdu_type_t pdu_type)
{
    static const uint8_t pdu_lookup[] = {
        /* MESH_PROV_STATE_IDLE                   */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_WAIT_LINK              */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_INVITE                 */ PROV_PDU_TYPE_INVITE         | PDU_VALID_PROVISIONEE,
        /* MESH_PROV_STATE_WAIT_CAPS              */ PROV_PDU_TYPE_CAPABILITIES   | PDU_VALID_PROVISIONER,
        /* MESH_PROV_STATE_WAIT_CAPS_CONFIRM      */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_WAIT_START             */ PROV_PDU_TYPE_START          | PDU_VALID_PROVISIONEE,
        /* MESH_PROV_STATE_WAIT_START_ACK         */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_WAIT_PUB_KEY_ACK       */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_WAIT_PUB_KEY           */ PROV_PDU_TYPE_PUBLIC_KEY     | PDU_VALID_PROVISIONEE | PDU_VALID_PROVISIONER,
        /* MESH_PROV_STATE_WAIT_OOB_PUB_KEY       */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_WAIT_EXTERNAL_ECDH     */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_WAIT_OOB_INPUT         */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_WAIT_OOB_STATIC        */ PROV_PDU_TYPE_CONFIRMATION   | PDU_VALID_PROVISIONEE,
        /* MESH_PROV_STATE_WAIT_OOB_STATIC_C_RCVD */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_WAIT_CONFIRMATION_ACK  */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_WAIT_CONFIRMATION      */ PROV_PDU_TYPE_CONFIRMATION   | PDU_VALID_PROVISIONEE | PDU_VALID_PROVISIONER,
        /* MESH_PROV_STATE_WAIT_INPUT_COMPLETE    */ PROV_PDU_TYPE_INPUT_COMPLETE | PDU_VALID_PROVISIONER,
        /* MESH_PROV_STATE_WAIT_RANDOM            */ PROV_PDU_TYPE_RANDOM         | PDU_VALID_PROVISIONEE | PDU_VALID_PROVISIONER,
        /* MESH_PROV_STATE_WAIT_DATA              */ PROV_PDU_TYPE_DATA           | PDU_VALID_PROVISIONEE,
        /* MESH_PROV_STATE_WAIT_COMPLETE          */ PROV_PDU_TYPE_COMPLETE       | PDU_VALID_PROVISIONER,
        /* MESH_PROV_STATE_COMPLETE               */ PROV_PDU_TYPE_INVALID,
        /* MESH_PROV_STATE_FAILED                 */ PROV_PDU_TYPE_INVALID,
    };

    if (role == MESH_PROV_ROLE_PROVISIONER)
    {
        return ((pdu_lookup[state] & ~PDU_VALID_PROVISIONEE) == (pdu_type | PDU_VALID_PROVISIONER) ||
                pdu_type == PROV_PDU_TYPE_FAILED);
    }
    else
    {
        return ((pdu_lookup[state] & ~PDU_VALID_PROVISIONER) == (pdu_type | PDU_VALID_PROVISIONEE));
    }
}


bool prov_utils_is_valid_public_key(const uint8_t * p_public_key)
{
    return uECC_valid_public_key(p_public_key, uECC_secp256r1());
}


bool prov_utils_use_ecdh_offloading(void)
{
    return false;
}


uint32_t prov_utils_calculate_shared_secret(const mesh_prov_ctx_t * p_ctx, uint8_t * p_shared_secret)
{
    if (!uECC_shared_secret(p_ctx->peer_public_key, p_ctx->p_private_key, p_shared_secret, uECC_secp256r1()))
    {
        return MESH_ERROR_INTERNAL;
    }
    return MESH_SUCCESS;
}

uint32_t prov_utils_calculate_shared_secret_first(uint8_t * p_peer_public_key,uint8_t * p_private_key,uint8_t * p_shared_secret)
{
    if (!uECC_shared_secret(p_peer_public_key, p_private_key, p_shared_secret, uECC_secp256r1()))
    {
        return MESH_ERROR_INTERNAL;
    }
    return MESH_SUCCESS;
}

static void create_confirmation_salt(const mesh_prov_ctx_t * p_ctx, uint8_t * p_confirmation_salt)
{
    uint8_t confirmation_inputs[CONFIRMATION_INPUTS_SIZE];

    memcpy(confirmation_inputs, p_ctx->confirmation_inputs, PROV_CONFIRMATION_INPUT_LEN);
    uint8_t target_index = PROV_CONFIRMATION_INPUT_LEN;

    if (p_ctx->role == MESH_PROV_ROLE_PROVISIONER)
    {
        memcpy(&confirmation_inputs[target_index], p_ctx->p_public_key, MESH_PROV_PUBKEY_SIZE);
        target_index += MESH_PROV_PUBKEY_SIZE;
        memcpy(&confirmation_inputs[target_index], p_ctx->peer_public_key, MESH_PROV_PUBKEY_SIZE);
    }
    else
    {
        memcpy(&confirmation_inputs[target_index], p_ctx->peer_public_key, MESH_PROV_PUBKEY_SIZE);
        target_index += MESH_PROV_PUBKEY_SIZE;
        memcpy(&confirmation_inputs[target_index], p_ctx->p_public_key, MESH_PROV_PUBKEY_SIZE);
    }
    enc_s1(confirmation_inputs, CONFIRMATION_INPUTS_SIZE, p_confirmation_salt);
}

void prov_utils_authentication_values_derive(const mesh_prov_ctx_t * p_ctx,
        uint8_t * p_confirmation_salt,
        uint8_t * p_confirmation,
        uint8_t * p_random)
{
    create_confirmation_salt(p_ctx, p_confirmation_salt);
    uint8_t confirmation_key[MESH_KEY_SIZE];
    enc_k1(p_ctx->shared_secret,MESH_ECDH_SHARED_SECRET_SIZE,p_confirmation_salt,CONFIRMATION_KEY_INFO, CONFIRMATION_KEY_INFO_LENGTH,confirmation_key);
    rand_hw_rng_get(p_random, PROV_RANDOM_LEN);
    uint8_t random_and_auth[PROV_RANDOM_LEN + PROV_AUTH_LEN];
    memcpy(&random_and_auth[0], p_random, PROV_RANDOM_LEN);
    memcpy(&random_and_auth[PROV_RANDOM_LEN], p_ctx->auth_value, PROV_AUTH_LEN);
    enc_aes_cmac(confirmation_key,random_and_auth,PROV_RANDOM_LEN + PROV_AUTH_LEN, p_confirmation);
}


bool prov_utils_confirmation_check(const mesh_prov_ctx_t * p_ctx)
{
    uint8_t confirmation_key[MESH_KEY_SIZE];
    enc_k1(p_ctx->shared_secret, MESH_ECDH_SHARED_SECRET_SIZE, p_ctx->confirmation_salt, CONFIRMATION_KEY_INFO, CONFIRMATION_KEY_INFO_LENGTH, confirmation_key);
    uint8_t random_and_auth[PROV_RANDOM_LEN + PROV_AUTH_LEN];
    memcpy(&random_and_auth[0], p_ctx->peer_random, PROV_RANDOM_LEN);
    memcpy(&random_and_auth[PROV_RANDOM_LEN], p_ctx->auth_value, PROV_AUTH_LEN);
    uint8_t confirmation[PROV_CONFIRMATION_LEN];
    enc_aes_cmac(confirmation_key,random_and_auth, PROV_RANDOM_LEN + PROV_AUTH_LEN, confirmation);
    return memcmp(confirmation, p_ctx->peer_confirmation, sizeof(confirmation)) == 0;
}

void prov_utils_derive_keys(const mesh_prov_ctx_t * p_ctx,
        uint8_t * p_session_key,
        uint8_t * p_session_nonce,
        uint8_t * p_device_key)
{

    uint8_t provisioning_salt_data[PROV_SALT_LEN + PROV_RANDOM_LEN + PROV_RANDOM_LEN];
    memcpy(&provisioning_salt_data[0], p_ctx->confirmation_salt, PROV_SALT_LEN);
    if (p_ctx->role == MESH_PROV_ROLE_PROVISIONER)
    {
        memcpy(&provisioning_salt_data[PROV_SALT_LEN], p_ctx->node_random, PROV_RANDOM_LEN);
        memcpy(&provisioning_salt_data[PROV_SALT_LEN + PROV_RANDOM_LEN], p_ctx->peer_random, PROV_RANDOM_LEN);
    }
    else
    {
        memcpy(&provisioning_salt_data[PROV_SALT_LEN], p_ctx->peer_random, PROV_RANDOM_LEN);
        memcpy(&provisioning_salt_data[PROV_SALT_LEN + PROV_RANDOM_LEN], p_ctx->node_random, PROV_RANDOM_LEN);
    }

    uint8_t provisioning_salt[PROV_SALT_LEN];
    enc_s1(provisioning_salt_data,
           PROV_SALT_LEN + PROV_RANDOM_LEN + PROV_RANDOM_LEN,
           provisioning_salt);

    enc_k1(p_ctx->shared_secret, MESH_ECDH_SHARED_SECRET_SIZE,
           provisioning_salt,
           SESSION_KEY_INFO, SESSION_KEY_INFO_SIZE,
           p_session_key);

    uint8_t session_nonce_temp[MESH_KEY_SIZE];
    enc_k1(p_ctx->shared_secret, MESH_ECDH_SHARED_SECRET_SIZE,
           provisioning_salt,
           DATA_NONCE_INFO, DATA_NONCE_INFO_SIZE,
           session_nonce_temp);
    memcpy(p_session_nonce, &session_nonce_temp[MESH_KEY_SIZE - PROV_NONCE_LEN], PROV_NONCE_LEN);

    enc_k1(p_ctx->shared_secret, MESH_ECDH_SHARED_SECRET_SIZE,
           provisioning_salt,
           DEVICE_KEY_INFO, DEVICE_KEY_INFO_SIZE,
           p_device_key);
}






