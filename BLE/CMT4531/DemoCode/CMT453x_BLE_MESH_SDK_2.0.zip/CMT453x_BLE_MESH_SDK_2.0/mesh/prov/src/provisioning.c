#include "provisioning.h"
#include "mesh_error.h"
#include "mesh.h"
#include "mesh_config_prov.h"
#include "prov_utils.h"


static uint32_t send_data(prov_bearer_t * p_bearer, const uint8_t * p_payload, uint16_t size)
{
    return p_bearer->p_interface->tx(p_bearer, p_payload, size);
}

bool prov_packet_length_valid(const uint8_t * p_buffer, uint16_t length)
{
    static const uint8_t pdu_sizes[PROV_PDU_TYPE_COUNT] =
                        {sizeof(prov_pdu_invite_t), sizeof(prov_pdu_caps_t), sizeof(prov_pdu_prov_start_t),
                         sizeof(prov_pdu_pubkey_t), sizeof(prov_pdu_input_complete_t), sizeof(prov_pdu_confirm_t),
                         sizeof(prov_pdu_random_t), sizeof(prov_pdu_data_t), sizeof(prov_pdu_complete_t),
                         sizeof(prov_pdu_failed_t)};
    bool valid;
    if (p_buffer == NULL || p_buffer[0] >= PROV_PDU_TYPE_INVALID)
    {
        valid = false;
    }
    else if (length == pdu_sizes[p_buffer[0]])
    {
        valid = true;
    }
    else
    {
        valid = false;
    }
    return valid;
}

uint32_t prov_tx_invite(prov_bearer_t * p_bearer, uint8_t attention_duration_s, uint8_t * p_confirmation_inputs)
{
    prov_pdu_invite_t pdu;
    pdu.pdu_type = PROV_PDU_TYPE_INVITE;
    pdu.attention_duration_s = attention_duration_s;
    memcpy(p_confirmation_inputs + PROV_CONFIRM_INPUTS_INVITE_OFFSET, ((const uint8_t *) &pdu) + 1, sizeof(prov_pdu_invite_t) - 1);
    return send_data(p_bearer, (const uint8_t *) &pdu, sizeof(prov_pdu_invite_t));
}

uint32_t prov_tx_capabilities(prov_bearer_t * p_bearer, const prov_pdu_caps_t * p_caps, uint8_t * p_confirmation_inputs)
{
    memcpy(p_confirmation_inputs + PROV_CONFIRM_INPUTS_CAPS_OFFSET, ((const uint8_t *) p_caps) + 1, sizeof(prov_pdu_caps_t) - 1);
    return send_data(p_bearer, (const uint8_t *) p_caps, sizeof(prov_pdu_caps_t));
}

uint32_t prov_tx_start(prov_bearer_t * p_bearer, const prov_pdu_prov_start_t * p_start, uint8_t * p_confirmation_inputs)
{
    memcpy(p_confirmation_inputs + PROV_CONFIRM_INPUTS_START_OFFSET, ((const uint8_t *) p_start) + 1, sizeof(prov_pdu_prov_start_t) - 1);
    return send_data(p_bearer, (const uint8_t *) p_start, sizeof(prov_pdu_prov_start_t));
}

uint32_t prov_tx_public_key(prov_bearer_t * p_bearer, const uint8_t * p_public_key)
{
    prov_pdu_pubkey_t pdu;
    pdu.pdu_type = PROV_PDU_TYPE_PUBLIC_KEY;
    memcpy(pdu.public_key, p_public_key, sizeof(pdu.public_key));
    return send_data(p_bearer, (const uint8_t *) &pdu, sizeof(prov_pdu_pubkey_t));
}

uint32_t prov_tx_input_complete(prov_bearer_t * p_bearer)
{
    prov_pdu_input_complete_t pdu;
    pdu.pdu_type = PROV_PDU_TYPE_INPUT_COMPLETE;
    return send_data(p_bearer, (const uint8_t *) &pdu, sizeof(prov_pdu_input_complete_t));
}

uint32_t prov_tx_confirmation(prov_bearer_t * p_bearer, const uint8_t * p_confirmation_value)
{
    prov_pdu_confirm_t pdu;
    pdu.pdu_type = PROV_PDU_TYPE_CONFIRMATION;
    memcpy(pdu.confirmation, p_confirmation_value, sizeof(pdu.confirmation));
    return send_data(p_bearer, (const uint8_t *) &pdu, sizeof(prov_pdu_confirm_t));
}

uint32_t prov_tx_random(prov_bearer_t * p_bearer, const uint8_t * p_random)
{
    prov_pdu_random_t pdu;
    pdu.pdu_type = PROV_PDU_TYPE_RANDOM;
    memcpy(pdu.random, p_random, sizeof(pdu.random));
    return send_data(p_bearer, (const uint8_t *) &pdu, sizeof(prov_pdu_random_t));
}

uint32_t prov_tx_complete(prov_bearer_t * p_bearer)
{
    prov_pdu_complete_t pdu;
    pdu.pdu_type = PROV_PDU_TYPE_COMPLETE;
    return send_data(p_bearer, (const uint8_t *) &pdu, sizeof(prov_pdu_complete_t));
}

uint32_t prov_tx_failed(prov_bearer_t * p_bearer, const mesh_prov_failure_code_t failure_code)
{
    prov_pdu_failed_t pdu;
    pdu.pdu_type = PROV_PDU_TYPE_FAILED;
    pdu.failure_code = (uint8_t) failure_code;
    return send_data(p_bearer, (const uint8_t *) &pdu, sizeof(prov_pdu_failed_t));
}

uint32_t prov_tx_data(prov_bearer_t * p_bearer, const prov_pdu_data_t * p_data)
{
    return send_data(p_bearer, (const uint8_t *) p_data, sizeof(prov_pdu_data_t));
}

uint32_t prov_tx(prov_bearer_t * p_bearer, const uint8_t * p_data, uint16_t length)
{
    return send_data(p_bearer, p_data, length);
}
