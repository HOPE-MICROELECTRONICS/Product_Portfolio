#include "mesh_stack.h"
#include <stdio.h>
#include "mesh_config.h"
#include "mesh_opt.h"
#include "mesh_events.h"
#include "net_state.h"
#include "config_server.h"
#include "bsp_wdt.h"


static dsm_handle_t netkey_handle = 0, devkey_handle = 0;

uint32_t mesh_stack_provisioning_data_store(const mesh_prov_provisioning_data_t * p_prov_data,const uint8_t * p_devkey)
{
    uint32_t status;
    dsm_local_unicast_address_t local_address;
    local_address.address_start = p_prov_data->address;
    local_address.count = ACCESS_ELEMENT_COUNT;

    bsp_wdt_feed();    
    status = dsm_local_unicast_addresses_set(&local_address);  
    net_state_iv_index_set(p_prov_data->iv_index, p_prov_data->flags.iv_update);
    status = dsm_subnet_add(p_prov_data->netkey_index, p_prov_data->netkey, &netkey_handle);

    return MESH_SUCCESS;
}


uint32_t mesh_stack_provisioning_data_store2(const mesh_prov_provisioning_data_t * p_prov_data,const uint8_t * p_devkey)
{
    uint32_t status;
    bsp_wdt_feed();      
    status = dsm_devkey_add(p_prov_data->address, netkey_handle, p_devkey, &devkey_handle);          
    config_server_bind(devkey_handle);   
    return MESH_SUCCESS;
}










