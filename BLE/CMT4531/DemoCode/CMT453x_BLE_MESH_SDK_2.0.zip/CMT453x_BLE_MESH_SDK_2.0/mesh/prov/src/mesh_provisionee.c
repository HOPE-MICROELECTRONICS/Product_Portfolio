#include "mesh_provisionee.h"
#include "mesh_error.h"
#include <stdio.h>
#include "mesh_events.h"
#include "mesh_prov_types.h"
#include "mesh_prov.h"
#include "mesh_config_app.h"
#include "mesh_prov_bearer_gatt.h"
#include "mesh_stack.h"
#include "global_var.h"
#include "prf.h"
#include "proxy.h"
#include "rwip.h"
#include "mesh_app_task.h"
#include "bsp_lpuart.h"
#include "net_state.h"



static uint8_t                         m_public_key[MESH_PROV_PUBKEY_SIZE] = {
0x54, 0xB0, 0x83, 0xCF, 0x90, 0x35, 0x0E, 0xF6, 0xA6, 0x3D, 0x74, 0x07, 0xC1, 0x97, 0x76, 0x54,                 
0xCD, 0xB7, 0x64, 0x2E, 0x16, 0xDC, 0x39, 0x47, 0xFC, 0x74, 0x9F, 0x7D, 0xC2, 0x41, 0x67, 0x0D,                 
0xB5, 0xE4, 0x56, 0x1E, 0x63, 0x44, 0xB4, 0xEB, 0x3B, 0x20, 0xDB, 0x1A, 0x31, 0xF4, 0xF7, 0x23,                 
0x26, 0x92, 0x10, 0xF6, 0x11, 0x2E, 0x24, 0xA7, 0xD1, 0xB2, 0xE9, 0x58, 0xAE, 0x33, 0x8E, 0xA0,  
};
static uint8_t                         m_private_key[MESH_PROV_PRIVKEY_SIZE] = {
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x46, 0x8D,  
};
static mesh_provisionee_start_params_t m_params;
static mesh_prov_ctx_t             m_prov_ctx;
static mesh_prov_bearer_gatt_t     m_prov_bearer_gatt;
static bool                            m_device_identification_started;
static bool                            m_device_provisioned = false;
static bool                            m_doing_gatt_reset;


static void mesh_evt_handler(const mesh_evt_t * p_evt);
static mesh_evt_handler_t m_mesh_evt_handler = {
    .evt_cb = mesh_evt_handler,
};

void print_keys(void)
{
    printf("m_public_key : \r\n");
    log_hexdump(m_public_key,MESH_PROV_PUBKEY_SIZE);
    printf("m_private_key : \r\n");
    log_hexdump(m_private_key,MESH_PROV_PRIVKEY_SIZE); 
    printf("================================\r\n");   
}

static uint32_t provisionee_start(void)
{
    uint32_t bearers = 0;
    bearers |= MESH_PROV_BEARER_GATT;
    uint32_t error = 0;
    if(!net_state_is_test_mode()){
        error = mesh_prov_generate_keys(m_public_key, m_private_key);
    }
    return mesh_prov_listen(&m_prov_ctx, m_params.p_device_uri, 0, bearers);
}
static void mesh_evt_handler(const mesh_evt_t * p_evt)
{
    if (p_evt->type == MESH_EVT_DISABLED && m_doing_gatt_reset)
    {
        m_doing_gatt_reset = false;
        mesh_evt_handler_remove(&m_mesh_evt_handler);
        mesh_key_index_t key_index;
        uint32_t count = 1;
        mesh_key_refresh_phase_t kr_phase;
        dsm_subnet_get_all(&key_index, &count);
        dsm_subnet_kr_phase_get(dsm_net_key_index_to_subnet_handle(key_index),&kr_phase);   

        prf_init(RWIP_RST);
        proxy_init();       
        proxy_node_id_enable(NULL, kr_phase);
    }
}

int mesh_task_gatt_reset_handler(ke_msg_id_t const msgid, void const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
    m_doing_gatt_reset = true;
    mesh_evt_handler_add(&m_mesh_evt_handler);
    mesh_disable();
    return KE_MSG_CONSUMED;
}

static void prov_evt_handler(const mesh_prov_evt_t * p_evt)
{
    switch (p_evt->type)
    {
        case MESH_PROV_EVT_INVITE_RECEIVED:
        {
            LOG_PRINTF("MESH_PROV_EVT_INVITE_RECEIVED\r\n");
        }break;
        case MESH_PROV_EVT_START_RECEIVED:
        {
            LOG_PRINTF("MESH_PROV_EVT_START_RECEIVED\r\n");
        }break;        
        case MESH_PROV_EVT_DATA:
        {
            LOG_PRINTF("MESH_PROV_EVT_DATA\r\n");
            mesh_stack_provisioning_data_store(p_evt->params.prov_data.p_prov_data, p_evt->params.prov_data.p_devkey);
        }break;          
        case MESH_PROV_EVT_LINK_CLOSED:
        {
            LOG_PRINTF("MESH_PROV_EVT_LINK_CLOSED\r\n");
            if (!m_device_provisioned)
            {
                (void) provisionee_start();
            }
            else
            {
                ke_msg_send_basic(MESH_TASK_GATT_RESET, TASK_MESH, TASK_NONE);
            }        
        }break;
        case MESH_PROV_EVT_COMPLETE:
        {
            LOG_PRINTF("MESH_PROV_EVT_COMPLETE\r\n");
            mesh_stack_provisioning_data_store2(p_evt->params.prov_data.p_prov_data, p_evt->params.prov_data.p_devkey);
            m_device_provisioned = true;    
            ke_msg_send_basic(MESH_TASK_PROVISION_COMPLETE, TASK_MESH, TASK_NONE);
            
        }break;

        default:
            break;
    } 
}




uint32_t mesh_provisionee_prov_start(const mesh_provisionee_start_params_t * p_start_params)
{
    mesh_prov_oob_caps_t prov_caps =
    {
        ACCESS_ELEMENT_COUNT,
        MESH_PROV_ALGORITHM_FIPS_P256EC,
        0,
        0,
        0,
        0,
        0,
        0
    };    
    m_params = *p_start_params;
    mesh_prov_init(&m_prov_ctx, m_public_key, m_private_key, &prov_caps, prov_evt_handler);
    mesh_prov_bearer_gatt_init(&m_prov_bearer_gatt);
    mesh_prov_bearer_add(&m_prov_ctx, mesh_prov_bearer_gatt_interface_get(&m_prov_bearer_gatt));    
    return provisionee_start();
}


uint32_t mesh_provisionee_prov_listen_stop(void)
{
    return mesh_prov_listen_stop(&m_prov_ctx);
}



void mesh_provisionee_prov_pause(void)
{

    mesh_prov_pause(&m_prov_ctx);
}

void mesh_provisionee_prov_resume(void)
{

    mesh_prov_resume(&m_prov_ctx);
}




