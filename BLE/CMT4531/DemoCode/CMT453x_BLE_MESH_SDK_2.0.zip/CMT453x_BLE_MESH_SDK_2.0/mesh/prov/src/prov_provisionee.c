#include "prov_provisionee.h"
#include "prov_utils.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#include "mesh_error.h"
#include "ccm_soft.h"
#include "enc.h"
#include "utils.h"
#include "provisioning.h"
#include "mesh_config_prov.h"
#include "mesh_prov_bearer.h"
#include "bsp_lpuart.h"
#include "mesh_app_task.h"
#include "net_state.h"
#include "mesh_gatt.h"

static uint32_t send_capabilities(mesh_prov_ctx_t * p_ctx);
static uint32_t handle_prov_start(mesh_prov_ctx_t * p_ctx, const uint8_t * p_buffer);
static void start_authentication(mesh_prov_ctx_t * p_ctx);
static uint32_t request_authentication(mesh_prov_ctx_t * p_ctx);
static void complete_provisioning(mesh_prov_ctx_t * p_ctx);
static uint32_t handle_data(mesh_prov_ctx_t * p_ctx, const uint8_t * p_buffer);


static void prov_provisionee_pkt_in(prov_bearer_t * p_bearer, const uint8_t * p_buffer, uint16_t length);
static void prov_provisionee_cb_ack_received(prov_bearer_t * p_bearer);
static void prov_provisionee_cb_link_established(prov_bearer_t * p_bearer);
static void prov_provisionee_cb_link_closed(prov_bearer_t * p_bearer, mesh_prov_link_close_reason_t reason);
static const prov_bearer_callbacks_t m_prov_callbacks =
             {
                .rx = prov_provisionee_pkt_in,
                .ack = prov_provisionee_cb_ack_received,
                .opened = prov_provisionee_cb_link_established,
                .closed = prov_provisionee_cb_link_closed
             };


static void send_failed(mesh_prov_ctx_t * p_ctx, mesh_prov_failure_code_t failure_code)
{
    if (MESH_SUCCESS != prov_tx_failed(p_ctx->p_active_bearer, failure_code))
    {
        p_ctx->p_active_bearer->p_interface->link_close(p_ctx->p_active_bearer, MESH_PROV_LINK_CLOSE_REASON_ERROR);
    }
    if (p_ctx->state != MESH_PROV_STATE_FAILED)
    {
        mesh_prov_evt_t app_event;
        app_event.type = MESH_PROV_EVT_FAILED;
        app_event.params.failed.p_context =  p_ctx;
        app_event.params.failed.failure_code = failure_code;
        p_ctx->failure_code = failure_code;
        p_ctx->state = MESH_PROV_STATE_FAILED;
        p_ctx->event_handler(&app_event);
    }
}
static uint32_t save_prov_data(mesh_prov_ctx_t * p_ctx)
{
    mesh_prov_evt_t event;
    event.type = MESH_PROV_EVT_DATA;
    event.params.prov_data.p_context = p_ctx;
    event.params.prov_data.p_devkey = p_ctx->device_key;
    event.params.prov_data.p_prov_data = &p_ctx->data;                
    p_ctx->event_handler(&event);   
    return MESH_SUCCESS;
}


static void prov_provisionee_pkt_in(prov_bearer_t * p_bearer, const uint8_t * p_buffer, uint16_t length)
{
    mesh_prov_ctx_t * p_ctx = prov_bearer_ctx_get(p_bearer);
    const prov_pdu_type_t pdu_type = (prov_pdu_type_t) p_buffer[0];

    if (!prov_packet_length_valid(p_buffer, length) || pdu_type >= PROV_PDU_TYPE_INVALID)
    {
        return;
    }
    else if (!prov_utils_is_valid_pdu(p_ctx->role, p_ctx->state, pdu_type))
    {
        return;
    }
    switch (p_buffer[0])
    {
        case PROV_PDU_TYPE_INVITE:
        {           
            LOG_PRINTF("PROV_PDU_TYPE_INVITE  \r\n");
            memcpy(p_ctx->confirmation_inputs + PROV_CONFIRM_INPUTS_INVITE_OFFSET, p_buffer + 1, sizeof(prov_pdu_invite_t) - 1);
            if (MESH_SUCCESS != send_capabilities(p_ctx))
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_OUT_OF_RESOURCES);
            }             
        }break;
        case PROV_PDU_TYPE_START:
        {
            LOG_PRINTF("PROV_PDU_TYPE_START  \r\n");            
            if (MESH_SUCCESS != handle_prov_start(p_ctx, p_buffer))
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_INVALID_FORMAT);
                break;
            }
            p_ctx->state = MESH_PROV_STATE_WAIT_PUB_KEY;    
        }break;
        case PROV_PDU_TYPE_PUBLIC_KEY:
        {
            LOG_PRINTF("PROV_PDU_TYPE_PUBLIC_KEY  \r\n");
            const prov_pdu_pubkey_t * p_pdu = (const prov_pdu_pubkey_t *) p_buffer;
            memcpy(p_ctx->peer_public_key, p_pdu->public_key, MESH_PROV_PUBKEY_SIZE);
            if (MESH_SUCCESS != prov_tx_public_key(p_ctx->p_active_bearer, p_ctx->p_public_key))
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_OUT_OF_RESOURCES);
            }
        } break;
        case PROV_PDU_TYPE_CONFIRMATION:
        {
            LOG_PRINTF("PROV_PDU_TYPE_CONFIRMATION  \r\n");  
            dynamic_hsi_trim(DANAMIC_HSI_TRIM_120MHZ);
            start_authentication(p_ctx);
            dynamic_hsi_trim(SystemCoreClock);
            if (p_ctx->state == MESH_PROV_STATE_WAIT_CONFIRMATION)
            {            
                const prov_pdu_confirm_t * p_pdu = (const prov_pdu_confirm_t *) p_buffer;
                memcpy(p_ctx->peer_confirmation, p_pdu->confirmation, sizeof(p_ctx->peer_confirmation));
                uint8_t confirmation_value[PROV_CONFIRMATION_LEN];
                dynamic_hsi_trim(DANAMIC_HSI_TRIM_120MHZ);
                prov_utils_authentication_values_derive(p_ctx, p_ctx->confirmation_salt, confirmation_value, p_ctx->node_random);
                dynamic_hsi_trim(SystemCoreClock);
                uint32_t err_code = prov_tx_confirmation(p_ctx->p_active_bearer, confirmation_value);
                if (MESH_SUCCESS != err_code)
                {
                    send_failed(p_ctx, MESH_PROV_FAILURE_CODE_OUT_OF_RESOURCES);
                }
            }
            else if (p_ctx->state == MESH_PROV_STATE_WAIT_OOB_STATIC)
            {
                const prov_pdu_confirm_t * p_pdu = (const prov_pdu_confirm_t *) p_buffer;
                memcpy(p_ctx->peer_confirmation, p_pdu->confirmation, sizeof(p_ctx->peer_confirmation));
                p_ctx->state = MESH_PROV_STATE_WAIT_OOB_STATIC_C_RCVD;
            }        
        }break;
        case PROV_PDU_TYPE_RANDOM:
        {
            LOG_PRINTF("PROV_PDU_TYPE_RANDOM  \r\n");
            const prov_pdu_random_t * p_pdu = (const prov_pdu_random_t *) p_buffer;
            memcpy(p_ctx->peer_random, p_pdu->random, sizeof(p_pdu->random));
            if (!prov_utils_confirmation_check(p_ctx))
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_CONFIRMATION_FAILED);
            }
            else if (MESH_SUCCESS == prov_tx_random(p_ctx->p_active_bearer, p_ctx->node_random))
            {
                dynamic_hsi_trim(DANAMIC_HSI_TRIM_120MHZ);
                prov_utils_derive_keys(p_ctx, p_ctx->session_key, p_ctx->data_nonce, p_ctx->device_key);
                dynamic_hsi_trim(SystemCoreClock);
            }   
            else
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_OUT_OF_RESOURCES);
            }    
            
           
            
        }break;
        case PROV_PDU_TYPE_DATA:
        {
            LOG_PRINTF("PROV_PDU_TYPE_DATA  \r\n");
            if (MESH_SUCCESS != handle_data(p_ctx, p_buffer))
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_DECRYPTION_FAILED);
            }
            else if (!prov_data_is_valid(&p_ctx->data))
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_INVALID_FORMAT);
            }
            else if (!prov_address_is_valid(&p_ctx->data, p_ctx->capabilities.num_elements))
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_CANNOT_ASSIGN_ADDR);
            }
            else if (MESH_SUCCESS != prov_tx_complete(p_ctx->p_active_bearer))
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_OUT_OF_RESOURCES);
            }
            else if (MESH_SUCCESS != save_prov_data(p_ctx))
            {
                send_failed(p_ctx, MESH_PROV_FAILURE_CODE_OUT_OF_RESOURCES);
            }             
            DEBUG_PRINTF("iv_index --> %d\r\n",p_ctx->data.iv_index);
            DEBUG_PRINTF("flags iv_update --> %d\r\n",p_ctx->data.flags.iv_update);
        }break;

        default:
            break;
    }    
}
static void prov_provisionee_cb_ack_received(prov_bearer_t * p_bearer)
{
    mesh_prov_ctx_t * p_ctx = prov_bearer_ctx_get(p_bearer);
    switch (p_ctx->state)
    {
        case MESH_PROV_STATE_INVITE:    
            LOG_PRINTF("ack : MESH_PROV_STATE_INVITE  \r\n");
            p_ctx->state = MESH_PROV_STATE_WAIT_START;
            break;
        case MESH_PROV_STATE_WAIT_START: 
            LOG_PRINTF("ack : MESH_PROV_STATE_WAIT_START  \r\n");
            break;
        case MESH_PROV_STATE_WAIT_PUB_KEY:  
            LOG_PRINTF("ack : MESH_PROV_STATE_WAIT_PUB_KEY  \r\n");
            if (MESH_SUCCESS != request_authentication(p_ctx))
            {
                
            }          
            break;
        case MESH_PROV_STATE_WAIT_OOB_INPUT:
            LOG_PRINTF("ack : MESH_PROV_STATE_WAIT_OOB_INPUT  \r\n");
            p_ctx->state = MESH_PROV_STATE_WAIT_CONFIRMATION;
            break;
        case MESH_PROV_STATE_WAIT_OOB_STATIC_C_RCVD:
            LOG_PRINTF("ack : MESH_PROV_STATE_WAIT_OOB_STATIC_C_RCVD  \r\n");
        case MESH_PROV_STATE_WAIT_CONFIRMATION:         
            LOG_PRINTF("ack : MESH_PROV_STATE_WAIT_CONFIRMATION  \r\n");
            p_ctx->state = MESH_PROV_STATE_WAIT_RANDOM;
            break;
        case MESH_PROV_STATE_WAIT_RANDOM:
            LOG_PRINTF("ack : MESH_PROV_STATE_WAIT_RANDOM  \r\n");
            p_ctx->state = MESH_PROV_STATE_WAIT_DATA;
            break;
        case MESH_PROV_STATE_WAIT_DATA:
            LOG_PRINTF("ack : MESH_PROV_STATE_WAIT_DATA  \r\n");
            complete_provisioning(p_ctx);
            p_ctx->state = MESH_PROV_STATE_COMPLETE;
            if(!net_state_is_test_mode()){
                #ifdef ALEXA
                extern uint8_t alloc_relay;
                alloc_relay = false;
                ke_timer_set(MESH_TASK_PROVISION_ERROR_TIMER, TASK_MESH, 16000);  
                #endif
                
            }
            break;
        case MESH_PROV_STATE_FAILED:
            break;
        default:break;
            
    }    
    
    
    
}
static void prov_provisionee_cb_link_established(prov_bearer_t * p_bearer)
{
    mesh_prov_ctx_t * p_ctx = prov_bearer_ctx_get(p_bearer);
    p_ctx->p_active_bearer = p_bearer;
    prov_bearer_t * p_tmp_bearer;
    LIST_FOREACH(p_item, p_ctx->p_bearers)
    {
        p_tmp_bearer = PARENT_BY_FIELD_GET(prov_bearer_t, node, p_item);
        if (p_tmp_bearer != p_bearer)
        {
            (void) p_tmp_bearer->p_interface->listen_stop(p_tmp_bearer);
        }
    }    
    p_ctx->state = MESH_PROV_STATE_INVITE;
    mesh_prov_evt_t app_event;
    app_event.type = MESH_PROV_EVT_LINK_ESTABLISHED;
    app_event.params.link_established.p_context =  p_ctx;
    p_ctx->event_handler(&app_event);    
    
}
static void prov_provisionee_cb_link_closed(prov_bearer_t * p_bearer, mesh_prov_link_close_reason_t reason)
{
    LOG_PRINTF("prov_provisionee_cb_link_closed\r\n");
    mesh_prov_ctx_t * p_ctx = prov_bearer_ctx_get(p_bearer);
    if (p_ctx->state == MESH_PROV_STATE_WAIT_DATA && reason == MESH_PROV_LINK_CLOSE_REASON_SUCCESS)
    {
        complete_provisioning(p_ctx);
    }
    p_ctx->state = MESH_PROV_STATE_IDLE;
    mesh_prov_evt_t app_event;
    app_event.type = MESH_PROV_EVT_LINK_CLOSED;
    app_event.params.link_closed.p_context =  p_ctx;
    app_event.params.link_closed.close_reason = reason;    
    p_ctx->event_handler(&app_event);    
}    
uint32_t prov_provisionee_listen(mesh_prov_ctx_t * p_ctx, prov_bearer_t * p_bearer, const char * URI, uint16_t oob_info_sources)
{
    if (p_ctx->state != MESH_PROV_STATE_IDLE &&
        p_ctx->state != MESH_PROV_STATE_WAIT_LINK)
    {
        return MESH_ERROR_INVALID_STATE;
    }
    else
    {
        p_bearer->p_callbacks = &m_prov_callbacks;
        return p_bearer->p_interface->listen_start(p_bearer, URI, oob_info_sources, MESH_PROV_LINK_TIMEOUT_MIN_US);
    }
}

static uint32_t send_capabilities(mesh_prov_ctx_t * p_ctx)
{
    prov_pdu_caps_t pdu;
    pdu.pdu_type = PROV_PDU_TYPE_CAPABILITIES;
    pdu.num_elements = p_ctx->capabilities.num_elements;
    pdu.algorithms = LE2BE16(p_ctx->capabilities.algorithms);
    pdu.pubkey_type = p_ctx->capabilities.pubkey_type;
    pdu.oob_static_types = p_ctx->capabilities.oob_static_types;
    pdu.oob_output_size = p_ctx->capabilities.oob_output_size;
    pdu.oob_output_actions = LE2BE16(p_ctx->capabilities.oob_output_actions);
    pdu.oob_input_size = p_ctx->capabilities.oob_input_size;
    pdu.oob_input_actions = LE2BE16(p_ctx->capabilities.oob_input_actions);
    return prov_tx_capabilities(p_ctx->p_active_bearer, &pdu, p_ctx->confirmation_inputs);
}



static uint32_t handle_prov_start(mesh_prov_ctx_t * p_ctx, const uint8_t * p_buffer)
{
    const prov_pdu_prov_start_t * p_pdu = (const prov_pdu_prov_start_t *) p_buffer;

    if (p_pdu->algorithm >= MESH_PROV_ALGORITHM_RFU ||
        p_pdu->public_key >= MESH_PROV_PUBLIC_KEY_PROHIBITED ||
        p_pdu->auth_method >= MESH_PROV_OOB_METHOD_PROHIBITED)
    {
        return MESH_ERROR_INVALID_DATA;
    }

    if (p_pdu->public_key == MESH_PROV_PUBLIC_KEY_OOB &&
        p_ctx->capabilities.pubkey_type != MESH_PROV_OOB_PUBKEY_TYPE_OOB)
    {
        return MESH_ERROR_INVALID_DATA;
    }

    if ((p_pdu->auth_method == MESH_PROV_OOB_METHOD_NONE ||
         p_pdu->auth_method == MESH_PROV_OOB_METHOD_STATIC) &&
        (p_pdu->auth_action > 0 || p_pdu->auth_size > 0))
    {
        return MESH_ERROR_INVALID_DATA;
    }

    if (p_pdu->auth_method == MESH_PROV_OOB_METHOD_OUTPUT &&
       (p_pdu->auth_action >= MESH_PROV_OUTPUT_ACTION_RFU ||
        p_pdu->auth_size < 1 || p_pdu->auth_size > 8))
    {
        return MESH_ERROR_INVALID_LENGTH;
    }

    if (p_pdu->auth_method == MESH_PROV_OOB_METHOD_INPUT &&
       (p_pdu->auth_action >= MESH_PROV_INPUT_ACTION_RFU ||
        p_pdu->auth_size < 1 || p_pdu->auth_size > 8))
    {
        return MESH_ERROR_INVALID_LENGTH;
    }
    memcpy(p_ctx->confirmation_inputs + PROV_CONFIRM_INPUTS_START_OFFSET, p_buffer + 1, sizeof(prov_pdu_prov_start_t) - 1);
    return MESH_SUCCESS;
}

static void start_authentication(mesh_prov_ctx_t * p_ctx)
{
    LOG_PRINTF("start_authentication \r\n");
    if (MESH_SUCCESS == prov_utils_calculate_shared_secret(p_ctx, p_ctx->shared_secret))
    {

    }
    else
    {

    }
}



static uint32_t request_authentication(mesh_prov_ctx_t * p_ctx)
{
    uint32_t retval = MESH_SUCCESS;
    switch (p_ctx->oob_method)
    {
        case MESH_PROV_OOB_METHOD_INPUT:
        {
            mesh_prov_evt_t event;
            event.type = MESH_PROV_EVT_INPUT_REQUEST;
            event.params.input_request.p_context =  p_ctx;
            event.params.input_request.size = p_ctx->oob_size;
            event.params.input_request.action = p_ctx->oob_action;
            p_ctx->state = MESH_PROV_STATE_WAIT_OOB_INPUT;
            p_ctx->event_handler(&event);
            break;
        }
        case MESH_PROV_OOB_METHOD_OUTPUT:
        {
            mesh_prov_evt_t event;
            event.type = MESH_PROV_EVT_OUTPUT_REQUEST;
            event.params.output_request.p_context =  p_ctx;
            event.params.output_request.size = p_ctx->oob_size;
            event.params.output_request.action = p_ctx->oob_action;
            event.params.output_request.p_data = p_ctx->auth_value;
            p_ctx->state = MESH_PROV_STATE_WAIT_CONFIRMATION;
            p_ctx->event_handler(&event);
            break;
        }
        case MESH_PROV_OOB_METHOD_STATIC:
        {
            mesh_prov_evt_t event;
            event.type = MESH_PROV_EVT_STATIC_REQUEST;
            event.params.static_request.p_context =  p_ctx;
            p_ctx->state = MESH_PROV_STATE_WAIT_OOB_STATIC;
            p_ctx->event_handler(&event);
            break;
        }
        case MESH_PROV_OOB_METHOD_NONE:
            memset(p_ctx->auth_value, 0, sizeof(p_ctx->auth_value));
            p_ctx->state = MESH_PROV_STATE_WAIT_CONFIRMATION;
            break;
        default:
            retval = MESH_ERROR_INTERNAL;
            break;
    }

    return retval;
}

static void complete_provisioning(mesh_prov_ctx_t * p_ctx)
{
    mesh_prov_evt_t app_event;
    app_event.type = MESH_PROV_EVT_COMPLETE;
    app_event.params.complete.p_context = p_ctx;
    app_event.params.complete.p_devkey = p_ctx->device_key;
    app_event.params.complete.p_prov_data = &p_ctx->data;
    p_ctx->event_handler(&app_event);
}


static uint32_t handle_data(mesh_prov_ctx_t * p_ctx, const uint8_t * p_buffer)
{
    dynamic_hsi_trim(DANAMIC_HSI_TRIM_120MHZ);
    const prov_pdu_data_t * p_pdu = (const prov_pdu_data_t *) p_buffer;
    prov_pdu_data_t unencrypted_pdu;

    ccm_soft_data_t ccm_data;
    ccm_data.p_key = p_ctx->session_key;
    ccm_data.p_nonce = p_ctx->data_nonce;
    ccm_data.p_m = (uint8_t *) &p_pdu->data;
    ccm_data.m_len = sizeof(prov_pdu_data_block_t);
    ccm_data.p_out = (uint8_t *) &unencrypted_pdu.data;
    ccm_data.p_mic = (uint8_t *) p_pdu->mic;
    ccm_data.p_a = NULL;
    ccm_data.a_len = 0;
    ccm_data.mic_len = PROV_PDU_DATA_MIC_LENGTH;

    bool mic_passed = false;
    enc_aes_ccm_decrypt(&ccm_data, &mic_passed);
    if (!mic_passed)
    {
        return MESH_ERROR_INVALID_DATA;
    }

    memcpy(p_ctx->data.netkey, unencrypted_pdu.data.netkey, MESH_KEY_SIZE);
    p_ctx->data.iv_index = BE2LE32(unencrypted_pdu.data.iv_index);
    p_ctx->data.address = BE2LE16(unencrypted_pdu.data.address);
    p_ctx->data.netkey_index = BE2LE16(unencrypted_pdu.data.netkey_index);
    p_ctx->data.flags.iv_update = unencrypted_pdu.data.flags.iv_update;
    p_ctx->data.flags.key_refresh = unencrypted_pdu.data.flags.key_refresh;
    dynamic_hsi_trim(SystemCoreClock);
    return MESH_SUCCESS;
}





