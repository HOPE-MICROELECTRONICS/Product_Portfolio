#include "prov_beacon.h"
#include <string.h>
#include "mesh_prov_events.h"
#include "mesh_configure.h"
#include "enc.h"
#include "beacon.h"

#define UNPROV_BEACON_DATA_LEN            (sizeof(prov_beacon_unprov_packet_t))                      
#define UNPROV_BEACON_DATA_LEN_NO_HASH    (UNPROV_BEACON_DATA_LEN - MESH_BEACON_UNPROV_URI_HASH_SIZE) 



typedef struct __attribute((packed))
{
    uint8_t  device_uuid[MESH_UUID_SIZE];       
    uint16_t oob_info;                             
    uint8_t  uri_hash[MESH_BEACON_UNPROV_URI_HASH_SIZE]; 
} prov_beacon_unprov_packet_t;


static mesh_prov_evt_handler_cb_t m_event_handler;



adv_packet_t * prov_beacon_unprov_build(advertiser_t * p_adv, const char * p_uri, uint16_t oob_info)
{
//    LOG_PRINTF("%s\r\n",__FUNCTION__);
    prov_beacon_unprov_packet_t unprov_packet;
    uint8_t packet_len;
    if (p_uri == NULL)
    {
        packet_len = UNPROV_BEACON_DATA_LEN_NO_HASH;
    }
    else
    {
        packet_len = UNPROV_BEACON_DATA_LEN;
        uint8_t uri_data_hash[MESH_KEY_SIZE];
        enc_s1((const uint8_t*) p_uri, strlen(p_uri), uri_data_hash);
        memcpy(unprov_packet.uri_hash, uri_data_hash, MESH_BEACON_UNPROV_URI_HASH_SIZE);
    }

    unprov_packet.oob_info = LE2BE16(oob_info);
    memcpy(unprov_packet.device_uuid, mesh_configure_device_uuid_get(), MESH_UUID_SIZE);

    return beacon_create(p_adv, BEACON_TYPE_UNPROV, &unprov_packet, packet_len);
}


void prov_beacon_unprov_packet_in(const uint8_t * p_data, uint8_t length, const mesh_rx_metadata_t * p_meta)
{
//    LOG_PRINTF("%s\r\n",__FUNCTION__);
    if  (!(length == UNPROV_BEACON_DATA_LEN || length == UNPROV_BEACON_DATA_LEN_NO_HASH))
    {
        return;
    }
    if (m_event_handler)
    {
        prov_beacon_unprov_packet_t* p_unprov_beacon = (prov_beacon_unprov_packet_t*) p_data;

        mesh_prov_evt_t unprov_evt;
        memset(&unprov_evt, 0, sizeof(unprov_evt));
        unprov_evt.params.unprov.p_metadata = p_meta;
        memcpy(unprov_evt.params.unprov.device_uuid, p_unprov_beacon->device_uuid, MESH_UUID_SIZE);
        unprov_evt.params.unprov.gatt_supported = (p_meta->source == MESH_RX_SOURCE_GATT);
        unprov_evt.type = MESH_PROV_EVT_UNPROVISIONED_RECEIVED;
        if (length == UNPROV_BEACON_DATA_LEN)
        {
            unprov_evt.params.unprov.uri_hash_present = true;
            memcpy(unprov_evt.params.unprov.uri_hash, p_unprov_beacon->uri_hash, MESH_BEACON_UNPROV_URI_HASH_SIZE);
        }
        else
        {
            unprov_evt.params.unprov.uri_hash_present = false;
            memset(unprov_evt.params.unprov.uri_hash, 0, MESH_BEACON_UNPROV_URI_HASH_SIZE);
        }
        m_event_handler(&unprov_evt);
    }
}



void prov_beacon_scan_start(mesh_prov_evt_handler_cb_t event_handler)
{
//    LOG_PRINTF("%s\r\n",__FUNCTION__);
    m_event_handler = event_handler;
}

void prov_beacon_scan_stop(void)
{
//    LOG_PRINTF("%s\r\n",__FUNCTION__);
    m_event_handler = NULL;
}











