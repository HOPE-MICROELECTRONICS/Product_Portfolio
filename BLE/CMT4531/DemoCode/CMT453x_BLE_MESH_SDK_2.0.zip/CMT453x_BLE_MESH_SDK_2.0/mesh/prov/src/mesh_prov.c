#include <stdbool.h>
#include <string.h>
#include "mesh_prov.h"
#include "mesh_error.h"
#include "mesh_list.h"
#include "utils.h"
#include "bitfield.h"
#include "prov_utils.h"
#include "mesh_prov.h"
#include "mesh_error.h"
#include "mesh_list.h"
#include "utils.h"
#include "bitfield.h"
#include "prov_utils.h"
#include "prov_provisionee.h"


static bool bearer_compare_callback(const list_node_t * p_elem1, const list_node_t * p_elem2)
{
    return (PARENT_BY_FIELD_GET(prov_bearer_t, node, p_elem1)->bearer_type ==
            PARENT_BY_FIELD_GET(prov_bearer_t, node, p_elem2)->bearer_type);
}

uint32_t mesh_prov_init(mesh_prov_ctx_t *            p_ctx,
                            const uint8_t *                  p_public_key,
                            const uint8_t *                  p_private_key,
                            const mesh_prov_oob_caps_t * p_caps,
                            mesh_prov_evt_handler_cb_t   event_handler)
{
    if (p_ctx         == NULL ||
        p_public_key  == NULL ||
        p_private_key == NULL ||
        p_caps        == NULL ||
        event_handler == NULL)
    {
        return MESH_ERROR_NULL;
    }
    else if (p_ctx->state != MESH_PROV_STATE_IDLE)
    {
        return MESH_ERROR_INVALID_STATE;
    }
    else
    {
        p_ctx->event_handler = event_handler;
        p_ctx->p_public_key  = p_public_key;
        p_ctx->p_private_key = p_private_key;
        memcpy(&p_ctx->capabilities, p_caps, sizeof(mesh_prov_oob_caps_t));
        return MESH_SUCCESS;
    }
}


uint32_t mesh_prov_bearer_add(mesh_prov_ctx_t * p_ctx, prov_bearer_t * p_prov_bearer)
{
    if (p_ctx == NULL || p_prov_bearer == NULL)
    {
        return MESH_ERROR_NULL;
    }

    uint32_t status = list_compare_add(&p_ctx->p_bearers, &p_prov_bearer->node, bearer_compare_callback);
    if (status == MESH_SUCCESS)
    {
        p_prov_bearer->p_parent = p_ctx;
        p_ctx->supported_bearers |= p_prov_bearer->bearer_type;
    }
    return status;
}

uint32_t mesh_prov_generate_keys(uint8_t * p_public, uint8_t * p_private)
{
    return prov_utils_keys_generate(p_public, p_private);
}



static prov_bearer_t * prov_bearer_find(const list_node_t * p_bearers,
                                        mesh_prov_bearer_type_t bearer_type)
{
    prov_bearer_t * p_bearer;
    LIST_FOREACH(p_item, p_bearers)
    {
        p_bearer = PARENT_BY_FIELD_GET(prov_bearer_t, node, p_item);
        if (p_bearer->bearer_type == bearer_type)
        {
            return p_bearer;
        }
    }
    return NULL;
}

uint32_t mesh_prov_listen(mesh_prov_ctx_t *       p_ctx,
                              const char *                URI,
                              uint16_t                    oob_info_sources,
                              uint32_t                    bearer_types)
{
    if (p_ctx == NULL)
    {
        return MESH_ERROR_NULL;
    }
    else if(p_ctx->state != MESH_PROV_STATE_IDLE &&
            p_ctx->state != MESH_PROV_STATE_WAIT_LINK)
    {
        return MESH_ERROR_INVALID_STATE;
    }
    else if (bearer_types == 0 ||
             !bitfield_is_subset_of(&p_ctx->supported_bearers,
                                    &bearer_types,
                                    MESH_PROV_BEARER_COUNT))
    {
        return MESH_ERROR_INVALID_PARAM;
    }

    p_ctx->state = MESH_PROV_STATE_WAIT_LINK;
    p_ctx->role = MESH_PROV_ROLE_PROVISIONEE;

    for (uint32_t i = bitfield_next_get(&bearer_types, MESH_PROV_BEARER_COUNT, 0);
         i != MESH_PROV_BEARER_COUNT;
         i = bitfield_next_get(&bearer_types, MESH_PROV_BEARER_COUNT, i + 1))
    {
        prov_bearer_t * p_bearer = prov_bearer_find(p_ctx->p_bearers, (mesh_prov_bearer_type_t) (1 << i));
        uint32_t err_code = prov_provisionee_listen(p_ctx, p_bearer, URI, oob_info_sources);
        if (err_code != MESH_SUCCESS)
        {
            (void) mesh_prov_listen_stop(p_ctx);
            return err_code;
        }
    }
    return MESH_SUCCESS;
}

uint32_t mesh_prov_listen_stop(mesh_prov_ctx_t * p_ctx)
{
    if (p_ctx == NULL)
    {
        return MESH_ERROR_NULL;
    }
    else if (p_ctx->state != MESH_PROV_STATE_WAIT_LINK)
    {
        return MESH_ERROR_INVALID_STATE;
    }

    prov_bearer_t * p_bearer;
    LIST_FOREACH(p_item, p_ctx->p_bearers)
    {
        p_bearer = PARENT_BY_FIELD_GET(prov_bearer_t, node, p_item);
        (void) p_bearer->p_interface->listen_stop(p_bearer);
    }
    p_ctx->state = MESH_PROV_STATE_IDLE;

    return MESH_SUCCESS;
}


uint32_t mesh_prov_pause(mesh_prov_ctx_t * p_ctx)
{
    if (p_ctx == NULL)
    {
        return MESH_ERROR_NULL;
    }
    else if (p_ctx->state != MESH_PROV_STATE_WAIT_LINK)
    {
        prov_bearer_t * p_bearer;
        LIST_FOREACH(p_item, p_ctx->p_bearers)
        {
            p_bearer = PARENT_BY_FIELD_GET(prov_bearer_t, node, p_item);
            (void) p_bearer->p_interface->link_close(p_bearer, MESH_PROV_LINK_CLOSE_REASON_DELIBERATE);
        }
        p_ctx->state = MESH_PROV_STATE_IDLE;          
        
    }else{
    
        prov_bearer_t * p_bearer;
        LIST_FOREACH(p_item, p_ctx->p_bearers)
        {
            p_bearer = PARENT_BY_FIELD_GET(prov_bearer_t, node, p_item);
            (void) p_bearer->p_interface->listen_stop(p_bearer);
        }
        p_ctx->state = MESH_PROV_STATE_IDLE;    
    
    }
    return MESH_SUCCESS;
}



uint32_t mesh_prov_resume(mesh_prov_ctx_t * p_ctx)
{
    if (p_ctx == NULL)
    {
        return MESH_ERROR_NULL;
    }
    else if (p_ctx->state != MESH_PROV_STATE_IDLE)
    {
        return MESH_ERROR_INVALID_STATE;
    }

    prov_bearer_t * p_bearer;
    LIST_FOREACH(p_item, p_ctx->p_bearers)
    {
        p_bearer = PARENT_BY_FIELD_GET(prov_bearer_t, node, p_item);
        (void) p_bearer->p_interface->listen_resume(p_bearer);
    }
    p_ctx->state = MESH_PROV_STATE_WAIT_LINK;

    return MESH_SUCCESS;
}












