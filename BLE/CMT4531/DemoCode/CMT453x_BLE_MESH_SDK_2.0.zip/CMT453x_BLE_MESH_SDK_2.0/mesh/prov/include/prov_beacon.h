#ifndef PROV_BEACON_H__
#define PROV_BEACON_H__




#include <stdint.h>
#include "packet.h"
#include "advertiser.h"
#include "mesh_prov_events.h"




adv_packet_t * prov_beacon_unprov_build(advertiser_t * p_adv, const char * p_uri, uint16_t oob_info);
void prov_beacon_unprov_report(bool unprov_report);
void prov_beacon_unprov_packet_in(const uint8_t * p_data, uint8_t length, const mesh_rx_metadata_t * p_meta);
void prov_beacon_scan_start(mesh_prov_evt_handler_cb_t event_handler);
void prov_beacon_scan_stop(void);





#endif /* PROV_BEACON_H__ */


