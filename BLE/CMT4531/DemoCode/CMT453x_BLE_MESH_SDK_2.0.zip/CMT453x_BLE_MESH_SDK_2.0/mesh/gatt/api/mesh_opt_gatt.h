#ifndef MESH_OPT_GATT_H__
#define MESH_OPT_GATT_H__

#include "mesh_opt.h"

#define MESH_OPT_GATT_PROXY_EID     MESH_OPT_CORE_ID(MESH_OPT_GATT_ID_START + 0)

uint32_t mesh_opt_gatt_proxy_set(bool enabled);
uint32_t mesh_opt_gatt_proxy_get(bool * p_enabled);


#endif /* MESH_OPT_GATT_H__ */
