#ifndef __DFU_GATT_SRV_H__
#define __DFU_GATT_SRV_H__



#include "rwip_config.h"     // SW configuration

#include "prf_types.h"
#include "prf.h"


#define SERVICE_HP_IUS       {0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,  0x01,0x00,  0x11,0x11}        
#define CHAR_HP_IUS_RC       {0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11  ,0x02,0x00,  0x11,0x11}     
#define CHAR_HP_IUS_CC       {0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11  ,0x03,0x00,  0x11,0x11}        



enum
{
    HP_IUS_IDX_SVC,

    HP_IUS_IDX_RC_CHAR,
    HP_IUS_IDX_RC_VAL,
    HP_IUS_IDX_RC_CFG,

    HP_IUS_IDX_CC_CHAR,
    HP_IUS_IDX_CC_VAL,
    HP_IUS_IDX_CC_CFG,
        
    HP_IUS_IDX_NB,
};
enum
{
    HP_IUS_CREATE_DB_REQ = TASK_FIRST_MSG(TASK_ID_HP_IUS),  
    HP_IUS_VALUE_REQ_IND,
    HP_IUS_VAL_WRITE_IND,
    HP_IUS_ATT_INFO_REQ,
    HP_IUS_CONNECT,
    HP_IUS_DISCONNECT,
};
enum hp_ius_state
{
    HP_IUS_IDLE,
    HP_IUS_BUSY,
    HP_IUS_STATE_MAX,
};

struct hp_ius_db_cfg
{
    uint8_t max_nb_att;
    uint8_t *att_tbl;
    uint8_t *cfg_flag;
    uint16_t features;
};
struct hp_ius_val_write_ind
{
    uint8_t  conidx;
    uint16_t handle;
    uint16_t length;
    uint8_t  value[__ARRAY_EMPTY];
};
struct hp_ius_value_req_ind
{
    uint8_t  conidx;
    uint16_t att_idx;
};

struct hp_ius_att_info_req
{
    uint8_t  conidx;
    uint16_t att_idx;
};


struct hp_ius_disconnect
{
    uint8_t  conidx;
};


#define HP_IUS_IDX_MAX        (1)
struct hp_ius_val_elmt
{
    struct co_list_hdr hdr;
    uint8_t att_idx;
    uint8_t length;
    uint8_t data[__ARRAY_EMPTY];
};
struct hp_ius_env_tag
{
    prf_env_t prf_env;
    uint16_t shdl;
    uint8_t max_nb_att;
    struct ke_msg *operation;
    uint8_t cursor;
    uint8_t ccc_idx;
    struct co_list values;
    ke_state_t state[HP_IUS_IDX_MAX];
};

struct hp_ius_connection_req_ind
{
    uint16_t conhdl;
    uint8_t con_index;    
};


extern struct attm_desc_128 hp_ius_att_db[HP_IUS_IDX_NB];



void hp_ble_ius_app_cc_send(uint8_t conn_idx, uint8_t *p_data, uint16_t length);
void app_hp_ius_remove_ius(void);






#endif //__DFU_GATT_SRV_H__
