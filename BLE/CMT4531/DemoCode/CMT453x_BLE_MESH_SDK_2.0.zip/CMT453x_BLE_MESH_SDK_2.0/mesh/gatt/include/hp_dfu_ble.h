/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file hp_dfu_ble.h
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */

 /** @addtogroup 
 * @{
 */
#ifndef __HP_DFU_BLE_H__
#define __HP_DFU_BLE_H__







#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#include <stdint.h>

/* Public define ------------------------------------------------------------*/
/* Public typedef -----------------------------------------------------------*/
/* Public define ------------------------------------------------------------*/  


#define OTA_CMD_CONN_PARAM_UPDATE                     1
#define OTA_CMD_MTU_UPDATE                            2
#define OTA_CMD_VERSION                               3
#define OTA_CMD_CREATE_OTA_SETTING                    4
#define OTA_CMD_CREATE_OTA_IMAGE                      5
#define OTA_CMD_VALIDATE_OTA_IMAGE                    6
#define OTA_CMD_ACTIVATE_OTA_IMAGE                    7
#define OTA_CMD_JUMP_IMAGE_UPDATE                     8

#define CONN_PARAM_UPDATE                                                0xFE



typedef struct{

    uint32_t start_address;
    uint32_t size;
    uint32_t crc;
    uint32_t version;
}Dfu_setting_bank_t;

typedef struct{

    uint32_t crc;
    Dfu_setting_bank_t app1;
    Dfu_setting_bank_t app2;
    Dfu_setting_bank_t image_update;
    uint8_t signature[64];
}Dfu_setting_t;

extern uint8_t manual_conn_param_update;
extern uint8_t manual_mtu_update;
/* Public constants ---------------------------------------------------------*/
/* Public function prototypes -----------------------------------------------*/
void hp_dfu_ble_handler_cc(uint8_t const *input, uint8_t input_len, uint8_t *output, uint8_t *output_len);
void hp_dfu_ble_handler_rc(uint8_t const  *input, uint32_t input_len);















#ifdef __cplusplus
}
#endif



#endif //__HP_DFU_BLE_H__
