#ifndef PROXY_CONFIG_PACKET_H__
#define PROXY_CONFIG_PACKET_H__

#include <stdint.h>
#include "mesh_config_core.h"

#define PROXY_CONFIG_PARAM_OVERHEAD (offsetof(proxy_config_msg_t, params))

typedef enum
{
    PROXY_CONFIG_OPCODE_FILTER_TYPE_SET = 0x00,
    PROXY_CONFIG_OPCODE_FILTER_ADDR_ADD = 0x01,
    PROXY_CONFIG_OPCODE_FILTER_ADDR_REMOVE = 0x02,
    PROXY_CONFIG_OPCODE_FILTER_STATUS = 0x03,
} proxy_config_opcode_t;


typedef struct __attribute((packed))
{
    uint8_t filter_type;
} proxy_config_params_filter_type_set_t;

typedef struct __attribute((packed))
{
    uint16_t addrs[MESH_GATT_PROXY_FILTER_ADDR_COUNT];
} proxy_config_params_filter_addr_add_t;

typedef struct __attribute((packed))
{
    uint16_t addrs[MESH_GATT_PROXY_FILTER_ADDR_COUNT];
} proxy_config_params_filter_addr_remove_t;

typedef struct __attribute((packed))
{
    uint8_t filter_type;
    uint16_t list_size;
} proxy_config_params_filter_status_t;

typedef struct __attribute((packed))
{
    uint8_t opcode;
    union __attribute((packed))
    {
        proxy_config_params_filter_type_set_t filter_type_set;
        proxy_config_params_filter_addr_add_t filter_addr_add;
        proxy_config_params_filter_addr_remove_t filter_addr_remove;
        proxy_config_params_filter_status_t filter_status;
    } params;
} proxy_config_msg_t;

#endif /* PROXY_CONFIG_PACKET_H__ */
