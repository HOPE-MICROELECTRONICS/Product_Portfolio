#ifndef __DFU_GATT_H__
#define __DFU_GATT_H__




#include "dfu_gatt_srv.h"
#include "gapc.h"
#include "gapc_task.h"
#include "gattc_task.h"




extern const struct app_subtask_handlers hp_ius_app_handlers;


void app_hp_ius_add_hp_ius(void);
void hp_dfu_ble_handler_conn_param_update(uint8_t status);
void dfu_gatt_update_conn_param(struct gapc_conn_param *p_conn_param);
void dfu_gatt_cc_send(uint8_t *p_data, uint8_t len);
void dfu_gatt_mtu_set(uint16_t mtu);
void hp_dfu_ble_handler_mtu_update(uint8_t status);

#endif //__DFU_GATT_H__
