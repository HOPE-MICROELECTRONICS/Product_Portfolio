/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file mesh_app_task.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */
#include "mesh_app_task.h"
#include "cmt453x.h"
#include "gapm_task.h"
#include "rwip.h"
#include "co_bt_defines.h"
#include "gapc_task.h" 
#include "ke_task.h" 
#include "co_utils.h" 
#include "stdio.h" 
#include "scanner.h" 
#include "bsp_led.h"
#include "mesh_app.h"
#include "bsp_lpuart.h"
#include "toolchain.h"
#include "reg_ipcore.h"

/** 
 * @brief Start to scan.
 *
 * @param[in] msgid     Id of the message.
 * @param[in] param   	Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the task instance (TASK_MESH).
 * @param[in] src_id    ID of the task instance.
 *
 * @return If the message was consumed or not. 
 */
static int mesh_task_start_scan_handler(ke_msg_id_t const msgid, void const *param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    scanner_radio_start();
    return (KE_MSG_CONSUMED);
}
/** 
 * @brief Stop scanning.
 *
 * @param[in] msgid     Id of the message.
 * @param[in] param   	Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the task instance (TASK_MESH).
 * @param[in] src_id    ID of the task instance.
 *
 * @return If the message was consumed or not. 
 */
static int mesh_task_stop_scan_handler(ke_msg_id_t const msgid, void const *param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    scanner_radio_stop();
    return (KE_MSG_CONSUMED);
}

static int mesh_task_provision_complete_handler(ke_msg_id_t const msgid, void const *param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
   LOG_PRINTF("%s\r\n",__FUNCTION__);
   return (KE_MSG_CONSUMED);
}

extern uint32_t g_rf_scan_adv_report_counter;

extern int mesh_task_button_timer_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_flash_evt_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_flash_end_evt_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_bearer_evt_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_gatt_reset_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_wdt_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_schedule_timer_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_timer_sched_timeout_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_model_timer_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_post_init_evt_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_flash_defrag_evt_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_ad_report_mesh_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_ad_beacon_report_mesh_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
extern int mesh_task_uart_rx_data_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
#ifdef PC_PROVISIONER
extern int mesh_task_hw_test_evt_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret);
#endif  



/* Mesh task related events handlers. */
KE_MSG_HANDLER_TAB(mesh)
{
    {MESH_TASK_BUTTON_TIMER,        (ke_msg_func_t)mesh_task_button_timer_handler},
    {MESH_TASK_FLASH_EVT,           (ke_msg_func_t)mesh_task_flash_evt_handler},
    {MESH_TASK_FLASH_END_EVT,       (ke_msg_func_t)mesh_task_flash_end_evt_handler},
    {MESH_TASK_FLASH_DEFRAG_EVT,    (ke_msg_func_t)mesh_task_flash_defrag_evt_handler},
    {MESH_TASK_BEARER_EVENT,        (ke_msg_func_t)mesh_task_bearer_evt_handler},
    {MESH_TASK_START_SCAN,          (ke_msg_func_t)mesh_task_start_scan_handler},
    {MESH_TASK_STOP_SCAN,           (ke_msg_func_t)mesh_task_stop_scan_handler},
    {MESH_TASK_GATT_RESET,          (ke_msg_func_t)mesh_task_gatt_reset_handler},
    {MESH_TASK_WDT,                 (ke_msg_func_t)mesh_task_wdt_handler},
    {MESH_TASK_SCHEDULE_TIMER,      (ke_msg_func_t)mesh_task_schedule_timer_handler},    
    {MESH_TASK_AD_REPORT_MESH,      (ke_msg_func_t)mesh_task_ad_report_mesh_handler},
    {MESH_TASK_AD_BEACON_REPORT_MESH,      (ke_msg_func_t)mesh_task_ad_beacon_report_mesh_handler},
    {MESH_TASK_TIMER_SCHED_TIMEOUT, (ke_msg_func_t)mesh_task_timer_sched_timeout_handler},
    {MESH_TASK_MODEL_TIMER_LL,      (ke_msg_func_t)mesh_task_model_timer_handler},
    {MESH_TASK_MODEL_TIMER_CTL,     (ke_msg_func_t)mesh_task_model_timer_handler},
    {MESH_TASK_MODEL_TIMER_HSL,     (ke_msg_func_t)mesh_task_model_timer_handler},
    {MESH_TASK_PROVISION_COMPLETE,  (ke_msg_func_t)mesh_task_provision_complete_handler },
    {MESH_TASK_UART_RX_DATA,        (ke_msg_func_t)mesh_task_uart_rx_data_handler},
    {MESH_TASK_POST_INIT_EVT,       (ke_msg_func_t)mesh_task_post_init_evt_handler},
    #ifdef PC_PROVISIONER
    {MESH_TASK_HW_TEST_EVT,       (ke_msg_func_t)mesh_task_hw_test_evt_handler},
    #endif    
};
/* Defines the place holder for the states of all the task instances. */
ke_state_t mesh_state[1];
/* Mesh task descriptor */
const struct ke_task_desc TASK_DESC_MESH_M = {mesh_msg_handler_tab, mesh_state, 1, ARRAY_LEN(mesh_msg_handler_tab)};









