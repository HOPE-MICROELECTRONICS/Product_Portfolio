/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file app_task.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */

/** 
 * @addtogroup APPTASK
 * @{ 
 */

/* Includes ------------------------------------------------------------------*/
#include "app_task.h"
#include "co_utils.h"
#include "gapm_task.h" 
#include "gapc_task.h" 
#include "ahi_task.h"
#include "co_hci.h"
#include "hci.h"
#include "stdio.h"
#include "attm.h"
#include "atts.h"
#include "gapm_int.h"
#include "llm_int.h"
#include "prf.h"
#include "bsp_led.h"
#include "app.h"
#include "ke_timer.h"
#include "global_var.h"
#include "mesh_gatt.h"
#include "dfu_gatt.h"
#include "hp_dfu_ble.h"
#include "mal_adv.h"
#include "broadcast.h"
#include "scanner.h"
#include "bsp_lpuart.h"
#include "gatt.h"
#include "gattm_int.h"
#include "mesh_app_task.h"



uint8_t m_actv_idx;
uint8_t m_scan_actv_idx;
static uint8_t m_con_idx = 0;
volatile uint32_t g_rf_scan_adv_report_counter = 0;




/** 
 * @brief Handles GAP manager command complete events.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] p_param   Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int gapm_cmp_evt_handler(ke_msg_id_t const msgid, struct gapm_cmp_evt const *p_param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
		switch(p_param->operation)
		{
			case GAPM_RESET:{
                LOG_PRINTF("GAPM_RESET --> %02X\r\n",p_param->status);
			}break;
			case GAPM_SET_DEV_CONFIG:{
                LOG_PRINTF("GAPM_SET_DEV_CONFIG --> %02X\r\n",p_param->status);
				prf_init(RWIP_1ST_RST); 
                app_gap_gatt_srv_add();
			}break;            
			case GAPM_PROFILE_TASK_ADD:{
                LOG_PRINTF("GAPM_PROFILE_TASK_ADD --> %02X\r\n",p_param->status);
			}break;
			case GAPM_CREATE_ADV_ACTIVITY:{
//                LOG_PRINTF("GAPM_CREATE_ADV_ACTIVITY --> %02X, %d\r\n",p_param->status, p_param->actv_idx);
			}break;	  
			case GAPM_SET_ADV_DATA:{
//                LOG_PRINTF("GAPM_SET_ADV_DATA --> %02X, %d\r\n",p_param->status, p_param->actv_idx);
			}break;
			case GAPM_SET_SCAN_RSP_DATA:{
//                LOG_PRINTF("GAPM_SET_SCAN_RSP_DATA --> %02X, %d\r\n",p_param->status, p_param->actv_idx);
			}break;	
			case GAPM_START_ACTIVITY:{
                LOG_PRINTF("GAPM_START_ACTIVITY --> %02X, %d\r\n",p_param->status, p_param->actv_idx);
                if(prov_proxy_adv_adv_idx_get() == p_param->actv_idx){
                    if(p_param->status == LL_ERR_MEMORY_CAPA_EXCEED){
                        prov_proxy_adv_start();
                    }
                }
			}break;            
			case GAPM_STOP_ACTIVITY:{
//                LOG_PRINTF("GAPM_STOP_ACTIVITY --> %02X, %d\r\n",p_param->status, p_param->actv_idx);
			}break;   
			case GAPM_DELETE_ALL_ACTIVITIES:{
//                LOG_PRINTF("GAPM_DELETE_ALL_ACTIVITIES --> %02X, %d\r\n",p_param->status, p_param->actv_idx);
			}break;     

			case GAPM_CREATE_SCAN_ACTIVITY:{
//                LOG_PRINTF("GAPM_CREATE_SCAN_ACTIVITY --> %02X, %d\r\n",p_param->status, p_param->actv_idx);
			}break;
			case GAPM_DELETE_ACTIVITY:{
//                LOG_PRINTF("GAPM_DELETE_ACTIVITY --> %02X, %d\r\n",p_param->status, p_param->actv_idx);
			}break;            
            
		}
	
        if (p_param->operation >= GAPM_CREATE_ADV_ACTIVITY)
        {
            mal_activity_cmp_evt_handler(p_param->operation, p_param->status, p_param->actv_idx);
        }        
        
        
	
    return KE_MSG_CONSUMED;
}
/** 
 * @brief GAPC message complete event handler.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] p_param   Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int gapc_cmp_evt_handler(ke_msg_id_t const msgid,struct gapc_cmp_evt const *p_param, ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
    switch(p_param->operation)
    {
        case GAPC_UPDATE_PARAMS:{
            LOG_PRINTF("GAPC_UPDATE_PARAMS --> 0x%02X\r\n",p_param->status);
            if(p_param->status != GAP_ERR_NO_ERROR){
                ke_timer_set(TIMER_CONN_PARAM_MSG, TASK_APP, 1000); 
            }
            }break;
        case GAPC_SET_LE_PKT_SIZE:{	
            }break;

        default:
        break;
    }
    return KE_MSG_CONSUMED;
}
static int gattc_cmp_evt_handler(ke_msg_id_t const msgid, struct gattc_cmp_evt const *p_param,ke_task_id_t const dest_id, ke_task_id_t const src_id)
{    
    switch(p_param->operation){
        case GATTC_MTU_EXCH:{
//            LOG_PRINTF("GATTC_MTU_EXCH --> 0x%02X\r\n",p_param->status);
        }break;    
    } 

    return (KE_MSG_CONSUMED);
}
/** 
 * @brief Get application profile message handler.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] p_param   Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static uint8_t app_get_handler(const struct app_subtask_handlers *handler_list_desc, ke_msg_id_t msgid, void const *p_param, ke_task_id_t src_id)
{
    uint8_t counter;
    for (counter = handler_list_desc->msg_cnt; 0 < counter; counter--)
    {
        struct ke_msg_handler handler = (*(handler_list_desc->p_msg_handler_tab + counter - 1));
        
        if ((handler.id == msgid) || (handler.id == KE_MSG_DEFAULT_HANDLER))
        {
            return (uint8_t)(handler.func(msgid, p_param, TASK_APP, src_id));
        }
    }
    return KE_MSG_CONSUMED;
}
/** 
 * @brief Handles application message.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] p_param   Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int app_msg_default_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
	ke_task_id_t src_task_id = MSG_T(msgid);
	switch (src_task_id)
	{	
		case TASK_ID_MESH_GATT:{
            app_get_handler(&mesh_gatt_app_handlers, msgid, p_param, src_id);
		} break;	
	}
  return KE_MSG_CONSUMED;
}

/** 
 * @brief Handles connection parameter update event from the GAP
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] p_param   Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */

void app_task_change_conn_interval(void)
{
    struct app_conn_param conn_param;
    conn_param.intv_min = 32;
    conn_param.intv_max = 32;
    conn_param.latency = 0;
    conn_param.time_out = 500; 
    app_update_param(m_con_idx, &conn_param);  
}

static int app_timer_conn_param_handler(ke_msg_id_t const msgid, void const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
//    LOG_PRINTF("*******************app_timer_conn_param_handler\r\n");
    if(m_con_idx != 0xff){    
        struct app_conn_param conn_param;
        conn_param.intv_min = 100;
        conn_param.intv_max = 150;
        conn_param.latency = 0;
        conn_param.time_out = 500; 
        app_update_param(m_con_idx, &conn_param);    
    }

    return KE_MSG_CONSUMED;
}

/** 
 * @brief Handles connection complete event from the GAP. Enable all required profiles
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] p_param   Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int gapc_connection_req_ind_handler(ke_msg_id_t const msgid, struct gapc_connection_req_ind const *p_param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    DEBUG_PRINTF("gapc_connection_req_ind_handler\r\n");
    g_rf_scan_adv_report_counter++;
	struct gapc_connection_cfm *cfm = KE_MSG_ALLOC(GAPC_CONNECTION_CFM,KE_BUILD_ID(TASK_GAPC, KE_IDX_GET(src_id)), TASK_APP, gapc_connection_cfm);    
    cfm->pairing_lvl = GAP_AUTH_REQ_NO_MITM_NO_BOND; 
    ke_msg_send(cfm);
    m_con_idx = KE_IDX_GET(src_id);
	struct mesh_gatt_connection_req_ind *p_cmd = KE_MSG_ALLOC(MESH_GATT_CONNECT, TASK_APP, dest_id, mesh_gatt_connection_req_ind);	
	p_cmd->conhdl = p_param->conhdl;
    p_cmd->con_index = KE_IDX_GET(src_id);
	ke_msg_send(p_cmd);	   

    if (mesh_is_device_provisioned())
    {
        ke_timer_clear(TIMER_CONN_PARAM_MSG, TASK_APP); 
        ke_timer_set(TIMER_CONN_PARAM_MSG, TASK_APP, 5000); 
    }
    
    return KE_MSG_CONSUMED;
}
/** 
 * @brief Handles disconnection complete event from the GAP.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] p_param   Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int gapc_disconnect_ind_handler(ke_msg_id_t const msgid, struct gapc_disconnect_ind const *p_param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    DEBUG_PRINTF("gapc_disconnect_ind_handler : 0x%02X\r\n",p_param->reason);
    ke_timer_clear(TIMER_CONN_PARAM_MSG, TASK_APP); 
    m_con_idx = 0xff;
	struct gapc_disconnect_ind *p_cmd = KE_MSG_ALLOC(MESH_GATT_DISCONNECT, TASK_APP, dest_id, gapc_disconnect_ind);	
	p_cmd->conhdl = p_param->conhdl;
	ke_msg_send(p_cmd);		
    return KE_MSG_CONSUMED;
}
/** 
 * @brief Handles connection complete event from the GAP. Enable all required profiles
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] p_param   Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int gapc_param_update_req_ind_handler(ke_msg_id_t const msgid,struct gapc_param_update_req_ind const *p_param, ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
//    LOG_PRINTF("================gapc_param_update_req_ind_handler\r\n");
    DEBUG_PRINTF("----------------intv_min --> %d\r\n", p_param->intv_min);
//    LOG_PRINTF("intv_max --> %d\r\n", p_param->intv_max);
//    LOG_PRINTF("latency --> %d\r\n", p_param->latency);
//    LOG_PRINTF("time_out --> %d\r\n", p_param->time_out);  
    struct gapc_param_update_cfm *cfm = KE_MSG_ALLOC(GAPC_PARAM_UPDATE_CFM,KE_BUILD_ID(TASK_GAPC, KE_IDX_GET(src_id)), TASK_APP,gapc_param_update_cfm);
    cfm->accept = true;
    cfm->ce_len_min = 0xFFFF;
    cfm->ce_len_max = 0xFFFF;
    ke_msg_send(cfm);  
    return KE_MSG_CONSUMED;          

}

/** 
 * @brief Handles 
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] p_param   Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */

static int gapc_param_updated_ind_handler(ke_msg_id_t const msgid, struct gapc_param_updated_ind const *p_param, ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
//    LOG_PRINTF("================gapc_param_updated_ind_handler\r\n");
    DEBUG_PRINTF("con_interval --> %d\r\n", p_param->con_interval);    
    g_rf_scan_adv_report_counter++;
    return KE_MSG_CONSUMED;
}
/** 
 * @brief Handles GAPM_ACTIVITY_STOPPED_IND event.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance.
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int gapm_activity_stopped_ind_handler(ke_msg_id_t const msgid, struct gapm_activity_stopped_ind const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
    LOG_PRINTF("gapm_activity_stopped_ind_handler\r\n");
    if(p_param->actv_type == GAPM_ACTV_TYPE_SCAN)
    {     
        LOG_PRINTF("gapm_activity_stopped_ind_handler : GAPM_ACTV_TYPE_SCAN\r\n");
    } else if(p_param->actv_type == GAPM_ACTV_TYPE_ADV)  {   
        LOG_PRINTF("gapm_activity_stopped_ind_handler --> %02X\r\n",p_param->reason);
        mal_adv_stopped_ind_handler(p_param->actv_type, p_param->reason, p_param->actv_idx);
        broadcast_stop(p_param->actv_idx);
    }  
    return KE_MSG_CONSUMED;
}
/** 
 * @brief Handles GATTC_MTU_CHANGED_IND event.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance.
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int gattc_mtu_changed_ind_handler(ke_msg_id_t const msgid, struct  gattc_mtu_changed_ind const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
    DEBUG_PRINTF("gattc_mtu_changed_ind_handler\r\n");
    DEBUG_PRINTF("mtu --> %d\r\n", p_param->mtu);
    DEBUG_PRINTF("seq_num --> %d\r\n", p_param->seq_num);    
    return KE_MSG_CONSUMED;
}
/** 
 * @brief Handles GAPC_LE_PKT_IND event.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance.
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int gapc_le_pkt_size_ind_handler(ke_msg_id_t const msgid, struct  gapc_le_pkt_size_ind const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
    DEBUG_PRINTF("gapc_le_pkt_size_ind_handler\r\n");
    DEBUG_PRINTF("max_rx_octets --> %d\r\n", p_param->max_rx_octets);
    DEBUG_PRINTF("max_rx_time --> %d\r\n", p_param->max_rx_time);    
    DEBUG_PRINTF("max_tx_octets --> %d\r\n", p_param->max_tx_octets);
    DEBUG_PRINTF("max_tx_time --> %d\r\n", p_param->max_tx_time);        
    return KE_MSG_CONSUMED;
}
/** 
 * @brief Handles GAPM_ACTIVITY_CREATED_IND event.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance.
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */
static int gapm_activity_created_ind_handler(ke_msg_id_t const msgid,struct gapm_activity_created_ind const *p_param, ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
//    LOG_PRINTF("gapm_activity_created_ind_handler actv_idx --> %d\r\n",p_param->actv_idx);
    if(p_param->actv_type == GAPM_ACTV_TYPE_ADV)
    {
        m_actv_idx = p_param->actv_idx;   
        mal_adv_created_ind_handler(p_param->actv_type, p_param->actv_idx);
    }
    else if(p_param->actv_type == GAPM_ACTV_TYPE_SCAN)
    {
        m_scan_actv_idx = p_param->actv_idx;  
    }
    return KE_MSG_CONSUMED;
}
/*
 * @brief Handles GAPC_GET_DEV_INFO_REQ_IND event.
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 * @return If the message was consumed or not.
*/
#if defined(CFG_PRF_GAP) && defined(CFG_PRF_GATT)
static int gapc_get_dev_info_req_ind_handler(ke_msg_id_t const msgid,
        struct gapc_get_dev_info_req_ind const *p_param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    LOG_PRINTF("%s, req:%d\r\n",__func__,p_param->req);
    switch(p_param->req)
    {
        case GAPC_DEV_NAME:
        {
            LOG_PRINTF("GAPC_DEV_NAME\r\n");
            struct gapc_get_dev_info_cfm * cfm = KE_MSG_ALLOC_DYN(GAPC_GET_DEV_INFO_CFM,
                                                    src_id, dest_id,
                                                    gapc_get_dev_info_cfm, 18);
            cfm->req = GAPC_DEV_NAME;
            char name[20];
            memset(name,0,sizeof(name));
            sprintf(name,"MESH_%02X%02X",g_co_default_bdaddr.addr[4],g_co_default_bdaddr.addr[5]);
            cfm->info.name.length = strlen(name);
            memcpy(cfm->info.name.value,name,strlen(name));            
            // Send message
            ke_msg_send(cfm);
        } break;

        case GAPC_DEV_APPEARANCE:
        {
            LOG_PRINTF("GAPC_DEV_APPEARANCE\r\n");
            // Allocate message
            struct gapc_get_dev_info_cfm *cfm = KE_MSG_ALLOC(GAPC_GET_DEV_INFO_CFM,
                                                             src_id, dest_id,
                                                             gapc_get_dev_info_cfm);
            cfm->req = GAPC_DEV_APPEARANCE;
            // Set the device appearance
            // No appearance
            cfm->info.appearance = false;
            // Send message
            ke_msg_send(cfm);
        } break;

        case GAPC_DEV_SLV_PREF_PARAMS:
        {
            LOG_PRINTF("GAPC_DEV_SLV_PREF_PARAMS\r\n");
            // Allocate message
            struct gapc_get_dev_info_cfm *cfm = KE_MSG_ALLOC(GAPC_GET_DEV_INFO_CFM,
                                                            src_id, dest_id,
                                                            gapc_get_dev_info_cfm);
            cfm->req = GAPC_DEV_SLV_PREF_PARAMS;
            cfm->info.slv_pref_params.con_intv_min  = 40;
            cfm->info.slv_pref_params.con_intv_max  = 50;
            cfm->info.slv_pref_params.slave_latency = 0;
            cfm->info.slv_pref_params.conn_timeout  = 500;

            // Send message
            ke_msg_send(cfm);
        } break;

        default: /* Do Nothing */ break;
    }

    return (KE_MSG_CONSUMED);
}
#endif
/** 
 * @brief Handles GAPM_ACTIVITY_STOPPED_IND event.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance.
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not. 
 */

static int appm_gapm_ext_adv_repoer_ind_handler(ke_msg_id_t const msgid, struct gapm_ext_adv_report_ind const *param,
                                 ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    g_rf_scan_adv_report_counter++;
    if (mesh_is_device_provisioned()){
        if(param->info == (GAPM_REPORT_TYPE_ADV_LEG | GAPM_REPORT_INFO_COMPLETE_BIT)){    
            mesh_rx_metadata_scanner_t metadata;
            metadata.adv_type = BLE_PACKET_TYPE_ADV_NONCONN_IND;
            metadata.rssi = param->rssi;
            metadata.adv_addr.addr[0] = param->trans_addr.addr.addr[0];
            metadata.adv_addr.addr[1] = param->trans_addr.addr.addr[1];
            metadata.adv_addr.addr[2] = param->trans_addr.addr.addr[2];
            metadata.adv_addr.addr[3] = param->trans_addr.addr.addr[3];
            metadata.adv_addr.addr[4] = param->trans_addr.addr.addr[4];
            metadata.adv_addr.addr[5] = param->trans_addr.addr.addr[5];
            scanner_handle_end_event(&metadata, (uint8_t *)param->data,param->length);
        }    
    }


    return (KE_MSG_CONSUMED);
}



extern int app_bearer_event_handler(ke_msg_id_t const msgid, void const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id);
extern int flash_evt_handler(ke_msg_id_t const msgid, void const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id);
extern int flash_end_evt_handler(ke_msg_id_t const msgid, void const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id);
extern int gatt_reset_handler(ke_msg_id_t const msgid, void const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id);
/* Default State handlers definition. */
KE_MSG_HANDLER_TAB(app)
{
    {KE_MSG_DEFAULT_HANDLER,         (ke_msg_func_t)app_msg_default_handler},
    {GAPM_CMP_EVT,                   (ke_msg_func_t)gapm_cmp_evt_handler},
    {GAPC_CMP_EVT,                   (ke_msg_func_t)gapc_cmp_evt_handler},
    {GAPC_CONNECTION_REQ_IND,        (ke_msg_func_t)gapc_connection_req_ind_handler},
    {GAPC_DISCONNECT_IND,            (ke_msg_func_t)gapc_disconnect_ind_handler},
    {GAPC_PARAM_UPDATE_REQ_IND,      (ke_msg_func_t)gapc_param_update_req_ind_handler},
    {GAPM_ACTIVITY_CREATED_IND,      (ke_msg_func_t)gapm_activity_created_ind_handler},
    {GAPM_ACTIVITY_STOPPED_IND,      (ke_msg_func_t)gapm_activity_stopped_ind_handler},       
    {GATTC_MTU_CHANGED_IND,          (ke_msg_func_t)gattc_mtu_changed_ind_handler},
    {GATTC_CMP_EVT,                  (ke_msg_func_t)gattc_cmp_evt_handler},
    #if defined(CFG_PRF_GAP) && defined(CFG_PRF_GATT)
    {GAPC_GET_DEV_INFO_REQ_IND,      (ke_msg_func_t)gapc_get_dev_info_req_ind_handler},  
    #endif
    {GAPC_LE_PKT_SIZE_IND,           (ke_msg_func_t)gapc_le_pkt_size_ind_handler},
    {GAPC_PARAM_UPDATED_IND,         (ke_msg_func_t)gapc_param_updated_ind_handler},
    {GAPM_EXT_ADV_REPORT_IND,        (ke_msg_func_t)appm_gapm_ext_adv_repoer_ind_handler},
    {TIMER_CONN_PARAM_MSG,           (ke_msg_func_t)app_timer_conn_param_handler},
    
};

/* Defines the place holder for the states of all the task instances. */
ke_state_t app_state[1];

// Application task descriptor
const struct ke_task_desc TASK_DESC_APP_M = {app_msg_handler_tab, app_state, 1, ARRAY_LEN(app_msg_handler_tab)};








