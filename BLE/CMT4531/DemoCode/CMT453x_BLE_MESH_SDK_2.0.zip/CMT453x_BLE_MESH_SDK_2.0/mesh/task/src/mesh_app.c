/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file mesh_app.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "cmt453x.h"
#include "gapm_task.h"
#include "rwip.h"
#include "co_bt_defines.h"
#include "gapc_task.h" 
#include "ke_task.h" 
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "rwip.h"
#include "app_task.h"
#include "rwip_int.h"
#include "mesh.h"
#include "flash_manager.h"
#include "mesh_opt.h"
#include "mesh_events.h"
#include "event.h"
#include "stdio.h"
#include "bsp_lpuart.h"
#include "app.h"
#include "Typedefine.h"
#include "ke_env.h"
#include "global_func.h"



typedef void (*func_ptr_t)(void);
static volatile uint32_t was_masked;
/**
 * @brief  Reset the flash sectors.
 */
void hp_mesh_nvds_clear(void)
{    
    for(int i=1;i<MESH_OPT_FIRST_FREE_ID;i++)
    {
        Qflash_Erase_Sector(MESH_CONFIG_FLASH_START+((i)*4096));
    }
}

/**
 * @brief  Initialize the mesh stack.
 * @param  model_init function used to initialize the application models.
 */
void hp_mesh_stack_init(void (*model_init)(void))
{ 
    ke_task_delete(TASK_MESH);  
    ke_task_create(TASK_MESH, &TASK_DESC_MESH_M);          
    mesh_stack_init(model_init);    
}

int mesh_task_post_init_evt_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    LOG_PRINTF("mesh_task_post_init_evt_handler\r\n");
    const mesh_evt_t enabled =
    {
        .type = MESH_EVT_ENABLED,
    };
    event_handle(&enabled);    
    return (KE_MSG_CONSUMED);
}
/**
 * @brief  Mesh stack enables.
 */
void hp_mesh_stack_enable(void)
{
    ke_msg_send_basic(MESH_TASK_POST_INIT_EVT, TASK_MESH, TASK_NONE);
}





struct mblock_free
{
    uint16_t corrupt_check;
    uint16_t free_size;
    struct mblock_free* next;
    struct mblock_free* previous;
};
uint32_t check_ke_mem_used_size(void)
{
    uint16_t heap_used[KE_MEM_BLOCK_MAX];
    uint32_t max_heap_used = 0;    
    uint8_t cursor = 0;
    struct mblock_free *node = NULL;
    GLOBAL_INT_DISABLE();
    while((cursor < KE_MEM_BLOCK_MAX))
    {   
        uint8_t heap_id = CO_MOD((cursor), KE_MEM_BLOCK_MAX);
        uint32_t totalfreesize = 0;
        node = ke_env.heap[heap_id];
        while (node != NULL)
        {
            totalfreesize += node->free_size;
            node = node->next;
        }     
        heap_used[heap_id] = ke_env.heap_size[heap_id] - totalfreesize;
        cursor ++;
    }
    uint32_t totalusedsize = 0;
    for(cursor = 0 ; cursor < KE_MEM_BLOCK_MAX ; cursor ++)
    {
        totalusedsize +=  heap_used[cursor];
    }

    if(max_heap_used < totalusedsize)
    {
        max_heap_used = totalusedsize;
    }
    GLOBAL_INT_RESTORE();
    
    return max_heap_used;
    
    
}












