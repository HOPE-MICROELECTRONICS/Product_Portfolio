
#ifndef APP_LIGHT_LIGHTNESS_H__
#define APP_LIGHT_LIGHTNESS_H__

#include <stdint.h>

#include "light_lightness_setup_server.h"
#include "app_transition.h"





#define APP_LIGHT_LIGHTNESS_SETUP_SERVER_DEF(_name, _force_segmented, _mic_size, _set_cb, _get_cb, _transition_cb) \
    static app_light_lightness_setup_server_t _name =                   \
    {                                                                   \
        .light_lightness_setup_server.settings.force_segmented = _force_segmented, \
        .light_lightness_setup_server.settings.transmic_size = _mic_size, \
        .app_add_notify.app_add_publish_cb = NULL,                      \
        .app_add_notify.app_notify_set_cb = NULL,                       \
        .app_light_lightness_set_cb = _set_cb,                          \
        .app_light_lightness_get_cb = _get_cb,                          \
        .app_light_lightness_transition_cb = _transition_cb             \
    };

typedef struct
{
    uint16_t present_lightness;
    uint16_t target_lightness;
    uint16_t initial_present_lightness;
    uint16_t init_present_snapshot;
    uint16_t target_snapshot;
    bool new_tid;
    uint32_t published_ms;
    app_transition_t transition;
} app_light_lightness_state_t;


typedef struct __app_light_lightness_setup_server_t app_light_lightness_setup_server_t;

typedef void (*app_light_lightness_set_cb_t)(const app_light_lightness_setup_server_t * p_app,
                                             uint16_t lightness);

typedef void (*app_light_lightness_get_cb_t)(const app_light_lightness_setup_server_t * p_app,
                                             uint16_t * p_present_lightness);

typedef void (*app_light_lightness_transition_cb_t)(const app_light_lightness_setup_server_t * p_app,
                                                         uint32_t transition_time_ms, uint16_t target_lightness);

typedef void (*app_additional_publish_cb_t)(const void * p_app_v,
                                            light_lightness_status_params_t * p_pub_data);

typedef void (*app_notify_set_cb_t)(const void * p_app_v, uint16_t lightness);

typedef struct
{
    app_additional_publish_cb_t app_add_publish_cb;
    void * p_app_publish_v;
    app_notify_set_cb_t app_notify_set_cb;
    void * p_app_notify_v;
} app_additional_light_lightness_notify_t;

struct __app_light_lightness_setup_server_t
{
    light_lightness_setup_server_t light_lightness_setup_server;
    app_light_lightness_set_cb_t app_light_lightness_set_cb;
    app_light_lightness_get_cb_t app_light_lightness_get_cb;
    app_light_lightness_transition_cb_t app_light_lightness_transition_cb;
    app_additional_light_lightness_notify_t app_add_notify;
    app_light_lightness_state_t state;
    bool abort_move;
    list_node_t node;
};

uint32_t app_light_lightness_model_init(app_light_lightness_setup_server_t * p_app, uint8_t element_index);

uint32_t app_light_lightness_binding_setup(app_light_lightness_setup_server_t * p_app);

uint32_t app_light_lightness_current_value_publish(app_light_lightness_setup_server_t * p_app);

uint32_t app_light_lightness_direct_actual_set(app_light_lightness_setup_server_t * p_app, uint16_t lightness_value);

#if (SCENE_SETUP_SERVER_INSTANCES_MAX > 0) || (DOXYGEN)

uint32_t app_light_lightness_scene_context_set(app_light_lightness_setup_server_t * p_app, 
                                               app_scene_setup_server_t  * p_app_scene);
#endif
 
#endif /* APP_LIGHT_LIGHTNESS_H__*/
