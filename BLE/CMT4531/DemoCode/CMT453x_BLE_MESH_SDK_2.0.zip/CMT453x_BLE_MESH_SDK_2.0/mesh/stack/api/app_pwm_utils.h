#ifndef __APP_PWM_UTILS_H__
#define __APP_PWM_UTILS_H__


#include <stdint.h>
#include <string.h>
#include "app_pwm.h"





void pwm_utils_enable(pwm_utils_contex_t * p_ctx);
void pwm_utils_level_set(pwm_utils_contex_t * p_ctx, int16_t level);
int16_t pwm_utils_level_get(pwm_utils_contex_t * p_ctx);
uint32_t pwm_utils_level_set_unsigned(pwm_utils_contex_t * p_ctx, uint16_t level);
uint16_t pwm_utils_level_get_unsigned(pwm_utils_contex_t * p_ctx);





















#endif //__APP_PWM_UTILS_H__
