
#ifndef APP_TRANSITION_H__
#define APP_TRANSITION_H__

#include <stdint.h>

#include "model_timer.h"
#include "fsm.h"
#include "timer_scheduler.h"






typedef enum
{
    APP_TRANSITION_TYPE_SET,
    APP_TRANSITION_TYPE_DELTA_SET,
    APP_TRANSITION_TYPE_MOVE_SET,
    APP_TRANSITION_TYPE_NONE
} app_transition_type_t;
 
typedef struct
{
    uint32_t transition_time_ms;
    int32_t required_delta;
    uint32_t minimum_step_ms;
    app_transition_type_t transition_type;
} app_transition_params_t;


typedef struct __app_transition_t app_transition_t;

typedef void (*app_transition_delay_start_cb_t)(const app_transition_t * p_transition);

typedef void (*app_transition_transition_start_cb_t)(const app_transition_t * p_transition);

typedef void (*app_transition_transition_tick_cb_t)(const app_transition_t * p_transition);

typedef void (*app_transition_transition_complete_cb_t)(const app_transition_t * p_transition);

struct __app_transition_t
{
    app_transition_delay_start_cb_t delay_start_cb;
    app_transition_transition_start_cb_t transition_start_cb;
    app_transition_transition_tick_cb_t transition_tick_cb;
    app_transition_transition_complete_cb_t transition_complete_cb;
    app_transition_params_t requested_params;
    app_transition_params_t ongoing_params;

    uint32_t delay_ms;

    model_timer_t timer;
    timer_event_t delay_timer;
    void * p_context;
    fsm_t fsm;
};








uint32_t app_transition_remaining_time_get(app_transition_t * p_transition);

uint32_t app_transition_elapsed_time_get(app_transition_t * p_transition);

bool app_transition_time_complete_check(app_transition_t * p_transition);

void app_transition_trigger(app_transition_t * p_transition);

void app_transition_abort(app_transition_t *p_transition);

uint32_t app_transition_init(app_transition_t * p_transition);

static inline app_transition_params_t * app_transition_requested_get(app_transition_t * p_transition)
{
    return &p_transition->requested_params;
}

static inline app_transition_params_t * app_transition_ongoing_get(app_transition_t * p_transition)
{
    return &p_transition->ongoing_params;
}
 
#endif /* APP_TRANSITION_H__ */
