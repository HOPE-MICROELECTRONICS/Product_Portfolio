#ifndef __APP_LIGHT_CTL_HSL_H__
#define __APP_LIGHT_CTL_HSL_H__




#include <stdint.h>

#include "light_ctl_hsl_setup_server.h"
#include "app_transition.h"



#define APP_LIGHT_CTL_HSL_SETUP_SERVER_DEF(_name, _force_segmented, _mic_size, ll_set_cb, ll_get_cb, ll_transition_cb, hsl_set_cb, hsl_get_cb, hsl_transition_cb, ctl_set_cb, ctl_get_cb, ctl_transition_cb) \
    static app_light_ctl_hsl_setup_server_t _name =                   \
    {                                                                   \
        .light_ctl_hsl_server.generic_onoff_srv.settings.force_segmented = _force_segmented, \
        .light_ctl_hsl_server.light_lightness_srv.settings.force_segmented = _force_segmented, \
        .light_ctl_hsl_server.hsl_srv.settings.force_segmented = _force_segmented, \
        .light_ctl_hsl_server.ctl_srv.settings.force_segmented = _force_segmented, \
        .light_ctl_hsl_server.generic_onoff_srv.settings.transmic_size = _mic_size, \
        .light_ctl_hsl_server.light_lightness_srv.settings.transmic_size = _mic_size, \
        .light_ctl_hsl_server.hsl_srv.settings.transmic_size = _mic_size, \
        .light_ctl_hsl_server.ctl_srv.settings.transmic_size = _mic_size, \
        .app_light_lightness_set_cb = ll_set_cb,                          \
        .app_light_lightness_get_cb = ll_get_cb,                          \
        .app_light_lightness_transition_cb = ll_transition_cb,             \
        .app_light_hsl_set_cb = hsl_set_cb,                            \
        .app_light_hsl_get_cb = hsl_get_cb,                            \
        .app_light_hsl_transition_cb = hsl_transition_cb,              \
        .app_light_ctl_set_cb = ctl_set_cb,                            \
        .app_light_ctl_get_cb = ctl_get_cb,                            \
        .app_light_ctl_transition_cb = ctl_transition_cb              \
    };


typedef struct __app_light_ctl_hsl_setup_server_t app_light_ctl_hsl_setup_server_t;

    
    
typedef struct
{
    uint16_t hue;
    uint16_t saturation;
} app_light_hsl_hw_state_t;    
    
typedef struct
{
    uint32_t temperature32;
    uint16_t delta_uv;
} app_light_ctl_temperature_duv_hw_state_t;


typedef struct
{
    uint16_t present_lightness;
    uint16_t target_lightness;
    uint16_t initial_present_lightness;
    uint16_t init_present_snapshot;
    uint16_t target_snapshot;
    bool new_tid;
    uint32_t published_ms;
    app_transition_t transition;
} app_light_lightness_state_t;



typedef void (*app_light_lightness_set_cb_t)(const app_light_ctl_hsl_setup_server_t * p_app,  uint16_t lightness);
typedef void (*app_light_lightness_get_cb_t)(const app_light_ctl_hsl_setup_server_t * p_app, uint16_t * p_present_lightness);
typedef void (*app_light_lightness_transition_cb_t)(const app_light_ctl_hsl_setup_server_t * p_app, uint32_t transition_time_ms, uint16_t target_lightness);    
typedef void (*app_light_hsl_set_cb_t)(const app_light_ctl_hsl_setup_server_t * p_app, app_light_hsl_hw_state_t * p_hsl_state);
typedef void (*app_light_hsl_get_cb_t)(const app_light_ctl_hsl_setup_server_t * p_app, app_light_hsl_hw_state_t * p_present_hsl_state);
typedef void (*app_light_hsl_transition_cb_t)(const app_light_ctl_hsl_setup_server_t * p_app, uint32_t transition_time_ms, app_light_hsl_hw_state_t target_hsl_state);
typedef void (*app_light_ctl_set_cb_t)(const app_light_ctl_hsl_setup_server_t * p_app, app_light_ctl_temperature_duv_hw_state_t * p_ctl_state);
typedef void (*app_light_ctl_get_cb_t)(const app_light_ctl_hsl_setup_server_t * p_app, app_light_ctl_temperature_duv_hw_state_t * p_present_ctl_state);
typedef void (*app_light_ctl_transition_cb_t)(const app_light_ctl_hsl_setup_server_t * p_app, uint32_t transition_time_ms, app_light_ctl_temperature_duv_hw_state_t target_ctl_state);
    
    

struct __app_light_ctl_hsl_setup_server_t
{
    light_ctl_hsl_server_t                  light_ctl_hsl_server;
    app_light_lightness_set_cb_t            app_light_lightness_set_cb;
    app_light_lightness_get_cb_t            app_light_lightness_get_cb;
    app_light_lightness_transition_cb_t     app_light_lightness_transition_cb;    
    app_light_hsl_set_cb_t                  app_light_hsl_set_cb;
    app_light_hsl_get_cb_t                  app_light_hsl_get_cb;
    app_light_hsl_transition_cb_t           app_light_hsl_transition_cb;    
    app_light_ctl_set_cb_t                  app_light_ctl_set_cb;
    app_light_ctl_get_cb_t                  app_light_ctl_get_cb;
    app_light_ctl_transition_cb_t           app_light_ctl_transition_cb;    
    app_light_lightness_state_t             ll_state;
    bool ll_abort_move;
    list_node_t node;
};





uint32_t app_light_ctl_hsl_model_init(app_light_ctl_hsl_setup_server_t * p_app, uint8_t element);
uint32_t app_light_ctl_hsl_binding_setup(app_light_ctl_hsl_setup_server_t * p_app);





#endif //__APP_LIGHT_CTL_HSL_H__
