#ifndef __APP_LIGHT_HSL_H__
#define __APP_LIGHT_HSL_H__


#include "light_hsl_setup_server.h"
#include <stdbool.h>
#include <stdint.h>
#include "app_transition.h"
#include "app_light_lightness.h"
#include "light_lightness_setup_server.h"

typedef struct
{
    uint16_t hue;
    uint16_t saturation;
} app_light_hsl_hw_state_t;


#define APP_LIGHT_HSL_SETUP_SERVER_DEF(_name, _force_segmented, _mic_size, _light_hsl_set_cb, _light_hsl_get_cb, _light_hsl_transition_cb) \
    static app_light_hsl_setup_server_t _name =                               \
    {                                                                         \
        .light_hsl_setup_server.settings.force_segmented = _force_segmented,     \
        .light_hsl_setup_server.settings.transmic_size = _mic_size,              \
        .app_light_hsl_set_cb = _light_hsl_set_cb,                            \
        .app_light_hsl_get_cb = _light_hsl_get_cb,                            \
        .app_light_hsl_transition_cb = _light_hsl_transition_cb,              \
    };



typedef struct
{
    uint16_t present_hue;
    uint16_t present_saturation;
    uint16_t target_hue;
    uint16_t target_saturation;
    uint16_t initial_present_hue;
    uint16_t initial_present_saturation;
    uint16_t init_present_hue_snapshot;
    uint16_t target_hue_snapshot;
    uint16_t init_present_saturation_snapshot;
    uint16_t target_saturation_snapshot;
    bool new_tid;
    uint32_t published_ms;
    app_transition_t transition;
} app_light_hsl_state_t;

typedef struct __app_light_hsl_setup_server_t app_light_hsl_setup_server_t;
typedef void (*app_light_hsl_set_cb_t)(const app_light_hsl_setup_server_t * p_app, app_light_hsl_hw_state_t * p_hsl_state);
typedef void (*app_light_hsl_get_cb_t)(const app_light_hsl_setup_server_t * p_app, app_light_hsl_hw_state_t * p_present_hsl_state);
typedef void (*app_light_hsl_transition_cb_t)(const app_light_hsl_setup_server_t * p_app, uint32_t transition_time_ms, app_light_hsl_hw_state_t target_hsl_state);



struct __app_light_hsl_setup_server_t
{
    light_hsl_setup_server_t                light_hsl_setup_server;
    app_light_lightness_setup_server_t *    p_app_ll;
    app_light_hsl_set_cb_t                  app_light_hsl_set_cb;
    app_light_hsl_get_cb_t                  app_light_hsl_get_cb;
    app_light_hsl_transition_cb_t           app_light_hsl_transition_cb;
    app_light_hsl_state_t                   state;
    bool                                    hsl_state_set_active;
    bool                                    hsl_hue_state_set_active;
    bool                                    hsl_saturation_state_set_active;
    bool                                    abort_move;
    list_node_t                             node;
};






uint32_t app_light_hsl_model_init(app_light_hsl_setup_server_t * p_app, uint8_t element_index, app_light_lightness_setup_server_t * p_app_ll);
uint32_t app_light_hsl_binding_setup(app_light_hsl_setup_server_t * p_app);








#endif //__APP_LIGHT_HSL_H__

