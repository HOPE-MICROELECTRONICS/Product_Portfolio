#ifndef APP_PWM_H__
#define APP_PWM_H__

#include <stdint.h>
#include "cmt453x_tim.h"


#define PWM_CHANNEL_0	0
#define PWM_CHANNEL_1	1
#define PWM_CHANNEL_2	2
#define PWM_CHANNEL_3	3
#define PWM_CHANNEL_0N	4
#define PWM_CHANNEL_1N	5
#define PWM_CHANNEL_2N	6
#define PWM_CHANNEL_3N	7


//timer3 channel1 AF2 PB4
#define LED_PWM_1_PORT		GPIOB
#define LED_PWM_1_GPIO_PIN		GPIO_PIN_4

//timer3 channel2 AF2 PB5
#define LED_PWM_2_PORT		GPIOB
#define LED_PWM_2_GPIO_PIN		GPIO_PIN_5

//timer3 channel3 AF2 PB6
#define LED_PWM_3_PORT		GPIOB
#define LED_PWM_3_GPIO_PIN		GPIO_PIN_6

//timer3 channel4 AF2 PB7
#define LED_PWM_4_PORT		GPIOB
#define LED_PWM_4_GPIO_PIN		GPIO_PIN_7

//timer1 channel1 AF1 PB8
#define LED_PWM_5_PORT		GPIOB
#define LED_PWM_5_GPIO_PIN		GPIO_PIN_8

//timer1 channel3 AF1 PB10
#define LED_PWM_6_PORT		GPIOB
#define LED_PWM_6_GPIO_PIN		GPIO_PIN_10

//timer1 channel4 AF1 PB11
#define LED_PWM_7_PORT		GPIOB
#define LED_PWM_7_GPIO_PIN		GPIO_PIN_11

//timer1 channel1N AF1 PB12
#define LED_PWM_8_PORT		GPIOB
#define LED_PWM_8_GPIO_PIN		GPIO_PIN_12

//timer1 channel2N AF1 PB13
#define LED_PWM_9_PORT		GPIOB
#define LED_PWM_9_GPIO_PIN		GPIO_PIN_13




#define APP_PWM_INSTANCE(name, timerX)                                                \
	TIM_Module *m_pwm_##name##_timer = timerX; \
    app_pwm_cb_t m_pwm_##name##_cb;                                           \
    app_pwm_t name = {                                                  \
        .p_cb    = &m_pwm_##name##_cb,                                        \
		.p_timer = timerX,														\
    }

#define APP_PWM_DEFAULT_CONFIG_1CH(port, pin)                           \
    {                                                                                  \
        .gpio_port            = port,                                                      \
        .gpio_pin             = pin,                                                      \
    }




typedef uint32_t ret_code_t;
typedef uint16_t app_pwm_duty_t;


typedef void (* app_pwm_callback_t)(uint32_t);



typedef struct
{
    GPIO_Module*       gpio_port;
    uint16_t           gpio_pin;                                                        
} app_pwm_config_t;


typedef struct
{    
    uint32_t           pulsewidth;         
} app_pwm_channel_cb_t;

typedef struct
{
    app_pwm_channel_cb_t    channels_cb[5];  
    uint32_t                period;                                       
} app_pwm_cb_t;


typedef struct
{
    app_pwm_cb_t *p_cb;    
    TIM_Module              * p_timer; 
} app_pwm_t;


typedef struct
{
    app_pwm_t * p_pwm;
    app_pwm_config_t * p_pwm_config;
    uint8_t channel;
    uint16_t pwm_ticks_max;
} pwm_utils_contex_t;

ret_code_t app_pwm_init(pwm_utils_contex_t * p_ctx);
void app_pwm_enable(app_pwm_t * p_instance);
ret_code_t app_pwm_channel_duty_set(app_pwm_t * p_instance, uint8_t channel, app_pwm_duty_t duty);
app_pwm_duty_t app_pwm_channel_duty_get(app_pwm_t * p_instance, uint8_t channel);
ret_code_t app_pwm_channel_duty_ticks_set(app_pwm_t * p_instance, uint8_t channel, uint16_t ticks);
uint16_t app_pwm_channel_duty_ticks_get(app_pwm_t * p_instance, uint8_t channel);
uint16_t app_pwm_cycle_ticks_get(app_pwm_t * p_instance);


#endif //APP_PWM_H__
