#ifndef __APP_LIGHT_CTL_H__
#define __APP_LIGHT_CTL_H__

#include <stdint.h>
#include "light_ctl_setup_server.h"
#include "light_lightness_setup_server.h"
#include "app_transition.h"
#include "app_light_lightness.h"
#include "mesh_list.h"




typedef struct
{
    uint32_t temperature32;
    uint16_t delta_uv;
} app_light_ctl_temperature_duv_hw_state_t;

#define APP_LIGHT_CTL_SETUP_SERVER_DEF(_name, _force_segmented, _mic_size, _light_ctl_set_cb, _light_ctl_get_cb, _light_ctl_transition_cb) \
    static app_light_ctl_setup_server_t _name =                               \
    {                                                                         \
        .light_ctl_setup_srv.settings.force_segmented = _force_segmented,     \
        .light_ctl_setup_srv.settings.transmic_size = _mic_size,              \
        .app_light_ctl_set_cb = _light_ctl_set_cb,                            \
        .app_light_ctl_get_cb = _light_ctl_get_cb,                            \
        .app_light_ctl_transition_cb = _light_ctl_transition_cb,              \
    };

typedef struct
{
    uint32_t present_temperature32;
    int16_t present_delta_uv;
    uint32_t target_temperature32;
    int16_t target_delta_uv;
    uint32_t initial_present_temperature32;
    int16_t initial_present_delta_uv;
    uint32_t init_present_temp32_snapshot;
    uint32_t target_temp32_snapshot;
    int16_t init_present_duv_snapshot;
    int16_t target_duv_snapshot;
    bool new_tid;
    uint32_t published_ms;
    app_transition_t transition;
} app_light_ctl_state_t;

typedef struct __app_light_ctl_setup_server_t app_light_ctl_setup_server_t;
typedef void (*app_light_ctl_set_cb_t)(const app_light_ctl_setup_server_t * p_app, app_light_ctl_temperature_duv_hw_state_t * p_ctl_state);
typedef void (*app_light_ctl_get_cb_t)(const app_light_ctl_setup_server_t * p_app, app_light_ctl_temperature_duv_hw_state_t * p_present_ctl_state);
typedef void (*app_light_ctl_transition_cb_t)(const app_light_ctl_setup_server_t * p_app, uint32_t transition_time_ms, app_light_ctl_temperature_duv_hw_state_t target_ctl_state);

struct __app_light_ctl_setup_server_t
{
    light_ctl_setup_server_t light_ctl_setup_srv;
    app_light_lightness_setup_server_t * p_app_ll;
    app_light_ctl_set_cb_t app_light_ctl_set_cb;
    app_light_ctl_get_cb_t app_light_ctl_get_cb;
    app_light_ctl_transition_cb_t app_light_ctl_transition_cb;
    app_light_ctl_state_t state;
    bool ctl_state_set_active;
    bool ctl_temperature_state_set_active;
    bool abort_move;
    list_node_t node;
};

uint32_t app_light_ctl_model_init(app_light_ctl_setup_server_t * p_app, uint8_t element_index, app_light_lightness_setup_server_t * p_app_ll);
uint32_t app_light_ctl_binding_setup(app_light_ctl_setup_server_t * p_app);
uint32_t app_light_ctl_current_value_publish(app_light_ctl_setup_server_t * p_app);







#endif //__APP_LIGHT_CTL_H__
