#ifndef __APP_LEVEL_H__
#define __APP_LEVEL_H__



#include <stdint.h>
#include "generic_level_server.h"
#include "app_transition.h"



#define APP_LEVEL_SERVER_DEF(_name, _force_segmented, _mic_size, _p_dtt, _set_cb, _get_cb, _transition_cb)  \
    static app_level_server_t _name =  \
    {  \
        .server.settings.force_segmented = _force_segmented,  \
        .server.settings.transmic_size = _mic_size,  \
        .p_dtt_ms = _p_dtt, \
        .level_set_cb = _set_cb,  \
        .level_get_cb = _get_cb,  \
        .level_transition_cb = _transition_cb  \
    };


typedef struct
{
    /** For storing actual required amount of level change. */
    int32_t required_delta;
    /** Initial present level required for handling Set/Delta Set message. */
    int16_t initial_present_level;
} set_transition_t;



typedef struct
{
    /** Scaled representation of the Level value. */
    int16_t required_move;
    /** Initial present level required for handling Set/Delta Set message. */
    int16_t initial_present_level;
} move_transition_t;

/** Internal structure to hold state and timing information. */
typedef struct
{
    /** Present value of the Level state */
    int16_t present_level;
    /** Target value of the Level state, as received from the model interface. */
    int16_t target_level;

    /** For storing actual required amount of level change. */
    int32_t delta;
    /** Initial present level required for handling Set/Delta Set message. */
    int16_t initial_present_level;

    /** Present value when message was received */
    int16_t init_present_snapshot;
    /** Requested target */
    int16_t target_snapshot;

    /** Structure for using transition module functionality */
    app_transition_t transition;
} app_level_state_t;

typedef struct __app_level_server_t app_level_server_t;

typedef void (*app_level_set_cb_t)(const app_level_server_t * p_app, int16_t present_level);
typedef void (*app_level_get_cb_t)(const app_level_server_t * p_app, int16_t * p_present_level);

typedef void (*app_level_transition_cb_t)(const app_level_server_t * p_app,
                                               uint32_t transition_time_ms,
                                               uint16_t target_level,
                                               app_transition_type_t transition_type);

struct __app_level_server_t
{
    /** Level server model interface context structure */
    generic_level_server_t server;
    /** Callaback to be called for informing the user application to update the value*/
    app_level_set_cb_t  level_set_cb;
    /** Callback to be called for requesting current value from the user application */
    app_level_get_cb_t level_get_cb;
    /** Callaback to be called for informing the user application to update the value*/
    app_level_transition_cb_t  level_transition_cb;

    /** Pointer to the default transition time value (in milliseconds) if present */
    const uint32_t * p_dtt_ms;
    /** Internal variable. Representation of the Level state related data and transition parameters
     *  required for behavioral implementation, and for communicating with the application. */
    app_level_state_t state;

};

uint32_t app_level_current_value_publish(app_level_server_t * p_app);
uint32_t app_level_init(app_level_server_t * p_app, uint8_t element_index);
uint32_t app_level_value_restore(app_level_server_t * p_app);






#endif //__APP_LEVEL_H__
