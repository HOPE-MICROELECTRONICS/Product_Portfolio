#include "app_light_hsl.h"
#include "mesh_error.h"
#include "mesh_app_task.h"
#include "light_hsl_mc.h"
#include "light_lightness_mc.h"
#include "light_hsl_utils.h"
#include "bsp_lpuart.h"


#define HSL_ADDITIONAL_PUBLISH_START_MARGIN_MS      (1500)
#define HSL_ADDITIONAL_PUBLISH_INTERVAL_MS          (1000)

#define APP_HSL_TRANSITION_SET APP_TRANSITION_TYPE_SET
#define APP_HSL_TRANSITION_DELTA_SET APP_TRANSITION_TYPE_DELTA_SET
#define APP_HSL_TRANSITION_MOVE_SET APP_TRANSITION_TYPE_MOVE_SET





#define CHECK_INVALID_HUE_RANGE(__range)                        \
    if ((__range.hue_range_min == LIGHT_HSL_UNKNOWN) || \
        (__range.hue_range_max == LIGHT_HSL_UNKNOWN)) \
    {                                                                   \
        LOG_PRINTF("Unknown hue in HSL range\n"); \
    }

#define CHECK_INVALID_SATURATION_RANGE(__range)                        \
    if ((__range.saturation_range_min == LIGHT_HSL_UNKNOWN) || \
        (__range.saturation_range_max == LIGHT_HSL_UNKNOWN)) \
    {                                                                   \
        LOG_PRINTF("Unknown saturation in HSL range\n"); \
    }


static list_node_t * mp_app_light_hsl_head;
static bearer_event_flag_t m_transition_abort_flag;


static void transition_parameters_set(app_light_hsl_setup_server_t * p_app,
                                      uint32_t delta,
                                      const model_transition_t * p_in_transition,
                                      app_transition_type_t transition_type);

static void hsl_state_set_cb(const light_hsl_setup_server_t * p_self,
                             const access_message_rx_meta_t * p_meta,
                             const light_hsl_set_params_t * p_in,
                             const model_transition_t * p_in_transition,
                             light_hsl_status_params_t * p_out);

static void hsl_state_get_cb(const light_hsl_setup_server_t * p_self,
                             const access_message_rx_meta_t * p_meta,
                             light_hsl_status_params_t * p_out);

static void light_hsl_state_hue_set_cb(const light_hsl_setup_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       const light_hsl_hue_set_params_t * p_in,
                                       const model_transition_t * p_in_transition,
                                       light_hsl_hue_status_params_t * p_out);
static void light_hsl_state_hue_get_cb(const light_hsl_setup_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       light_hsl_hue_status_params_t * p_out);
                                       
static void light_hsl_state_saturation_set_cb(const light_hsl_setup_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       const light_hsl_saturation_set_params_t * p_in,
                                       const model_transition_t * p_in_transition,
                                       light_hsl_saturation_status_params_t * p_out);
static void light_hsl_state_saturation_get_cb(const light_hsl_setup_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       light_hsl_saturation_status_params_t * p_out);                                       
                                       

static void light_hsl_state_hue_range_get_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             light_hsl_hue_range_status_params_t * p_out);

static void light_hsl_state_saturation_range_get_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             light_hsl_saturation_range_status_params_t * p_out);
static void light_hsl_state_range_set_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             const light_hsl_range_set_params_t * p_in,
                                                             light_hsl_range_status_params_t * p_out);
static void light_hsl_state_range_get_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             light_hsl_range_status_params_t * p_out);  
static void light_hsl_state_default_set_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             const light_hsl_default_set_params_t * p_in,
                                                             light_hsl_default_status_params_t * p_out);
static void light_hsl_state_default_get_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             light_hsl_default_status_params_t * p_out); 
                                                             
                                                             
static void light_move_set_hue_cb(const light_hsl_setup_server_t * p_self,
                                  const access_message_rx_meta_t * p_meta,
                                  const light_hsl_hue_move_set_params_t * p_in,
                                  const model_transition_t * p_in_transition,
                                  light_hsl_hue_status_params_t * p_out);

static void light_delta_set_hue_cb(const light_hsl_setup_server_t * p_self,
                                   const access_message_rx_meta_t * p_meta,
                                   const light_hsl_hue_delta_set_params_t * p_in,
                                   const model_transition_t * p_in_transition,
                                   light_hsl_hue_status_params_t * p_out);       


static void light_move_set_saturation_cb(const light_hsl_setup_server_t * p_self,
                                  const access_message_rx_meta_t * p_meta,
                                  const light_hsl_saturation_move_set_params_t * p_in,
                                  const model_transition_t * p_in_transition,
                                  light_hsl_saturation_status_params_t * p_out);

static void light_delta_set_saturation_cb(const light_hsl_setup_server_t * p_self,
                                   const access_message_rx_meta_t * p_meta,
                                   const light_hsl_saturation_delta_set_params_t * p_in,
                                   const model_transition_t * p_in_transition,
                                   light_hsl_saturation_status_params_t * p_out);  
                                   

static void light_hsl_state_target_get_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             light_hsl_target_status_params_t * p_out); 

                                                             
static const light_hsl_setup_server_callbacks_t hsl_setup_srv_cbs =
{
    .light_hsl_cbs.set_cb = hsl_state_set_cb,
    .light_hsl_cbs.get_cb = hsl_state_get_cb,

    
    .light_hsl_cbs.set_hue_cb = light_hsl_state_hue_set_cb,
    .light_hsl_cbs.get_hue_cb = light_hsl_state_hue_get_cb,
    
    .light_hsl_cbs.set_saturation_cb = light_hsl_state_saturation_set_cb,
    .light_hsl_cbs.get_saturation_cb = light_hsl_state_saturation_get_cb,    
    
    .light_hsl_cbs.hue_range_get_cb = light_hsl_state_hue_range_get_cb,   

    .light_hsl_cbs.saturation_range_get_cb = light_hsl_state_saturation_range_get_cb,   

    .light_hsl_cbs.range_set_cb = light_hsl_state_range_set_cb,
    .light_hsl_cbs.range_get_cb = light_hsl_state_range_get_cb,  
    
    .light_hsl_cbs.default_set_cb = light_hsl_state_default_set_cb,
    .light_hsl_cbs.default_get_cb = light_hsl_state_default_get_cb,     
    
    .light_hsl_cbs.move_set_hue_cb         = light_move_set_hue_cb,
    .light_hsl_cbs.delta_set_hue_cb        = light_delta_set_hue_cb,
    
    .light_hsl_cbs.move_set_saturation_cb  = light_move_set_saturation_cb,
    .light_hsl_cbs.delta_set_saturation_cb = light_delta_set_saturation_cb,   


    .light_hsl_cbs.target_get_cb = light_hsl_state_target_get_cb, 

 
};


static uint32_t hsl_state_delta_max_compute(app_light_hsl_setup_server_t * p_app,
                                           uint32_t initial_present_hue,
                                           uint32_t target_hue,
                                           uint32_t initial_present_saturation,
                                           uint32_t target_saturation)
{
    uint32_t temp_delta;
    uint32_t duv_delta;
    temp_delta = target_hue - initial_present_hue;;
    duv_delta = target_saturation - initial_present_saturation;
    return temp_delta > duv_delta ? temp_delta : duv_delta;
}


static uint32_t app_hsl_setup_server_init(app_light_hsl_setup_server_t * p_app, uint8_t element_index)
{
     
    uint32_t status = MESH_ERROR_INTERNAL;
    light_hsl_setup_server_t * p_s_server;
    p_s_server = &p_app->light_hsl_setup_server;
    p_s_server->settings.p_callbacks = &hsl_setup_srv_cbs;
    status = light_hsl_mc_open(&p_s_server->state.handle);
    if (status != MESH_SUCCESS)
    {
        return status;
    }
    p_s_server->state.initialized = false;
    return light_hsl_setup_server_init(p_s_server, &p_app->p_app_ll->light_lightness_setup_server, element_index);
}



static void hsl_state_set_cb(const light_hsl_setup_server_t * p_self,
                             const access_message_rx_meta_t * p_meta,
                             const light_hsl_set_params_t * p_in,
                             const model_transition_t * p_in_transition,
                             light_hsl_status_params_t * p_out)
{
     
    DEBUG_PRINTF("%s\r\n",__FUNCTION__);
    app_light_hsl_setup_server_t * p_app;
    app_light_hsl_hw_state_t present_hsl_state;
    uint32_t transition_time_ms;
    light_lightness_set_params_t ll_in;
    light_lightness_status_params_t ll_out;
    light_lightness_setup_server_state_cbs_t * p_ll_srv_cbs;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_app->hsl_state_set_active = true;
    ll_in.lightness = p_in->lightness;
    ll_in.tid = p_in->tid;
    p_ll_srv_cbs = (light_lightness_setup_server_state_cbs_t *)&(p_app->p_app_ll->light_lightness_setup_server.settings.p_callbacks->light_lightness_cbs);
    p_ll_srv_cbs->set_cb(&p_app->p_app_ll->light_lightness_setup_server, p_meta, &ll_in, p_in_transition, &ll_out);
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    p_app->state.target_hue_snapshot = p_in->hue;
    p_app->state.target_saturation_snapshot = p_in->saturation;
    p_app->state.init_present_hue_snapshot = p_app->state.present_hue;
    p_app->state.init_present_saturation_snapshot = p_app->state.present_saturation;
    
    light_hsl_mc_hue_state_set(p_self->state.handle, p_app->state.target_hue_snapshot);
    light_hsl_mc_saturation_state_set(p_self->state.handle, p_app->state.target_saturation_snapshot);
    
    
    
    DEBUG_PRINTF("initialized : %d\r\n",p_self->state.initialized);
    DEBUG_PRINTF("transition_time_ms : %d\r\n",p_in_transition->transition_time_ms);
    DEBUG_PRINTF("delay_ms : %d\r\n",p_in_transition->delay_ms);    
    DEBUG_PRINTF("present_hsl_state.hue : %d\r\n",present_hsl_state.hue);
    DEBUG_PRINTF("present_hsl_state.saturation : %d\r\n",present_hsl_state.saturation);
    DEBUG_PRINTF("p_in->hue : %d\r\n",p_in->hue);
    DEBUG_PRINTF("p_in->saturation : %d\r\n",p_in->saturation);

    
    if (!p_self->state.initialized || (present_hsl_state.hue != p_in->hue) ||
        (present_hsl_state.saturation != p_in->saturation))
    {
        uint32_t delta = hsl_state_delta_max_compute(p_app, present_hsl_state.hue,
                                                    p_app->state.target_hue_snapshot,
                                                    present_hsl_state.saturation,
                                                    p_app->state.target_saturation_snapshot);
        transition_parameters_set(p_app, delta, p_in_transition, APP_HSL_TRANSITION_SET);
        transition_time_ms = p_params->transition_time_ms;
        
        app_transition_trigger(&p_app->state.transition);
    }
    else
    {
        transition_time_ms = 0;
    }
    if (p_out != NULL)
    {
        p_out->present_lightness = ll_out.present_lightness;
        p_out->present_hue = p_app->state.present_hue;
        p_out->present_saturation = p_app->state.present_saturation;
        p_out->remaining_time_ms = transition_time_ms;
    }    
    
    
    
    
    
}


static void hsl_state_get_cb(const light_hsl_setup_server_t * p_self,
                             const access_message_rx_meta_t * p_meta,
                             light_hsl_status_params_t * p_out)
{
     
    app_light_hsl_setup_server_t * p_app;
    app_light_hsl_hw_state_t present_hsl_state;
    uint16_t lightness;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    p_app->p_app_ll->app_light_lightness_get_cb(p_app->p_app_ll, &lightness);
    p_out->present_lightness = lightness;
    p_out->present_hue = present_hsl_state.hue;
    p_out->present_saturation = present_hsl_state.saturation;
    if (p_params->transition_type == APP_HSL_TRANSITION_MOVE_SET)
    {
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0) ? 0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }
    else
    {
        p_out->remaining_time_ms = app_transition_remaining_time_get(&p_app->state.transition);
    }
}

static void light_hsl_state_hue_set_cb(const light_hsl_setup_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       const light_hsl_hue_set_params_t * p_in,
                                       const model_transition_t * p_in_transition,
                                       light_hsl_hue_status_params_t * p_out)
{
     
    app_light_hsl_setup_server_t * p_app;
    app_light_hsl_hw_state_t present_hsl_state;
    uint32_t transition_time_ms;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_app->hsl_hue_state_set_active = true;
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    p_app->state.target_hue_snapshot = p_in->hue;
    p_app->state.init_present_hue_snapshot = p_app->state.present_hue;
    light_hsl_mc_hue_state_set(p_self->state.handle, p_app->state.target_hue_snapshot);
    if (!p_self->state.initialized || (present_hsl_state.hue != p_in->hue))
    {
        uint32_t delta = hsl_state_delta_max_compute(p_app, present_hsl_state.hue,
                                                    p_app->state.target_hue_snapshot,
                                                    0,
                                                    0);
        transition_parameters_set(p_app, delta, p_in_transition, APP_HSL_TRANSITION_SET);
        transition_time_ms = p_params->transition_time_ms;
        app_transition_trigger(&p_app->state.transition);
    }
    else
    {
        transition_time_ms = 0;
    }
    if (p_out != NULL)
    {
        p_out->present_hue = p_app->state.present_hue;
        p_out->target_hue = p_app->state.target_hue_snapshot;
        p_out->remaining_time_ms = transition_time_ms;
    }
}
static void light_hsl_state_hue_get_cb(const light_hsl_setup_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       light_hsl_hue_status_params_t * p_out)
{
     
    app_light_hsl_setup_server_t * p_app;
    app_light_hsl_hw_state_t present_hsl_state;
    light_hsl_hue_range_set_params_t range_set;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    p_out->present_hue = present_hsl_state.hue;
    p_out->target_hue = present_hsl_state.hue;
    if (p_params->transition_type == APP_HSL_TRANSITION_MOVE_SET)
    {
        light_hsl_mc_hue_range_state_get(p_self->state.handle, &range_set);
        p_out->target_hue = p_app->state.target_hue == range_set.hue_range_max ? INT16_MAX : INT16_MIN;
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0 || p_params->required_delta == 0) ? 0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }
    else
    {
        p_out->target_hue = p_app->state.target_hue;
        p_out->remaining_time_ms = app_transition_remaining_time_get(&p_app->state.transition);
    }
}
static void light_hsl_state_saturation_set_cb(const light_hsl_setup_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       const light_hsl_saturation_set_params_t * p_in,
                                       const model_transition_t * p_in_transition,
                                       light_hsl_saturation_status_params_t * p_out)
{
    app_light_hsl_setup_server_t * p_app;
    app_light_hsl_hw_state_t present_hsl_state;
    uint32_t transition_time_ms;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_app->hsl_saturation_state_set_active = true;
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    p_app->state.target_saturation_snapshot = p_in->saturation;
    p_app->state.init_present_saturation_snapshot = p_app->state.present_saturation;
    light_hsl_mc_hue_state_set(p_self->state.handle, p_app->state.target_hue_snapshot);
    if (!p_self->state.initialized || (present_hsl_state.saturation != p_in->saturation))
    {
        uint32_t delta = hsl_state_delta_max_compute(p_app, 0,
                                                    0,
                                                    present_hsl_state.saturation,
                                                    p_app->state.target_saturation_snapshot);
        transition_parameters_set(p_app, delta, p_in_transition, APP_HSL_TRANSITION_SET);
        transition_time_ms = p_params->transition_time_ms;
        app_transition_trigger(&p_app->state.transition);
    }
    else
    {
        transition_time_ms = 0;
    }
    if (p_out != NULL)
    {
        p_out->present_saturation = p_app->state.present_saturation;
        p_out->target_saturation = p_app->state.target_saturation_snapshot;
        p_out->remaining_time_ms = transition_time_ms;
    }     
}                                       
static void light_hsl_state_saturation_get_cb(const light_hsl_setup_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       light_hsl_saturation_status_params_t * p_out)
{
    app_light_hsl_setup_server_t * p_app;
    app_light_hsl_hw_state_t present_hsl_state;
    light_hsl_saturation_range_set_params_t range_set;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    p_out->present_saturation = present_hsl_state.saturation;
    p_out->target_saturation = present_hsl_state.saturation;
    if (p_params->transition_type == APP_HSL_TRANSITION_MOVE_SET)
    {
        light_hsl_mc_saturation_range_state_get(p_self->state.handle, &range_set);
        p_out->target_saturation = p_app->state.target_saturation == range_set.saturation_range_max ? INT16_MAX : INT16_MIN;
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0 || p_params->required_delta == 0) ? 0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }
    else
    {
        p_out->target_saturation = p_app->state.target_saturation;
        p_out->remaining_time_ms = app_transition_remaining_time_get(&p_app->state.transition);
    }     

}                                       

static void light_hsl_state_hue_range_get_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             light_hsl_hue_range_status_params_t * p_out)
{
    light_hsl_hue_range_set_params_t range_set;
    light_hsl_mc_hue_range_state_get(p_self->state.handle, &range_set);
    p_out->status_code = LIGHT_HSL_RANGE_STATUS_GOOD;
    p_out->hue_range_min = range_set.hue_range_min;
    p_out->hue_range_max = range_set.hue_range_max;
//    CHECK_INVALID_HUE_RANGE(range_set);     

}

static void light_hsl_state_saturation_range_get_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             light_hsl_saturation_range_status_params_t * p_out)
{
     
    light_hsl_saturation_range_set_params_t range_set;
    light_hsl_mc_saturation_range_state_get(p_self->state.handle, &range_set);
    p_out->status_code = LIGHT_HSL_RANGE_STATUS_GOOD;
    p_out->saturation_range_min = range_set.saturation_range_min;
    p_out->saturation_range_max = range_set.saturation_range_max;
//    CHECK_INVALID_SATURATION_RANGE(range_set);
}
static void light_hsl_state_default_set_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             const light_hsl_default_set_params_t * p_in,
                                                             light_hsl_default_status_params_t * p_out)
{
     
    light_hsl_default_status_params_t default_status;
    app_light_hsl_setup_server_t * p_app;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    light_lightness_mc_default_state_set(p_app->p_app_ll->light_lightness_setup_server.state.handle, p_in->lightness);
    light_hsl_mc_hue_default_state_set(p_self->state.handle, p_in->hue);
    light_hsl_mc_saturation_default_state_set(p_self->state.handle, p_in->saturation);
    light_lightness_mc_default_state_get(p_app->p_app_ll->light_lightness_setup_server.state.handle, &default_status.lightness);
    light_hsl_mc_hue_default_state_get(p_self->state.handle, &default_status.hue);
    light_hsl_mc_saturation_default_state_get(p_self->state.handle, &default_status.saturation);
    (void) light_hsl_server_default_status_publish(&p_self->hsl_srv, &default_status);
    if (p_out != NULL)
    {
        *p_out = default_status;
    }    
}                                                             
static void light_hsl_state_default_get_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             light_hsl_default_status_params_t * p_out)
{
     
    app_light_hsl_setup_server_t * p_app;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    light_lightness_mc_default_state_get(p_app->p_app_ll->light_lightness_setup_server.state.handle,&p_out->lightness);
    light_hsl_mc_hue_default_state_get(p_self->state.handle, &p_out->hue);
    light_hsl_mc_saturation_default_state_get(p_self->state.handle, &p_out->saturation);
}                                                             


static void light_hsl_state_range_set_cb(const light_hsl_setup_server_t * p_self,  const access_message_rx_meta_t * p_meta, const light_hsl_range_set_params_t * p_in,  light_hsl_range_status_params_t * p_out)
{
     
    light_hsl_range_status_params_t range;
    light_hsl_range_set_params_t range_set;
    light_hsl_hue_range_set_params_t hue_range_set;
    light_hsl_mc_hue_range_state_get(p_self->state.handle, &hue_range_set);
    light_hsl_saturation_range_set_params_t saturation_range_set;
    light_hsl_mc_saturation_range_state_get(p_self->state.handle, &saturation_range_set);  
    range_set.hue_range_min = hue_range_set.hue_range_min;
    range_set.hue_range_max = hue_range_set.hue_range_max;
    saturation_range_set.saturation_range_min = saturation_range_set.saturation_range_min;
    saturation_range_set.saturation_range_max = saturation_range_set.saturation_range_max;
//    CHECK_INVALID_HUE_RANGE(hue_range_set);
//    CHECK_INVALID_SATURATION_RANGE(saturation_range_set);
    range.status_code = LIGHT_HSL_RANGE_STATUS_GOOD;
    range.hue_range_min = range_set.hue_range_min;
    range.hue_range_max = range_set.hue_range_max;
    range.saturation_range_min = range_set.saturation_range_min;
    range.saturation_range_max = range_set.saturation_range_max;    
//    if (p_in->hue_range_min < LIGHT_HSL_DEFAULT_ALLOWED_HUE_MIN)
//    {
//        range.status_code = LIGHT_HSL_RANGE_STATUS_CANNOT_SET_MIN_RANGE;
//    }

    if (p_in->hue_range_max > LIGHT_HSL_DEFAULT_ALLOWED_HUE_MAX)
    {
        range.status_code = LIGHT_HSL_RANGE_STATUS_CANNOT_SET_MAX_RANGE;
    }

    if (range.status_code == LIGHT_HSL_RANGE_STATUS_GOOD)
    {
        range.hue_range_min = p_in->hue_range_min;
        range.hue_range_max = p_in->hue_range_max;
        range.saturation_range_min = p_in->saturation_range_min;
        range.saturation_range_max = p_in->saturation_range_max;               
        light_hsl_mc_hue_range_state_set(p_self->state.handle, &hue_range_set);
        light_hsl_mc_saturation_range_state_set(p_self->state.handle, &saturation_range_set);
        (void) light_hsl_server_range_status_publish(&p_self->hsl_srv, &range);
    }

    if (p_out)
    {
        *p_out = range;
    }  
}
                                                   
static void light_hsl_state_range_get_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_hsl_range_status_params_t * p_out)
{
     
    light_hsl_hue_range_set_params_t hue_range_set;
    light_hsl_mc_hue_range_state_get(p_self->state.handle, &hue_range_set);
    light_hsl_saturation_range_set_params_t saturation_range_set;
    light_hsl_mc_saturation_range_state_get(p_self->state.handle, &saturation_range_set);    
    p_out->status_code = LIGHT_HSL_RANGE_STATUS_GOOD;
    p_out->hue_range_min = hue_range_set.hue_range_min;
    p_out->hue_range_max = hue_range_set.hue_range_max;
    p_out->saturation_range_min = saturation_range_set.saturation_range_min;
    p_out->saturation_range_max = saturation_range_set.saturation_range_max;    
//    CHECK_INVALID_HUE_RANGE(hue_range_set);    
//    CHECK_INVALID_SATURATION_RANGE(saturation_range_set);   
  
}                                                             




static void light_move_set_hue_cb(const light_hsl_setup_server_t * p_self,
                                  const access_message_rx_meta_t * p_meta,
                                  const light_hsl_hue_move_set_params_t * p_in,
                                  const model_transition_t * p_in_transition,
                                  light_hsl_hue_status_params_t * p_out)
{
     
    app_light_hsl_setup_server_t * p_app;
    light_hsl_hue_range_set_params_t range_set;
    app_light_hsl_hw_state_t present_hsl_state;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_app->hsl_hue_state_set_active = true;
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    p_app->state.present_hue = present_hsl_state.hue;
    p_app->state.present_saturation = present_hsl_state.saturation;
    light_hsl_mc_hue_range_state_get(p_self->state.handle, &range_set);
    transition_parameters_set(p_app, (int32_t)p_in->delta_hue, p_in_transition, APP_HSL_TRANSITION_MOVE_SET);
    if (p_in->delta_hue > 0 && p_app->state.transition.requested_params.transition_time_ms > 0)
    {
        p_app->state.target_hue_snapshot = range_set.hue_range_max;
    }
    else if (p_in->delta_hue < 0 && p_app->state.transition.requested_params.transition_time_ms > 0)
    {
        p_app->state.target_hue_snapshot = range_set.hue_range_min;
    }
    else
    {
        p_app->state.target_hue_snapshot = p_app->state.present_hue;
    }
    app_transition_trigger(&p_app->state.transition);
    if (p_out != NULL)
    {
        p_out->present_hue = p_app->state.present_hue;
        p_out->target_hue = p_app->state.target_saturation_snapshot == range_set.hue_range_max ? UINT32_MAX : 0;
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0 || p_in->delta_hue == 0) ? 0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }      
}

static void light_delta_set_hue_cb(const light_hsl_setup_server_t * p_self,
                                   const access_message_rx_meta_t * p_meta,
                                   const light_hsl_hue_delta_set_params_t * p_in,
                                   const model_transition_t * p_in_transition,
                                   light_hsl_hue_status_params_t * p_out)
{
     
    app_light_hsl_setup_server_t * p_app;
    app_light_hsl_hw_state_t present_hsl_state;
    int64_t delta32;
    int64_t target_hue;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_app->hsl_hue_state_set_active = true;
    p_app->state.new_tid = model_transaction_is_new(&p_app->light_hsl_setup_server.hsl_srv.tid_tracker);
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    delta32 = SCALE_UP((int64_t)p_in->delta_hue, T32_SCALE_FACTOR);
    light_hsl_hue_range_set_params_t range_set;
    light_hsl_mc_hue_range_state_get(p_self->state.handle, &range_set);
    if (p_app->state.new_tid)
    {
        p_app->state.init_present_hue_snapshot = p_app->state.present_hue;
    }
    target_hue = p_app->state.new_tid ? present_hsl_state.hue + delta32 : p_app->state.initial_present_hue + delta32;
    p_app->state.target_hue_snapshot = target_hue > (int64_t)range_set.hue_range_max ? range_set.hue_range_max : target_hue < (int64_t)range_set.hue_range_min ? range_set.hue_range_min : target_hue;
    transition_parameters_set(p_app, p_in->delta_hue, p_in_transition, APP_HSL_TRANSITION_DELTA_SET);
    app_transition_trigger(&p_app->state.transition);
    if (p_out != NULL)
    {
        p_out->present_hue = p_app->state.present_hue;
        p_out->target_hue = p_app->state.target_hue_snapshot;
        p_out->remaining_time_ms = p_params->transition_time_ms;
    }    
}                                   


static void light_move_set_saturation_cb(const light_hsl_setup_server_t * p_self,
                                  const access_message_rx_meta_t * p_meta,
                                  const light_hsl_saturation_move_set_params_t * p_in,
                                  const model_transition_t * p_in_transition,
                                  light_hsl_saturation_status_params_t * p_out)
{
     
    app_light_hsl_setup_server_t * p_app;
    light_hsl_saturation_range_set_params_t range_set;
    app_light_hsl_hw_state_t present_hsl_state;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_app->hsl_saturation_state_set_active = true;
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    p_app->state.present_hue = present_hsl_state.hue;
    p_app->state.present_saturation = present_hsl_state.saturation;
    light_hsl_mc_saturation_range_state_get(p_self->state.handle, &range_set);
    transition_parameters_set(p_app, (int32_t)p_in->delta_saturation, p_in_transition, APP_HSL_TRANSITION_MOVE_SET);
    if (p_in->delta_saturation > 0 && p_app->state.transition.requested_params.transition_time_ms > 0)
    {
        p_app->state.target_saturation_snapshot = range_set.saturation_range_max;
    }
    else if (p_in->delta_saturation < 0 && p_app->state.transition.requested_params.transition_time_ms > 0)
    {
        p_app->state.target_saturation_snapshot = range_set.saturation_range_min;
    }
    else
    {
        p_app->state.target_saturation_snapshot = p_app->state.present_saturation;
    }
    app_transition_trigger(&p_app->state.transition);
    if (p_out != NULL)
    {
        p_out->present_saturation = p_app->state.present_saturation;
        p_out->target_saturation = p_app->state.target_saturation_snapshot == range_set.saturation_range_max ? UINT32_MAX : 0;
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0 || p_in->delta_saturation == 0) ? 0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }    
}

static void light_delta_set_saturation_cb(const light_hsl_setup_server_t * p_self,
                                   const access_message_rx_meta_t * p_meta,
                                   const light_hsl_saturation_delta_set_params_t * p_in,
                                   const model_transition_t * p_in_transition,
                                   light_hsl_saturation_status_params_t * p_out)
{
     
    app_light_hsl_setup_server_t * p_app;
    app_light_hsl_hw_state_t present_hsl_state;
    int64_t delta32;
    int64_t target_saturation;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_app->hsl_hue_state_set_active = true;
    p_app->state.new_tid = model_transaction_is_new(&p_app->light_hsl_setup_server.hsl_srv.tid_tracker);
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    delta32 = SCALE_UP((int64_t)p_in->delta_saturation, T32_SCALE_FACTOR);
    light_hsl_saturation_range_set_params_t range_set;
    light_hsl_mc_saturation_range_state_get(p_self->state.handle, &range_set);
    if (p_app->state.new_tid)
    {
        p_app->state.init_present_saturation_snapshot = p_app->state.present_saturation;
    }
    target_saturation = p_app->state.new_tid ? present_hsl_state.hue + delta32 : p_app->state.initial_present_saturation + delta32;
    p_app->state.target_saturation_snapshot = target_saturation > (int64_t)range_set.saturation_range_max ? range_set.saturation_range_max : target_saturation < (int64_t)range_set.saturation_range_min ? range_set.saturation_range_min : target_saturation;
    transition_parameters_set(p_app, p_in->delta_saturation, p_in_transition, APP_HSL_TRANSITION_DELTA_SET);
    app_transition_trigger(&p_app->state.transition);
    if (p_out != NULL)
    {
        p_out->present_saturation = p_app->state.present_saturation;
        p_out->target_saturation = p_app->state.target_saturation_snapshot;
        p_out->remaining_time_ms = p_params->transition_time_ms;
    }
}                                   


static void light_hsl_state_target_get_cb(const light_hsl_setup_server_t * p_self,
                                                             const access_message_rx_meta_t * p_meta,
                                                             light_hsl_target_status_params_t * p_out)
{
     
    app_light_hsl_setup_server_t * p_app;
    p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, light_hsl_setup_server, p_self);
    p_out->target_lightness = p_app->p_app_ll->state.target_lightness;
    p_out->target_hue = p_app->state.target_hue;
    p_out->target_saturation = p_app->state.target_saturation;
}



static app_light_hsl_setup_server_t * transition_to_app(const app_transition_t * p_transition)
{
    app_light_hsl_state_t * p_state;
    p_state = PARENT_BY_FIELD_GET(app_light_hsl_state_t, transition, p_transition);
    return PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t, state, p_state);
}

static void present_hsl_values_set(app_light_hsl_setup_server_t * p_app, light_hsl_hue_range_set_params_t * p_range_hue, light_hsl_saturation_range_set_params_t * p_range_saturation)
{
    app_light_hsl_hw_state_t present_hsl_state;
    present_hsl_state.hue = p_app->state.present_hue;
    present_hsl_state.saturation = p_app->state.present_saturation;
    if (p_app->app_light_hsl_set_cb != NULL)
    {
        p_app->app_light_hsl_set_cb(p_app, &present_hsl_state);
    }
    p_app->state.present_hue = present_hsl_state.hue;
    p_app->state.present_saturation = present_hsl_state.saturation;
}

static void transition_delay_start_cb(const app_transition_t * p_transition)
{
    DEBUG_PRINTF("%s\r\n",__FUNCTION__);
    app_light_hsl_setup_server_t * p_app;
    p_app = transition_to_app(p_transition);   
    LOG_PRINTF("Element %d: starting delay\n", p_app->light_hsl_setup_server.settings.element_index);    
}


static void transition_start_cb(const app_transition_t * p_transition)
{
    DEBUG_PRINTF("%s\r\n",__FUNCTION__);
    app_light_hsl_setup_server_t * p_app;
    p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    app_light_hsl_hw_state_t present_hsl_state;
    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);

    if ((p_app->state.transition.requested_params.transition_type == APP_HSL_TRANSITION_DELTA_SET &&
        p_app->state.new_tid) ||
        (p_app->state.transition.requested_params.transition_type == APP_HSL_TRANSITION_SET) ||
        (p_app->state.transition.requested_params.transition_type == APP_HSL_TRANSITION_MOVE_SET))
    {
        p_app->state.initial_present_hue = p_app->state.init_present_hue_snapshot;
        p_app->state.initial_present_saturation = p_app->state.init_present_saturation_snapshot;
    }
    p_app->state.target_hue = p_app->state.target_hue_snapshot;
    p_app->state.target_saturation = p_app->state.target_saturation_snapshot;
    p_app->state.published_ms = 0;
    if (p_app->app_light_hsl_transition_cb != NULL)
    {
        app_light_hsl_hw_state_t target_hsl_state;
        target_hsl_state.hue = p_app->state.target_hue;
        target_hsl_state.saturation = p_app->state.target_saturation;
        p_app->app_light_hsl_transition_cb(p_app, p_params->transition_time_ms, target_hsl_state);
    }    
    
}
static inline bool hue_limit_check(uint32_t present_hue,
                                             light_hsl_hue_range_set_params_t * p_range,
                                             int32_t required_delta)
{
    return ((required_delta > 0 && present_hue == p_range->hue_range_max) ||
            (required_delta < 0 && present_hue == p_range->hue_range_min));
}

static uint32_t hsl_publish(app_light_hsl_setup_server_t * p_app, uint32_t remaining_time_ms)
{
    DEBUG_PRINTF("%s\r\n",__FUNCTION__);
    light_hsl_status_params_t publication_data;
    light_hsl_hue_status_params_t temp_publication_data_hue;
    light_hsl_saturation_status_params_t temp_publication_data_saturation;
    light_hsl_server_t * p_hsl_srv;
    light_hsl_hue_server_t * p_hsl_hue_srv;
    light_hsl_saturation_server_t * p_hsl_saturation_srv;
    uint32_t status = MESH_SUCCESS;
    app_light_hsl_hw_state_t present_hsl_state;
    uint32_t ll_remaining_time = 0;
    uint16_t lightness;

    p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
    p_app->p_app_ll->app_light_lightness_get_cb(p_app->p_app_ll, &lightness);

    if (!p_app->hsl_hue_state_set_active)
    {
        if (app_transition_ongoing_get(&p_app->p_app_ll->state.transition)->transition_time_ms > 0)
        {
            ll_remaining_time = app_transition_remaining_time_get(&p_app->p_app_ll->state.transition);
        }

        if (ll_remaining_time == 0)
        {
            publication_data.remaining_time_ms = remaining_time_ms;
        }
        else
        {
            publication_data.remaining_time_ms = MAX(remaining_time_ms, ll_remaining_time);
        }
        publication_data.present_lightness = lightness;
        publication_data.present_hue = present_hsl_state.hue;
        publication_data.present_saturation = present_hsl_state.saturation;

        p_hsl_srv = &p_app->light_hsl_setup_server.hsl_srv;
        status = light_hsl_server_status_publish(p_hsl_srv, &publication_data);
        if (status != MESH_SUCCESS)
        {
            return status;
        }        
    }

    temp_publication_data_hue.present_hue = present_hsl_state.hue;
    temp_publication_data_hue.target_hue = p_app->state.target_hue;
    temp_publication_data_hue.remaining_time_ms = remaining_time_ms;
    p_hsl_hue_srv = &p_app->light_hsl_setup_server.hsl_hue_srv;
    status = light_hsl_server_hue_status_publish(p_hsl_hue_srv, &temp_publication_data_hue);
    if (status != MESH_SUCCESS)
    {
        return status;
    }
    temp_publication_data_saturation.present_saturation = present_hsl_state.saturation;
    temp_publication_data_saturation.target_saturation = p_app->state.target_saturation;
    temp_publication_data_saturation.remaining_time_ms = remaining_time_ms;
    p_hsl_saturation_srv = &p_app->light_hsl_setup_server.hsl_saturation_srv;
    status = light_hsl_server_saturation_status_publish(p_hsl_saturation_srv, &temp_publication_data_saturation);
    if (status != MESH_SUCCESS)
    {
        return status;
    }    
    return status;
}

static void transition_tick_cb(const app_transition_t * p_transition)
{
    DEBUG_PRINTF("%s\r\n",__FUNCTION__);
    uint32_t elapsed_ms;
    uint32_t remaining_ms;
    app_light_hsl_setup_server_t * p_app;
    uint32_t delta_hue;
    uint32_t delta_saturation;
    int32_t total_time_ms;
    light_hsl_hue_range_set_params_t hue_range_set;
    light_hsl_saturation_range_set_params_t saturation_range_set;
    p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    total_time_ms = p_params->transition_time_ms;
    elapsed_ms = app_transition_elapsed_time_get((app_transition_t *)p_transition);
    remaining_ms = total_time_ms - elapsed_ms;
    if (p_params->transition_type != APP_HSL_TRANSITION_MOVE_SET)
    {
        delta_hue = p_app->state.target_hue - p_app->state.initial_present_hue; 
        p_app->state.present_hue = p_app->state.initial_present_hue + (delta_hue * (int64_t)elapsed_ms / total_time_ms);
        delta_saturation = (p_app->state.target_saturation - p_app->state.initial_present_saturation);
        p_app->state.present_saturation = p_app->state.initial_present_saturation + (delta_saturation * (int64_t)elapsed_ms / total_time_ms);
    }
    else
    {
        delta_hue = p_params->required_delta;
        p_app->state.present_hue = p_app->state.initial_present_hue + ((elapsed_ms * delta_hue) / (int64_t)p_params->transition_time_ms);
    }
    light_hsl_mc_hue_range_state_get(p_app->light_hsl_setup_server.state.handle, &hue_range_set);
    light_hsl_mc_saturation_range_state_get(p_app->light_hsl_setup_server.state.handle, &saturation_range_set);
//    CHECK_INVALID_HUE_RANGE(hue_range_set);
//    CHECK_INVALID_SATURATION_RANGE(saturation_range_set);
    present_hsl_values_set(p_app, &hue_range_set, &saturation_range_set);
    if (p_params->transition_type == APP_HSL_TRANSITION_MOVE_SET &&
        hue_limit_check(p_app->state.present_hue, &hue_range_set, p_params->required_delta))
    {
        p_app->abort_move = true;
        bearer_event_flag_set(m_transition_abort_flag);
    }
    if ((remaining_ms > HSL_ADDITIONAL_PUBLISH_START_MARGIN_MS) &&
        (elapsed_ms - p_app->state.published_ms > HSL_ADDITIONAL_PUBLISH_INTERVAL_MS))
    {
        p_app->state.published_ms = elapsed_ms;
        (void) hsl_publish(p_app, remaining_ms);
    }
}

static void transition_complete_cb(const app_transition_t * p_transition)
{
    DEBUG_PRINTF("%s\r\n",__FUNCTION__);
    app_light_hsl_setup_server_t * p_app;
    light_hsl_hue_range_set_params_t hue_range_set;
    light_hsl_saturation_range_set_params_t saturation_range_set;

    p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);

    p_app->state.target_hue = p_app->state.target_hue_snapshot;
    p_app->state.target_saturation = p_app->state.target_saturation_snapshot;

    if (p_params->transition_type != APP_HSL_TRANSITION_MOVE_SET)
    {
        p_app->state.present_hue = p_app->state.target_hue;
        p_app->state.present_saturation = p_app->state.target_saturation;
    }

    light_hsl_mc_hue_range_state_get(p_app->light_hsl_setup_server.state.handle, &hue_range_set);
    light_hsl_mc_saturation_range_state_get(p_app->light_hsl_setup_server.state.handle, &saturation_range_set);
//    CHECK_INVALID_HUE_RANGE(hue_range_set);
//    CHECK_INVALID_SATURATION_RANGE(saturation_range_set);
    present_hsl_values_set(p_app, &hue_range_set, &saturation_range_set);

    if (p_app->app_light_hsl_transition_cb != NULL)
    {
        app_light_hsl_hw_state_t target_ctl_state;
        target_ctl_state.hue = p_app->state.target_hue;
        target_ctl_state.saturation = p_app->state.target_saturation;
        p_app->app_light_hsl_transition_cb(p_app, p_params->transition_time_ms, target_ctl_state);
    }
    light_hsl_mc_hue_state_set(p_app->light_hsl_setup_server.state.handle, p_app->state.present_hue);
    light_hsl_mc_saturation_state_set(p_app->light_hsl_setup_server.state.handle, p_app->state.present_saturation);
    (void) hsl_publish(p_app, 0);
    p_app->hsl_state_set_active = false;
    p_app->hsl_hue_state_set_active = false;
    p_app->hsl_saturation_state_set_active = false;
}

static bool m_transition_abort_flag_cb(void)
{
     
    LIST_FOREACH(p_iter, mp_app_light_hsl_head)
    {
        app_light_hsl_setup_server_t * p_app = PARENT_BY_FIELD_GET(app_light_hsl_setup_server_t,
                                                                   node,
                                                                   p_iter);
        if (p_app->abort_move)
        {
            p_app->abort_move = false;
            app_transition_abort(&p_app->state.transition);
        }
    }
    return true;
}
static void add_publish(const void * p_app_v, light_lightness_status_params_t * p_pub_data)
{
    app_light_hsl_hw_state_t present_hsl_state;
    light_hsl_status_params_t publication_data;
    const app_light_hsl_setup_server_t * p_app = (app_light_hsl_setup_server_t *) p_app_v;
    if (p_app->light_hsl_setup_server.state.initialized == false)
    {
        return;
    }
    if (p_app->hsl_state_set_active == false)
    {
        p_app->app_light_hsl_get_cb(p_app, &present_hsl_state);
        publication_data.present_lightness = p_pub_data->present_lightness;
        publication_data.target_lightness =  p_pub_data->target_lightness;
        publication_data.remaining_time_ms = p_pub_data->remaining_time_ms;
        publication_data.present_hue = present_hsl_state.hue;
        publication_data.target_hue = p_app->state.target_hue;
        publication_data.present_saturation = present_hsl_state.saturation;
        publication_data.target_saturation = p_app->state.target_saturation;        
        (void) light_hsl_server_status_publish(&p_app->light_hsl_setup_server.hsl_srv, &publication_data);
    }     
}

static void transition_parameters_set(app_light_hsl_setup_server_t * p_app,
                                      uint32_t delta,
                                      const model_transition_t * p_in_transition,
                                      app_transition_type_t transition_type)
{
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_params->transition_type = transition_type;
    p_params->required_delta  = delta;
    p_params->minimum_step_ms = TRANSITION_STEP_MIN_MS;
    if (p_in_transition == NULL)
    {
        p_app->state.transition.delay_ms = 0;
        light_lightness_mc_dtt_state_get(p_app->p_app_ll->light_lightness_setup_server.state.handle, &p_params->transition_time_ms);
    }
    else
    {
        p_app->state.transition.delay_ms = p_in_transition->delay_ms;
        p_params->transition_time_ms = p_in_transition->transition_time_ms;
    }
}


uint32_t app_light_hsl_model_init(app_light_hsl_setup_server_t * p_app, uint8_t element_index, app_light_lightness_setup_server_t * p_app_ll)
{
     
    uint32_t status;
    if (p_app == NULL || p_app_ll == NULL)
    {
        return MESH_ERROR_NULL;
    }
    if ( (p_app->app_light_hsl_get_cb == NULL) ||
         ( (p_app->app_light_hsl_set_cb == NULL) &&
           (p_app->app_light_hsl_transition_cb == NULL) ) )
    {
        return MESH_ERROR_NULL;
    }
    p_app->p_app_ll = p_app_ll;
    p_app->p_app_ll->app_add_notify.p_app_publish_v = p_app;
    p_app->p_app_ll->app_add_notify.app_add_publish_cb = add_publish;    
    status = app_hsl_setup_server_init(p_app, element_index);

    if (status != MESH_SUCCESS)
    {
        return status;
    }
    p_app->state.transition.delay_start_cb = transition_delay_start_cb;
    p_app->state.transition.transition_start_cb = transition_start_cb;
    p_app->state.transition.transition_tick_cb = transition_tick_cb;
    p_app->state.transition.transition_complete_cb = transition_complete_cb;
    p_app->state.transition.timer.msg_id = MESH_TASK_MODEL_TIMER_HSL;
    p_app->state.transition.p_context = &p_app->state.transition;
    p_app->abort_move = false;
    status = app_transition_init(&p_app->state.transition);
    if (status == MESH_SUCCESS)
    {
        list_add(&mp_app_light_hsl_head, &p_app->node);
        m_transition_abort_flag = bearer_event_flag_add(m_transition_abort_flag_cb);
    }
    return status;
}



uint32_t app_light_hsl_binding_setup(app_light_hsl_setup_server_t * p_app)
{
     
    light_hsl_saved_values_t state;
    uint16_t index;
    uint16_t ll_index;

    if (p_app == NULL)
    {
        return MESH_ERROR_NULL;
    }

    index = p_app->light_hsl_setup_server.state.handle;
    ll_index = p_app->p_app_ll->light_lightness_setup_server.state.handle;

    light_lightness_mc_onpowerup_state_get(ll_index, &state.onpowerup);
    light_lightness_mc_actual_state_get(ll_index, &state.actual_lightness);
    light_lightness_mc_default_state_get(ll_index, &state.default_lightness); 
    light_hsl_mc_hue_state_get(index, &state.hue);
    light_hsl_mc_hue_default_state_get(index, &state.default_hue);
    light_hsl_mc_hue_range_state_get(index, &state.hue_range);
    light_hsl_mc_saturation_state_get(index, &state.saturation);
    light_hsl_mc_saturation_default_state_get(index, &state.default_saturation);
    light_hsl_mc_saturation_range_state_get(index, &state.saturation_range);

//    CHECK_INVALID_HUE_RANGE(state.hue_range);
//    CHECK_INVALID_SATURATION_RANGE(state.saturation_range);

    return light_hsl_ponoff_binding_setup(&p_app->light_hsl_setup_server, &state);
}









