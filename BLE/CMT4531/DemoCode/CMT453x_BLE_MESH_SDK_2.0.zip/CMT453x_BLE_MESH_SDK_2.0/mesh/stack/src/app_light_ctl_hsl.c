#include "app_light_ctl_hsl.h"
#include <stdlib.h>

#include "utils.h"
#include "assert.h"
#include "mesh_config_entry.h"
#include "mesh_config.h"

#include "light_lightness_mc.h"
#include "light_lightness_setup_server.h"
#include "light_lightness_utils.h"
#include "light_hsl_mc.h"
#include "light_hsl_utils.h"
#include "light_ctl_mc.h"
#include "light_ctl_utils.h"
#include "light_ctl_hsl_common.h"


#include "model_timer.h"
#include "bearer_event.h"
#include "mesh_app_task.h"


static list_node_t * mp_app_light_lightness_head;
static list_node_t * mp_app_light_ctl_head;

static bearer_event_flag_t m_ll_transition_abort_flag;


//light lightness callback from light ctl hsl setup server


static inline app_light_ctl_hsl_setup_server_t * ll_transition_to_app(const app_transition_t * p_transition)
{
    printf("%s\r\n",__FUNCTION__);
    app_light_lightness_state_t* p_state = PARENT_BY_FIELD_GET(app_light_lightness_state_t, transition, p_transition);
    return PARENT_BY_FIELD_GET(app_light_ctl_hsl_setup_server_t, ll_state, p_state);
}

static void ll_transition_delay_start_cb(const app_transition_t * p_transition)
{
    printf("%s\r\n",__FUNCTION__);
    app_light_ctl_hsl_setup_server_t *p_app = ll_transition_to_app(p_transition);
    printf("Starting delay, present-lightness: %d\n", p_app->ll_state.present_lightness);
}
static bool m_ll_transition_abort_flag_cb(void)
{
    printf("%s\r\n",__FUNCTION__);
    LIST_FOREACH(p_iter, mp_app_light_lightness_head)
    {
        app_light_ctl_hsl_setup_server_t * p_app = PARENT_BY_FIELD_GET(app_light_ctl_hsl_setup_server_t,
                                                                         node,
                                                                         p_iter);
        if (p_app->ll_abort_move)
        {
            p_app->ll_abort_move = false;
            app_transition_abort(&p_app->ll_state.transition);
        }
    }
    return true;
}
static void ll_transition_start_cb(const app_transition_t * p_transition)
{
    printf("%s\r\n",__FUNCTION__);
    app_light_ctl_hsl_setup_server_t *p_app = ll_transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->ll_state.transition);
    if((p_app->ll_state.transition.requested_params.transition_type == APP_TRANSITION_TYPE_DELTA_SET &&
       p_app->ll_state.new_tid) ||
       (p_app->ll_state.transition.requested_params.transition_type == APP_TRANSITION_TYPE_SET) ||
       (p_app->ll_state.transition.requested_params.transition_type == APP_TRANSITION_TYPE_MOVE_SET))
    {
       p_app->ll_state.initial_present_lightness = p_app->ll_state.init_present_snapshot;
    }
    p_app->ll_state.target_lightness = p_app->ll_state.target_snapshot;
    p_app->ll_state.published_ms = 0;
    if (p_app->app_light_lightness_transition_cb != NULL)
    {
        p_app->app_light_lightness_transition_cb(p_app, p_params->transition_time_ms, p_app->ll_state.target_lightness);
    }
}


static void ll_range_get(uint16_t state_handle, light_lightness_range_status_params_t * p_range)
{
    printf("%s\r\n",__FUNCTION__);
    light_lightness_mc_range_min_state_get(state_handle, &p_range->range_min);
    light_lightness_mc_range_max_state_get(state_handle, &p_range->range_max);
    light_lightness_mc_range_status_state_get(state_handle, &p_range->status);
}
static uint16_t ll_target_snapshot_get(uint16_t state_handle, uint16_t lightness)
{
    printf("%s\r\n",__FUNCTION__);
    light_lightness_range_status_params_t range;
    uint16_t target_snapshot;
    ll_range_get(state_handle, &range);
    target_snapshot = lightness > range.range_max ? range.range_max :
                      lightness < range.range_min && lightness != 0 ? range.range_min :
                      lightness;
    return target_snapshot;
}
static void ll_transition_parameters_set(app_light_ctl_hsl_setup_server_t * p_app, int32_t delta, const model_transition_t * p_in_transition, app_transition_type_t transition_type)
{
    printf("%s\r\n",__FUNCTION__);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->ll_state.transition);
    p_params->transition_type = transition_type;
    p_params->required_delta  = delta;
    p_params->minimum_step_ms = TRANSITION_STEP_MIN_MS;
    if (p_in_transition == NULL)
    {
        p_app->ll_state.transition.delay_ms = 0;
        light_lightness_mc_dtt_state_get(p_app->light_ctl_hsl_server.state.ll_handle,&p_params->transition_time_ms);
    }
    else
    {
        p_app->ll_state.transition.delay_ms = p_in_transition->delay_ms;
        p_params->transition_time_ms = p_in_transition->transition_time_ms;
    }
}

static void ll_present_lightness_set(app_light_ctl_hsl_setup_server_t * p_app)
{
    printf("%s\r\n",__FUNCTION__);
    if (p_app->app_light_lightness_set_cb != NULL)
    {
        p_app->app_light_lightness_set_cb(p_app, p_app->ll_state.present_lightness);
    }
}
static inline bool ll_lightness_limit_check(uint16_t present_lightness, light_lightness_range_status_params_t * p_range, int32_t required_delta)
{
    printf("%s\r\n",__FUNCTION__);
    return ((required_delta > 0 && present_lightness == p_range->range_max) ||
            (required_delta < 0 && present_lightness == p_range->range_min));
}

static void ll_transition_tick_cb(const app_transition_t * p_transition)
{
    printf("%s\r\n",__FUNCTION__);
    int32_t present_lightness;
    uint32_t elapsed_ms;
    uint32_t remaining_ms;
    light_lightness_range_status_params_t range;
    app_light_ctl_hsl_setup_server_t * p_app = ll_transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->ll_state.transition);
    elapsed_ms = app_transition_elapsed_time_get((app_transition_t *)p_transition);
    remaining_ms = app_transition_remaining_time_get((app_transition_t *)p_transition);
    if (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET)
    {
        int32_t delta = (p_app->ll_state.target_lightness - p_app->ll_state.initial_present_lightness);
        present_lightness = p_app->ll_state.initial_present_lightness +(delta * (int64_t)elapsed_ms / (int32_t)p_params->transition_time_ms);
    }
    else
    {
        present_lightness = p_app->ll_state.initial_present_lightness +(((int64_t)elapsed_ms * (int64_t)p_params->required_delta) /(int64_t)p_params->transition_time_ms);
    }
    ll_range_get(p_app->light_ctl_hsl_server.state.ll_handle, &range);
    p_app->ll_state.present_lightness = present_lightness == 0 ? 0 : MIN((int32_t)MAX(present_lightness, range.range_min), range.range_max);
    ll_present_lightness_set(p_app);
    if (p_params->transition_type == APP_TRANSITION_TYPE_MOVE_SET && ll_lightness_limit_check(p_app->ll_state.present_lightness, &range, p_params->required_delta))
    { 
        p_app->ll_abort_move = true;
        bearer_event_flag_set(m_ll_transition_abort_flag);
    }
}
static void ll_present_lightness_set_with_range_clip(app_light_ctl_hsl_setup_server_t * p_app)
{
    printf("%s\r\n",__FUNCTION__);
    light_lightness_range_status_params_t range;
    ll_range_get(p_app->light_ctl_hsl_server.state.ll_handle, &range);
    p_app->ll_state.present_lightness = light_lightness_utils_actual_to_range_restrict(p_app->ll_state.present_lightness, range.range_min, range.range_max);
    ll_present_lightness_set(p_app);
}
static void ll_transition_complete_cb(const app_transition_t * p_transition)
{
    printf("%s\r\n",__FUNCTION__);
    app_light_ctl_hsl_setup_server_t * p_app = ll_transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->ll_state.transition);
    p_app->ll_state.target_lightness = p_app->ll_state.target_snapshot;
    if (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET)
    {
        p_app->ll_state.present_lightness = p_app->ll_state.target_lightness;
    }
    ll_present_lightness_set_with_range_clip(p_app);
    if (p_app->app_light_lightness_transition_cb != NULL)
    {
        p_app->app_light_lightness_transition_cb(p_app, p_params->transition_time_ms, p_app->ll_state.target_lightness);
    }
    if (p_app->ll_state.present_lightness >= LIGHT_LIGHTNESS_LAST_MIN)
    {
        light_lightness_mc_last_state_set(p_app->light_ctl_hsl_server.state.ll_handle, p_app->ll_state.present_lightness, LIGHT_LIGHTNESS_MC_WRITE_DESTINATION_ALL);
    }
    light_lightness_mc_actual_state_set(p_app->light_ctl_hsl_server.state.ll_handle, p_app->ll_state.present_lightness);
}



static void light_lightness_state_set_cb(const light_lightness_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_lightness_set_params_t * p_in, const model_transition_t * p_in_transition, light_lightness_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
    light_ctl_hsl_server_t * pp_self = (light_ctl_hsl_server_t *)p_self;
    app_light_ctl_hsl_setup_server_t * p_app = PARENT_BY_FIELD_GET(app_light_ctl_hsl_setup_server_t, light_ctl_hsl_server, pp_self);
    uint16_t present_lightness;
    uint32_t transition_time_ms;    
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->ll_state.transition);
    p_app->app_light_lightness_get_cb(p_app, &present_lightness);
    p_app->ll_state.target_snapshot = ll_target_snapshot_get(pp_self->state.ll_handle, p_in->lightness);
    p_app->ll_state.init_present_snapshot = p_app->ll_state.present_lightness;
    light_lightness_mc_actual_state_set(pp_self->state.ll_handle, p_app->ll_state.target_snapshot);
    if (p_app->ll_state.target_snapshot >= LIGHT_LIGHTNESS_LAST_MIN)
    {
        light_lightness_mc_last_state_set(pp_self->state.ll_handle, p_app->ll_state.target_snapshot, LIGHT_LIGHTNESS_MC_WRITE_DESTINATION_FLASH_ONLY);
    }
    if (!pp_self->state.initialized || (present_lightness != p_in->lightness))
    {
        ll_transition_parameters_set(p_app, (int32_t)p_app->ll_state.target_snapshot - (int32_t)present_lightness, p_in_transition, APP_TRANSITION_TYPE_SET);
        transition_time_ms = p_params->transition_time_ms;
        app_transition_trigger(&p_app->ll_state.transition);
    }
    else
    {
        transition_time_ms = 0;
    }    
    if (p_out != NULL)
    {
        p_out->present_lightness = p_app->ll_state.present_lightness;
        p_out->target_lightness  = p_app->ll_state.target_snapshot;
        p_out->remaining_time_ms = transition_time_ms;
    }    
}
static void light_lightness_state_get_cb(const light_lightness_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_lightness_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
    light_ctl_hsl_server_t * pp_self = (light_ctl_hsl_server_t *)p_self;
    app_light_ctl_hsl_setup_server_t * p_app = PARENT_BY_FIELD_GET(app_light_ctl_hsl_setup_server_t, light_ctl_hsl_server, (light_ctl_hsl_server_t *)p_self);
    uint16_t present_lightness;
    light_lightness_range_status_params_t range;
    
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->ll_state.transition);
    p_app->app_light_lightness_get_cb(p_app,&present_lightness);
    p_out->present_lightness = present_lightness;
    if (p_params->transition_type == APP_TRANSITION_TYPE_MOVE_SET)
    {
        ll_range_get(pp_self->state.ll_handle, &range);
        p_out->target_lightness = p_app->ll_state.target_lightness == range.range_max ? UINT16_MAX : 0;
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0 || p_params->required_delta == 0) ? 0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }
    else
    {
        p_out->target_lightness = p_app->ll_state.target_lightness;
        p_out->remaining_time_ms = app_transition_remaining_time_get(&p_app->ll_state.transition);
    }    
}
static void light_lightness_state_last_get_cb(const light_lightness_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_lightness_last_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_lightness_state_default_set_cb(const light_lightness_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_lightness_default_set_params_t * p_in, light_lightness_default_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_lightness_state_default_get_cb(const light_lightness_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_lightness_default_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_lightness_state_range_set_cb(const light_lightness_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_lightness_range_set_params_t * p_in, light_lightness_range_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_lightness_state_range_get_cb(const light_lightness_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_lightness_range_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
    light_lightness_range_status_params_t range;
    ll_range_get(((light_ctl_hsl_server_t *)p_self)->state.ll_handle, &range);
    p_out->range_min = range.range_min;
    p_out->range_max = range.range_max;
    p_out->status = range.status;    
}
static void light_lightness_state_move_set_cb(const light_lightness_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_lightness_move_set_params_t * p_in, const model_transition_t * p_in_transition, light_lightness_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_lightness_state_delta_set_cb(const light_lightness_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_lightness_delta_set_params_t * p_in, const model_transition_t * p_in_transition, light_lightness_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}

//light lightness callback from light ctl hsl setup server


//light hsl callback from light ctl hsl setup server

static void hsl_state_set_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_set_params_t * p_in, const model_transition_t * p_in_transition, light_hsl_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void hsl_state_get_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_hsl_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_hue_set_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_hue_set_params_t * p_in, const model_transition_t * p_in_transition, light_hsl_hue_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_hue_get_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_hsl_hue_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_saturation_set_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_saturation_set_params_t * p_in, const model_transition_t * p_in_transition, light_hsl_saturation_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_saturation_get_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_hsl_saturation_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_hue_range_get_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_hsl_hue_range_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_saturation_range_get_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_hsl_saturation_range_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_default_set_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_default_set_params_t * p_in, light_hsl_default_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_default_get_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_hsl_default_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_range_set_cb(const light_hsl_setup_server_t * p_self,  const access_message_rx_meta_t * p_meta, const light_hsl_range_set_params_t * p_in,  light_hsl_range_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_range_get_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_hsl_range_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_move_set_hue_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_hue_move_set_params_t * p_in, const model_transition_t * p_in_transition, light_hsl_hue_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_delta_set_hue_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_hue_delta_set_params_t * p_in, const model_transition_t * p_in_transition, light_hsl_hue_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_move_set_saturation_cb(const light_hsl_setup_server_t * p_self,  const access_message_rx_meta_t * p_meta, const light_hsl_saturation_move_set_params_t * p_in, const model_transition_t * p_in_transition, light_hsl_saturation_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_delta_set_saturation_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_saturation_delta_set_params_t * p_in, const model_transition_t * p_in_transition, light_hsl_saturation_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void light_hsl_state_target_get_cb(const light_hsl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_hsl_target_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
//light hsl callback from light ctl hsl setup server


//light ctl callback from light ctl hsl setup server
static void ctl_state_set_cb(const light_ctl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_ctl_set_params_t * p_in, const model_transition_t * p_in_transition, light_ctl_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void ctl_state_get_cb(const light_ctl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_ctl_status_params_t * p_out)
{
   printf("%s\r\n",__FUNCTION__);
}
static void ctl_state_temperature32_get_cb(const light_ctl_setup_server_t * p_self,  const access_message_rx_meta_t * p_meta, light_ctl_temperature_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void ctl_state_temperature32_set_cb(const light_ctl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_ctl_temperature_set_params_t * p_in, const model_transition_t * p_in_transition, light_ctl_temperature_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void ctl_state_default_get_cb(const light_ctl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_ctl_default_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void ctl_state_default_set_cb(const light_ctl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_ctl_default_set_params_t * p_in, light_ctl_default_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void ctl_state_range_get_cb(const light_ctl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, light_ctl_temperature_range_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void ctl_state_range_set_cb(const light_ctl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_ctl_temperature_range_set_params_t * p_in, light_ctl_temperature_range_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void ctl_state_delta_set_cb(const light_ctl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_ctl_temperature_delta_set_params_t * p_in, const model_transition_t * p_in_transition, light_ctl_temperature_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
static void ctl_state_move_set_cb(const light_ctl_setup_server_t * p_self, const access_message_rx_meta_t * p_meta, const light_ctl_temperature_move_set_params_t * p_in, const model_transition_t * p_in_transition, light_ctl_temperature_status_params_t * p_out)
{
    printf("%s\r\n",__FUNCTION__);
}
//light ctl callback from light ctl hsl setup server





static const light_ctl_hsl_setup_server_callbacks_t light_ctl_hsl_setup_srv_cbs =
{
    //light lightness callback from light ctl hsl setup server
    .light_lightness_cbs.set_cb                 = light_lightness_state_set_cb,
    .light_lightness_cbs.get_cb                 = light_lightness_state_get_cb,
    .light_lightness_cbs.last_get_cb            = light_lightness_state_last_get_cb,
    .light_lightness_cbs.default_set_cb         = light_lightness_state_default_set_cb,
    .light_lightness_cbs.default_get_cb         = light_lightness_state_default_get_cb,
    .light_lightness_cbs.range_set_cb           = light_lightness_state_range_set_cb,
    .light_lightness_cbs.range_get_cb           = light_lightness_state_range_get_cb,
    .light_lightness_cbs.move_set_cb            = light_lightness_state_move_set_cb,
    .light_lightness_cbs.delta_set_cb           = light_lightness_state_delta_set_cb,
    //light hsl callback from light ctl hsl setup server
    .light_hsl_cbs.set_cb                       = hsl_state_set_cb,
    .light_hsl_cbs.get_cb                       = hsl_state_get_cb,
    .light_hsl_cbs.set_hue_cb                   = light_hsl_state_hue_set_cb,
    .light_hsl_cbs.get_hue_cb                   = light_hsl_state_hue_get_cb,
    .light_hsl_cbs.set_saturation_cb            = light_hsl_state_saturation_set_cb,
    .light_hsl_cbs.get_saturation_cb            = light_hsl_state_saturation_get_cb,    
    .light_hsl_cbs.hue_range_get_cb             = light_hsl_state_hue_range_get_cb,   
    .light_hsl_cbs.saturation_range_get_cb      = light_hsl_state_saturation_range_get_cb,   
    .light_hsl_cbs.range_set_cb                 = light_hsl_state_range_set_cb,
    .light_hsl_cbs.range_get_cb                 = light_hsl_state_range_get_cb,  
    .light_hsl_cbs.default_set_cb               = light_hsl_state_default_set_cb,
    .light_hsl_cbs.default_get_cb               = light_hsl_state_default_get_cb,     
    .light_hsl_cbs.move_set_hue_cb              = light_move_set_hue_cb,
    .light_hsl_cbs.delta_set_hue_cb             = light_delta_set_hue_cb,
    .light_hsl_cbs.move_set_saturation_cb       = light_move_set_saturation_cb,
    .light_hsl_cbs.delta_set_saturation_cb      = light_delta_set_saturation_cb,   
    .light_hsl_cbs.target_get_cb                = light_hsl_state_target_get_cb,     
    //light ctl callback from light ctl hsl setup server
    .light_ctl_cbs.set_cb                       = ctl_state_set_cb,
    .light_ctl_cbs.get_cb                       = ctl_state_get_cb,
    .light_ctl_cbs.temperature32_set_cb         = ctl_state_temperature32_set_cb,
    .light_ctl_cbs.temperature32_get_cb         = ctl_state_temperature32_get_cb,
    .light_ctl_cbs.temperature32_range_set_cb   = ctl_state_range_set_cb,
    .light_ctl_cbs.temperature32_range_get_cb   = ctl_state_range_get_cb,
    .light_ctl_cbs.default_set_cb               = ctl_state_default_set_cb,
    .light_ctl_cbs.default_get_cb               = ctl_state_default_get_cb,
    .light_ctl_cbs.move_set_cb                  = ctl_state_move_set_cb,
    .light_ctl_cbs.delta_set_cb                 = ctl_state_delta_set_cb,
};









static uint32_t app_light_ctl_hsl_setup_server_init(light_ctl_hsl_server_t * p_setup_server, uint8_t element_index)
{
    printf("%s\r\n",__FUNCTION__);
    uint32_t status;
    if (!p_setup_server)
    {
        return MESH_ERROR_NULL;
    }

    p_setup_server->settings.p_callbacks = &light_ctl_hsl_setup_srv_cbs;


    status = light_lightness_mc_open(&p_setup_server->state.ll_handle);
    if (status != MESH_SUCCESS)
    {
        return status;
    }
    status = light_hsl_mc_open(&p_setup_server->state.hsl_handle);
    if (status != MESH_SUCCESS)
    {
        return status;
    }    
    status = light_ctl_mc_open(&p_setup_server->state.ctl_handle);
    if (status != MESH_SUCCESS)
    {
        return status;
    }        
    
    
    p_setup_server->state.initialized = false;

    return light_ctl_hsl_setup_server_init(p_setup_server, element_index);
}




uint32_t app_light_ctl_hsl_model_init(app_light_ctl_hsl_setup_server_t * p_app, uint8_t element)
{
    uint32_t status = MESH_ERROR_NULL;
    if (p_app == NULL)
    {
        return status;
    }
    
    
    status = app_light_ctl_hsl_setup_server_init(&p_app->light_ctl_hsl_server, element);
    if (status != MESH_SUCCESS)
    {
        return status;
    }
    p_app->ll_state.transition.delay_start_cb = ll_transition_delay_start_cb;
    p_app->ll_state.transition.transition_start_cb = ll_transition_start_cb;
    p_app->ll_state.transition.transition_tick_cb = ll_transition_tick_cb;
    p_app->ll_state.transition.transition_complete_cb = ll_transition_complete_cb;
    p_app->ll_state.transition.timer.msg_id = MESH_TASK_MODEL_TIMER_LL;
    p_app->ll_state.transition.p_context = &p_app->ll_state.transition;
    p_app->ll_abort_move = false;
    status = app_transition_init(&p_app->ll_state.transition);    
    if (status != MESH_SUCCESS)
    {
        return status;
    }    
    list_add(&mp_app_light_lightness_head, &p_app->node);
    m_ll_transition_abort_flag = bearer_event_flag_add(m_ll_transition_abort_flag_cb);    
    
    return status;
}






uint32_t app_light_ctl_hsl_binding_setup(app_light_ctl_hsl_setup_server_t * p_app)
{
    light_ctl_hsl_saved_values_t state;
    uint8_t ll_index;
    uint8_t hsl_index;
    uint8_t ctl_index;

    if (p_app == NULL)
    {
        return MESH_ERROR_NULL;
    }    
    
    light_ctl_hsl_server_t *p_server = &p_app->light_ctl_hsl_server;
    ll_index = p_server->state.ll_handle;
    light_lightness_mc_range_status_state_get(ll_index, &state.ll_state.range.status);
    light_lightness_mc_range_min_state_get(ll_index, &state.ll_state.range.range_min);
    light_lightness_mc_range_max_state_get(ll_index, &state.ll_state.range.range_max);
    light_lightness_mc_onpowerup_state_get(ll_index, &state.ll_state.onpowerup);
    light_lightness_mc_actual_state_get(ll_index, &state.ll_state.actual_lightness);
    light_lightness_mc_last_state_get(ll_index, &state.ll_state.last_lightness);
    light_lightness_mc_default_state_get(ll_index, &state.ll_state.default_lightness);     
    hsl_index = p_server->state.hsl_handle;
    light_hsl_mc_hue_state_get(hsl_index, &state.hsl_state.hue);
    light_hsl_mc_hue_default_state_get(hsl_index, &state.hsl_state.default_hue);
    light_hsl_mc_hue_range_state_get(hsl_index, &state.hsl_state.hue_range);
    light_hsl_mc_saturation_state_get(hsl_index, &state.hsl_state.saturation);
    light_hsl_mc_saturation_default_state_get(hsl_index, &state.hsl_state.default_saturation);
    light_hsl_mc_saturation_range_state_get(hsl_index, &state.hsl_state.saturation_range);    
    ctl_index = p_server->state.ctl_handle;
    light_ctl_mc_temperature32_state_get(ctl_index, &state.ctl_state.temperature32);
    light_ctl_mc_default_temperature32_state_get(ctl_index, &state.ctl_state.default_temperature32);
    light_ctl_mc_delta_uv_state_get(ctl_index, (int16_t *) &state.ctl_state.delta_uv);
    light_ctl_mc_default_delta_uv_state_get(ctl_index, (int16_t *) &state.ctl_state.default_delta_uv);
    light_ctl_mc_temperature32_range_state_get(ctl_index, &state.ctl_state.temperature32_range);
    
    
    
    return light_ctl_hsl_ponoff_binding_setup(&p_app->light_ctl_hsl_server, &state);
}






