#include "app_pwm_utils.h"



static inline uint16_t pwm_signed_level_to_ticks(pwm_utils_contex_t * p_ctx, int16_t signed_value)
{
    return (uint16_t)((((int32_t)(signed_value - INT16_MIN) * (p_ctx->pwm_ticks_max - 1))/UINT16_MAX) + 1);
}

static inline uint16_t pwm_unsigned_level_to_ticks(pwm_utils_contex_t * p_ctx, uint16_t unsigned_value)
{
    if( unsigned_value == 0) return 0;
    return (uint16_t)(((uint32_t)(unsigned_value * (p_ctx->pwm_ticks_max - 1))/UINT16_MAX) + 1);
}

static inline uint16_t pwm_ticks_to_unsigned_level(pwm_utils_contex_t * p_ctx, uint16_t ticks)
{
    if (ticks == 0)
    {
        ticks = 1;
    }

    return (uint16_t)(((uint32_t)(ticks - 1) * UINT16_MAX) / (uint32_t)(p_ctx->pwm_ticks_max - 1));
}

static inline int16_t pwm_ticks_to_signed_level(pwm_utils_contex_t * p_ctx, uint16_t ticks)
{
    return (int16_t)((int32_t)pwm_ticks_to_unsigned_level(p_ctx, ticks) + INT16_MIN);
}


void pwm_utils_enable(pwm_utils_contex_t * p_ctx)
{
    
    app_pwm_init(p_ctx);
    p_ctx->pwm_ticks_max = app_pwm_cycle_ticks_get(p_ctx->p_pwm);
    app_pwm_enable(p_ctx->p_pwm); 
    
}

void pwm_utils_level_set(pwm_utils_contex_t * p_ctx, int16_t level)
{
    (void) app_pwm_channel_duty_ticks_set(p_ctx->p_pwm, p_ctx->channel, pwm_signed_level_to_ticks(p_ctx, level));
}

int16_t pwm_utils_level_get(pwm_utils_contex_t * p_ctx)
{
    return pwm_ticks_to_signed_level(p_ctx, app_pwm_channel_duty_ticks_get(p_ctx->p_pwm, p_ctx->channel));
}

uint32_t pwm_utils_level_set_unsigned(pwm_utils_contex_t * p_ctx, uint16_t level)
{
    return (app_pwm_channel_duty_ticks_set(p_ctx->p_pwm, p_ctx->channel, pwm_unsigned_level_to_ticks(p_ctx, level)));
}
uint16_t pwm_utils_level_get_unsigned(pwm_utils_contex_t * p_ctx)
{
    return pwm_ticks_to_unsigned_level(p_ctx, app_pwm_channel_duty_ticks_get(p_ctx->p_pwm, p_ctx->channel));
}



