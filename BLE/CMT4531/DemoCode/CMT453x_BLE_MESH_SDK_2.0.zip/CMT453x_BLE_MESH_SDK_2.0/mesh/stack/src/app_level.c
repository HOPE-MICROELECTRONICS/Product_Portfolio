#include "app_level.h"
#include <stdint.h>
#include <stdlib.h>
#include "generic_level_server.h"
#include "mesh_app_task.h"
#include "bsp_lpuart.h"

static void generic_level_state_get_cb(const generic_level_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       generic_level_status_params_t * p_out);
static void generic_level_state_set_cb(const generic_level_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       const generic_level_set_params_t * p_in,
                                       const model_transition_t * p_in_transition,
                                       generic_level_status_params_t * p_out);

static void generic_level_state_delta_set_cb(const generic_level_server_t * p_self,
                                             const access_message_rx_meta_t * p_meta,
                                             const generic_level_delta_set_params_t * p_in,
                                             const model_transition_t * p_in_transition,
                                             generic_level_status_params_t * p_out);

static void generic_level_state_move_set_cb(const generic_level_server_t * p_self,
                                            const access_message_rx_meta_t * p_meta,
                                            const generic_level_move_set_params_t * p_in,
                                            const model_transition_t * p_in_transition,
                                            generic_level_status_params_t * p_out);

static const generic_level_server_callbacks_t m_level_srv_cbs =
{
    .level_cbs.get_cb = generic_level_state_get_cb,
    .level_cbs.set_cb = generic_level_state_set_cb,
    .level_cbs.delta_set_cb = generic_level_state_delta_set_cb,
    .level_cbs.move_set_cb = generic_level_state_move_set_cb
};


static void transition_params_set(app_level_server_t * p_app,
                                  int32_t delta,
                                  const model_transition_t * p_in_transition,
                                  app_transition_type_t transition_type)
{
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);

    p_params->transition_type = transition_type;
    p_params->required_delta = delta;
    p_params->minimum_step_ms = TRANSITION_STEP_MIN_MS;
    if (p_in_transition == NULL)
    {
        p_app->state.transition.delay_ms = 0;
        p_params->transition_time_ms = 0;
    }
    else
    {
        p_app->state.transition.delay_ms = p_in_transition->delay_ms;
        p_params->transition_time_ms = p_in_transition->transition_time_ms;
    }
}

static inline app_level_server_t * transition_to_app(const app_transition_t * p_transition)
{
    app_level_state_t * p_state = PARENT_BY_FIELD_GET(app_level_state_t,
                                  transition,
                                  p_transition);
    return PARENT_BY_FIELD_GET(app_level_server_t,
                               state,
                               p_state);
}

static void app_level_delay_start_cb(const app_transition_t * p_transition)
{
    LOG_PRINTF("Starting delay\r\n");
}

static void app_level_transition_start_cb(const app_transition_t * p_transition)
{
    app_level_server_t * p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);

    p_app->state.delta = p_params->required_delta;
    p_app->state.initial_present_level = p_app->state.init_present_snapshot;
    p_app->state.target_level = p_app->state.target_snapshot;

    if (p_app->level_transition_cb != NULL)
    {
        p_app->level_transition_cb(p_app, p_params->transition_time_ms,
                                          p_app->state.target_level,
                                          p_params->transition_type);
    }

    LOG_PRINTF("Starting transition\n");
}

static void app_level_transition_tick_cb(const app_transition_t * p_transition)
{
    app_level_server_t * p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);

    if (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET)
    {
        int32_t delta = (p_app->state.target_level - p_app->state.initial_present_level);
        p_app->state.present_level = p_app->state.initial_present_level +
                                        (delta * (int64_t)app_transition_elapsed_time_get(&p_app->state.transition) /
                                          (int64_t)p_params->transition_time_ms);
    }
    else
    {
        p_app->state.present_level = p_app->state.initial_present_level +
                                        (((int64_t)app_transition_elapsed_time_get(&p_app->state.transition) * (int64_t)p_app->state.delta) /
                                          (int64_t)p_params->transition_time_ms);
    }

    if (p_app->level_set_cb != NULL)
    {
        p_app->level_set_cb(p_app, p_app->state.present_level);
    }
    

    LOG_PRINTF("Elapsed time: %d\n", (uint32_t) app_transition_elapsed_time_get(&p_app->state.transition));
}


static void app_level_transition_complete_cb(const app_transition_t * p_transition)
{
    app_level_server_t * p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    p_app->state.target_level = p_app->state.target_snapshot;

    if (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET)
    {
        p_app->state.present_level = p_app->state.target_level;
    }
    generic_level_status_params_t status_params;
    status_params.present_level = p_app->state.present_level;
    status_params.target_level = p_app->state.target_level;
    status_params.remaining_time_ms = 0;
    generic_level_server_status_publish(&p_app->server, &status_params);

    if (p_app->level_set_cb != NULL)
    {
        p_app->level_set_cb(p_app, p_app->state.present_level);
    }

    if (p_app->level_transition_cb != NULL)
    {
        p_app->level_transition_cb(p_app, p_params->transition_time_ms,
                                          p_app->state.target_level,
                                          p_params->transition_type);
    }
    LOG_PRINTF("Transition completed: Present-L: %d  Target-L: %d\n", p_app->state.present_level, p_app->state.target_level);
}

static void generic_level_state_get_cb(const generic_level_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       generic_level_status_params_t * p_out)
{
    app_level_server_t * p_app = PARENT_BY_FIELD_GET(app_level_server_t, server, p_self);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    p_app->level_get_cb(p_app, &p_app->state.present_level);
    p_out->present_level = p_app->state.present_level;
    p_out->target_level = p_app->state.target_level;
    if (p_params->transition_type == APP_TRANSITION_TYPE_MOVE_SET)
    {
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0) ?
                                    0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }
    else
    {
        p_out->remaining_time_ms = app_transition_remaining_time_get(&p_app->state.transition);
    }

    LOG_PRINTF("GET: Present-L: %d  Target-L: %d  Remaining_t: %d \n", p_out->present_level, p_out->target_level, p_out->remaining_time_ms);
}

static void generic_level_state_set_cb(const generic_level_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       const generic_level_set_params_t * p_in,
                                       const model_transition_t * p_in_transition,
                                       generic_level_status_params_t * p_out)
{
    app_level_server_t * p_app = PARENT_BY_FIELD_GET(app_level_server_t, server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_app->state.target_snapshot = p_in->level;
    p_app->state.init_present_snapshot = p_app->state.present_level;
    transition_params_set(p_app,
                          (int32_t)p_app->state.target_snapshot - (int32_t)p_app->state.init_present_snapshot,
                          p_in_transition,
                          APP_TRANSITION_TYPE_SET);

    LOG_PRINTF("SET: Level: %d  delay: %d  tt: %d  req-delta: %d  trans-type: %d\n",
          p_app->state.target_snapshot,  p_app->state.transition.delay_ms, p_params->transition_time_ms,
          p_params->required_delta,
          p_params->transition_type);

    app_transition_trigger(&p_app->state.transition);
    if (p_out != NULL)
    {
        p_out->present_level = p_app->state.present_level;
        p_out->target_level = p_app->state.target_snapshot;
        p_out->remaining_time_ms = p_params->transition_time_ms;
    }
}

static void generic_level_state_delta_set_cb(const generic_level_server_t * p_self,
                                             const access_message_rx_meta_t * p_meta,
                                             const generic_level_delta_set_params_t * p_in,
                                             const model_transition_t * p_in_transition,
                                             generic_level_status_params_t * p_out)
{
    app_level_server_t * p_app = PARENT_BY_FIELD_GET(app_level_server_t, server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    int32_t delta = p_in->delta_level % ((int32_t)UINT16_MAX + 1);
    if (!model_transaction_is_new(&p_app->server.tid_tracker))
    {
        LOG_PRINTF("tid: %d Same TID, assuming cumulative delta set.\n", p_in->tid);
    }
    else
    {
        p_app->state.init_present_snapshot = p_app->state.present_level;
    }
    p_app->state.target_snapshot = p_app->state.init_present_snapshot + delta;
    transition_params_set(p_app, delta, p_in_transition, APP_TRANSITION_TYPE_DELTA_SET);
    LOG_PRINTF("Delta SET: delta: %d  delay: %d  tt: %d\n",
          p_in->delta_level, p_app->state.transition.delay_ms, p_params->transition_time_ms);
    LOG_PRINTF("Delta SET: initial-level: %d  present-level: %d  target-level: %d\n",
          p_app->state.init_present_snapshot, p_app->state.present_level, p_app->state.target_snapshot);
    app_transition_trigger(&p_app->state.transition);
    if (p_out != NULL)
    {
        p_out->present_level = p_app->state.present_level;
        p_out->target_level = p_app->state.target_snapshot;
        p_out->remaining_time_ms = p_params->transition_time_ms;
    }
}


static void generic_level_state_move_set_cb(const generic_level_server_t * p_self,
                                            const access_message_rx_meta_t * p_meta,
                                            const generic_level_move_set_params_t * p_in,
                                            const model_transition_t * p_in_transition,
                                            generic_level_status_params_t * p_out)
{
    app_level_server_t * p_app = PARENT_BY_FIELD_GET(app_level_server_t, server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    if (p_in->move_level > 0)
    {
        p_app->state.target_snapshot = INT16_MAX;
    }
    else
    {
        p_app->state.target_snapshot = INT16_MIN;
    }

    p_app->state.init_present_snapshot = p_app->state.present_level;

    transition_params_set(p_app,
                          (int32_t) p_in->move_level,
                          p_in_transition,
                          APP_TRANSITION_TYPE_MOVE_SET);

    LOG_PRINTF("MOVE SET: move-level: %d  delay: %d  tt: %d \n",
          p_in->move_level, p_app->state.transition.delay_ms, p_params->transition_time_ms);

    app_transition_trigger(&p_app->state.transition);
    if (p_out != NULL)
    {
        p_out->present_level = p_app->state.present_level;
        p_out->target_level = p_app->state.target_snapshot;
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0) ?
                                    0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }
}


uint32_t app_level_current_value_publish(app_level_server_t * p_app)
{
    p_app->level_get_cb(p_app, &p_app->state.present_level);
    app_transition_abort(&p_app->state.transition);
    p_app->state.target_level = p_app->state.present_level;
    p_app->state.transition.delay_ms = 0;
    memset(app_transition_ongoing_get(&p_app->state.transition), 0, sizeof(app_transition_params_t));
    memset(app_transition_requested_get(&p_app->state.transition), 0, sizeof(app_transition_params_t));
    generic_level_status_params_t status = {
                .present_level = p_app->state.present_level,
                .target_level = p_app->state.target_level,
                .remaining_time_ms = 0
            };
    return generic_level_server_status_publish(&p_app->server, &status);
}


uint32_t app_level_init(app_level_server_t * p_app, uint8_t element_index)
{
    uint32_t status = MESH_ERROR_INTERNAL;

    if (p_app == NULL)
    {
        return MESH_ERROR_NULL;
    }

    if ( (p_app->level_get_cb == NULL) ||
         ( (p_app->level_set_cb == NULL) &&
           (p_app->level_transition_cb == NULL) ) )
    {
        return MESH_ERROR_NULL;
    }

    p_app->server.settings.p_callbacks = &m_level_srv_cbs;
    status = generic_level_server_init(&p_app->server, element_index);
    if (status != MESH_SUCCESS)
    {
        return status;
    }
    p_app->state.transition.delay_start_cb = app_level_delay_start_cb;
    p_app->state.transition.transition_start_cb = app_level_transition_start_cb;
    p_app->state.transition.transition_tick_cb = app_level_transition_tick_cb;
    p_app->state.transition.transition_complete_cb = app_level_transition_complete_cb;
    p_app->state.transition.timer.msg_id = MESH_TASK_MODEL_TIMER_LL;
    p_app->state.transition.p_context = p_app;
    return app_transition_init(&p_app->state.transition);
}










