/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file app_transition.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */
#include "app_transition.h"

#include <stdlib.h>
#include "mesh_config_core.h"
#include "fsm_assistant.h"
#include "co_timer_schedule.h"
#include "bsp_lpuart.h"

/**************************************************************************************************/

#define EVENT_LIST E_START,                     \
                   E_TIMEOUT,                   \
                   E_DELAY_EXPIRED,             \
                   E_ABORT

#define STATE_LIST  S_IDLE,                     \
                    S_IN_PROGRESS

#define ACTION_LIST A_DELAY_START,              a_delay_start,         \
                    A_TRANSITION_START,         a_transition_start,    \
                    A_TRANSITION_COMPLETE,      a_transition_complete, \
                    A_TRANSITION_COMPLETE_WPS,  a_transition_complete_with_param_swap, \
                    A_TRANSITION_TICK,          a_transition_tick,     \
                    A_ABORT,                    a_abort

#define GUARD_LIST  G_SET_DELAY,            g_set_delay,           \
                    G_SET_TRANSITION,       g_set_transition,      \
                    G_TRANSITION_COMPLETE,  g_transition_complete

typedef enum
{
    DECLARE_ENUM(EVENT_LIST)
} app_transition_event_ids_t;

typedef enum
{
    DECLARE_ENUM(STATE_LIST)
} app_transition_state_ids_t;

typedef enum
{
    DECLARE_ENUM_PAIR(ACTION_LIST)
} app_transition_action_ids_t;

typedef enum
{
    DECLARE_ENUM_PAIR(GUARD_LIST)
} app_transition_guard_ids_t;

typedef void (* app_transition_fsm_action_t)(void *);
typedef bool (* app_transition_fsm_guard_t)(void *);

DECLARE_ACTION_PROTOTYPE(ACTION_LIST)
DECLARE_GUARD_PROTOTYPE(GUARD_LIST)

static void app_transition_fsm_action(fsm_action_id_t action_id, void * p_data);
static bool app_transition_fsm_guard(fsm_action_id_t action_id, void * p_data);

static const fsm_transition_t m_app_transition_fsm_transition_table[] =
{
    FSM_STATE(S_IDLE),

    FSM_STATE(S_IN_PROGRESS),
    FSM_TRANSITION(E_DELAY_EXPIRED,  G_SET_TRANSITION,       A_TRANSITION_START,        FSM_SAME_STATE),
    FSM_TRANSITION(E_DELAY_EXPIRED,  FSM_OTHERWISE,          A_TRANSITION_COMPLETE_WPS, S_IDLE),
    FSM_TRANSITION(E_TIMEOUT,        G_TRANSITION_COMPLETE,  A_TRANSITION_COMPLETE,     S_IDLE),
    FSM_TRANSITION(E_TIMEOUT,        FSM_OTHERWISE,          A_TRANSITION_TICK,         FSM_SAME_STATE),

    FSM_STATE(FSM_ANY_STATE),
    FSM_TRANSITION(E_START,          G_SET_DELAY,            A_DELAY_START,             S_IN_PROGRESS),
    FSM_TRANSITION(E_START,          G_SET_TRANSITION,       A_TRANSITION_START,        S_IN_PROGRESS),
    FSM_TRANSITION(E_START,          FSM_OTHERWISE,          A_TRANSITION_COMPLETE_WPS, S_IDLE),
    FSM_TRANSITION(E_ABORT,          FSM_ALWAYS,             A_ABORT,                   S_IDLE)
};

#if FSM_DEBUG
static const char * m_action_lookup_table[] =
{
    DECLARE_STRING_PAIR(ACTION_LIST)
};

static const char * m_guard_lookup_table[] =
{
    DECLARE_STRING_PAIR(GUARD_LIST)
};

static const char * m_event_lookup_table[] =
{
    DECLARE_STRING(EVENT_LIST)
};

static const char * m_state_lookup_table[] =
{
    DECLARE_STRING(STATE_LIST)
};
#endif   

static const fsm_const_descriptor_t m_fsm_descriptor =
{
    .transition_table = m_app_transition_fsm_transition_table,
    .transitions_count = ARRAY_SIZE(m_app_transition_fsm_transition_table),
    .initial_state = S_IDLE,
    .guard = app_transition_fsm_guard,
    .action = app_transition_fsm_action,
#if FSM_DEBUG
    .fsm_name = "app_trans",
    .action_lookup = m_action_lookup_table,
    .event_lookup = m_event_lookup_table,
    .guard_lookup = m_guard_lookup_table,
    .state_lookup = m_state_lookup_table
#endif  
};

static const app_transition_fsm_action_t app_transition_fsm_actions[] =
{
    DECLARE_HANDLER(ACTION_LIST)
};

static void app_transition_fsm_action(fsm_action_id_t action_id, void * p_data)
{
    app_transition_fsm_actions[action_id](p_data);
}

static const app_transition_fsm_guard_t app_transition_fsm_guards[] =
{
    DECLARE_HANDLER(GUARD_LIST)
};

static bool app_transition_fsm_guard(fsm_guard_id_t guard_id, void * p_data)
{
    return app_transition_fsm_guards[guard_id](p_data);
}

static void a_delay_start(void * p_data)
{
    app_transition_t * p_transition = (app_transition_t *) p_data;
    timer_sch_reschedule(&p_transition->delay_timer, bsp_time_now() + MS_TO_US(p_transition->delay_ms));
    if (p_transition->delay_start_cb != NULL)
    {
        p_transition->delay_start_cb(p_transition);
    }
}

static void a_transition_start(void * p_data)
{
    LOG_PRINTF("a_transition_start\r\n");
    app_transition_t * p_transition = (app_transition_t *) p_data;
    uint32_t abs_delta;
    uint64_t transition_time_us;
    uint64_t transition_step_us;
    uint64_t min_transition_step_us;
    
    model_timer_abort(&p_transition->timer);
    p_transition->ongoing_params = p_transition->requested_params;
    app_transition_params_t * p_params = &p_transition->ongoing_params;

    abs_delta = abs(p_params->required_delta);

    transition_time_us = MS_TO_US((uint64_t) p_params->transition_time_ms);
    transition_step_us = transition_time_us/abs_delta;
    min_transition_step_us = MS_TO_US((uint64_t) p_params->minimum_step_ms);
    if (transition_step_us < min_transition_step_us)
    {
        transition_step_us = min_transition_step_us;
    }

	if (transition_step_us < MODEL_TIMER_TIMEOUT_MIN_STEP_US)
    {
		p_transition->timer.timeout_us = MODEL_TIMER_TIMEOUT_MIN_STEP_US;
	}
    else
    {
		p_transition->timer.timeout_us = transition_step_us;
    }

    p_transition->timer.mode = MODEL_TIMER_MODE_REPEATED;
    
    uint32_t status = model_timer_schedule(&p_transition->timer);

    if ((MESH_SUCCESS == status) && p_transition->transition_start_cb)
    {
        p_transition->transition_start_cb(p_transition);
    }
}

static void a_transition_tick(void * p_data)
{
    app_transition_t * p_transition = (app_transition_t *) p_data;
    if (p_transition->transition_tick_cb != NULL)
    {
        p_transition->transition_tick_cb(p_transition);
    }
}

static void transition_complete_common(app_transition_t * p_transition)
{
    model_timer_abort(&p_transition->timer);
    app_transition_params_t * p_params = &p_transition->ongoing_params;
    p_params->transition_time_ms = 0;

    if (p_transition->transition_complete_cb != NULL)
    {
        p_transition->transition_complete_cb(p_transition);
    }
}

static void a_transition_complete(void * p_data)
{
    app_transition_t * p_transition = (app_transition_t *) p_data;
    transition_complete_common(p_transition);
}

static void a_transition_complete_with_param_swap(void * p_data)
{
    app_transition_t * p_transition = (app_transition_t *) p_data;
    p_transition->ongoing_params = p_transition->requested_params;
    transition_complete_common(p_transition);
}

static void a_abort(void * p_data)
{
    app_transition_t * p_transition = (app_transition_t *) p_data;
    p_transition->delay_ms = 0;
    p_transition->ongoing_params.transition_time_ms = 0;
    timer_sch_abort(&p_transition->delay_timer);
    model_timer_abort(&p_transition->timer);
}

static bool g_set_delay(void * p_data)
{
    app_transition_t * p_transition = (app_transition_t *) p_data;
    return (p_transition->delay_ms > 0);
}

static bool g_set_transition(void * p_data)
{
    app_transition_t * p_transition = (app_transition_t *) p_data;
    app_transition_params_t * p_params = &p_transition->requested_params;
    return (p_params->transition_time_ms > 0 &&
            p_params->transition_time_ms != MODEL_TRANSITION_TIME_UNKNOWN &&
            p_params->required_delta != 0);
}

static bool g_transition_complete(void * p_data)
{
    app_transition_t * p_transition = (app_transition_t *) p_data;
    app_transition_params_t * p_params = &p_transition->ongoing_params;
    return (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET &&
           (MODEL_TIMER_PERIOD_MS_GET(model_timer_elapsed_ticks_get(&p_transition->timer)) >= p_params->transition_time_ms));
}

static void delay_cb(timestamp_t timestamp, void * p_context)
{
    app_transition_t * p_transition = (app_transition_t *) p_context; 
    p_transition->delay_ms = 0;
    fsm_event_post(&p_transition->fsm, E_DELAY_EXPIRED, p_transition);
}

static void transition_timer_cb(void * p_context)
{
    app_transition_t * p_transition = (app_transition_t *) p_context;
    fsm_event_post(&p_transition->fsm, E_TIMEOUT, p_transition);
}

void app_transition_trigger(app_transition_t * p_transition)
{
    fsm_event_post(&p_transition->fsm, E_START, p_transition);
}

void app_transition_abort(app_transition_t *p_transition)
{
    fsm_event_post(&p_transition->fsm, E_ABORT, p_transition);
}

uint32_t app_transition_remaining_time_get(app_transition_t * p_transition)
{
    app_transition_params_t * p_params = &p_transition->ongoing_params;
    return (p_params->transition_time_ms - MODEL_TIMER_PERIOD_MS_GET(model_timer_elapsed_ticks_get(&p_transition->timer)));
}

uint32_t app_transition_elapsed_time_get(app_transition_t * p_transition)
{
    return (MODEL_TIMER_PERIOD_MS_GET(model_timer_elapsed_ticks_get(&p_transition->timer)));
}

bool app_transition_time_complete_check(app_transition_t * p_transition)
{
    app_transition_params_t * p_params = &p_transition->ongoing_params;
    return p_params->transition_time_ms == 0 && p_transition->delay_ms == 0;
}

uint32_t app_transition_init(app_transition_t * p_transition)
{
    uint32_t value;
    p_transition->delay_timer.p_context = p_transition;
    p_transition->delay_timer.cb = delay_cb;
    p_transition->timer.p_context = p_transition;
    p_transition->timer.cb = transition_timer_cb;
    value =  model_timer_create(&p_transition->timer);
    fsm_init(&p_transition->fsm, &m_fsm_descriptor);
    return value;
}
