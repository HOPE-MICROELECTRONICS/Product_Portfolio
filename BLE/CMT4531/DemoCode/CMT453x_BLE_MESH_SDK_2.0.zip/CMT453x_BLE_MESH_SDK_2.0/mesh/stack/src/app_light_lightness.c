/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file app_light_lightness.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */
#include "app_light_lightness.h"

#include <stdlib.h>

#include "utils.h"
#include "assert.h"
#include "mesh_config_entry.h"
#include "mesh_config.h"

#include "light_lightness_mc.h"
#include "light_lightness_setup_server.h"
#include "light_lightness_utils.h"
#include "model_timer.h"
#include "bearer_event.h"
#include "mesh_app_task.h"
#include "bsp_lpuart.h"

static list_node_t * mp_app_light_lightness_head;
static bearer_event_flag_t m_transition_abort_flag;
static generic_ponoff_setup_server_callbacks_t m_ponoff_srv_cbs;
static generic_dtt_server_callbacks_t m_dtt_srv_cbs;

static void transition_parameters_set(app_light_lightness_setup_server_t * p_app,
                                      int32_t delta,
                                      const model_transition_t * p_in_transition,
                                      app_transition_type_t transition_type)
{
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_params->transition_type = transition_type;
    p_params->required_delta  = delta;
    p_params->minimum_step_ms = TRANSITION_STEP_MIN_MS;
    if (p_in_transition == NULL)
    {
        p_app->state.transition.delay_ms = 0;
        light_lightness_mc_dtt_state_get(p_app->light_lightness_setup_server.state.handle,&p_params->transition_time_ms);
    }
    else
    {
        p_app->state.transition.delay_ms = p_in_transition->delay_ms;
        p_params->transition_time_ms = p_in_transition->transition_time_ms;
    }
}

static void range_get(uint16_t state_handle, light_lightness_range_status_params_t * p_range)
{
    light_lightness_mc_range_min_state_get(state_handle, &p_range->range_min);
    light_lightness_mc_range_max_state_get(state_handle, &p_range->range_max);
    light_lightness_mc_range_status_state_get(state_handle, &p_range->status);
}

static uint16_t target_snapshot_get(uint16_t state_handle, uint16_t lightness)
{
    light_lightness_range_status_params_t range;
    uint16_t target_snapshot;
    range_get(state_handle, &range);
    target_snapshot = lightness > range.range_max ? range.range_max :
                      lightness < range.range_min && lightness != 0 ? range.range_min :
                      lightness;
    return target_snapshot;
}

static void light_lightness_state_set_cb(const light_lightness_setup_server_t * p_self,
                                         const access_message_rx_meta_t * p_meta,
                                         const light_lightness_set_params_t * p_in,
                                         const model_transition_t * p_in_transition,
                                         light_lightness_status_params_t * p_out)
{
    DEBUG_PRINTF("%s\r\n",__FUNCTION__);
    app_light_lightness_setup_server_t * p_app;
    uint16_t present_lightness;
    uint32_t transition_time_ms;
    p_app = PARENT_BY_FIELD_GET(app_light_lightness_setup_server_t,
                                light_lightness_setup_server,
                                p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);

    if (p_app->app_add_notify.app_notify_set_cb != NULL)
    {
        p_app->app_add_notify.app_notify_set_cb(p_app->app_add_notify.p_app_notify_v, p_in->lightness);
    }

    p_app->app_light_lightness_get_cb(p_app, &present_lightness);

    p_app->state.target_snapshot = target_snapshot_get(p_self->state.handle, p_in->lightness);
    p_app->state.init_present_snapshot = p_app->state.present_lightness;

    light_lightness_mc_actual_state_set(p_self->state.handle, p_app->state.target_snapshot);
    if (p_app->state.target_snapshot >= LIGHT_LIGHTNESS_LAST_MIN)
    {
        light_lightness_mc_last_state_set(p_self->state.handle, p_app->state.target_snapshot,
                                                      LIGHT_LIGHTNESS_MC_WRITE_DESTINATION_FLASH_ONLY);
    }
    DEBUG_PRINTF("initialized : %d\r\n",p_self->state.initialized);
    DEBUG_PRINTF("transition_time_ms : %d\r\n",p_in_transition->transition_time_ms);
    DEBUG_PRINTF("delay_ms : %d\r\n",p_in_transition->delay_ms);    
    DEBUG_PRINTF("present_lightness : %d\r\n",present_lightness);
    DEBUG_PRINTF("p_in->lightness : %d\r\n",p_in->lightness);
    if (!p_self->state.initialized || (present_lightness != p_in->lightness))
    {
        (void) transition_parameters_set(p_app,
                                         (int32_t)p_app->state.target_snapshot - (int32_t)present_lightness,
                                         p_in_transition,
                                         APP_TRANSITION_TYPE_SET);
        transition_time_ms = p_params->transition_time_ms;
        app_transition_trigger(&p_app->state.transition);
    }
    else
    {
        transition_time_ms = 0;
    }
    if (p_out != NULL)
    {
        p_out->present_lightness = p_app->state.present_lightness;
        p_out->target_lightness  = p_app->state.target_snapshot;
        p_out->remaining_time_ms = transition_time_ms;
    }
}


static void light_lightness_state_get_cb(const light_lightness_setup_server_t * p_self,
                                         const access_message_rx_meta_t * p_meta,
                                         light_lightness_status_params_t * p_out)
{
    app_light_lightness_setup_server_t * p_app;
    uint16_t present_lightness;
    light_lightness_range_status_params_t range;

    p_app = PARENT_BY_FIELD_GET(app_light_lightness_setup_server_t,
                                light_lightness_setup_server,
                                p_self);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);

    p_app->app_light_lightness_get_cb(p_app, &present_lightness);
    p_out->present_lightness = present_lightness;

    if (p_params->transition_type == APP_TRANSITION_TYPE_MOVE_SET)
    {
        range_get(p_self->state.handle, &range);
        p_out->target_lightness = p_app->state.target_lightness == range.range_max ? UINT16_MAX : 0;
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0 || p_params->required_delta == 0) ?
                                    0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }
    else
    {
        p_out->target_lightness = p_app->state.target_lightness;
        p_out->remaining_time_ms = app_transition_remaining_time_get(&p_app->state.transition);
    }

}

static void light_lightness_state_last_get_cb(const light_lightness_setup_server_t * p_self,
                                              const access_message_rx_meta_t * p_meta,
                                              light_lightness_last_status_params_t * p_out)
{
    light_lightness_mc_last_state_get(p_self->state.handle, &p_out->lightness);
	
}

static void light_lightness_state_default_set_cb(const light_lightness_setup_server_t * p_self,
                                                 const access_message_rx_meta_t * p_meta,
                                                 const light_lightness_default_set_params_t * p_in,
                                                 light_lightness_default_status_params_t * p_out)
{
    light_lightness_mc_default_state_set(p_self->state.handle, p_in->lightness);
//    publish_default(p_self, p_in->lightness);
    if (p_out)
    {
        /* Prepare response */
        p_out->lightness = p_in->lightness;
    }
}

static void light_lightness_state_default_get_cb(const light_lightness_setup_server_t * p_self,
                                                 const access_message_rx_meta_t * p_meta,
                                                 light_lightness_default_status_params_t * p_out)
{
    light_lightness_mc_default_state_get(p_self->state.handle, &p_out->lightness);
	
}


static void light_lightness_state_range_set_cb(const light_lightness_setup_server_t * p_self,
                                               const access_message_rx_meta_t * p_meta,
                                               const light_lightness_range_set_params_t * p_in,
                                               light_lightness_range_status_params_t * p_out)
{
    light_lightness_range_status_params_t value;

    range_get(p_self->state.handle, &value);

    value.status = LIGHT_LIGHTNESS_RANGE_STATUS_SUCCESS;

    if (p_in->range_min < LIGHT_LIGHTNESS_DEFAULT_RANGE_MIN)
    {
        value.status = LIGHT_LIGHTNESS_RANGE_STATUS_CANNOT_SET_RANGE_MIN;
    }
    else if (p_in->range_max > LIGHT_LIGHTNESS_DEFAULT_RANGE_MAX)
    {
        value.status = LIGHT_LIGHTNESS_RANGE_STATUS_CANNOT_SET_RANGE_MAX;
    }
    else
    {
        value.range_min = p_in->range_min;
        value.range_max = p_in->range_max;
        light_lightness_mc_range_min_state_set(p_self->state.handle, value.range_min);
        light_lightness_mc_range_max_state_set(p_self->state.handle, value.range_max);
        light_lightness_mc_range_status_state_set(p_self->state.handle, value.status);

//        publish_range(p_self, &value);
    }

    if (p_out)
    {
        /* Prepare for a response.
         */
        p_out->range_min = value.range_min;
        p_out->range_max = value.range_max;
        p_out->status = value.status;
    }
}

static void light_lightness_state_range_get_cb(const light_lightness_setup_server_t * p_self,
                                               const access_message_rx_meta_t * p_meta,
                                               light_lightness_range_status_params_t * p_out)
{
    light_lightness_range_status_params_t range;
    range_get(p_self->state.handle, &range);
    p_out->range_min = range.range_min;
    p_out->range_max = range.range_max;
    p_out->status = range.status;
}


static void light_lightness_state_move_set_cb(const light_lightness_setup_server_t * p_self,
                                              const access_message_rx_meta_t * p_meta,
                                              const light_lightness_move_set_params_t * p_in,
                                              const model_transition_t * p_in_transition,
                                              light_lightness_status_params_t * p_out)
{
    app_light_lightness_setup_server_t * p_app;
    light_lightness_range_status_params_t range;

    p_app = PARENT_BY_FIELD_GET(app_light_lightness_setup_server_t,
                                light_lightness_setup_server,
                                p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);

    if (p_app->app_add_notify.app_notify_set_cb != NULL)
    {
        p_app->app_add_notify.app_notify_set_cb(p_app->app_add_notify.p_app_notify_v, p_in->delta);
    }

    transition_parameters_set(p_app, (int32_t)p_in->delta, p_in_transition,
                              APP_TRANSITION_TYPE_MOVE_SET);

    p_app->app_light_lightness_get_cb(p_app, &p_app->state.present_lightness);
    range_get(p_self->state.handle, &range);

    if (p_in->delta > 0 &&
        p_app->state.transition.requested_params.transition_time_ms > 0)
    {
        p_app->state.target_snapshot = range.range_max;
    }
    else if (p_in->delta < 0 &&
             p_app->state.transition.requested_params.transition_time_ms > 0)
    {
        p_app->state.target_snapshot = range.range_min;
    }
    else
    {
        p_app->state.target_snapshot = p_app->state.present_lightness;
    }

    app_transition_trigger(&p_app->state.transition);

    /* Prepare response */
    if (p_out != NULL)
    {
        p_out->present_lightness = p_app->state.present_lightness;
        p_out->target_lightness = p_app->state.target_lightness == range.range_max ? UINT16_MAX : 0;
       
        p_out->remaining_time_ms = (p_params->transition_time_ms == 0 || p_in->delta == 0) ?
                                    0 : MODEL_TRANSITION_TIME_UNKNOWN;
    }
}


static void light_lightness_state_delta_set_cb(const light_lightness_setup_server_t * p_self,
                                               const access_message_rx_meta_t * p_meta,
                                               const light_lightness_delta_set_params_t * p_in,
                                               const model_transition_t * p_in_transition,
                                               light_lightness_status_params_t * p_out)
{
    app_light_lightness_setup_server_t * p_app;
    int32_t target_lightness;
    light_lightness_range_status_params_t range;

    p_app = PARENT_BY_FIELD_GET(app_light_lightness_setup_server_t,
                                light_lightness_setup_server,
                                p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);

    if (p_app->app_add_notify.app_notify_set_cb != NULL)
    {
        p_app->app_add_notify.app_notify_set_cb(p_app->app_add_notify.p_app_notify_v, p_in->delta_lightness);
    }

    p_app->state.new_tid = model_transaction_is_new(&p_app->light_lightness_setup_server.light_lightness_srv.tid_tracker);

    p_app->app_light_lightness_get_cb(p_app, &p_app->state.present_lightness);

    range_get(p_self->state.handle, &range);

    if (p_app->state.new_tid)
    {
        p_app->state.init_present_snapshot = p_app->state.present_lightness;
    }

    target_lightness = p_app->state.new_tid ?
                        (int32_t)p_app->state.present_lightness + p_in->delta_lightness :
                        (int32_t)p_app->state.init_present_snapshot + p_in->delta_lightness;

    p_app->state.target_snapshot = target_lightness <= 0 ? 0 :
                                   target_lightness > range.range_max ? range.range_max :
                                   target_lightness < range.range_min ? range.range_min :
                                   target_lightness;

    (void) transition_parameters_set(p_app,
                                     p_in->delta_lightness,
                                     p_in_transition,
                                     APP_TRANSITION_TYPE_DELTA_SET);

    app_transition_trigger(&p_app->state.transition);

    /* Prepare response */
    if (p_out != NULL)
    {
        p_out->present_lightness = p_app->state.present_lightness;
        p_out->target_lightness  = p_app->state.target_snapshot;
        p_out->remaining_time_ms = p_params->transition_time_ms;
    }
}

static const light_lightness_setup_server_callbacks_t light_lightness_setup_srv_cbs =
{
    .light_lightness_cbs.set_cb         = light_lightness_state_set_cb,
    .light_lightness_cbs.get_cb         = light_lightness_state_get_cb,
    .light_lightness_cbs.last_get_cb    = light_lightness_state_last_get_cb,
    .light_lightness_cbs.default_set_cb = light_lightness_state_default_set_cb,
    .light_lightness_cbs.default_get_cb = light_lightness_state_default_get_cb,
    .light_lightness_cbs.range_set_cb   = light_lightness_state_range_set_cb,
    .light_lightness_cbs.range_get_cb   = light_lightness_state_range_get_cb,
    .light_lightness_cbs.move_set_cb    = light_lightness_state_move_set_cb,
    .light_lightness_cbs.delta_set_cb   = light_lightness_state_delta_set_cb
};


static uint32_t publish_lightness(app_light_lightness_setup_server_t * p_app, uint32_t remaining_time_ms)
{
    light_lightness_status_params_t publication_data;
    light_lightness_server_t * p_light_lightness_srv;
    publication_data.present_lightness = p_app->state.present_lightness;
    publication_data.target_lightness  = p_app->state.target_lightness;
    publication_data.remaining_time_ms = remaining_time_ms;
    /* Notify anyone interested that we are publishing lightness */
    if (p_app->app_add_notify.app_add_publish_cb != NULL)
    {
        p_app->app_add_notify.app_add_publish_cb(p_app->app_add_notify.p_app_publish_v, &publication_data);
    }
    p_light_lightness_srv = &p_app->light_lightness_setup_server.light_lightness_srv;
    return light_lightness_server_status_publish((const light_lightness_server_t * )p_light_lightness_srv, (const light_lightness_status_params_t *)&publication_data);
}


static inline app_light_lightness_setup_server_t * transition_to_app(const app_transition_t * p_transition)
{
    app_light_lightness_state_t   * p_state;
    p_state = PARENT_BY_FIELD_GET(app_light_lightness_state_t,
                                  transition,
                                  p_transition);
    return PARENT_BY_FIELD_GET(app_light_lightness_setup_server_t,
                               state,
                               p_state);
}

static void transition_delay_start_cb(const app_transition_t * p_transition)
{
    app_light_lightness_setup_server_t * p_app;
    p_app = transition_to_app(p_transition);
}


static void transition_start_cb(const app_transition_t * p_transition)
{
    app_light_lightness_setup_server_t * p_app;
    p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    if((p_app->state.transition.requested_params.transition_type == APP_TRANSITION_TYPE_DELTA_SET &&
       p_app->state.new_tid) ||
       (p_app->state.transition.requested_params.transition_type == APP_TRANSITION_TYPE_SET) ||
       (p_app->state.transition.requested_params.transition_type == APP_TRANSITION_TYPE_MOVE_SET))
    {
       p_app->state.initial_present_lightness = p_app->state.init_present_snapshot;
    }
    p_app->state.target_lightness = p_app->state.target_snapshot;
    p_app->state.published_ms = 0;
    if (p_app->app_light_lightness_transition_cb != NULL)
    {
        p_app->app_light_lightness_transition_cb(p_app,
                    p_params->transition_time_ms,
                    p_app->state.target_lightness);
    }
}

static void present_lightness_set(app_light_lightness_setup_server_t * p_app)
{
    if (p_app->app_light_lightness_set_cb != NULL)
    {
        p_app->app_light_lightness_set_cb(p_app, p_app->state.present_lightness);
    }
}

static void present_lightness_set_with_range_clip(app_light_lightness_setup_server_t * p_app)
{
    light_lightness_range_status_params_t range;
    range_get(p_app->light_lightness_setup_server.state.handle, &range);
    p_app->state.present_lightness =
            light_lightness_utils_actual_to_range_restrict(p_app->state.present_lightness,
                                                           range.range_min, range.range_max);
    present_lightness_set(p_app);
}

static inline bool lightness_limit_check(uint16_t present_lightness,
                                         light_lightness_range_status_params_t * p_range,
                                         int32_t required_delta)
{
    return ((required_delta > 0 && present_lightness == p_range->range_max) ||
            (required_delta < 0 && present_lightness == p_range->range_min));
}

static void transition_tick_cb(const app_transition_t * p_transition)
{
    int32_t present_lightness;
    uint32_t elapsed_ms;
    uint32_t remaining_ms;
    light_lightness_range_status_params_t range;
    app_light_lightness_setup_server_t * p_app;

    p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    elapsed_ms = app_transition_elapsed_time_get((app_transition_t *)p_transition);
    remaining_ms = app_transition_remaining_time_get((app_transition_t *)p_transition);
	
    if (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET)
    {
        int32_t delta = (p_app->state.target_lightness - p_app->state.initial_present_lightness);
        present_lightness = p_app->state.initial_present_lightness +
            (delta * (int64_t)elapsed_ms /
             (int32_t)p_params->transition_time_ms);
    }
    else
    {
        present_lightness = p_app->state.initial_present_lightness +
            (((int64_t)elapsed_ms * (int64_t)p_params->required_delta) /
             (int64_t)p_params->transition_time_ms);
    }

    range_get(p_app->light_lightness_setup_server.state.handle, &range);

    p_app->state.present_lightness = present_lightness == 0 ? 0 :
                                     MIN((int32_t)MAX(present_lightness, range.range_min), range.range_max);
    present_lightness_set(p_app);
    if (p_params->transition_type == APP_TRANSITION_TYPE_MOVE_SET &&
        lightness_limit_check(p_app->state.present_lightness, &range, p_params->required_delta))
    { 
        p_app->abort_move = true;
        bearer_event_flag_set(m_transition_abort_flag);
    }
}

static void transition_complete_cb(const app_transition_t * p_transition)
{
    app_light_lightness_setup_server_t * p_app;

    p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);

    p_app->state.target_lightness = p_app->state.target_snapshot;

    if (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET)
    {
        p_app->state.present_lightness = p_app->state.target_lightness;
    }

    present_lightness_set_with_range_clip(p_app);
 
    if (p_app->app_light_lightness_transition_cb != NULL)
    {
        p_app->app_light_lightness_transition_cb(p_app,
                    p_params->transition_time_ms,
                    p_app->state.target_lightness);
    }

    if (p_app->state.present_lightness >= LIGHT_LIGHTNESS_LAST_MIN)
    {
        light_lightness_mc_last_state_set(p_app->light_lightness_setup_server.state.handle,
                                                      p_app->state.present_lightness,
                                                      LIGHT_LIGHTNESS_MC_WRITE_DESTINATION_ALL);
    }
    light_lightness_mc_actual_state_set(p_app->light_lightness_setup_server.state.handle,p_app->state.present_lightness);
    /* Ignore status, as publish may fail due to several reasons and it is ok. */
    (void) publish_lightness(p_app, 0); 
}

static void app_onpowerup_server_set_cb(const generic_ponoff_setup_server_t * p_self,
                                        const access_message_rx_meta_t * p_meta,
                                        const generic_ponoff_set_params_t * p_in,
                                        generic_ponoff_status_params_t * p_out)
{
    light_lightness_setup_server_t * p_s_server;


    p_s_server = PARENT_BY_FIELD_GET(light_lightness_setup_server_t,
                                     generic_ponoff_setup_srv,
                                     p_self);

    light_lightness_mc_onpowerup_state_set(p_s_server->state.handle, p_in->on_powerup);

    if (p_out)
    {
        p_out->on_powerup = p_in->on_powerup;
    }
}

static void app_onpowerup_server_get_cb(const generic_ponoff_setup_server_t * p_self,
                                        const access_message_rx_meta_t * p_meta,
                                        generic_ponoff_status_params_t * p_out)
{
    light_lightness_setup_server_t * p_s_server;


    p_s_server = PARENT_BY_FIELD_GET(light_lightness_setup_server_t,
                                     generic_ponoff_setup_srv,
                                     p_self); 
    light_lightness_mc_onpowerup_state_get(p_s_server->state.handle, &p_out->on_powerup);
	
}
 
void app_dtt_server_get_cb(const generic_dtt_server_t * p_self,
                           const access_message_rx_meta_t * p_meta,
                           generic_dtt_status_params_t * p_out)
{
    generic_ponoff_setup_server_t * p_ponoff_s_server;
    light_lightness_setup_server_t * p_s_server;

    p_ponoff_s_server =
        PARENT_BY_FIELD_GET(generic_ponoff_setup_server_t,
                            generic_dtt_srv,
                            p_self);

    p_s_server =
        PARENT_BY_FIELD_GET(light_lightness_setup_server_t,
                            generic_ponoff_setup_srv,
                            p_ponoff_s_server);
 
    light_lightness_mc_dtt_state_get(p_s_server->state.handle, &p_out->transition_time_ms);
}
 
void app_dtt_server_set_cb(const generic_dtt_server_t * p_self,
                           const access_message_rx_meta_t * p_meta,
                           const generic_dtt_set_params_t * p_in,
                           generic_dtt_status_params_t * p_out)
{
    generic_dtt_status_params_t status_params;
    generic_ponoff_setup_server_t * p_ponoff_s_server;
    light_lightness_setup_server_t * p_s_server;

    p_ponoff_s_server = PARENT_BY_FIELD_GET(generic_ponoff_setup_server_t,
                                            generic_dtt_srv,
                                            p_self);

    p_s_server = PARENT_BY_FIELD_GET(light_lightness_setup_server_t,
                                     generic_ponoff_setup_srv,
                                     p_ponoff_s_server);

    light_lightness_mc_dtt_state_set(p_s_server->state.handle, p_in->transition_time_ms);
    status_params.transition_time_ms = p_in->transition_time_ms;

    if (p_out)
    {
        p_out->transition_time_ms = p_in->transition_time_ms;
    }
}


static uint32_t app_light_lightness_setup_server_init(light_lightness_setup_server_t * p_setup_server,
                                                      uint8_t element_index)
{
    uint32_t status;

    if (!p_setup_server)
    {
        return MESH_ERROR_NULL;
    }

    p_setup_server->settings.p_callbacks = &light_lightness_setup_srv_cbs;

    m_ponoff_srv_cbs.ponoff_cbs.set_cb = app_onpowerup_server_set_cb;
    m_ponoff_srv_cbs.ponoff_cbs.get_cb = app_onpowerup_server_get_cb;
    p_setup_server->generic_ponoff_setup_srv.settings.p_callbacks = &m_ponoff_srv_cbs;

    m_dtt_srv_cbs.dtt_cbs.set_cb = app_dtt_server_set_cb;
    m_dtt_srv_cbs.dtt_cbs.get_cb = app_dtt_server_get_cb;
    p_setup_server->generic_ponoff_setup_srv.generic_dtt_srv.settings.p_callbacks = &m_dtt_srv_cbs;

    status = light_lightness_mc_open(&p_setup_server->state.handle);
    if (status != MESH_SUCCESS)
    {
        return status;
    }
    p_setup_server->state.initialized = false;

    return light_lightness_setup_server_init(p_setup_server, element_index);
}

static bool m_transition_abort_flag_cb(void)
{
    LIST_FOREACH(p_iter, mp_app_light_lightness_head)
    {
        app_light_lightness_setup_server_t * p_app = PARENT_BY_FIELD_GET(app_light_lightness_setup_server_t,
                                                                         node,
                                                                         p_iter);
        if (p_app->abort_move)
        {
            p_app->abort_move = false;
            app_transition_abort(&p_app->state.transition);
        }
    }
    return true;
}


uint32_t app_light_lightness_model_init(app_light_lightness_setup_server_t * p_app, uint8_t element)
{
    uint32_t status = MESH_ERROR_NULL;
    if (p_app == NULL)
    {
        return status;
    }
    if ( (p_app->app_light_lightness_get_cb == NULL) ||
         ( (p_app->app_light_lightness_set_cb == NULL) &&
           (p_app->app_light_lightness_transition_cb == NULL) ) )
    {
        return MESH_ERROR_NULL;
    }
    status = app_light_lightness_setup_server_init(&p_app->light_lightness_setup_server, element);
    if (status != MESH_SUCCESS)
    {
        return status;
    }
    p_app->state.transition.delay_start_cb = transition_delay_start_cb;
    p_app->state.transition.transition_start_cb = transition_start_cb;
    p_app->state.transition.transition_tick_cb = transition_tick_cb;
    p_app->state.transition.transition_complete_cb = transition_complete_cb;
    p_app->state.transition.timer.msg_id = MESH_TASK_MODEL_TIMER_LL;
    p_app->state.transition.p_context = &p_app->state.transition;
    p_app->abort_move = false;
    status = app_transition_init(&p_app->state.transition);

    if (status == MESH_SUCCESS)
    {
        list_add(&mp_app_light_lightness_head, &p_app->node);
        m_transition_abort_flag = bearer_event_flag_add(m_transition_abort_flag_cb);
    }

    return status;
}

uint32_t app_light_lightness_binding_setup(app_light_lightness_setup_server_t * p_app)
{
    light_lightness_saved_values_t state;
    light_lightness_setup_server_t * p_s_server;
    uint16_t index;

    if (p_app == NULL)
    {
        return MESH_ERROR_NULL;
    }

    p_s_server = &p_app->light_lightness_setup_server;
    index    = p_s_server->state.handle;
    light_lightness_mc_range_status_state_get(index, &state.range.status);
    light_lightness_mc_range_min_state_get(index, &state.range.range_min);
    light_lightness_mc_range_max_state_get(index, &state.range.range_max);
    light_lightness_mc_onpowerup_state_get(index, &state.onpowerup);
    light_lightness_mc_actual_state_get(index, &state.actual_lightness);
    light_lightness_mc_last_state_get(index, &state.last_lightness);
    light_lightness_mc_default_state_get(index, &state.default_lightness); 
    return light_lightness_ponoff_binding_setup(p_s_server, &state);
}

