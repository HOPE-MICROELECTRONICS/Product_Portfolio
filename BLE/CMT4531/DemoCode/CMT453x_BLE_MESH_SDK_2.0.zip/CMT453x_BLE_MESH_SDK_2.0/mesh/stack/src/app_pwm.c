#include "app_pwm.h"
#include "mesh_error.h"
#include <string.h>
#include <stdio.h>
#include "bsp_lpuart.h"
#include "global_var.h"

extern uint32_t SystemCoreClock;



static inline void drv_timer_compare(TIM_Module* TIMx, uint8_t cc_channel, uint32_t cc_value, bool enable_int)
{
//    LOG_PRINTF("cc_value --> %d\r\n",cc_value);
	if(PWM_CHANNEL_0 == cc_channel)	
		TIMx->CCDAT1 = (uint16_t)cc_value;
	else if(PWM_CHANNEL_1 == cc_channel)	
		TIMx->CCDAT2 = (uint16_t)cc_value;
	else if(PWM_CHANNEL_2 == cc_channel)	
		TIMx->CCDAT3 = (uint16_t)cc_value;    
	else if(PWM_CHANNEL_3 == cc_channel)	
		TIMx->CCDAT4 = (uint16_t)cc_value;    
	else if(PWM_CHANNEL_0N == cc_channel)	
		TIMx->CCDAT1 = (uint16_t)cc_value; 
	else if(PWM_CHANNEL_1N == cc_channel)	
		TIMx->CCDAT2 = (uint16_t)cc_value; 
	else if(PWM_CHANNEL_2N == cc_channel)	
		TIMx->CCDAT3 = (uint16_t)cc_value; 
	else if(PWM_CHANNEL_3N == cc_channel)	
		TIMx->CCDAT4 = (uint16_t)cc_value;     
}


static void pwm_transition_n_to_m(app_pwm_t *p_instance, uint8_t channel, uint16_t ticks)
{
    app_pwm_cb_t            * p_cb     = p_instance->p_cb;
    app_pwm_channel_cb_t    * p_ch_cb  = &p_cb->channels_cb[channel];
	if(ticks >= p_cb->period)
		ticks = p_cb->period;
    drv_timer_compare(p_instance->p_timer, channel, ticks, false);
	p_ch_cb->pulsewidth = ticks;
}

static void pwm_transition(app_pwm_t * p_instance, uint8_t channel, uint16_t ticks)
{
	pwm_transition_n_to_m(p_instance, channel, ticks);
}

ret_code_t app_pwm_channel_duty_ticks_set(app_pwm_t *       p_instance,
                                          uint8_t           channel,
                                          uint16_t          ticks)
{
//    LOG_PRINTF("ticks --> %d\r\n",ticks);
    app_pwm_cb_t         * p_cb    = p_instance->p_cb;
    app_pwm_channel_cb_t * p_ch_cb = &p_cb->channels_cb[channel];
    if (ticks == p_ch_cb->pulsewidth)
    {
        return MESH_SUCCESS;     
    }
    pwm_transition(p_instance, channel, ticks);
    return MESH_SUCCESS;
}
uint16_t app_pwm_channel_duty_ticks_get(app_pwm_t * p_instance, uint8_t channel)
{
    app_pwm_cb_t         * p_cb      = p_instance->p_cb;
    app_pwm_channel_cb_t * p_ch_cb   = &p_cb->channels_cb[channel];
    return p_ch_cb->pulsewidth;
}
ret_code_t app_pwm_channel_duty_set(app_pwm_t *p_instance,
                                  uint8_t channel, app_pwm_duty_t duty)
{
    uint16_t ticks = ((uint32_t)app_pwm_cycle_ticks_get(p_instance) * (uint32_t)duty) / 100UL;
    return app_pwm_channel_duty_ticks_set(p_instance, channel, ticks);
}
app_pwm_duty_t app_pwm_channel_duty_get(app_pwm_t * p_instance, uint8_t channel)
{
    uint32_t value = ((uint32_t)app_pwm_channel_duty_ticks_get(p_instance, channel) * 100UL) \
                     / (uint32_t)app_pwm_cycle_ticks_get(p_instance);
    return (app_pwm_duty_t)value;
}

static uint32_t drv_timer_us_to_ticks(TIM_Module *TIMx, uint32_t sysclk, uint32_t period_us)
{
	uint16_t prescaler = TIMx->PSC;
    //�����޸ĳ�1024
	uint32_t ticks = period_us * (sysclk / (prescaler+1) / 1000000);	
	return ticks;
}	


static void app_pwm_channel_config(app_pwm_t * p_instance, uint8_t channel)
{
    LOG_PRINTF("app_pwm_channel_config : %d\r\n",*(volatile uint32_t *)SOFT_RESET_FLAG);
	switch(channel)
	{
		case PWM_CHANNEL_0:
            #ifdef ALEXA
            if(*(volatile uint32_t *)SOFT_RESET_FLAG != 1)
            #endif
            {
                OCInitType TIM_OCInitStructure =
                {
                    .OcMode = TIM_OCMODE_PWM1,
                    .OutputState = TIM_OUTPUT_STATE_ENABLE,
                    .OutputNState = TIM_OUTPUT_NSTATE_ENABLE,
                    .Pulse = 0,
                    .OcPolarity = TIM_OC_POLARITY_HIGH, 
                    .OcNPolarity = TIM_OCN_POLARITY_LOW, 
                    .OcIdleState  = TIM_OC_IDLE_STATE_SET,
                    .OcNIdleState = TIM_OC_IDLE_STATE_RESET,
                };
                TIM_InitOc1(p_instance->p_timer, &TIM_OCInitStructure); 
            }
			TIM_EnableOc1Preload(p_instance->p_timer, TIM_OC_PRE_LOAD_ENABLE);
			break;		
		case PWM_CHANNEL_1:
            #ifdef ALEXA
            if(*(volatile uint32_t *)SOFT_RESET_FLAG != 1)
            #endif
            {
                OCInitType TIM_OCInitStructure =
                {
                    .OcMode = TIM_OCMODE_PWM1,
                    .OutputState = TIM_OUTPUT_STATE_ENABLE,
                    .OutputNState = TIM_OUTPUT_NSTATE_ENABLE,
                    .Pulse = 0,
                    .OcPolarity = TIM_OC_POLARITY_HIGH, 
                    .OcNPolarity = TIM_OCN_POLARITY_LOW, 
                    .OcIdleState  = TIM_OC_IDLE_STATE_SET,
                    .OcNIdleState = TIM_OC_IDLE_STATE_RESET,
                };                
                TIM_InitOc2(p_instance->p_timer, &TIM_OCInitStructure);
            }            
			TIM_ConfigOc2Preload(p_instance->p_timer, TIM_OC_PRE_LOAD_ENABLE);
			break;        
		case PWM_CHANNEL_2:
            #ifdef ALEXA
            if(*(volatile uint32_t *)SOFT_RESET_FLAG != 1)
            #endif
            {
                OCInitType TIM_OCInitStructure =
                {
                    .OcMode = TIM_OCMODE_PWM1,
                    .OutputState = TIM_OUTPUT_STATE_ENABLE,
                    .OutputNState = TIM_OUTPUT_NSTATE_ENABLE,
                    .Pulse = 0,
                    .OcPolarity = TIM_OC_POLARITY_HIGH, 
                    .OcNPolarity = TIM_OCN_POLARITY_LOW, 
                    .OcIdleState  = TIM_OC_IDLE_STATE_SET,
                    .OcNIdleState = TIM_OC_IDLE_STATE_RESET,
                };                
                TIM_InitOc3(p_instance->p_timer, &TIM_OCInitStructure); 
            }            
			TIM_ConfigOc3Preload(p_instance->p_timer, TIM_OC_PRE_LOAD_ENABLE);
			break;        
		case PWM_CHANNEL_3:
            #ifdef ALEXA
            if(*(volatile uint32_t *)SOFT_RESET_FLAG != 1)
            #endif
            {
                OCInitType TIM_OCInitStructure =
                {
                    .OcMode = TIM_OCMODE_PWM1,
                    .OutputState = TIM_OUTPUT_STATE_ENABLE,
                    .OutputNState = TIM_OUTPUT_NSTATE_ENABLE,
                    .Pulse = 0,
                    .OcPolarity = TIM_OC_POLARITY_HIGH, 
                    .OcNPolarity = TIM_OCN_POLARITY_LOW, 
                    .OcIdleState  = TIM_OC_IDLE_STATE_SET,
                    .OcNIdleState = TIM_OC_IDLE_STATE_RESET,
                };                
                TIM_InitOc4(p_instance->p_timer, &TIM_OCInitStructure); 
            }            
			TIM_ConfigOc4Preload(p_instance->p_timer, TIM_OC_PRE_LOAD_ENABLE);
			break; 
		case PWM_CHANNEL_0N:
            #ifdef ALEXA
            if(*(volatile uint32_t *)SOFT_RESET_FLAG != 1)
            #endif
            {
                OCInitType TIM_OCInitStructure =
                {
                    .OcMode = TIM_OCMODE_PWM2,
                    .OutputState = TIM_OUTPUT_STATE_ENABLE,
                    .OutputNState = TIM_OUTPUT_NSTATE_ENABLE,
                    .Pulse = 0,
                    .OcPolarity = TIM_OC_POLARITY_LOW, 
                    .OcNPolarity = TIM_OCN_POLARITY_HIGH, 
                    .OcIdleState  = TIM_OC_IDLE_STATE_SET,
                    .OcNIdleState = TIM_OC_IDLE_STATE_RESET,
                };                
                TIM_InitOc1(p_instance->p_timer, &TIM_OCInitStructure); 
            }            
			TIM_EnableOc1Preload(p_instance->p_timer, TIM_OC_PRE_LOAD_ENABLE);
            
			break; 
		case PWM_CHANNEL_1N:
            #ifdef ALEXA
            if(*(volatile uint32_t *)SOFT_RESET_FLAG != 1)
            #endif
            {
                OCInitType TIM_OCInitStructure =
                {
                    .OcMode = TIM_OCMODE_PWM2,
                    .OutputState = TIM_OUTPUT_STATE_ENABLE,
                    .OutputNState = TIM_OUTPUT_NSTATE_ENABLE,
                    .Pulse = 0,
                    .OcPolarity = TIM_OC_POLARITY_LOW, 
                    .OcNPolarity = TIM_OCN_POLARITY_HIGH, 
                    .OcIdleState  = TIM_OC_IDLE_STATE_SET,
                    .OcNIdleState = TIM_OC_IDLE_STATE_RESET,
                };                
                TIM_InitOc2(p_instance->p_timer, &TIM_OCInitStructure); 
            }            
			TIM_ConfigOc2Preload(p_instance->p_timer, TIM_OC_PRE_LOAD_ENABLE);
			break;
		case PWM_CHANNEL_2N:
            #ifdef ALEXA
            if(*(volatile uint32_t *)SOFT_RESET_FLAG != 1)
            #endif
            {
                OCInitType TIM_OCInitStructure =
                {
                    .OcMode = TIM_OCMODE_PWM2,
                    .OutputState = TIM_OUTPUT_STATE_ENABLE,
                    .OutputNState = TIM_OUTPUT_NSTATE_ENABLE,
                    .Pulse = 0,
                    .OcPolarity = TIM_OC_POLARITY_LOW, 
                    .OcNPolarity = TIM_OCN_POLARITY_HIGH, 
                    .OcIdleState  = TIM_OC_IDLE_STATE_SET,
                    .OcNIdleState = TIM_OC_IDLE_STATE_RESET,
                };                
                TIM_InitOc3(p_instance->p_timer, &TIM_OCInitStructure); 
            }            
			TIM_ConfigOc3Preload(p_instance->p_timer, TIM_OC_PRE_LOAD_ENABLE);
			break;
		case PWM_CHANNEL_3N:
            #ifdef ALEXA
            if(*(volatile uint32_t *)SOFT_RESET_FLAG != 1)
            #endif
            {
                OCInitType TIM_OCInitStructure =
                {
                    .OcMode = TIM_OCMODE_PWM2,
                    .OutputState = TIM_OUTPUT_STATE_ENABLE,
                    .OutputNState = TIM_OUTPUT_NSTATE_ENABLE,
                    .Pulse = 0,
                    .OcPolarity = TIM_OC_POLARITY_LOW, 
                    .OcNPolarity = TIM_OCN_POLARITY_HIGH, 
                    .OcIdleState  = TIM_OC_IDLE_STATE_SET,
                    .OcNIdleState = TIM_OC_IDLE_STATE_RESET,
                };                
                TIM_InitOc4(p_instance->p_timer, &TIM_OCInitStructure); 
            }            
			TIM_ConfigOc4Preload(p_instance->p_timer, TIM_OC_PRE_LOAD_ENABLE);
			break;            
	}
}
static void app_pwm_timer_init(TIM_Module * TIMx, uint32_t sysclk, app_pwm_config_t const * const p_config)
{
	uint16_t PrescalerValue;	
    PrescalerValue = (uint16_t)(sysclk / 16000000) - 1; 
	TIM_TimeBaseInitType TIM_TimeBaseStructure;
    TIM_TimeBaseStructure.Period    = 100 *16-1;
    TIM_TimeBaseStructure.Prescaler = PrescalerValue;
    TIM_TimeBaseStructure.ClkDiv    = 0;
    TIM_TimeBaseStructure.CntMode   = TIM_CNT_MODE_UP;
    TIM_InitTimeBase(TIMx, &TIM_TimeBaseStructure);
}
static void GPIO_Configuration_pwm(pwm_utils_contex_t * p_ctx)
{
    GPIO_InitType GPIO_InitStructure;
    GPIO_InitStruct(&GPIO_InitStructure);
    GPIO_InitStructure.Pin        = p_ctx->p_pwm_config->gpio_pin;
    GPIO_InitStructure.GPIO_Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_SPEED_HIGH;
    GPIO_InitStructure.GPIO_Current = GPIO_DC_LOW;
    if(p_ctx->p_pwm->p_timer == TIM3)
        GPIO_InitStructure.GPIO_Alternate = GPIO_AF2_TIM3;
    else if(p_ctx->p_pwm->p_timer == TIM1)
        GPIO_InitStructure.GPIO_Alternate = GPIO_AF1_TIM1;
    GPIO_InitPeripheral(p_ctx->p_pwm_config->gpio_port, &GPIO_InitStructure);
}
static void RCC_Configuration_pwm(pwm_utils_contex_t * p_ctx)
{
    if(p_ctx->p_pwm->p_timer == TIM3){
        RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM3, ENABLE);
        RCC_EnableAPB2PeriphClk( RCC_APB2_PERIPH_GPIOB| RCC_APB2_PERIPH_AFIO, ENABLE);
    }
        
    if(p_ctx->p_pwm->p_timer == TIM1){
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_TIM1, ENABLE);
        RCC_EnableAPB2PeriphClk( RCC_APB2_PERIPH_GPIOB| RCC_APB2_PERIPH_AFIO, ENABLE);
    }
        
    
    
}
ret_code_t app_pwm_init(pwm_utils_contex_t * p_ctx)
{
    app_pwm_cb_t * p_cb = p_ctx->p_pwm->p_cb;
	uint32_t sysclk = SystemCoreClock;
    
	RCC_Configuration_pwm(p_ctx);
	GPIO_Configuration_pwm(p_ctx);
	app_pwm_timer_init(p_ctx->p_pwm->p_timer, sysclk, p_ctx->p_pwm_config);
    app_pwm_channel_config(p_ctx->p_pwm, p_ctx->channel);
    app_pwm_channel_duty_ticks_set(p_ctx->p_pwm, p_ctx->channel, 0);   

    uint32_t ticks = drv_timer_us_to_ticks(p_ctx->p_pwm->p_timer, sysclk, 100);
    p_cb->period = ticks; 
    return MESH_SUCCESS;
}


uint16_t app_pwm_cycle_ticks_get(app_pwm_t * p_instance)
{
    app_pwm_cb_t * p_cb = p_instance->p_cb;
    return (uint16_t)p_cb->period;
}
void app_pwm_enable(app_pwm_t * p_instance)
{	
	TIM_ConfigArPreload(p_instance->p_timer, ENABLE);
    TIM_Enable(p_instance->p_timer, ENABLE);
    if(p_instance->p_timer == TIM1){
        TIM_EnableCtrlPwmOutputs(TIM1, ENABLE);
    }
    return;
}











