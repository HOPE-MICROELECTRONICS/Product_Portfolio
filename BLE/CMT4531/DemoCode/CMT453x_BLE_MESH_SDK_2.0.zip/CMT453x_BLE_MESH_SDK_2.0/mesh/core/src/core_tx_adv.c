#include <stdint.h>
#include "core_tx_adv.h"
#include "core_tx.h"
#include "mesh_opt_core.h"
#include "mesh_config_entry.h"
#include "stdio.h"
#include "bsp_lpuart.h"
#include "advertiser.h"
#include "core_tx_adv_config.h"




static struct
{
    core_tx_role_t role;
    adv_packet_t * p_packet;
} m_current_alloc;
static core_tx_bearer_t m_bearer;
static core_tx_alloc_result_t packet_alloc(core_tx_bearer_t * p_bearer, const core_tx_alloc_params_t * p_params);
static void packet_send(core_tx_bearer_t * p_bearer, const uint8_t * p_packet, uint32_t packet_length);
static void packet_discard(core_tx_bearer_t * p_bearer);
static uint8_t m_originator_adv_packet_buffer[CORE_TX_QUEUE_BUFFER_SIZE_ORIGINATOR];
static uint8_t m_relay_adv_packet_buffer[CORE_TX_QUEUE_BUFFER_SIZE_RELAY];
static const core_tx_bearer_interface_t m_interface = {packet_alloc,
                                                       packet_send,
                                                       packet_discard};


extern mesh_dynamic_param_t mesh_dynamic_param;
                                             
static core_tx_alloc_result_t packet_alloc(core_tx_bearer_t * p_bearer, const core_tx_alloc_params_t * p_params)
{
    m_current_alloc.p_packet = advertiser_packet_alloc(&m_bearer_roles[p_params->role].advertiser, sizeof(ble_ad_header_t) + p_params->net_packet_len);

    if (m_current_alloc.p_packet == NULL)
    {
        
        return CORE_TX_ALLOC_FAIL_NO_MEM;
    }
    else
    {
        m_current_alloc.p_packet->token          = p_params->token;       
        m_current_alloc.p_packet->config.repeats = m_bearer_roles[p_params->role].adv_tx_count;
        m_current_alloc.role                     = p_params->role;

        return CORE_TX_ALLOC_SUCCESS;
    }
}
static void packet_send(core_tx_bearer_t * p_bearer, const uint8_t * p_packet, uint32_t packet_length)
{
    ble_ad_data_t * p_ad_data = (ble_ad_data_t *) &m_current_alloc.p_packet->packet.payload[0];
    p_ad_data->type           = AD_TYPE_MESH;
    p_ad_data->length         = BLE_AD_DATA_OVERHEAD + packet_length;
    memcpy(p_ad_data->data, p_packet, packet_length);
    #ifdef ALEXA
    if(m_current_alloc.role == CORE_TX_ROLE_ORIGINATOR){
        m_bearer_roles[m_current_alloc.role].adv_tx_count = mesh_dynamic_param.original_tx_cnt;
        m_current_alloc.p_packet->config.duration = mesh_dynamic_param.original_duration;
    }else{
        m_bearer_roles[m_current_alloc.role].adv_tx_count = mesh_dynamic_param.relay_tx_cnt;
        m_current_alloc.p_packet->config.duration = mesh_dynamic_param.relay_duration;
    }
    m_current_alloc.p_packet->config.repeats = m_bearer_roles[m_current_alloc.role].adv_tx_count;
    #endif
    
    LOG_PRINTF("adv_tx_count --> %d\r\n",m_bearer_roles[m_current_alloc.role].adv_tx_count);
    advertiser_packet_send(&m_bearer_roles[m_current_alloc.role].advertiser, m_current_alloc.p_packet);
    m_current_alloc.p_packet = NULL;
}
static void packet_discard(core_tx_bearer_t * p_bearer)
{
    advertiser_packet_discard(&m_bearer_roles[m_current_alloc.role].advertiser,
                              m_current_alloc.p_packet);
    m_current_alloc.p_packet = NULL;
}




static void adv_tx_complete_callback(advertiser_t * p_adv,
                                     mesh_tx_token_t token,
                                     timestamp_t timestamp)
{
    core_tx_role_t role = (core_tx_role_t) (PARENT_BY_FIELD_GET(adv_bearer_role_t, advertiser, p_adv) - &m_bearer_roles[0]);
    core_tx_complete(&m_bearer, role, timestamp, token);
}

void core_tx_adv_init(void)
{
    m_bearer_roles[CORE_TX_ROLE_ORIGINATOR].adv_tx_count = CORE_TX_REPEAT_ORIGINATOR_DEFAULT;
    m_bearer_roles[CORE_TX_ROLE_ORIGINATOR].advertiser.role = CORE_TX_ROLE_ORIGINATOR;
    advertiser_instance_init(&m_bearer_roles[CORE_TX_ROLE_ORIGINATOR].advertiser,
                             adv_tx_complete_callback,
                             m_originator_adv_packet_buffer,
                             sizeof(m_originator_adv_packet_buffer));
    advertiser_enable(&m_bearer_roles[CORE_TX_ROLE_ORIGINATOR].advertiser);
    
    
    
    m_bearer_roles[CORE_TX_ROLE_RELAY].adv_tx_count = CORE_TX_REPEAT_RELAY_DEFAULT;
    m_bearer_roles[CORE_TX_ROLE_RELAY].advertiser.role = CORE_TX_ROLE_RELAY;
    advertiser_instance_init(&m_bearer_roles[CORE_TX_ROLE_RELAY].advertiser,
                             NULL,
                             m_relay_adv_packet_buffer,
                             sizeof(m_relay_adv_packet_buffer));
    advertiser_enable(&m_bearer_roles[CORE_TX_ROLE_RELAY].advertiser);    
    
    
    core_tx_bearer_add(&m_bearer, &m_interface, CORE_TX_BEARER_TYPE_ADV);
}

bool core_tx_adv_is_enabled(core_tx_role_t role)
{
    return advertiser_is_enabled(&m_bearer_roles[role].advertiser);
}



