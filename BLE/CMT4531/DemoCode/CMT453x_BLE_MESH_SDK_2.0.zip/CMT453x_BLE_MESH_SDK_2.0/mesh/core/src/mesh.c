#include "mesh.h"
#include "device_state_manager.h"
#include "mesh_utils.h"
#include "event.h"
#include "bearer_handler.h"
#include "core_tx_adv_config.h"
#include "transport.h"
#include "proxy.h"
#include "access.h"
#include "scanner.h"
#include "ad_listener.h"
#include "core_tx_adv.h"
#include "mesh_configure.h"
#include "net_state.h"
#include "config_server.h"
#include "access.h"
#include "access_config.h"
#include "proxy.h"
#include "network.h"
#include "transport.h"
#include "Typedefine.h"
#include "app_onoff.h"
#include "generic_onoff_client.h"
#include "scanner.h"
#include "ke_timer.h"
#include "msg_cache.h"
#include "transport.h"
#include "global_var.h"
#include "mesh_aes.h"
#include "device_state_manager.h"
#include "timer_scheduler.h"
#include "bearer_event.h"
#include "mesh_flash.h"
#include "mesh_config.h"
#include "mesh_opt_core.h"
#include "bearer_handler.h"
#include "mesh_provisionee.h"
#include "prov_proxy_adv.h"
#include "mesh_gatt.h"
#include "mesh_app_task.h"
#include "bsp_led.h"
#include "model_config_file.h"
#include "health_server.h"
#include "mal_adv_inst.h"
#include "net_beacon.h"
#include "proxy.h"
#include "bsp_lpuart.h"



static enum
{
    MESH_STATE_UNINITIALIZED, 
    MESH_STATE_INITIALIZED,   
    MESH_STATE_ENABLED,       
    MESH_STATE_DISABLING,     
    MESH_STATE_DISABLED,      
} m_mesh_state;


static mesh_tx_token_t m_tx_token = MESH_INITIAL_TOKEN;

#define MAX_SCAN_PACKET_SIZE   (200)
typedef struct
{
    packet_buffer_t       packet_buffer;
    uint8_t               packet_buffer_data[MAX_SCAN_PACKET_SIZE];    
    packet_buffer_packet_t * p_buffer_packet;
} m_scan_packet_t;
static m_scan_packet_t m_scan_packet;

void mesh_evt_handler_add(mesh_evt_handler_t * p_handler_params)
{
    event_handler_add(p_handler_params);
}

static inline bool rx_group_address_get(uint16_t address, mesh_address_t * p_address)
{
    p_address->value = address;
    p_address->type = MESH_ADDRESS_TYPE_GROUP;
    p_address->p_virtual_uuid = NULL;

    switch (address)
    {
        case MESH_ALL_PROXIES_ADDR:
            return proxy_is_enabled();

        case MESH_ALL_FRIENDS_ADDR:
        {

            return false;
        }
        case MESH_ALL_RELAYS_ADDR:
        {
            mesh_opt_core_adv_t options;
            mesh_opt_core_adv_get(CORE_TX_ROLE_RELAY, &options);
            return options.enabled;
        }
        case MESH_ALL_NODES_ADDR:
            return true;
        default:
        {
            dsm_handle_t handle;
            return address_nonvirtual_subscription_exists(address, &handle);
        }
    }
}
bool mesh_rx_address_get(uint16_t raw_address, mesh_address_t * p_address)
{
    mesh_address_type_t type = mesh_address_type_get(raw_address);
    bool rx_addr_exists = false;
    switch (type)
    {
        case MESH_ADDRESS_TYPE_UNICAST:
            rx_addr_exists = rx_unicast_address_get(raw_address, p_address);
            break;
        case MESH_ADDRESS_TYPE_GROUP:
            rx_addr_exists = rx_group_address_get(raw_address, p_address);
            break;
        case MESH_ADDRESS_TYPE_VIRTUAL:
            break;
        default:
            break;
    }
    return rx_addr_exists;
}

bool mesh_is_address_rx(const mesh_address_t * p_addr)
{
    
    switch (p_addr->type)
    {
        case MESH_ADDRESS_TYPE_UNICAST:
        case MESH_ADDRESS_TYPE_GROUP:
        {
            mesh_address_t dummy;
            return mesh_rx_address_get(p_addr->value, &dummy);
        }
        case MESH_ADDRESS_TYPE_VIRTUAL:
        {
            dsm_handle_t virtual_addr_index;
            if (virtual_address_uuid_index_get(p_addr->p_virtual_uuid, &virtual_addr_index))
            {
                return (dsm_virtual_addresses[virtual_addr_index].subscription_count > 0);
            }
            return false;
        }
        default:
            return false;
    }
}

bool mesh_is_device_provisioned(void)
{
    dsm_local_unicast_address_t addr;
    dsm_local_unicast_addresses_get(&addr);
    return (addr.address_start != MESH_ADDR_UNASSIGNED);
} 
void mesh_unicast_address_get(uint16_t * p_addr_start, uint16_t * p_addr_count)
{
    *p_addr_start = dsm_local_unicast_addr.address_start;
    *p_addr_count = dsm_local_unicast_addr.count;
}
void mesh_app_secmat_next_get(const mesh_network_secmat_t * p_network_secmat, uint8_t aid, const mesh_application_secmat_t ** pp_app_secmat)
{
    dsm_handle_t subnet_handle = dsm_subnet_handle_get(p_network_secmat);
    if (subnet_handle == DSM_HANDLE_INVALID)
    {
        *pp_app_secmat = NULL;
    }
    else
    {
        get_app_secmat(subnet_handle,aid, pp_app_secmat);
    }
}



int mesh_task_ad_report_mesh_handler(ke_msg_id_t const msgid,void const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    packet_buffer_packet_t * p_packet;
    if(packet_buffer_pop(&m_scan_packet.packet_buffer, &p_packet) == MESH_SUCCESS)
    {
        struct ad_report_cmd *p_buf = (struct ad_report_cmd *)p_packet->packet;
        network_packet_in(p_buf->p_packet, p_buf->ad_packet_length, &p_buf->metadata); 
        packet_buffer_free(&m_scan_packet.packet_buffer, p_packet); 
    }     
    return (KE_MSG_CONSUMED);
}
static void packet_in(const uint8_t * p_packet, uint32_t ad_packet_length, const mesh_rx_metadata_t * p_metadata)
{
    if(check_ke_mem_used_size() < 10000){
        uint32_t status = MESH_ERROR_NO_MEM;
        do
        {
            status = packet_buffer_reserve(&m_scan_packet.packet_buffer, &m_scan_packet.p_buffer_packet, sizeof(struct ad_report_cmd)+ad_packet_length);   
            if (status != MESH_SUCCESS)
            {
                break;
            }
            struct ad_report_cmd *p_buf = (struct ad_report_cmd *) m_scan_packet.p_buffer_packet->packet;
            p_buf->ad_packet_length = ad_packet_length;
            p_buf->metadata = *p_metadata;
            memcpy(p_buf->p_packet,p_packet,ad_packet_length);
            packet_buffer_commit(&m_scan_packet.packet_buffer, m_scan_packet.p_buffer_packet, sizeof(struct ad_report_cmd)+ad_packet_length);        
            ke_msg_send_basic(MESH_TASK_AD_REPORT_MESH, TASK_MESH, TASK_NONE);
        } while (0);      
    } 
}

AD_LISTENER(m_mesh_packet_listener) = {
    .ad_type = AD_TYPE_MESH,
    .adv_packet_type = BLE_PACKET_TYPE_ADV_NONCONN_IND,
    .handler = packet_in,
};

static inline bool get_net_secmat_by_nid(dsm_handle_t subnet_handle, uint8_t nid,
                                  const mesh_network_secmat_t * p_secmat_cmp,
                                  const mesh_network_secmat_t * p_secmat_secondary_cmp,
                                  const mesh_network_secmat_t ** pp_secmat_out,
                                  const mesh_network_secmat_t ** pp_secmat_secondary_out)
{
    if (!bitfield_get(dsm_subnet_allocated, subnet_handle))
    {
        return false;
    }
    if (dsm_subnets[subnet_handle].key_refresh_phase != MESH_KEY_REFRESH_PHASE_0
        && (p_secmat_cmp->nid == nid && p_secmat_secondary_cmp->nid == nid))
    {
        *pp_secmat_out = p_secmat_cmp;
        *pp_secmat_secondary_out = p_secmat_secondary_cmp;
        return true;
    }
    else if (dsm_subnets[subnet_handle].key_refresh_phase != MESH_KEY_REFRESH_PHASE_0
             && p_secmat_secondary_cmp->nid == nid)
    {
        *pp_secmat_out = p_secmat_secondary_cmp;
        *pp_secmat_secondary_out = NULL;
        return true;
    }
    else if (p_secmat_cmp->nid == nid)
    {
        *pp_secmat_out = p_secmat_cmp;
        *pp_secmat_secondary_out = NULL;
        return true;
    }

    return false;
}
void mesh_net_secmat_next_get(uint8_t nid, const mesh_network_secmat_t ** pp_secmat, const mesh_network_secmat_t ** pp_secmat_secondary)
{
    nid &= PACKET_MESH_NET_NID_MASK;
    dsm_handle_t i = 0;
    if (*pp_secmat != NULL)
    {
        dsm_handle_t prev = get_subnet_handle(*pp_secmat);
        i = (prev == DSM_HANDLE_INVALID) ? 0 : prev + 1;
    }

    *pp_secmat = NULL;
    *pp_secmat_secondary = NULL;

    for (; i < DSM_SUBNET_MAX; i++)
    {
        if (get_net_secmat_by_nid(i, nid,
                                  &dsm_subnets[i].secmat, &dsm_subnets[i].secmat_updated,
                                  pp_secmat, pp_secmat_secondary))
        {
            break;
        }
    }
}

void mesh_evt_handler_remove(mesh_evt_handler_t * p_handler_params)
{
    event_handler_remove(p_handler_params);
}




static bool scanner_packet_process_cb(void)
{
    const scanner_packet_t * p_scanner_packet = scanner_rx();

    if (p_scanner_packet != NULL)
    {
        mesh_rx_metadata_t metadata;

        metadata.source = MESH_RX_SOURCE_SCANNER;
        metadata.params.scanner = p_scanner_packet->metadata;

        if (p_scanner_packet->packet.header.length >= BLE_ADV_PACKET_OVERHEAD &&
            p_scanner_packet->packet.header.type != BLE_PACKET_TYPE_ADV_EXT)
        {
            ad_listener_process((ble_packet_type_t) p_scanner_packet->packet.header.type,
                                p_scanner_packet->packet.payload,
                                p_scanner_packet->packet.header.length - BLE_ADV_PACKET_OVERHEAD,
                                &metadata);            
            
            
        }        

        scanner_packet_release(p_scanner_packet);
    }
    
    return scanner_rx_pending();
}




static void packet_process_cb(void)
{
    uint8_t volatile timeout = 10;
    while(scanner_packet_process_cb() && timeout--);
    
}





mesh_dynamic_param_t mesh_dynamic_param;



uint32_t mesh_init(const mesh_init_params_t * p_init_params)
{
    mesh_dynamic_param.relay_tx_cnt = 3;
    mesh_dynamic_param.original_tx_cnt = 13;
    mesh_dynamic_param.relay_duration = 10;
    mesh_dynamic_param.original_duration = 40;

    m_mesh_state = MESH_STATE_INITIALIZED;
    packet_buffer_init(&m_scan_packet.packet_buffer, m_scan_packet.packet_buffer_data, MAX_SCAN_PACKET_SIZE);
    mesh_configure_device_uuid_reset();
    scanner_init(packet_process_cb);
    ad_listener_init();
    core_tx_adv_init();
    return MESH_SUCCESS;
}

uint32_t mesh_enable(void)
{
    uint32_t status = MESH_SUCCESS;
    switch (m_mesh_state)
    {
        case MESH_STATE_INITIALIZED:
            LOG_PRINTF("MESH_STATE_INITIALIZED\r\n");
            network_enable();
            bearer_event_start();
        case MESH_STATE_DISABLED:
        case MESH_STATE_DISABLING:
            bearer_handler_start();
            break;
        default:
            return MESH_ERROR_INVALID_STATE;
    }

    if (status == MESH_SUCCESS)
    {
        m_mesh_state = MESH_STATE_ENABLED;
    }
    return status;
}
static void bearer_stopped_cb(void)
{
    if (m_mesh_state == MESH_STATE_DISABLING)
    {
        m_mesh_state = MESH_STATE_DISABLED;
        const mesh_evt_t disabled = {
            .type = MESH_EVT_DISABLED,
        };
        event_handle(&disabled);
    }
}
uint32_t mesh_disable(void)
{
    if (m_mesh_state != MESH_STATE_ENABLED)
    {
        return MESH_ERROR_INVALID_STATE;
    }
    m_mesh_state = MESH_STATE_DISABLING;
    bearer_handler_stop(bearer_stopped_cb);

    return MESH_SUCCESS;
}


void mesh_beacon_info_next_get(const uint8_t * p_network_id, const mesh_beacon_info_t ** pp_beacon_info, mesh_key_refresh_phase_t * p_kr_phase)
{
    uint32_t i = 0;
    if (*pp_beacon_info != NULL)
    {
        i = get_subnet_handle_by_beacon_info(*pp_beacon_info) + 1;
    }
    for (; i < DSM_SUBNET_MAX; i++)
    {
        if (bitfield_get(dsm_subnet_allocated, i))
        {
            bool valid_beacon_info = false;
            if (dsm_subnets[i].key_refresh_phase == MESH_KEY_REFRESH_PHASE_0)
            {
                valid_beacon_info = p_network_id == NULL
                    || memcmp(p_network_id, dsm_subnets[i].beacon.info.secmat.net_id, MESH_NETID_SIZE) == 0;
            }
            else
            {
                valid_beacon_info = p_network_id == NULL
                    || memcmp(p_network_id, dsm_subnets[i].beacon.info.secmat.net_id, MESH_NETID_SIZE) == 0
                    || memcmp(p_network_id, dsm_subnets[i].beacon.info.secmat_updated.net_id, MESH_NETID_SIZE) == 0;
            }

            if (valid_beacon_info)
            {
                dsm_subnets[i].beacon.info.iv_update_permitted =
                    (!dsm_has_primary_subnet ||
                     dsm_subnets[i].net_key_index == PRIMARY_SUBNET_INDEX);

                *pp_beacon_info = &dsm_subnets[i].beacon.info;
                *p_kr_phase = dsm_subnets[i].key_refresh_phase;
                return;
            }
        }
    }
    *pp_beacon_info = NULL;
}

uint32_t mesh_packet_send(const mesh_tx_params_t * p_params,
                              uint32_t * const p_packet_reference)
{
    return transport_tx(p_params, p_packet_reference);
}

mesh_tx_token_t mesh_unique_token_get(void)
{
   if (++m_tx_token == MESH_SERVICE_BORDER_TOKEN)
   {
       m_tx_token = MESH_INITIAL_TOKEN;
       m_tx_token++;
   }
   return m_tx_token;
}


static health_server_t m_health_server;



static bool mesh_relay_check_cb(const network_packet_metadata_t * p_metadata, const mesh_rx_metadata_t * p_rx_metadata)
{   
    if(p_rx_metadata->params.scanner.rssi > -50){
        mesh_dynamic_param.original_tx_cnt = 13 + rand()%5;
        mesh_dynamic_param.relay_tx_cnt = 3 + rand()%3;   
        mesh_dynamic_param.relay_duration = 10 + rand()%5;    
        mesh_dynamic_param.original_duration = 30 + rand()%10;

    }else{
        mesh_dynamic_param.original_tx_cnt = 8 + rand()%5;
        mesh_dynamic_param.relay_tx_cnt = 8 + rand()%3;
        mesh_dynamic_param.relay_duration = 10 + rand()%10;    
        mesh_dynamic_param.original_duration = 20 + rand()%10;      
    }

    return true;
}

void mesh_stack_init(void (*model_init)(void))
{
    timer_sch_init();
    mesh_aes_init();
    msg_cache_init();
    bearer_event_init();
    bearer_handler_init();
    mesh_flash_init();
    mesh_config_init();
    mesh_opt_init();
    #ifdef ALEXA
    const mesh_init_params_t init_params = {
        .relay_cb = mesh_relay_check_cb,
        .test_mode_enable = false,
    };
    #else
    const mesh_init_params_t init_params = {
        .relay_cb = NULL,
        .test_mode_enable = false,
    };    
    #endif
    network_init(&init_params);
    transport_init();
    heartbeat_init();
    model_config_file_init();
    dsm_init();
    access_init();
    config_server_init(NULL);
    #ifndef PC_PROVISIONER
    health_server_init(&m_health_server, 0, DEVICE_COMPANY_ID,NULL,NULL,NULL);
    #endif
    if(model_init)model_init();
    mesh_init(NULL); 
    mesh_config_load();
    uint32_t dsm_result = dsm_load_config_apply();
    uint32_t access_result = access_load_config_apply();    
    uint32_t model_result = model_config_file_config_apply();	
    net_state_enable();
    broadcast_init();
    mal_adv_init();
}

void mesh_stack_enable(uint32_t scan_delay)
{
    if (mesh_is_device_provisioned()){
        proxy_init();
        proxy_start();
    }else{
        mesh_provisionee_prov_start(NULL);    
    }    
    ke_timer_set(MESH_TASK_START_SCAN, TASK_MESH, scan_delay); 
    mesh_enable();
    transport_enable(); 
}

void mesh_stack_pause(void)
{
    scanner_pause();
    net_beacon_pause();
    if (mesh_is_device_provisioned()){
        proxy_pause();
    }else{
        mesh_provisionee_prov_pause();
    }

    
}

void mesh_stack_resume(void)
{

    net_beacon_resume();
    if (mesh_is_device_provisioned()){
        proxy_resume();
    }else{
        mesh_provisionee_prov_resume();
    }    
    scanner_resume();
}



