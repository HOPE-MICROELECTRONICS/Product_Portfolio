#ifndef __CACHE_H__
#define __CACHE_H__





#include <stdint.h>
#include <stdbool.h>



typedef void (*cache_memcpy_t)(void * p_dest, const void * p_src);
typedef void (*cache_erase_t)(void * p_elem);
typedef bool (*cache_memcmp_t)(const void* p_elem1, const void* p_elem2);
typedef struct
{
    void*           elem_array;     
    uint32_t        elem_size;      
    uint32_t        array_len;      
    uint32_t        head;           
    cache_memcpy_t  memcpy_fptr;    
    cache_memcmp_t  memcmp_fptr;    
    cache_erase_t   erase_fptr;     
} cache_t;
void cache_init(cache_t* p_cache);
bool cache_has_elem(const cache_t* p_cache, const void* p_elem);
void cache_put(cache_t* p_cache, const void* p_elem);
uint32_t cache_erase_elem(cache_t* p_cache, const void* p_elem);





#endif //__CACHE_H__
