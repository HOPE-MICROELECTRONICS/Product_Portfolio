#ifndef CORE_TX_ADV_H__
#define CORE_TX_ADV_H__
#include "core_tx.h"





typedef struct{

    uint8_t relay_tx_cnt;
    uint8_t original_tx_cnt;
    uint8_t relay_duration;
    uint8_t original_duration;
//    uint8_t relay_repeat_delay;
//    uint8_t original_repeat_delay;

}mesh_dynamic_param_t;


void core_tx_adv_init(void);
bool core_tx_adv_is_enabled(core_tx_role_t role);



#endif /* CORE_TX_ADV_H__ */
