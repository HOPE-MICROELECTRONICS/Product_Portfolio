#ifndef __NET_BEACON_H__
#define __NET_BEACON_H__

#include <stdbool.h>
#include <stdint.h>
#include "mesh.h"
#include "packet.h"




#define NET_BEACON_BUFFER_SIZE 22
#define NET_BEACON_CMAC_SIZE 8



void net_beacon_init(void);
void net_beacon_enable(void);
void net_beacon_state_set(bool enabled);
bool net_beacon_state_get(void);
uint32_t net_beacon_build(const mesh_beacon_secmat_t * p_beacon_secmat,
                          uint32_t iv_index,
                          net_state_iv_update_t iv_update,
                          bool key_refresh,
                          uint8_t * p_buffer);
void net_beacon_packet_in(const uint8_t * p_beacon_data, uint8_t data_length, const mesh_rx_metadata_t * p_meta);
static inline bool net_beacon_key_refresh_flag(mesh_key_refresh_phase_t phase)
{
    return (phase == MESH_KEY_REFRESH_PHASE_2);
}

void net_beacon_resume(void);
void net_beacon_pause(void);





#endif //__NET_BEACON_H__
