#ifndef __BEACON_H__
#define __BEACON_H__





#include <stdint.h>
#include <stdbool.h>
#include "packet.h"
#include "advertiser.h"


#define BEACON_TYPE_UNPROV        (0x00)  
#define BEACON_TYPE_SEC_NET_BCAST (0x01)  
#define BEACON_TYPE_INVALID       (0xFF)  


#define BEACON_PACKET_OVERHEAD    (1)     
#define BEACON_PACKET_AD_LEN_OVERHEAD (BEACON_PACKET_OVERHEAD + BLE_AD_DATA_OVERHEAD) 
#define BEACON_DATA_MAXLEN            (BLE_ADV_PACKET_PAYLOAD_MAX_LENGTH - (sizeof(ble_ad_header_t) + BEACON_PACKET_OVERHEAD))


typedef struct
{
    uint8_t beacon_type;  
    uint8_t payload[];    
} beacon_packet_t;



adv_packet_t * beacon_create(advertiser_t * p_adv, uint8_t beacon_type, const void* p_payload, uint8_t payload_len);
void beacon_init(void);






#endif //__BEACON_H__
