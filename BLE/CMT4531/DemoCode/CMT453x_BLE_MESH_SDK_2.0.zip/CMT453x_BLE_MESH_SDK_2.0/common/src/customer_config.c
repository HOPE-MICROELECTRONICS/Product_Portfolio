#include "customer_config.h"
#include "bsp_lpuart.h"







static customer_config_test1_data_t m_test1_data;
static customer_config_test2_data_t m_test2_data;
//static customer_config_test3_data_t m_test3_data;
//static customer_config_test4_data_t m_test4_data;

static uint32_t test1_block_setter(mesh_config_entry_id_t id, const void * p_entry)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    memcpy(&m_test1_data, p_entry, sizeof(customer_config_test1_data_t));
    return MESH_SUCCESS;
}    
static void test1_block_getter(mesh_config_entry_id_t id, void * p_entry)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    memcpy(p_entry, &m_test1_data, sizeof(customer_config_test1_data_t));
}

static void test1_block_deleter(mesh_config_entry_id_t id)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    memset(&m_test1_data, 0, sizeof(customer_config_test1_data_t));
}   

static uint32_t test2_block_setter(mesh_config_entry_id_t id, const void * p_entry)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    memcpy(&m_test2_data, p_entry, sizeof(customer_config_test2_data_t));
    return MESH_SUCCESS;
}    
static void test2_block_getter(mesh_config_entry_id_t id, void * p_entry)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    memcpy(p_entry, &m_test2_data, sizeof(customer_config_test2_data_t));
}

static void test2_block_deleter(mesh_config_entry_id_t id)
{
    LOG_PRINTF("%s\r\n",__FUNCTION__);
    memset(&m_test2_data, 0, sizeof(customer_config_test2_data_t));
}   






MESH_CONFIG_ENTRY(test1_data,
                  MESH_OPT_CUSTOMER_CONFIG_TEST1_BLOCK_EID,
                  1,
                  sizeof(customer_config_test1_data_t),
                  test1_block_setter,
                  test1_block_getter,
                  test1_block_deleter,
                  NULL);

MESH_CONFIG_ENTRY(test2_data,
                  MESH_OPT_CUSTOMER_CONFIG_TEST2_BLOCK_EID,
                  1,
                  sizeof(customer_config_test1_data_t),
                  test2_block_setter,
                  test2_block_getter,
                  test2_block_deleter,
                  NULL);



MESH_CONFIG_FILE(m_custom_config_file, MESH_OPT_CUSTOMER_FILE_ID, MESH_CONFIG_STRATEGY_CONTINUOUS);






uint32_t customer_config_test1_init(void)
{
    return mesh_config_entry_get(MESH_OPT_CUSTOMER_CONFIG_TEST1_BLOCK_EID, &m_test1_data);
}

uint32_t customer_config_test1_store(customer_config_test1_data_t *data)
{
    return mesh_config_entry_set(MESH_OPT_CUSTOMER_CONFIG_TEST1_BLOCK_EID, data);
}

void customer_config_test1_read(customer_config_test1_data_t *data)
{
    memcpy(data,&m_test1_data,sizeof(customer_config_test1_data_t));
}

uint32_t customer_config_test1_delete(void)
{
    return mesh_config_entry_delete(MESH_OPT_CUSTOMER_CONFIG_TEST1_BLOCK_EID);
}


uint32_t customer_config_test2_init(void)
{
    return mesh_config_entry_get(MESH_OPT_CUSTOMER_CONFIG_TEST2_BLOCK_EID, &m_test2_data);
}
uint32_t customer_config_test2_store(customer_config_test2_data_t *data)
{
    return mesh_config_entry_set(MESH_OPT_CUSTOMER_CONFIG_TEST2_BLOCK_EID, data);
}

void customer_config_test2_read(customer_config_test2_data_t *data)
{
    memcpy(data,&m_test2_data,sizeof(customer_config_test2_data_t));
}

uint32_t customer_config_test2_delete(void)
{
    return mesh_config_entry_delete(MESH_OPT_CUSTOMER_CONFIG_TEST2_BLOCK_EID);
}



