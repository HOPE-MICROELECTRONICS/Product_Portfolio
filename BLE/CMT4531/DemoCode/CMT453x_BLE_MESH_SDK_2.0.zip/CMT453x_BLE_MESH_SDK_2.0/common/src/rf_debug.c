#include "cmt453x.h"
#include "global_var.h"
#include "rwip_int.h"
#include "reg_ipcore.h"
#include "mesh_app_task.h"

#define REG32(addr)          (*(volatile uint32_t *)(addr))


void ll_dbg_enable(void)
{
        #if !SMALL_GREEN_BOARD
            RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
            GPIO_InitType GPIO_InitStructure;
            GPIO_InitStructure.Pin 				= GPIO_PIN_0  | GPIO_PIN_3;
            GPIO_InitStructure.GPIO_Mode        = GPIO_MODE_AF_PP;
            GPIO_InitStructure.GPIO_Pull        = GPIO_PULL_DOWN;
            GPIO_InitStructure.GPIO_Alternate 	= GPIO_AF6;
            GPIO_InitPeripheral(GPIOB,  &GPIO_InitStructure);
                //afec block clk is on in active mode
            REG32(0x40011000 + 0x0) |= 0x01 << 28; //open dbg port 
            ip_diagcntl_set(0x80 + 0x03); //enable dbg port 0 and set DIAG0[6:0] as 0x28
        #else
            RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
            GPIO_InitType GPIO_InitStructure;
            GPIO_InitStructure.Pin 				= GPIO_PIN_0;
            GPIO_InitStructure.GPIO_Mode        = GPIO_MODE_AF_PP;
            GPIO_InitStructure.GPIO_Pull        = GPIO_PULL_DOWN;
            GPIO_InitStructure.GPIO_Alternate 	= GPIO_AF6;
            GPIO_InitPeripheral(GPIOB,  &GPIO_InitStructure);
                //afec block clk is on in active mode
            REG32(0x40011000 + 0x0) |= 0x1 << 28; //open dbg port 
            ip_diagcntl_set(0x80 + 0x03); //enable dbg port 0 and set DIAG0[6:0] as 0x28
        #endif    
}



void mco_enable(void)
{
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB|RCC_APB2_PERIPH_AFIO, ENABLE);
    GPIO_InitType GPIO_InitStructure;
    GPIO_InitStructure.Pin = GPIO_PIN_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_MODE_AF_PP;
    GPIO_InitStructure.GPIO_Pull = GPIO_NO_PULL; 
    GPIO_InitStructure.GPIO_Alternate = GPIO_AF4;
    GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);    
    RCC_ConfigMco(RCC_MCO_HSI);  

}







void rf_io_debug_pin7_toggle(void)
{
    GPIO_TogglePin(GPIOB, GPIO_PIN_7);
}
void rf_io_debug_pin7_on(void)
{
    GPIO_SetBits(GPIOB, GPIO_PIN_7);
}
void rf_io_debug_pin7_off(void)
{
    GPIO_ResetBits(GPIOB, GPIO_PIN_7);
}

void rf_io_debug_pin10_toggle(void)
{
    GPIO_TogglePin(GPIOB, GPIO_PIN_10);
}
void rf_io_debug_pin10_on(void)
{
    GPIO_SetBits(GPIOB, GPIO_PIN_10);
}
void rf_io_debug_pin10_off(void)
{
    GPIO_ResetBits(GPIOB, GPIO_PIN_10);
}

void rf_io_debug_pin11_toggle(void)
{
    GPIO_TogglePin(GPIOB, GPIO_PIN_11);
}
void rf_io_debug_pin11_on(void)
{
    GPIO_SetBits(GPIOB, GPIO_PIN_11);
}
void rf_io_debug_pin11_off(void)
{
    GPIO_ResetBits(GPIOB, GPIO_PIN_11);
}

void rf_io_debug_pin13_toggle(void)
{
    GPIO_TogglePin(GPIOB, GPIO_PIN_13);
}
void rf_io_debug_pin13_on(void)
{
    GPIO_SetBits(GPIOB, GPIO_PIN_13);
}
void rf_io_debug_pin13_off(void)
{
    GPIO_ResetBits(GPIOB, GPIO_PIN_13);
}
void rf_io_debug(void)
{
    GPIO_InitType GPIO_InitStructure;
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);

    GPIO_InitStructure.Pin = GPIO_PIN_7 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_13;
    GPIO_InitStructure.GPIO_Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStructure.GPIO_Pull = GPIO_NO_PULL;
    GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);

    rf_io_debug_pin7_off();
    rf_io_debug_pin10_off();
    rf_io_debug_pin11_off();
    rf_io_debug_pin13_off();

    

}












