#ifndef __CUSTOMER_CONFIGH_H__
#define __CUSTOMER_CONFIGH_H__


#include "mesh_config.h"
#include "mesh_config_entry.h"
#include "mesh_opt.h"
#include "stdio.h"







typedef struct __attribute((packed))
{
    uint8_t data1;
    uint8_t data2;
    uint8_t data3;
    
} customer_config_test1_data_t;
typedef struct __attribute((packed))
{
    uint8_t data1;
    uint8_t data2;
    uint8_t data3;
    
} customer_config_test2_data_t;
typedef struct __attribute((packed))
{
    uint8_t data1;
    uint8_t data2;
    uint8_t data3;
    
} customer_config_test3_data_t;
typedef struct __attribute((packed))
{
    uint8_t data1;
    uint8_t data2;
    uint8_t data3;
    
} customer_config_test4_data_t;



enum
{
    MESH_OPT_CUSTOMER_CONFIG_TEST1_RECORD = 1,
    MESH_OPT_CUSTOMER_CONFIG_TEST2_RECORD = 2,
    MESH_OPT_CUSTOMER_CONFIG_TEST3_RECORD = 3,
    MESH_OPT_CUSTOMER_CONFIG_TEST4_RECORD = 4,
};


#define MESH_OPT_CUSTOMER_CONFIG_TEST1_BLOCK_EID  MESH_CONFIG_ENTRY_ID(MESH_OPT_CUSTOMER_FILE_ID, MESH_OPT_CUSTOMER_CONFIG_TEST1_RECORD)
#define MESH_OPT_CUSTOMER_CONFIG_TEST2_BLOCK_EID  MESH_CONFIG_ENTRY_ID(MESH_OPT_CUSTOMER_FILE_ID, MESH_OPT_CUSTOMER_CONFIG_TEST2_RECORD)
#define MESH_OPT_CUSTOMER_CONFIG_TEST3_BLOCK_EID  MESH_CONFIG_ENTRY_ID(MESH_OPT_CUSTOMER_FILE_ID, MESH_OPT_CUSTOMER_CONFIG_TEST3_RECORD)
#define MESH_OPT_CUSTOMER_CONFIG_TEST4_BLOCK_EID  MESH_CONFIG_ENTRY_ID(MESH_OPT_CUSTOMER_FILE_ID, MESH_OPT_CUSTOMER_CONFIG_TEST4_RECORD)






uint32_t customer_config_test1_init(void);
uint32_t customer_config_test1_store(customer_config_test1_data_t *data);
void customer_config_test1_read(customer_config_test1_data_t *data);
uint32_t customer_config_test1_delete(void);

uint32_t customer_config_test2_init(void);
uint32_t customer_config_test2_store(customer_config_test2_data_t *data);
void customer_config_test2_read(customer_config_test2_data_t *data);
uint32_t customer_config_test2_delete(void);

#endif //__CUSTOMER_CONFIGH_H__
