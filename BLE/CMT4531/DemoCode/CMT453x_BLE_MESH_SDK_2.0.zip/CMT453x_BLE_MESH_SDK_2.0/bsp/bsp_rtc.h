#ifndef __BSP_RTC_H__
#define __BSP_RTC_H__










#include "cmt453x.h"







void bsp_rtc_init(void);








#endif //__BSP_RTC_H__
