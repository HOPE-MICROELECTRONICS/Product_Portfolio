/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file bsp_button.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */

/** @addtogroup 
 * @{
 */

#include "bsp_button.h"
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "cmt453x.h"
#include "toolchain.h"
#include "stdio.h"
#include "mesh_app_task.h"
#include "ke_timer.h"
#include "co_utils.h"





typedef struct
{
    GPIO_Module* GPIOx; //GPIO port
    uint16_t Pin;       //GPIO pin
    uint8_t PortSource; //port source
    uint8_t PinSource;  //pin source
    uint32_t EXTI_Line; //exti line
    IRQn_Type NVIC_IRQChannel; //nvic channel
    uint8_t evt;
}KeyInit_t; //Key exti interrupt structure
static KeyInit_t *m_button;
static uint32_t m_count = 0;
static void (*m_callback)(uint8_t button_evt);
#define BTN_LONG_PUSH_COUNT       30



KeyInit_t key_1 = {
	.GPIOx = GPIOB,
	.Pin = GPIO_PIN_1,
	.PortSource = GPIOB_PORT_SOURCE,
	.PinSource = GPIO_PIN_SOURCE1,
	.EXTI_Line = EXTI_LINE1,
	.NVIC_IRQChannel = EXTI0_1_IRQn,
    .evt = BUTTON_EVT_ONE_SHORT_RELEASE,
};
KeyInit_t key_2 = {
	.GPIOx = GPIOB,
	.Pin = GPIO_PIN_2,
	.PortSource = GPIOB_PORT_SOURCE,
	.PinSource = GPIO_PIN_SOURCE2,
	.EXTI_Line = EXTI_LINE2,
	.NVIC_IRQChannel = EXTI2_3_IRQn,
    .evt = BUTTON_EVT_TWO_SHORT_RELEASE,
};
static void gpio_config(KeyInit_t *init);

/*Button delay timer handler*/
int mesh_task_button_timer_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    bool polarity = GPIO_ReadInputDataBit(m_button->GPIOx, m_button->Pin);
    if(polarity == 1)
    {
        m_count = 0;
        m_callback(m_button->evt);
    }
    else
    {
        m_count++;
        if(m_count > BTN_LONG_PUSH_COUNT)
        {     
            m_count = 0;
            m_callback(m_button->evt+100);		
        }else{
            ke_timer_set(MESH_TASK_BUTTON_TIMER, TASK_MESH, 50); 
        }
    }
    return KE_MSG_CONSUMED;
}
static void button_handler(KeyInit_t *key) __attribute__((section("user_function_ram")));
static inline void button_handler(KeyInit_t *key)
{
    m_button = key;
    m_count = 0;
    ke_timer_set(MESH_TASK_BUTTON_TIMER, TASK_MESH, 50);     
}
/*Gpio exti handler*/
static void EXTI0_1_IRQHandler(void) __attribute__((section("user_function_ram")));
static void EXTI0_1_IRQHandler(void) 
{
    if (RESET != EXTI_GetITStatus(key_1.EXTI_Line))
    {
        button_handler(&key_1);
        EXTI_ClrITPendBit(key_1.EXTI_Line);     
    }	
}
/*Gpio exti handler*/
static void EXTI2_3_IRQHandler(void) __attribute__((section("user_function_ram")));
static void EXTI2_3_IRQHandler(void)
{
    if (RESET != EXTI_GetITStatus(key_2.EXTI_Line))
    {
        button_handler(&key_2);   
        EXTI_ClrITPendBit(key_2.EXTI_Line);   
    }	
}
/*Button init*/
void bsp_button_init(void (* callback)(uint8_t button_evt))
{
	m_callback = callback;
	ModuleIrqRemoval(EXTI2_3_IRQn);
	ModuleIrqRegister(EXTI2_3_IRQn, EXTI2_3_IRQHandler);        
	ModuleIrqRemoval(EXTI0_1_IRQn);
	ModuleIrqRegister(EXTI0_1_IRQn, EXTI0_1_IRQHandler);  
    gpio_config(&key_1);
    gpio_config(&key_2);

}



/*Gpio exti init*/
static void gpio_config(KeyInit_t *init)
{
    GPIO_InitType GPIO_InitStructure;
    EXTI_InitType EXTI_InitStructure;
    NVIC_InitType NVIC_InitStructure;

    if (init->GPIOx == GPIOA)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA | RCC_APB2_PERIPH_AFIO, ENABLE);
    }
    else if (init->GPIOx == GPIOB)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB | RCC_APB2_PERIPH_AFIO, ENABLE);
    }
    else
    {
        return;
    }

    GPIO_InitStruct(&GPIO_InitStructure);
    GPIO_InitStructure.Pin          = init->Pin;
    GPIO_InitStructure.GPIO_Pull    = GPIO_PULL_UP;
    GPIO_InitPeripheral(init->GPIOx, &GPIO_InitStructure);
    
    GPIO_ConfigEXTILine(init->PortSource, init->PinSource);

    EXTI_InitStructure.EXTI_Line    = init->EXTI_Line;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; 
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_InitPeripheral(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel                   = init->NVIC_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPriority           = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}


















