/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file dfu_led.h
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */

 /** @addtogroup 
 * @{
 */
#ifndef __BSP_LED_H__
#define __BSP_LED_H__






/* Includes ------------------------------------------------------------------*/

#include "cmt453x.h"
#include <stdint.h>


/* Public define ------------------------------------------------------------*/
/* Public typedef -----------------------------------------------------------*/
/* Public define ------------------------------------------------------------*/  

#define LED1_GPIO_PORT         GPIOB
#define LED2_GPIO_PORT         GPIOA
#define LED_GPIO1_PIN         GPIO_PIN_0
#define LED_GPIO2_PIN         GPIO_PIN_6



//#define LED1_GPIO_PORT         GPIOA
//#define LED2_GPIO_PORT         GPIOA
//#define LED_GPIO1_PIN         GPIO_PIN_1
//#define LED_GPIO2_PIN         GPIO_PIN_0



/* Public constants ---------------------------------------------------------*/
/* Public function prototypes -----------------------------------------------*/
void bsp_leds_config(void);
void bsp_led_on(GPIO_Module* led_port, uint32_t led_pin);
void bsp_led_off(GPIO_Module* led_port, uint32_t led_pin);
void bsp_led_toggle(GPIO_Module* led_port, uint32_t led_pin);
bool bsp_led_read(GPIO_Module* led_port, uint32_t led_pin);




#endif //__BSP_LED_H__
