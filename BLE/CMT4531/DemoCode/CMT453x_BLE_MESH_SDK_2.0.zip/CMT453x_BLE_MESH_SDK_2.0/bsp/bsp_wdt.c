/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file bsp_wdt.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */

/** @addtogroup 
 * @{
 */
#include "bsp_wdt.h"
#include "cmt453x.h"
#include "ke_timer.h"
#include "stdio.h"
#include "mesh_app_task.h"
#include "bsp_led.h"
#include "bsp_lpuart.h"
#include "mesh_app.h"

/*Independent watch dog init*/
void bsp_wdt_init(void)
{
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_PWR, ENABLE);
	DBG_ConfigPeriph(DBG_IWDG_STOP, ENABLE);    
    if (RCC_GetFlagStatus(RCC_CTRLSTS_FLAG_IWDGRSTF) != RESET)
    {
		LOG_PRINTF("reset by WDG\r\n"); 
        RCC_ClrFlag();
    } 
    IWDG_WriteConfig(IWDG_WRITE_ENABLE);
    IWDG_SetPrescalerDiv(IWDG_PRESCALER_DIV256);
    IWDG_CntReload(256*20); //Configure watch dog to 10 seconds timeout and reset system.
    IWDG_ReloadKey();
    
}

#include "reg_ipcore.h"
/*Feed watch dog timer handler*/
int mesh_task_wdt_handler(ke_msg_id_t const msgid, void const *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id)
{   
    IWDG_ReloadKey();
    ke_timer_set(MESH_TASK_WDT, TASK_MESH, 5000); 
    return KE_MSG_CONSUMED;
}



/*Watch dog start*/
void bsp_wdt_start(void)
{
    IWDG_Enable();
    IWDG_ReloadKey();
    //Start a 2 seconds timer to feed the watchdog
    ke_timer_set(MESH_TASK_WDT, TASK_MESH, 5000); 
}


/*Watch dog feed*/
void bsp_wdt_feed(void)
{
    IWDG_ReloadKey();

}


