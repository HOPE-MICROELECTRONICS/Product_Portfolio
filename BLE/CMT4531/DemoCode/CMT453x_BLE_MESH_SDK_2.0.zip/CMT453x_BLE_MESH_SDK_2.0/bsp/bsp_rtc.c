#include "bsp_rtc.h"
#include <stdio.h>
#include <stdlib.h>
#include "cmt453x.h"
#include "toolchain.h"


static void RTC_CLKSourceConfig(void)
{
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_PWR, ENABLE);
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO, ENABLE);

    RCC_EnableRtcClk(DISABLE);
    RCC_EnableLsi(ENABLE);
    while (RCC_GetFlagStatus(RCC_LSCTRL_FLAG_LSIRD) == RESET)
    {
    }

    RCC_ConfigLSXSEL(RCC_RTCCLK_SRC_LSI);
    RCC_EnableRtcClk(ENABLE);
    RTC_WaitForSynchro();
}
static void RTC_PrescalerConfig(void)
{
    RTC_InitType RTC_InitStructure;
    RTC_InitStructure.RTC_AsynchPrediv = 0x7F;  // value range: 0-7F
    RTC_InitStructure.RTC_SynchPrediv  = 0xEA; // 30KHz
    RTC_InitStructure.RTC_HourFormat   = RTC_24HOUR_FORMAT;

    if (RTC_Init(&RTC_InitStructure) == ERROR)
    {
        while(1);
    }
}

static void rtc_wkup_handler(void) __attribute__((section("user_function_ram")));
static void rtc_wkup_handler(void)
{
    if (RTC_GetITStatus(RTC_INT_WUT) != RESET)
    {
        rf_io_debug_pin11_toggle();
        RTC_ClrIntPendingBit(RTC_INT_WUT);
        EXTI_ClrITPendBit(EXTI_LINE9);    
    }
}


static void EXTI9_RTCWKUP_Configuration(void)
{
    EXTI_InitType EXTI_InitStructure;
    NVIC_InitType NVIC_InitStructure;

    EXTI_ClrITPendBit(EXTI_LINE9);
    EXTI_InitStructure.EXTI_Line = EXTI_LINE9;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_InitPeripheral(&EXTI_InitStructure);

    /* Enable the RTC WakeUp Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel                   = RTC_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority           = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    ModuleIrqRemoval(RTC_IRQn);
    ModuleIrqRegister(RTC_IRQn, rtc_wkup_handler);    
    
}

void bsp_rtc_init(void)
{
    RTC_CLKSourceConfig();    
    RTC_PrescalerConfig();

    RTC_ConfigWakeUpClock(RTC_WKUPCLK_RTCCLK_DIV16);
    RTC_SetWakeUpCounter(1);
    EXTI9_RTCWKUP_Configuration();
    RTC_ConfigInt(RTC_INT_WUT, ENABLE);
    RTC_EnableWakeUp(ENABLE);
}














