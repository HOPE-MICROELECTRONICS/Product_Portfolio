#ifndef __BSP_UART_H__
#define __BSP_UART_H__















void bsp_usart1_init(void);









#endif //__BSP_UART_H__
