#include "bsp_uart.h"
#include "cmt453x.h"
#include "toolchain.h"
#include <stdio.h>
#include "mesh_app_task.h"
#include "ke_mem.h"

void USART1_IRQnHandler(void)
{
    if(USART_GetFlagStatus(USART1, USART_FLAG_RXDNE) != RESET)
    {
        uint8_t buffer = USART_ReceiveData(USART1);
        uint32_t num = 0xFFFFFFFF;
        if (buffer >= '1' && buffer <= '9')
        {
            num = buffer - '1';
        }
        if (buffer >= 'a' && buffer <= 'l')
        {
            num = buffer - 'a' + 0xa;
        }     
        if (num < 0xa)
        {
            num++;
        }   
        if(num > 0 && num < 0xF){
            struct mesh_task_uart_rx_data *msg = KE_MSG_ALLOC(MESH_TASK_UART_RX_DATA,
                                                              TASK_MESH, TASK_NONE,
                                                              mesh_task_uart_rx_data);
            msg->data = buffer;
            ke_msg_send(msg);      
        }
      
    }
}

static void rcc_configure_usart1(void)
{
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_USART1, ENABLE);
}

static void gpio_configure_usart1(void)
{
    GPIO_InitType GPIO_InitStructure;
    
    GPIO_InitStruct(&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Mode        =    GPIO_MODE_AF_OD;
    GPIO_InitStructure.Pin              =    GPIO_PIN_7;
    GPIO_InitStructure.GPIO_Alternate   =    GPIO_AF4_USART1;
    GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);    
    
    
}

static void config_usart1(void)
{
    USART_InitType USART_InitStructure;
    
    USART_InitStructure.BaudRate                   =      2000000;
    USART_InitStructure.WordLength                 =      USART_WL_8B;
    USART_InitStructure.StopBits                   =      USART_STPB_1;
    USART_InitStructure.Parity                     =      USART_PE_NO;
    USART_InitStructure.HardwareFlowControl        =      USART_HFCTRL_NONE;
    USART_InitStructure.Mode                       =      USART_MODE_RX;
    
    USART_Init(USART1, &USART_InitStructure);

}
static void nvic_configure_usart1(void)
{
    NVIC_InitType NVIC_InitStructure;
    
    NVIC_InitStructure.NVIC_IRQChannel              =            USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority      =            0;
    NVIC_InitStructure.NVIC_IRQChannelCmd           =            ENABLE;
    NVIC_Init(&NVIC_InitStructure);
     
}
static void config_interrupt_usart1(void)
{
    USART_ConfigInt(USART1, USART_INT_RXDNE, ENABLE);
}



void bsp_usart1_init(void)
{
	ModuleIrqRemoval(USART1_IRQn);
	ModuleIrqRegister(USART1_IRQn, USART1_IRQnHandler);    
    rcc_configure_usart1();
    gpio_configure_usart1();
    config_usart1();
    nvic_configure_usart1();
    config_interrupt_usart1();
    USART_Enable(USART1, ENABLE);
}
















