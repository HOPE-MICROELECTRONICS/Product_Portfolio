/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file dfu_crc.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */

/** @addtogroup 
 * @{
 */

 /* Includes ------------------------------------------------------------------*/
#include "bsp_crc.h"
#include "cmt453x_crc.h"




/* Public define ------------------------------------------------------------*/
/* Public typedef -----------------------------------------------------------*/
/* Public define ------------------------------------------------------------*/  




#define LITTLE_TO_BIG(u32)    \
(uint32_t) ((u32 & 0x000000FF) << 24) | \
(uint32_t) ((u32 & 0x0000FF00) << 8) | \
(uint32_t) ((u32 & 0x00FF0000) >> 8) | \
(uint32_t) ((u32 & 0xFF000000) >> 24)



/**
 * @brief Calculate crc32 for given data, using hardware crc32.
 * @param[in] p_data raw data.
 * @param[in] len raw data len. 
 * @return crc32 result.
 */
uint32_t bsp_crc32(uint8_t * p_data, uint32_t len)
{
    if(len%4 > 0)return 0;
    RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_CRC, ENABLE);
    CRC32_ResetCrc();
    uint32_t index = 0;
    uint32_t *u32p_data = (uint32_t *)p_data;
    for (index = 0; index < len/4; index++)
    {
            CRC->CRC32DAT = LITTLE_TO_BIG(u32p_data[index]);
    }
    return (CRC->CRC32DAT);
}











