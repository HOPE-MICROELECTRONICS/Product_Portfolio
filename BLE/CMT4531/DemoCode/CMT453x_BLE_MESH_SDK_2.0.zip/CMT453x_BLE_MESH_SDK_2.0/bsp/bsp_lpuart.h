/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file bsp_lpuart.h
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */
#ifndef __BSP_LPUART_H__
#define __BSP_LPUART_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "cmt453x.h"
#include "stdio.h"



#define LOG_ENABLE              0

#if LOG_ENABLE == 1
#define LOG_PRINTF(...)              printf(__VA_ARGS__)
#define LOG_HEXDUMP(p_data,len)      log_hexdump(p_data,len)   
#else
#define LOG_PRINTF(...)
#define LOG_HEXDUMP(p_data,len)
#endif

#define DEBUG_ENABLE              0

#if DEBUG_ENABLE == 1
#define DEBUG_PRINTF(...)              printf(__VA_ARGS__)
#define DEBUG_HEXDUMP(p_data,len)      log_hexdump(p_data,len)   
#else
#define DEBUG_PRINTF(...)
#define DEBUG_HEXDUMP(p_data,len)
#endif


void bsp_lpuart_init(void);
uint32_t bsp_lpuart_send(uint8_t *p_data, uint32_t len);
uint32_t log_hexdump(const uint8_t *p_data, uint16_t len);



#ifdef __cplusplus
}
#endif

#endif //__BSP_LPUART_H__
