/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file main.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */

#include "cmt453x.h"
#include "ble_stack_common.h"
#include "prf.h"
#include "hp_sleep.h"
#include <co_bt.h>
#include "bsp_led.h"
#include "bsp_lpuart.h"
#include "bsp_button.h"
#include "bsp_wdt.h"
#include "app.h"
#include "reg_ipcore.h"
#include "hp_delay.h"
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "utils.h"
#include "rwip.h"
#include "app_task.h"
#include "Typedefine.h"
#include "generic_onoff_client.h"
#include "ke_timer.h"
#include "global_var.h"
#include "rwip_int.h"
#include "hp_dfu_boot.h"


extern struct rwip_env_tag rwip_env;
extern otp1_stored_t otp1_stored;
extern void system_opt_read(uint8_t* p_data,uint32_t byte_length);

static void models_init(void);
static void HardFault_Handler_CC(void);
static uint8_t tid = 0;
static void button_evt(uint8_t evt);



static void mesh_events_handle(const mesh_evt_t * p_evt);
static mesh_evt_handler_t m_event_handler =
{
    .evt_cb = mesh_events_handle,
};

/**
 * @brief  A method to get the mac address.
 * @note   This function should only be called at initialization, since the address will be used later.
 */
void make_ble_mac(void)
{
        system_opt_read((uint8_t*)&otp1_stored,sizeof(otp1_stored));
        memcpy(g_co_default_bdaddr.addr,&otp1_stored.flash_uuid[5],6);  
}




/**
 * @brief  Main Entry.
 */
int main(void)
{
    SystemInit();
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);
    //Redirect Hardfault function.
    REG32(0x200000f0) =(uint32_t) HardFault_Handler_CC;
    //Initialize uart for logging.
    bsp_lpuart_init(); 
    printf("application start...\r\n");      
    //Initialize ble stack.
    HP_BLE_STACK_INIT();
    PATCH_init();
    //Setting RF TX Power
    rf_tx_power_set(TX_POWER_Pos6_DBM);
    //Create a unique ble mac address.
    make_ble_mac();      
    LOG_HEXDUMP(g_co_default_bdaddr.addr,6);
    //Initialize watch dog timer.
    bsp_wdt_init(); 
    //Initialize evaluation board button driver. 
    bsp_button_init(button_evt);    
    //Initialize evaluation board led driver.
    bsp_leds_config();
    //Initialize Q-spi Flash driver.
    Qflash_Init();   
    //Initalize ble app task.    
    app_init();    
    //Initialze mesh stack.
    hp_mesh_stack_init(models_init);    
    //Add a callback to post event
    mesh_evt_handler_add(&m_event_handler);     
    //Enable mesh stack
    hp_mesh_stack_enable();    
    //Start watch dog timer
//    bsp_wdt_start();  
    while(1){
        //Fork and handle events.
        rwip_schedule();
    }
}



__asm int return_sp()
{
    MOV r0, sp
    BX LR
}   
__asm uint32_t getStackedReg(uint32_t regnum, uint32_t u32SP)
{
    lsls    r0, r0, #2
    adds    r0, r0, r1
    ldr     r0, [r0]
    bx      lr
}
/**
 * @brief  Handle the exceptions.
 */
static void HardFault_Handler_CC(void)
{

    uint32_t was_masked;
    _DISABLE_IRQS(was_masked);    
    uint32_t sp = return_sp();
	printf("HardFault_Handler_CC --> 0x%08X\r\n",sp);   
    printf("r0 --> 0x%08X\r\n", getStackedReg(0, sp));
    printf("r1 --> 0x%08X\r\n", getStackedReg(1, sp));
    printf("r2 --> 0x%08X\r\n", getStackedReg(2, sp));
    printf("r3 --> 0x%08X\r\n", getStackedReg(3, sp));  
    printf("r12 --> 0x%08X\r\n",getStackedReg(4, sp));
    printf("lr --> 0x%08X\r\n", getStackedReg(5, sp));
    printf("pc --> 0x%08X\r\n", getStackedReg(6, sp));
    printf("psr --> 0x%08X\r\n",getStackedReg(7, sp));

    NVIC_SystemReset();

	while(1);
}

static void mesh_events_handle(const mesh_evt_t * p_evt)
{
    if (p_evt->type == MESH_EVT_ENABLED)
    {
        printf("mesh post init...\r\n"); 
        mesh_stack_enable(1000);       
    }
}
static void app_gen_onoff_client_publish_interval_cb(access_model_handle_t handle, void * p_self)
{
     printf("Publish desired message here.\n");
}
static void app_gen_onoff_client_transaction_status_cb(access_model_handle_t model_handle,
                                                       void * p_args,
                                                       access_reliable_status_t status)
{
    switch(status)
    {
        case ACCESS_RELIABLE_TRANSFER_SUCCESS:
            printf("Acknowledged transfer success.\n");
            break;

        case ACCESS_RELIABLE_TRANSFER_TIMEOUT:
            printf("Acknowledged transfer timeout.\n");
            break;

        case ACCESS_RELIABLE_TRANSFER_CANCELLED:
            printf("Acknowledged transfer cancelled.\n");
            break;

        default:
            break;
    }
}
static void app_generic_onoff_client_status_cb(const generic_onoff_client_t * p_self,
                                               const access_message_rx_meta_t * p_meta,
                                               const generic_onoff_status_params_t * p_in)
{
    if (p_in->remaining_time_ms > 0)
    {
        printf("OnOff server: 0x%04x, Present OnOff: %d, Target OnOff: %d, Remaining Time: %d ms\n",p_meta->src.value, p_in->present_on_off, p_in->target_on_off, p_in->remaining_time_ms);
    }
    else
    {
        printf("OnOff server: 0x%04x, Present OnOff: %d\n",p_meta->src.value, p_in->present_on_off);
    }
}
const generic_onoff_client_callbacks_t client_cbs =
{
    .onoff_status_cb = app_generic_onoff_client_status_cb,
    .ack_transaction_status_cb = app_gen_onoff_client_transaction_status_cb,
    .periodic_publish_cb = app_gen_onoff_client_publish_interval_cb
};
static generic_onoff_client_t m_clients = {
    .settings.p_callbacks = &client_cbs,
    .settings.timeout = 0,
    .settings.force_segmented = false,
    .settings.transmic_size = MESH_TRANSMIC_SIZE_SMALL,
};

/**
 * @brief	Generic onoff model init. In this function, generic onoff server and client models will be created.
*/
static void models_init(void)
{
    generic_onoff_client_init(&m_clients, 0);    
}

/**
 * @brief  Send out an onoff set message at the generic onoff client model.
 * @param  onoff if true, let the light be on, if false, the light will be off.
 */
static void generic_onoff_set(bool onoff)
{
    static uint8_t tid = 0;
    generic_onoff_set_params_t set_params;
    set_params.on_off = onoff;  
    set_params.tid = tid++;
//    generic_onoff_client_set_unack(&m_clients, &set_params, NULL, 0);    
    access_model_reliable_cancel(m_clients.model_handle);
    generic_onoff_client_set(&m_clients, &set_params, NULL)  ;  
}



/**
 * @brief  Handle button events.
 * @param  evt button event type 
 */
static void button_evt(uint8_t evt)
{
    switch(evt){
        case BUTTON_EVT_ONE_SHORT_RELEASE:{
            printf("BUTTON_EVT_ONE_SHORT_RELEASE\r\n");  
            generic_onoff_set(true);  
        }break;
        case BUTTON_EVT_TWO_SHORT_RELEASE:{
            printf("BUTTON_EVT_TWO_SHORT_RELEASE\r\n");
            generic_onoff_set(false);
        }break;    
        case BUTTON_EVT_TWO_LONG_PUSH:{
            uint32_t was_masked;
            _DISABLE_IRQS(was_masked);              
            hp_mesh_nvds_clear();  
            NVIC_SystemReset();
        }break;        
        
    }
}

int mesh_task_uart_rx_data_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    
    return (KE_MSG_CONSUMED);
}
