#include "cmt453x.h"
#include "ble_stack_common.h"
#include "prf.h"
#include <co_bt.h>
#include "bsp_led.h"
#include "bsp_lpuart.h"
#include "bsp_button.h"
#include "bsp_wdt.h"
#include "app.h"
#include "reg_ipcore.h"
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "utils.h"
#include "rwip.h"
#include "app_task.h"
#include "Typedefine.h"
#include "ke_timer.h"
#include "global_var.h"
#include "rwip_int.h"
#include "mesh_events.h"
#include "light_ctl_client.h"
#include "light_ctl_utils.h"
#include "bsp_uart.h"


extern struct rwip_env_tag rwip_env;
extern otp1_stored_t otp1_stored;
extern void system_opt_read(uint8_t* p_data,uint32_t byte_length);
static void HardFault_Handler_CC(void);
static void models_init(void);
static void button_evt(uint8_t evt);

static void mesh_events_handle(const mesh_evt_t * p_evt);
static mesh_evt_handler_t m_event_handler =
{
    .evt_cb = mesh_events_handle,
};

void make_ble_mac(void)
{
        system_opt_read((uint8_t*)&otp1_stored,sizeof(otp1_stored));
        memcpy(g_co_default_bdaddr.addr,&otp1_stored.flash_uuid[5],6);   
}


                           
                                  
int main(void)
{
    SystemInit();
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);    
    //Redirect Hardfault function.
    REG32(0x200000f0) =(uint32_t) HardFault_Handler_CC;
    //Initialize ble stack.
    HP_BLE_STACK_INIT();
    PATCH_init();
    //Setting RF TX Power
    rf_tx_power_set(TX_POWER_Pos6_DBM);
    //Create a unique ble mac address.
    make_ble_mac(); 
    //Initialize uart for logging.
    bsp_lpuart_init();    
    printf("application start...\r\n");  
    bsp_usart1_init();    
    //Initialize evaluation board button driver. 
    bsp_button_init(button_evt);      
    //Initialize watch dog timer.
    bsp_wdt_init();
    //Initialize Q-spi Flash driver.
    Qflash_Init();      
    //Initalize ble app task.
    app_init();   
    //Initialze mesh stack.
    hp_mesh_stack_init(models_init);
    //Add a callback to post event
    mesh_evt_handler_add(&m_event_handler);
    //Enable mesh stack
    hp_mesh_stack_enable();
    //Start watch dog timer
//    bsp_wdt_start();

    while(1){
        //Fork and handle events.
        rwip_schedule();
    }
}

__asm int return_sp()
{
    MOV r0, sp
    BX LR
}   
__asm uint32_t getStackedReg(uint32_t regnum, uint32_t u32SP)
{
    lsls    r0, r0, #2
    adds    r0, r0, r1
    ldr     r0, [r0]
    bx      lr
}
/**
 * @brief  Handle the exceptions.
 */
static void HardFault_Handler_CC(void)
{

    uint32_t was_masked;
    _DISABLE_IRQS(was_masked);    
    uint32_t sp = return_sp();
	printf("HardFault_Handler_CC --> 0x%08X\r\n",sp);   
    printf("r0 --> 0x%08X\r\n", getStackedReg(0, sp));
    printf("r1 --> 0x%08X\r\n", getStackedReg(1, sp));
    printf("r2 --> 0x%08X\r\n", getStackedReg(2, sp));
    printf("r3 --> 0x%08X\r\n", getStackedReg(3, sp));  
    printf("r12 --> 0x%08X\r\n",getStackedReg(4, sp));
    printf("lr --> 0x%08X\r\n", getStackedReg(5, sp));
    printf("pc --> 0x%08X\r\n", getStackedReg(6, sp));
    printf("psr --> 0x%08X\r\n",getStackedReg(7, sp));

    NVIC_SystemReset();

	while(1);
}





static void mesh_events_handle(const mesh_evt_t * p_evt)
{
    if (p_evt->type == MESH_EVT_ENABLED)
    {
        printf("mesh post init\r\n");
        mesh_stack_enable(1000);
    }
}                               




#define APP_STATE_OFF                (0)
#define APP_STATE_ON                 (1)
#define APP_UNACK_MSG_REPEAT_COUNT   (2)
#define APP_TIMEOUT_FOR_TID_CHANGE   (3)
#define APP_LIGHTNESS_STEP_SIZE          (10000L)
#define APP_TEMPERATURE32_STEP_SIZE      ((int64_t)light_ctl_utils_temperature_to_temperature32(5000))
#define APP_DELTA_UV_STEP_SIZE           (10000L)
#define APP_TEMPERATURE32_MIN            (light_ctl_utils_temperature_to_temperature32(LIGHT_CTL_TEMPERATURE_MIN_LIMIT))
#define APP_TEMPERATURE32_MAX            (light_ctl_utils_temperature_to_temperature32(LIGHT_CTL_TEMPERATURE_MAX_LIMIT))
#define APP_DELAY_MS                 (1000)
#define APP_TRANSITION_TIME_MS       (1000)

static void app_light_ctl_client_publish_interval_cb(access_model_handle_t handle, void * p_self);
static void app_light_ctl_client_transaction_status_cb(access_model_handle_t model_handle,
                                                       void * p_args,
                                                       access_reliable_status_t status);
static void app_light_ctl_client_status_cb(const light_ctl_client_t * p_self,
                                           const access_message_rx_meta_t * p_meta,
                                           const light_ctl_status_params_t * p_in);
static void app_light_ctl_client_temperature_status_cb(const light_ctl_client_t * p_self,
                                            const access_message_rx_meta_t * p_meta,
                                            const light_ctl_temperature_status_params_t * p_in);
static void app_light_ctl_client_temperature_range_status_cb(const light_ctl_client_t * p_self,
                                            const access_message_rx_meta_t * p_meta,
                                            const light_ctl_temperature_range_status_params_t * p_in);
static void app_light_ctl_client_default_status_cb(const light_ctl_client_t * p_self,
                                            const access_message_rx_meta_t * p_meta,
                                            const light_ctl_default_status_params_t * p_in);

static light_ctl_client_t m_clients[CLIENT_MODEL_INSTANCE_COUNT];
static bool m_device_provisioned;
static light_ctl_set_params_t m_set_params;
static light_ctl_temperature_set_params_t m_temperature_set_params;
static light_ctl_temperature_range_set_params_t m_range_set_params;
static light_ctl_default_set_params_t m_default_set_params;

static const light_ctl_client_callbacks_t m_client_cbs =
{
    .light_ctl_status_cb = app_light_ctl_client_status_cb,
    .light_ctl_temperature_status_cb = app_light_ctl_client_temperature_status_cb,
    .light_ctl_temperature_range_status_cb = app_light_ctl_client_temperature_range_status_cb,
    .light_ctl_default_status_cb = app_light_ctl_client_default_status_cb,
    .ack_transaction_status_cb = app_light_ctl_client_transaction_status_cb,
    .periodic_publish_cb = app_light_ctl_client_publish_interval_cb
};

static void app_light_ctl_client_publish_interval_cb(access_model_handle_t handle, void * p_self)
{
     printf("Publish desired message here.\n");
}

static void app_light_ctl_client_transaction_status_cb(access_model_handle_t model_handle,
                                                       void * p_args,
                                                       access_reliable_status_t status)
{
    switch(status)
    {
        case ACCESS_RELIABLE_TRANSFER_SUCCESS:
            printf("Acknowledged transfer success.\n");
            break;

        case ACCESS_RELIABLE_TRANSFER_TIMEOUT:
            printf("Acknowledged transfer timeout.\n");
            break;

        case ACCESS_RELIABLE_TRANSFER_CANCELLED:
            printf("Acknowledged transfer cancelled.\n");
            break;

        default:
            break;
    }
}

static void app_light_ctl_client_status_cb(const light_ctl_client_t * p_self,
                                                 const access_message_rx_meta_t * p_meta,
                                                 const light_ctl_status_params_t * p_in)
{
    if (p_in->remaining_time_ms > 0)
    {
        printf("CTL client: 0x%04x, Present: lightness %d, temperature %d "
              "Target: lightness %d, temperature %d remaining time: %d ms\n",
              p_meta->src.value, p_in->present_lightness,
              light_ctl_utils_temperature32_to_temperature(p_in->present_temperature32),
              p_in->target_lightness,
              light_ctl_utils_temperature32_to_temperature(p_in->target_temperature32),
              p_in->remaining_time_ms);
    }
    else
    {
        printf("CTL client: 0x%04x, Present: lightness %d, temperature %d\n",
              p_meta->src.value, p_in->present_lightness,
              light_ctl_utils_temperature32_to_temperature(p_in->present_temperature32));
    }
}

static void app_light_ctl_client_temperature_status_cb(const light_ctl_client_t * p_self,
                                                const access_message_rx_meta_t * p_meta,
                                                const light_ctl_temperature_status_params_t * p_in)
{
    if (p_in->remaining_time_ms > 0)
    {
        printf("CTL client: 0x%04x, Present: temperature %d delta_uv %d"
              "Target: temperature %d delta_uv %d remaining time %d\n",
              p_meta->src.value,
              light_ctl_utils_temperature32_to_temperature(p_in->present_temperature32),
              p_in->present_delta_uv,
              light_ctl_utils_temperature32_to_temperature(p_in->target_temperature32),
              p_in->target_delta_uv, p_in->remaining_time_ms);
    }
    else
    {
        printf("CTL client: 0x%04x, Present: temperature %d delta_uv %d\n",
              p_meta->src.value,
              light_ctl_utils_temperature32_to_temperature(p_in->present_temperature32),
              p_in->present_delta_uv);
    }

}

static void app_light_ctl_client_temperature_range_status_cb(const light_ctl_client_t * p_self,
                                            const access_message_rx_meta_t * p_meta,
                                            const light_ctl_temperature_range_status_params_t * p_in)
{
    printf("CTL client: 0x%04x, Range Temperature32 status: %s, min: %d, max: %d\n",
          p_meta->src.value, (p_in->status_code == 0) ? "success":"can't set range",
          light_ctl_utils_temperature32_to_temperature(p_in->temperature32_range_min),
          light_ctl_utils_temperature32_to_temperature(p_in->temperature32_range_max));
}

static void app_light_ctl_client_default_status_cb(const light_ctl_client_t * p_self,
                                                   const access_message_rx_meta_t * p_meta,
                                                   const light_ctl_default_status_params_t * p_in)
{
    printf("CTL client: 0x%04x, Default: lightness %d temperature %d delta_uv %d\n",
          p_meta->src.value, p_in->lightness,
          light_ctl_utils_temperature32_to_temperature(p_in->temperature32), p_in->delta_uv);
}


int mesh_task_uart_rx_data_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    uint8_t data = *(uint8_t *)p_param;
    uint32_t num = 0xFFFFFFFF;
    if (data >= '1' && data <= '9')
    {
        num = data - '1';
    }
    if (data >= 'a' && data <= 'l')
    {
        num = data - 'a' + 0xa;
    }     
    if (num < 0xa)
    {
        num++;
    }    
    printf("num %u passed\r\n", num);
    uint32_t status = MESH_SUCCESS;
    static uint8_t client = 0;
    printf("client --> %d\r\n",client);
    model_transition_t transition_params;
    static uint32_t timestamp = 0;
    timestamp_t current_time;

    switch(num)
    {
        case 1:
            m_set_params.lightness =
                (m_set_params.lightness + APP_LIGHTNESS_STEP_SIZE) >= UINT16_MAX ?
                UINT16_MAX : m_set_params.lightness + APP_LIGHTNESS_STEP_SIZE;
            m_set_params.temperature32 = m_temperature_set_params.temperature32;
            m_set_params.delta_uv = m_temperature_set_params.delta_uv;
            m_set_params.tid++;
            break;
        case 2:
            m_set_params.lightness =
                (m_set_params.lightness - APP_LIGHTNESS_STEP_SIZE) <= 0 ?
                0 : m_set_params.lightness - APP_LIGHTNESS_STEP_SIZE;
            m_set_params.temperature32 = m_temperature_set_params.temperature32;
            m_set_params.delta_uv = m_temperature_set_params.delta_uv;
            m_set_params.tid++;
            break;
        case 3:
            m_temperature_set_params.temperature32 =
                (m_temperature_set_params.temperature32 + APP_TEMPERATURE32_STEP_SIZE) >= APP_TEMPERATURE32_MAX ?
                APP_TEMPERATURE32_MAX : m_temperature_set_params.temperature32 + APP_TEMPERATURE32_STEP_SIZE;
            m_temperature_set_params.tid++;
            break;
        case 4:
            m_temperature_set_params.temperature32 =
                (m_temperature_set_params.temperature32 - APP_TEMPERATURE32_STEP_SIZE) <= APP_TEMPERATURE32_MIN ?
                APP_TEMPERATURE32_MIN : m_temperature_set_params.temperature32 - APP_TEMPERATURE32_STEP_SIZE;
            m_temperature_set_params.tid++;
            break;
        case 5:
            m_temperature_set_params.delta_uv =
                (m_temperature_set_params.delta_uv + APP_DELTA_UV_STEP_SIZE) >= UINT16_MAX ?
                UINT16_MAX : m_temperature_set_params.delta_uv + APP_DELTA_UV_STEP_SIZE;
            m_temperature_set_params.tid++;
            break;
        case 6:
            m_temperature_set_params.delta_uv =
                (m_temperature_set_params.delta_uv - APP_DELTA_UV_STEP_SIZE) <= 0 ?
                0 : m_temperature_set_params.delta_uv - APP_DELTA_UV_STEP_SIZE;
            m_temperature_set_params.tid++;
            break;

        default:
            break;
    }

    current_time = bsp_time_now();
    if (timestamp + SEC_TO_US(APP_TIMEOUT_FOR_TID_CHANGE) < current_time)
    {
        m_temperature_set_params.tid++;
        m_set_params.tid++;
    }
    timestamp = current_time;

    transition_params.delay_ms = APP_DELAY_MS;
    transition_params.transition_time_ms = APP_TRANSITION_TIME_MS+2000;
    switch (num)
    {
        case 1:
        case 2:
            printf("Sending msg: UnAck CTL Set: lightness %d, temperature %d delta_uv %d "
                  "tid: %d trans time: %d ms delay: %d ms\n\n",
                   m_set_params.lightness,
                   light_ctl_utils_temperature32_to_temperature(m_set_params.temperature32),
                   m_set_params.delta_uv,
                   m_set_params.tid, transition_params.transition_time_ms,
                   transition_params.delay_ms);
            status = light_ctl_client_set_unack(&m_clients[client],
                                                &m_set_params, &transition_params, 0);
            break;
        case 3:
        case 4:
        case 5:
        case 6:
            printf("Sending msg: UnAck CTL Temperature Set: temperature %d delta_uv %d "
                  "tid: %d trans time: %d ms delay: %d ms\n\n",
                   light_ctl_utils_temperature32_to_temperature(m_temperature_set_params.temperature32),
                   m_temperature_set_params.delta_uv,
                   m_temperature_set_params.tid, transition_params.transition_time_ms,
                   transition_params.delay_ms);
            status = light_ctl_client_temperature_set_unack(&m_clients[client],
                                                             &m_temperature_set_params,
                                                             &transition_params, 0);
            break;

        case 0xe:
            client++;
            client = (client < CLIENT_MODEL_INSTANCE_COUNT) ? client : 0;
            printf("Switching to client instance: %d\n", client);
            break;
        default:
            break;
    }

    switch (status)
    {
        case MESH_SUCCESS:
            break;

        case MESH_ERROR_NO_MEM:
        case MESH_ERROR_BUSY:
        case MESH_ERROR_INVALID_STATE:
            printf("Client %u cannot send: status: %d\n", client, status);
            break;

        case MESH_ERROR_INVALID_PARAM:
            printf("Publication not configured for client %u\n", client);
            break;
        default:
            break;
    }    
    
    
    return (KE_MSG_CONSUMED);
}

static void models_init(void)
{
    m_temperature_set_params.temperature32 = APP_TEMPERATURE32_MIN;
    m_temperature_set_params.delta_uv = UINT16_MAX/2;
    m_range_set_params.temperature32_range_min = APP_TEMPERATURE32_MIN;
    m_range_set_params.temperature32_range_max = APP_TEMPERATURE32_MAX;
    m_default_set_params.temperature32 = APP_TEMPERATURE32_MIN;
    m_default_set_params.delta_uv = UINT16_MAX/2;    
    
    for (uint32_t i = 0; i < CLIENT_MODEL_INSTANCE_COUNT; ++i)
    {
        m_clients[i].settings.p_callbacks = &m_client_cbs;
        m_clients[i].settings.timeout = 0;
        m_clients[i].settings.force_segmented = false;
        m_clients[i].settings.transmic_size = MESH_TRANSMIC_SIZE_SMALL;
        light_ctl_client_init(&m_clients[i], i + 1);
    }    
}
static void button_evt(uint8_t evt)
{
    switch(evt){
        case BUTTON_EVT_ONE_SHORT_RELEASE:{
            printf("BUTTON_EVT_ONE_SHORT_RELEASE\r\n");

        }break;
        case BUTTON_EVT_TWO_SHORT_RELEASE:{
            printf("BUTTON_EVT_TWO_SHORT_RELEASE\r\n");

        }break;    
        case BUTTON_EVT_TWO_LONG_PUSH:{
            uint32_t was_masked;
            _DISABLE_IRQS(was_masked);              
            hp_mesh_nvds_clear();  
            NVIC_SystemReset();
        }break;        
        
    }
}

