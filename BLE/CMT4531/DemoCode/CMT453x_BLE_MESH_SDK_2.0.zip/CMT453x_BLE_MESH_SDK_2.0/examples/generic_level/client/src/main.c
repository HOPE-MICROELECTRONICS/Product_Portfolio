#include "cmt453x.h"
#include "ble_stack_common.h"
#include "prf.h"
#include <co_bt.h>
#include "bsp_led.h"
#include "bsp_lpuart.h"
#include "bsp_button.h"
#include "bsp_wdt.h"
#include "app.h"
#include "reg_ipcore.h"
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "utils.h"
#include "rwip.h"
#include "app_task.h"
#include "Typedefine.h"
#include "ke_timer.h"
#include "global_var.h"
#include "rwip_int.h"
#include "app_level.h"
#include "app_pwm_utils.h"
#include "app_pwm.h"
#include "bsp_uart.h"
#include "generic_level_client.h"


extern struct rwip_env_tag rwip_env;
extern otp1_stored_t otp1_stored;
extern void system_opt_read(uint8_t* p_data,uint32_t byte_length);
static void HardFault_Handler_CC(void);
static void models_init(void);
static void button_evt(uint8_t evt);


static void mesh_events_handle(const mesh_evt_t * p_evt);
static mesh_evt_handler_t m_event_handler =
{
    .evt_cb = mesh_events_handle,
};


void make_ble_mac(void)
{
        system_opt_read((uint8_t*)&otp1_stored,sizeof(otp1_stored));
        memcpy(g_co_default_bdaddr.addr,&otp1_stored.flash_uuid[5],6);       
}

int main(void)
{
    SystemInit();
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);
    //Redirect Hardfault function.
    REG32(0x200000f0) =(uint32_t) HardFault_Handler_CC;
    //Initialize ble stack.
    HP_BLE_STACK_INIT();
    PATCH_init();
    //Setting RF TX Power
    rf_tx_power_set(TX_POWER_Pos6_DBM);
    //Create a unique ble mac address.
    make_ble_mac(); 
    //Initialize uart for logging.
    bsp_lpuart_init();    
    printf("application start...\r\n"); 
    bsp_usart1_init();
    //Initialize evaluation board button driver. 
    bsp_button_init(button_evt);    
    //Initialize evaluation board led driver.
    bsp_leds_config();
    //Initialize watch dog timer.
    bsp_wdt_init();
    //Initialize Q-spi Flash driver.
    Qflash_Init();
    //Initalize ble app task.
    app_init();   
    //Initialze mesh stack.
    hp_mesh_stack_init(models_init);
    //Add a callback to post event
    mesh_evt_handler_add(&m_event_handler);  
    //Enable mesh stack
    hp_mesh_stack_enable();
    //Start watch dog timer
//    bsp_wdt_start();
   
   
    while(1){
        //Fork and handle events.
        rwip_schedule();                
    }
}

__asm int return_sp()
{
    MOV r0, sp
    BX LR
}   
__asm uint32_t getStackedReg(uint32_t regnum, uint32_t u32SP)
{
    lsls    r0, r0, #2
    adds    r0, r0, r1
    ldr     r0, [r0]
    bx      lr
}
/**
 * @brief  Handle the exceptions.
 */
static void HardFault_Handler_CC(void)
{

    uint32_t was_masked;
    _DISABLE_IRQS(was_masked);    
    uint32_t sp = return_sp();
	printf("HardFault_Handler_CC --> 0x%08X\r\n",sp);   
    printf("r0 --> 0x%08X\r\n", getStackedReg(0, sp));
    printf("r1 --> 0x%08X\r\n", getStackedReg(1, sp));
    printf("r2 --> 0x%08X\r\n", getStackedReg(2, sp));
    printf("r3 --> 0x%08X\r\n", getStackedReg(3, sp));  
    printf("r12 --> 0x%08X\r\n",getStackedReg(4, sp));
    printf("lr --> 0x%08X\r\n", getStackedReg(5, sp));
    printf("pc --> 0x%08X\r\n", getStackedReg(6, sp));
    printf("psr --> 0x%08X\r\n",getStackedReg(7, sp));

    NVIC_SystemReset();

	while(1);
}

static void mesh_events_handle(const mesh_evt_t * p_evt)
{
    
    if (p_evt->type == MESH_EVT_ENABLED)
    {
        printf("mesh post init...\r\n");
        mesh_stack_enable(1000);
    }
}



static generic_level_client_t m_clients[CLIENT_MODEL_INSTANCE_COUNT];
static void app_gen_level_client_publish_interval_cb(access_model_handle_t handle, void * p_self);
static void app_generic_level_client_status_cb(const generic_level_client_t * p_self,
                                               const access_message_rx_meta_t * p_meta,
                                               const generic_level_status_params_t * p_in);
static void app_gen_level_client_transaction_status_cb(access_model_handle_t model_handle,
                                                       void * p_args,
                                                       access_reliable_status_t status);
const generic_level_client_callbacks_t client_cbs =
{
    .level_status_cb = app_generic_level_client_status_cb,
    .ack_transaction_status_cb = app_gen_level_client_transaction_status_cb,
    .periodic_publish_cb = app_gen_level_client_publish_interval_cb
};
static void app_gen_level_client_transaction_status_cb(access_model_handle_t model_handle,
                                                       void * p_args,
                                                       access_reliable_status_t status)
{
    switch(status)
    {
        case ACCESS_RELIABLE_TRANSFER_SUCCESS:
            printf("Acknowledged transfer success.\n");
            break;

        case ACCESS_RELIABLE_TRANSFER_TIMEOUT:
            printf("Acknowledged transfer timeout.\n");
            break;

        case ACCESS_RELIABLE_TRANSFER_CANCELLED:
            printf("Acknowledged transfer cancelled.\n");
            break;
    }
}

static void app_generic_level_client_status_cb(const generic_level_client_t * p_self,
                                               const access_message_rx_meta_t * p_meta,
                                               const generic_level_status_params_t * p_in)
{
    if (p_in->remaining_time_ms > 0)
    {
        printf("Level server: 0x%04x, Present Level: %d, Target Level: %d, Remaining Time: %d ms\n", p_meta->src.value, p_in->present_level, p_in->target_level, p_in->remaining_time_ms);
    }
    else
    {
        printf("Level server: 0x%04x, Present Level: %d\n", p_meta->src.value, p_in->present_level);
    }
}
static void app_gen_level_client_publish_interval_cb(access_model_handle_t handle, void * p_self)
{
    printf("Publish desired message here.\n");
}

static void models_init(void)
{
    for (uint32_t i = 0; i < CLIENT_MODEL_INSTANCE_COUNT; ++i)
    {
        m_clients[i].settings.p_callbacks = &client_cbs;
        m_clients[i].settings.timeout = 0;
        m_clients[i].settings.force_segmented = false;
        m_clients[i].settings.transmic_size = MESH_TRANSMIC_SIZE_SMALL;

        generic_level_client_init(&m_clients[i], i + 1);
    }    

}
static void button_evt(uint8_t evt)
{
    switch(evt){
        case BUTTON_EVT_ONE_SHORT_RELEASE:{
            printf("BUTTON_EVT_ONE_SHORT_RELEASE\r\n");
  
        }break;
        case BUTTON_EVT_TWO_SHORT_RELEASE:{
            printf("BUTTON_EVT_TWO_SHORT_RELEASE\r\n");

        }break;    
        case BUTTON_EVT_TWO_LONG_PUSH:{
            uint32_t was_masked;
            _DISABLE_IRQS(was_masked);              
            hp_mesh_nvds_clear();  
            NVIC_SystemReset();
        }break;        
        
    }
}

#define APP_LEVEL_STEP_SIZE          (2000L)
#define APP_TIMEOUT_FOR_TID_CHANGE   (3)
#define APP_LEVEL_DELAY_MS           (100)
#define APP_LEVEL_TRANSITION_TIME_MS (4000)


int mesh_task_uart_rx_data_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    uint8_t data = *(uint8_t *)p_param;
    uint32_t status = MESH_SUCCESS;
    static uint8_t client = 0;
    static generic_level_set_params_t set_params = {0};
    static generic_level_move_set_params_t move_set_params = {0};
    static generic_level_delta_set_params_t delta_set_params = {0};
    model_transition_t transition_params;
    static uint32_t timestamp = 0;
    timestamp_t current_time;    
    
    
        switch(data)
        {
            case '1':
            set_params.level = (set_params.level + APP_LEVEL_STEP_SIZE) >= INT16_MAX ?
                               INT16_MAX : set_params.level + APP_LEVEL_STEP_SIZE;                
            set_params.tid++;                
            break;
            case '2':
            set_params.level = (set_params.level - APP_LEVEL_STEP_SIZE) <= INT16_MIN ?
                               INT16_MIN : set_params.level - APP_LEVEL_STEP_SIZE;
            set_params.tid++;                
            break;
           
        }    
    
    current_time = bsp_time_now();
    if (timestamp + SEC_TO_US(APP_TIMEOUT_FOR_TID_CHANGE) < current_time)
    {
        delta_set_params.tid++;
    }
    timestamp = current_time;

    transition_params.delay_ms = APP_LEVEL_DELAY_MS;
    transition_params.transition_time_ms = APP_LEVEL_TRANSITION_TIME_MS;        
        
        
        switch(data)
        {
            case '1':
            case '2':
            printf("Sending msg: Acknowledged Level Set: Target: %d Tid: %d Transition time: %d ms Delay: %d ms\n",
                  set_params.level, set_params.tid, transition_params.transition_time_ms, transition_params.delay_ms);    
            (void)access_model_reliable_cancel(m_clients[client].model_handle);
            status = generic_level_client_set(&m_clients[client], &set_params, &transition_params);              
            break;       
        }           
        
    switch (status)
    {
        case MESH_SUCCESS:
            break;

        case MESH_ERROR_NO_MEM:
        case MESH_ERROR_BUSY:
        case MESH_ERROR_INVALID_STATE:
            printf("Client %u cannot send: status: %d\n", client, status);
            break;

        case MESH_ERROR_INVALID_PARAM:

            printf("Publication not configured for client %u\n", client);
            break;

    }        
    
    return (KE_MSG_CONSUMED);
}


