#include "cmt453x.h"
#include "ble_stack_common.h"
#include "prf.h"
#include <co_bt.h>
#include "bsp_led.h"
#include "bsp_lpuart.h"
#include "bsp_button.h"
#include "bsp_wdt.h"
#include "app.h"
#include "reg_ipcore.h"
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "utils.h"
#include "rwip.h"
#include "app_task.h"
#include "Typedefine.h"
#include "ke_timer.h"
#include "global_var.h"
#include "rwip_int.h"
#include "app_pwm_utils.h"
#include "app_pwm.h"
#include "app_light_lightness.h"



extern struct rwip_env_tag rwip_env;
extern otp1_stored_t otp1_stored;
extern void system_opt_read(uint8_t* p_data,uint32_t byte_length);
static void HardFault_Handler_CC(void);
static void models_init(void);
static void button_evt(uint8_t evt);

static void mesh_events_handle(const mesh_evt_t * p_evt);
static mesh_evt_handler_t m_event_handler =
{
    .evt_cb = mesh_events_handle,
};



void make_ble_mac(void)
{
        system_opt_read((uint8_t*)&otp1_stored,sizeof(otp1_stored));
        memcpy(g_co_default_bdaddr.addr,&otp1_stored.flash_uuid[5],6);   
}
static APP_PWM_INSTANCE(PWM0, TIM3);
static app_pwm_config_t m_pwm0_config = APP_PWM_DEFAULT_CONFIG_1CH(LED_PWM_1_PORT, LED_PWM_1_GPIO_PIN);
static pwm_utils_contex_t m_pwm = {
                                    .p_pwm = &PWM0,
                                    .p_pwm_config = &m_pwm0_config,
                                    .channel = 0
                                  };

                                   
int main(void)
{    
    SystemInit();
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);    
    //Redirect Hardfault function.
    REG32(0x200000f0) =(uint32_t) HardFault_Handler_CC;
    //Initialize ble stack.
    HP_BLE_STACK_INIT();
    PATCH_init();
    //Setting RF TX Power
    rf_tx_power_set(TX_POWER_Pos6_DBM);
    //Create a unique ble mac address.
    make_ble_mac(); 
    //Initialize uart for logging.
    bsp_lpuart_init();    
    printf("application start...\r\n");   
    //Initialize evaluation board button driver. 
    bsp_button_init(button_evt);    
    //Initialize evaluation board led driver.
    pwm_utils_enable(&m_pwm);     
    //Initialize watch dog timer.
    bsp_wdt_init();
    //Initialize Q-spi Flash driver.
    Qflash_Init();
    //Initalize ble app task.
    app_init();   
    //Initialze mesh stack.
    hp_mesh_stack_init(models_init);
    //Add a callback to post event
    mesh_evt_handler_add(&m_event_handler);
    //Enable mesh stack
    hp_mesh_stack_enable();
    //Start watch dog timer
//    bsp_wdt_start();

    while(1){
        //Fork and handle events.
        rwip_schedule();
    }
}

__asm int return_sp()
{
    MOV r0, sp
    BX LR
}   
__asm uint32_t getStackedReg(uint32_t regnum, uint32_t u32SP)
{
    lsls    r0, r0, #2
    adds    r0, r0, r1
    ldr     r0, [r0]
    bx      lr
}
/**
 * @brief  Handle the exceptions.
 */
static void HardFault_Handler_CC(void)
{

    uint32_t was_masked;
    _DISABLE_IRQS(was_masked);    
    uint32_t sp = return_sp();
	printf("HardFault_Handler_CC --> 0x%08X\r\n",sp);   
    printf("r0 --> 0x%08X\r\n", getStackedReg(0, sp));
    printf("r1 --> 0x%08X\r\n", getStackedReg(1, sp));
    printf("r2 --> 0x%08X\r\n", getStackedReg(2, sp));
    printf("r3 --> 0x%08X\r\n", getStackedReg(3, sp));  
    printf("r12 --> 0x%08X\r\n",getStackedReg(4, sp));
    printf("lr --> 0x%08X\r\n", getStackedReg(5, sp));
    printf("pc --> 0x%08X\r\n", getStackedReg(6, sp));
    printf("psr --> 0x%08X\r\n",getStackedReg(7, sp));

//    NVIC_SystemReset();

	while(1);
}
static void set_lightness_cb(const app_light_lightness_setup_server_t * p_app, uint16_t lightness);
static void get_lightness_cb(const app_light_lightness_setup_server_t * p_app, uint16_t * p_lightness);
static void transition_time_lightness_cb(const app_light_lightness_setup_server_t * p_server,
                                         uint32_t transition_time_ms, uint16_t target_lightness);
static uint16_t m_pwm0_present_actual_lightness;

APP_LIGHT_LIGHTNESS_SETUP_SERVER_DEF(m_light_lightness_server_0,
                                     false,
                                     MESH_TRANSMIC_SIZE_SMALL,
                                     set_lightness_cb,
                                     get_lightness_cb,
                                     transition_time_lightness_cb)  

static void set_lightness_cb(const app_light_lightness_setup_server_t * p_app, uint16_t lightness)
{
    printf("set_lightness_cb : %d\r\n",lightness);
    m_pwm0_present_actual_lightness = lightness;
    (void)pwm_utils_level_set_unsigned(&m_pwm, m_pwm0_present_actual_lightness);
}

static void get_lightness_cb(const app_light_lightness_setup_server_t * p_app, uint16_t * p_lightness)
{
    
    *p_lightness = (m_pwm0_present_actual_lightness);
    printf("get_lightness_cb : %d\r\n",*p_lightness);
}

static void transition_time_lightness_cb(const app_light_lightness_setup_server_t * p_server,
                                         uint32_t transition_time_ms, uint16_t target_lightness)
{
    printf("Transition time: %d, Target lightness: %d\n", transition_time_ms, target_lightness);                                     
}
static void mesh_events_handle(const mesh_evt_t * p_evt)
{
    
    if (p_evt->type == MESH_EVT_ENABLED)
    {
        printf("mesh post init....\r\n");
        app_light_lightness_binding_setup(&m_light_lightness_server_0);
        mesh_stack_enable(1000);
    }
}
static void models_init(void)
{
    app_light_lightness_model_init(&m_light_lightness_server_0, 0);

    
    
    
}
static void button_evt(uint8_t evt)
{
    switch(evt){
        case BUTTON_EVT_ONE_SHORT_RELEASE:{
            printf("BUTTON_EVT_ONE_SHORT_RELEASE\r\n");

        }break;
        case BUTTON_EVT_TWO_SHORT_RELEASE:{
            printf("BUTTON_EVT_TWO_SHORT_RELEASE\r\n");

        }break;    
        case BUTTON_EVT_TWO_LONG_PUSH:{
            uint32_t was_masked;
            _DISABLE_IRQS(was_masked);              
            hp_mesh_nvds_clear();  
            NVIC_SystemReset();
        }break;        
        
    }
}
int mesh_task_uart_rx_data_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    
    return (KE_MSG_CONSUMED);
}
