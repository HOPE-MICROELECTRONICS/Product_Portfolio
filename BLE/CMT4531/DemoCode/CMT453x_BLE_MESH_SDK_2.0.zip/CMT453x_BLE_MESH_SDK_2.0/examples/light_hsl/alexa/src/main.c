#include "cmt453x.h"
#include "ble_stack_common.h"
#include "prf.h"
#include <co_bt.h>
#include "bsp_led.h"
#include "bsp_lpuart.h"
#include "bsp_button.h"
#include "bsp_wdt.h"
#include "app.h"
#include "reg_ipcore.h"
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "utils.h"
#include "rwip.h"
#include "app_task.h"
#include "Typedefine.h"
#include "ke_timer.h"
#include "global_var.h"
#include "rwip_int.h"
#include "app_pwm_utils.h"
#include "app_pwm.h"
#include "app_light_lightness.h"
#include "app_light_ctl.h"
#include "mesh_config_listener.h"
#include "app_light_hsl.h"
#include "light_hsl_utils.h"
#include "customer_config.h"
#include "mal_adv_inst.h"
#include "net_state.h"



extern struct rwip_env_tag rwip_env;
extern otp1_stored_t otp1_stored;
extern void system_opt_read(uint8_t* p_data,uint32_t byte_length);
static void HardFault_Handler_CC(void);
static void models_init(void);
static void button_evt(uint8_t evt);

static void mesh_events_handle(const mesh_evt_t * p_evt);
static mesh_evt_handler_t m_event_handler =
{
    .evt_cb = mesh_events_handle,
};

void make_ble_mac(void)
{
        system_opt_read((uint8_t*)&otp1_stored,sizeof(otp1_stored));
        memcpy(g_co_default_bdaddr.addr,&otp1_stored.flash_uuid[5],6);             
}


   
 

int main(void)
{   
    SystemInit();
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);
    #if SOP16_LIGHT
    system_delay_n_10us(2000*100);
    #endif
    //Redirect Hardfault function.
    REG32(0x200000f0) =(uint32_t) HardFault_Handler_CC;
    //Initialize uart for logging.
    bsp_lpuart_init(); 
    printf("application start...\r\n");      
    //Initialize ble stack.
    HP_BLE_STACK_INIT();
    PATCH_init();
    //Setting RF TX Power
    rf_tx_power_set(TX_POWER_Pos6_DBM);
    //Create a unique ble mac address.
    make_ble_mac();      
    LOG_HEXDUMP(g_co_default_bdaddr.addr,6);
    //Initialize watch dog timer.
    bsp_wdt_init(); 
    //Initialize evaluation board button driver. 
    bsp_button_init(button_evt);    
    //Initialize evaluation board led driver.
    if(*(volatile uint32_t *)SOFT_RESET_FLAG != 1){
        GPIO_InitType GPIO_InitStructure;
        GPIO_InitStruct(&GPIO_InitStructure);
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
        #if !SMALL_GREEN_BOARD
        GPIO_InitStructure.Pin = GPIO_PIN_6 | GPIO_PIN_4 | GPIO_PIN_5;
        #else
        GPIO_InitStructure.Pin = GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5;
        #endif
        GPIO_InitStructure.GPIO_Mode = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStructure.GPIO_Pull = GPIO_NO_PULL;
        GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);
        #if !SMALL_GREEN_BOARD
        GPIO_SetBits(GPIOB, GPIO_PIN_4);
        GPIO_SetBits(GPIOB, GPIO_PIN_5);    
        GPIO_SetBits(GPIOB, GPIO_PIN_6); 
        #else
        GPIO_SetBits(GPIOB, GPIO_PIN_3);
        GPIO_SetBits(GPIOB, GPIO_PIN_4);
        GPIO_SetBits(GPIOB, GPIO_PIN_5);    
        #endif
    }
    //Initialize Q-spi Flash driver.
    Qflash_Init();   
    //Initalize ble app task.
    mesh_soft_reset_done();      
    app_init();    
    //Initialze mesh stack.
    hp_mesh_stack_init(models_init);    
    customer_config_test1_init();   
    customer_config_test2_init();   
    //Add a callback to post event
    mesh_evt_handler_add(&m_event_handler);     
    //Enable mesh stack
    hp_mesh_stack_enable();    
    //Start watch dog timer
//    bsp_wdt_start();  

    
    #if SOP16_LIGHT
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
        GPIO_InitType GPIO_InitStructure;
        GPIO_InitStruct(&GPIO_InitStructure);
        GPIO_InitStructure.Pin = GPIO_PIN_4 | GPIO_PIN_5;
        GPIO_InitStructure.GPIO_Mode = GPIO_MODE_OUTPUT_PP; 
        GPIO_InitPeripheral(GPIOA, &GPIO_InitStructure);   
        GPIO_SetBits(GPIOA, GPIO_PIN_4);   
        GPIO_SetBits(GPIOA, GPIO_PIN_5);         
    #else
    
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
        GPIO_InitType GPIO_InitStructure;
        GPIO_InitStructure.Pin = GPIO_PIN_6;
        GPIO_InitStructure.GPIO_Mode = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStructure.GPIO_Pull = GPIO_NO_PULL;    
        GPIO_InitPeripheral(GPIOA, &GPIO_InitStructure);
        GPIO_ResetBits(GPIOA, GPIO_PIN_6);       
    #endif

    while(1){
        //Fork and handle events.
        rwip_schedule();
    }
}

__asm int return_sp()
{
    MOV r0, sp
    BX LR
}   
__asm uint32_t getStackedReg(uint32_t regnum, uint32_t u32SP)
{
    lsls    r0, r0, #2
    adds    r0, r0, r1
    ldr     r0, [r0]
    bx      lr
}



static void jlink_print(uint32_t sp)
{
    *(volatile uint32_t *)(0x20004000-4*2) = getStackedReg(0, sp); 
    *(volatile uint32_t *)(0x20004000-4*3) = getStackedReg(1, sp);     
    *(volatile uint32_t *)(0x20004000-4*4) = getStackedReg(2, sp);  
    *(volatile uint32_t *)(0x20004000-4*5) = getStackedReg(3, sp);  
    *(volatile uint32_t *)(0x20004000-4*6) = getStackedReg(4, sp);  
    *(volatile uint32_t *)(0x20004000-4*7) = getStackedReg(5, sp);  
    *(volatile uint32_t *)(0x20004000-4*8) = getStackedReg(6, sp);  
    *(volatile uint32_t *)(0x20004000-4*9) = getStackedReg(7, sp);  

    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
    GPIO_InitType GPIO_InitStructure;
    GPIO_InitStructure.Pin = GPIO_PIN_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStructure.GPIO_Pull = GPIO_NO_PULL;    
    GPIO_InitPeripheral(GPIOA, &GPIO_InitStructure);
    GPIO_SetBits(GPIOA, GPIO_PIN_6);    
    
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
    GPIO_InitStructure.Pin = GPIO_PIN_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStructure.GPIO_Pull = GPIO_NO_PULL;    
    GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);
    GPIO_SetBits(GPIOB, GPIO_PIN_0);     
    
}
/**
 * @brief  Handle the exceptions.
 */
static void HardFault_Handler_CC(void) __attribute__((section("user_function_ram")));
static void HardFault_Handler_CC(void)
{
    uint32_t sp = return_sp() + 24;
	printf("HardFault_Handler_CC --> 0x%08X\r\n",sp);
    printf("r0 --> 0x%08X\r\n", getStackedReg(0, sp));
    printf("r1 --> 0x%08X\r\n", getStackedReg(1, sp));
    printf("r2 --> 0x%08X\r\n", getStackedReg(2, sp));
    printf("r3 --> 0x%08X\r\n", getStackedReg(3, sp));
    printf("r12 --> 0x%08X\r\n",getStackedReg(4, sp));
    printf("lr --> 0x%08X\r\n", getStackedReg(5, sp));
    printf("pc --> 0x%08X\r\n", getStackedReg(6, sp));
    printf("psr --> 0x%08X\r\n",getStackedReg(7, sp));
    


    jlink_print(sp);
    

    
//    NVIC_SystemReset();

	while(1);
}



static void pwm_lightness_hue_saturation_set(uint16_t lightness, uint16_t hue, uint16_t saturation)
{
    float var_1,var_2,H,S,L,R,G,B;
    
    H = hue/65535.0;
    S = saturation/65535.0;
    L = lightness/65535.0;
    
    if(S == 0){
        R = L;
        G = L;
        B = L;
    }else{
        if ( L < 0.5 ) var_2 = L * ( 1 + S );
        else var_2 = ( L + S ) - ( S * L );
        var_1 = 2 * L - var_2;
        R = light_hsl_utils_hue_to_rgb( var_1, var_2, H + ( 1/3 ));
        G = light_hsl_utils_hue_to_rgb( var_1, var_2, H );
        B = light_hsl_utils_hue_to_rgb( var_1, var_2, H - ( 1/3 ));
    }

    if(lightness == 0xfffe && hue == 0 && saturation == 0){
    
        
        #if !SMALL_GREEN_BOARD
        GPIO_ResetBits(GPIOB, GPIO_PIN_4);
        GPIO_ResetBits(GPIOB, GPIO_PIN_5);    
        GPIO_ResetBits(GPIOB, GPIO_PIN_6); 
        #else
        GPIO_ResetBits(GPIOB, GPIO_PIN_3);
        GPIO_ResetBits(GPIOB, GPIO_PIN_4);    
        GPIO_ResetBits(GPIOB, GPIO_PIN_5);    
        #endif          
         
        
    }else if(lightness == 0){

        #if !SMALL_GREEN_BOARD
        GPIO_SetBits(GPIOB, GPIO_PIN_6);
        GPIO_SetBits(GPIOB, GPIO_PIN_4);    
        GPIO_SetBits(GPIOB, GPIO_PIN_5);  
        #else
        GPIO_SetBits(GPIOB, GPIO_PIN_3);
        GPIO_SetBits(GPIOB, GPIO_PIN_4);    
        GPIO_SetBits(GPIOB, GPIO_PIN_5);     
        #endif        
    }else{
    
        
        
        
        if(hue == 0x0000){
            #if !SMALL_GREEN_BOARD
            GPIO_ResetBits(GPIOB, GPIO_PIN_4);    
            GPIO_SetBits(GPIOB, GPIO_PIN_5);    
            GPIO_SetBits(GPIOB, GPIO_PIN_6);  
            #else
            GPIO_ResetBits(GPIOB, GPIO_PIN_3);
            GPIO_SetBits(GPIOB, GPIO_PIN_4);    
            GPIO_SetBits(GPIOB, GPIO_PIN_5);    
            #endif 
        
        }else if(hue == 0x5555){  
            #if !SMALL_GREEN_BOARD
                GPIO_SetBits(GPIOB, GPIO_PIN_4);
                GPIO_ResetBits(GPIOB, GPIO_PIN_5);    
                GPIO_SetBits(GPIOB, GPIO_PIN_6);  
            #else
                GPIO_SetBits(GPIOB, GPIO_PIN_3);
                GPIO_ResetBits(GPIOB, GPIO_PIN_4);    
                GPIO_SetBits(GPIOB, GPIO_PIN_5);   
            #endif      
        }else if(hue == 0xAAAA){
            #if !SMALL_GREEN_BOARD
                GPIO_SetBits(GPIOB, GPIO_PIN_4);
                GPIO_SetBits(GPIOB, GPIO_PIN_5);    
                GPIO_ResetBits(GPIOB, GPIO_PIN_6);  
            #else
                GPIO_SetBits(GPIOB, GPIO_PIN_3);
                GPIO_SetBits(GPIOB, GPIO_PIN_4);    
                GPIO_ResetBits(GPIOB, GPIO_PIN_5); 
            #endif              
        }
    }

    
    
}

                            

static void light_hsl_lightness_set_cb(const app_light_lightness_setup_server_t * p_app, uint16_t lightness);
static void light_hsl_lightness_get_cb(const app_light_lightness_setup_server_t * p_app, uint16_t * p_lightness);
static void ligth_hsl_lightness_transition_cb(const app_light_lightness_setup_server_t * p_server, uint32_t transition_time_ms, uint16_t target_lightness);
APP_LIGHT_LIGHTNESS_SETUP_SERVER_DEF(m_light_hsl_server_0_ll,
                                     false,
                                     MESH_TRANSMIC_SIZE_SMALL,
                                     light_hsl_lightness_set_cb,
                                     light_hsl_lightness_get_cb,
                                     ligth_hsl_lightness_transition_cb)
static app_light_hsl_hw_state_t     m_pwm0_present_hsl_value;                                 
static uint16_t                     m_pwm0_present_actual_lightness;                  
                                     
static void light_hsl_lightness_set_cb(const app_light_lightness_setup_server_t * p_app, uint16_t lightness)
{
    m_pwm0_present_actual_lightness = lightness;
    pwm_lightness_hue_saturation_set(m_pwm0_present_actual_lightness, m_pwm0_present_hsl_value.hue, m_pwm0_present_hsl_value.saturation);
}

static void light_hsl_lightness_get_cb(const app_light_lightness_setup_server_t * p_app, uint16_t * p_lightness)
{
     *p_lightness = m_pwm0_present_actual_lightness;
}

static void ligth_hsl_lightness_transition_cb(const app_light_lightness_setup_server_t * p_server,
                                                   uint32_t transition_time_ms, uint16_t target_lightness)
{

}    
                                     
                                     

static void light_hsl_set_cb(const app_light_hsl_setup_server_t * p_app, app_light_hsl_hw_state_t * present_hsl_state);
static void light_hsl_get_cb(const app_light_hsl_setup_server_t * p_app, app_light_hsl_hw_state_t * present_hsl_state);
static void ligth_hsl_transition_cb(const app_light_hsl_setup_server_t * p_server, uint32_t transition_time_ms, app_light_hsl_hw_state_t target_hsl_state);

APP_LIGHT_HSL_SETUP_SERVER_DEF(m_light_hsl_server_0,
                               false,
                               MESH_TRANSMIC_SIZE_SMALL,
                               light_hsl_set_cb,
                               light_hsl_get_cb,
                               ligth_hsl_transition_cb)

static void light_hsl_set_cb(const app_light_hsl_setup_server_t * p_app, app_light_hsl_hw_state_t * present_hsl_state)
{
    m_pwm0_present_hsl_value.hue = present_hsl_state->hue;
    m_pwm0_present_hsl_value.saturation = present_hsl_state->saturation;
    pwm_lightness_hue_saturation_set(m_pwm0_present_actual_lightness, m_pwm0_present_hsl_value.hue, m_pwm0_present_hsl_value.saturation);

}
static void light_hsl_get_cb(const app_light_hsl_setup_server_t * p_app, app_light_hsl_hw_state_t * present_hsl_state)
{
    present_hsl_state->hue = m_pwm0_present_hsl_value.hue;
    present_hsl_state->saturation = m_pwm0_present_hsl_value.saturation;
}
static void ligth_hsl_transition_cb(const app_light_hsl_setup_server_t * p_server, uint32_t transition_time_ms, app_light_hsl_hw_state_t target_hsl_state)
{

}

int mesh_task_timeout_pwr_on_record_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
   mesh_app_pwr_on_record_clear();
   return (KE_MSG_CONSUMED);
}


static void mesh_events_handle(const mesh_evt_t * p_evt)
{
    if (p_evt->type == MESH_EVT_ENABLED)
    {
        LOG_PRINTF("mesh stack post init\r\n");
        app_light_lightness_binding_setup(&m_light_hsl_server_0_ll);
        app_light_hsl_binding_setup(&m_light_hsl_server_0);
        mesh_stack_enable(1000);
        ke_timer_clear(MESH_TASK_TIMEOUT_FAKE_RESET, TASK_MESH);
        if(!net_state_is_test_mode()){
            ke_timer_set(MESH_TASK_TIMEOUT_FAKE_RESET, TASK_MESH, 120000); 
        }         
        mesh_app_pwr_on_record_set();
        ke_timer_set(MESH_TASK_TIMEOUT_PWR_ON_RECORD, TASK_MESH, 5000);       
    }
}                         
                               
                               
static void models_init(void)
{
    LOG_PRINTF("models_init\r\n");
    app_light_lightness_model_init(&m_light_hsl_server_0_ll, 0);
    app_light_hsl_model_init(&m_light_hsl_server_0, 0, &m_light_hsl_server_0_ll);
}



static void button_evt(uint8_t evt)
{
    switch(evt){
        case BUTTON_EVT_ONE_SHORT_RELEASE:{
            LOG_PRINTF("BUTTON_EVT_ONE_SHORT_RELEASE\r\n");
      
        }break;
        case BUTTON_EVT_TWO_SHORT_RELEASE:{
            LOG_PRINTF("BUTTON_EVT_TWO_SHORT_RELEASE\r\n");
            dsm_local_unicast_address_t address;
            dsm_local_unicast_addresses_get(&address);
            uint8_t net_key[MESH_KEY_SIZE];
            subnet_key_get(net_key,0);
            uint8_t app_key[MESH_KEY_SIZE];
            uint8_t dev_key[MESH_KEY_SIZE];
            appkey_get(app_key,0);
            devkey_get(dev_key,0);
            log_hexdump(g_co_default_bdaddr.addr,6);
            printf("netkey : ");
            log_hexdump(net_key, MESH_KEY_SIZE);             
            printf("appkey : ");
            log_hexdump(app_key, MESH_KEY_SIZE); 
            printf("devkey : ");
            log_hexdump(dev_key, MESH_KEY_SIZE);           
            printf("unicast addr start --> 0x%04X\r\n",address.address_start);
            printf("unicast addr count --> 0x%04X\r\n",address.count);            
            printf("appkey_present --> %d\r\n",appkey_present());
            print_keys();
        }break;    
        case BUTTON_EVT_TWO_LONG_PUSH:{
            uint32_t was_masked;
            _DISABLE_IRQS(was_masked);              
            hp_mesh_nvds_clear();  
            NVIC_SystemReset();
        }break;        
        
    }
}





