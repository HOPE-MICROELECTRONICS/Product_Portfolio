/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/
/**
 * @file app.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */

/** 
 * @addtogroup APP
 * @{ 
 */

#include "app.h"
#include <string.h>
#include <stdio.h>
#include "app_task.h"
#include "gapm_task.h"
#include "rwip.h"
#include "co_bt_defines.h"
#include "gapc_task.h" 
#include "ke_task.h" 
#include "app_task.h"
#include "mesh_gatt.h"
#include "gatt.h"
#include "gattm_int.h"
#include "gapm_int.h"
#include "co_utils.h"
#include "bsp_lpuart.h"


/*BLE stack reset*/
static void reset(void)
{
    struct gapm_reset_cmd *p_cmd = KE_MSG_ALLOC(GAPM_RESET_CMD,TASK_GAPM, TASK_APP,gapm_reset_cmd);
    p_cmd->operation = GAPM_RESET;
    ke_msg_send(p_cmd);
    rwip_schedule();
}

/*BLE device config*/
static void config(void)
{
    struct gapm_set_dev_config_cmd* p_cmd = KE_MSG_ALLOC(GAPM_SET_DEV_CONFIG_CMD,TASK_GAPM, TASK_APP,gapm_set_dev_config_cmd);
    p_cmd->operation = GAPM_SET_DEV_CONFIG;				
    p_cmd->role = GAP_ROLE_ALL;
    p_cmd->pairing_mode = GAPM_PAIRING_DISABLE;
    p_cmd->max_mtu = 517; 
    p_cmd->sugg_max_tx_time   = 2120;
    p_cmd->sugg_max_tx_octets = 200; 	
    p_cmd->privacy_cfg = 0;
    SETF(p_cmd->att_cfg, GAPM_ATT_SLV_PREF_CON_PAR_EN, 1);
    memset((void *)&p_cmd->irk.key[0], 0x00, KEY_LEN);
    ke_msg_send(p_cmd);
    rwip_schedule();
    
}

/*App init*/
void app_init(void)
{ 
    ke_task_create(TASK_APP, &TASK_DESC_APP_M);
    reset();
    config();

}



/*BLE connection parameter update*/
void app_update_param(uint8_t con_idx, struct app_conn_param *p_conn_param)
{
    struct gapc_param_update_cmd *p_cmd = KE_MSG_ALLOC(GAPC_PARAM_UPDATE_CMD,
                                                     KE_BUILD_ID(TASK_GAPC, con_idx), TASK_APP,
                                                     gapc_param_update_cmd);
    p_cmd->operation  = GAPC_UPDATE_PARAMS;
    p_cmd->intv_min   = p_conn_param->intv_min;
    p_cmd->intv_max   = p_conn_param->intv_max;
    p_cmd->latency    = p_conn_param->latency;
    p_cmd->time_out   = p_conn_param->time_out;
    p_cmd->ce_len_min = 0xFFFF;
    p_cmd->ce_len_max = 0xFFFF;
    ke_msg_send(p_cmd);
}



#if defined(CFG_PRF_GAP)
/// GAP Attribute database description
static const struct attm_desc gapm_att_db[GAP_IDX_NUMBER] =
{
    // GAP_IDX_PRIM_SVC - GAP service
    [GAP_IDX_PRIM_SVC]                 =   {ATT_DECL_PRIMARY_SERVICE, PERM(RD, ENABLE), 0, 0},
    // GAP_IDX_CHAR_DEVNAME - device name declaration
    [GAP_IDX_CHAR_DEVNAME]             =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, 0},
    // GAP_IDX_DEVNAME - device name definition
    [GAP_IDX_DEVNAME]                  =   {ATT_CHAR_DEVICE_NAME, (PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE)), PERM(RI, ENABLE), GAP_MAX_NAME_SIZE},
    // GAP_IDX_CHAR_ICON - appearance declaration
    [GAP_IDX_CHAR_ICON]                =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, 0},
    // GAP_IDX_ICON -appearance
    [GAP_IDX_ICON]                     =   {ATT_CHAR_APPEARANCE, PERM(RD, ENABLE), PERM(RI, ENABLE), sizeof(uint16_t)},
    // GAP_IDX_CHAR_SLAVE_PREF_PARAM - Peripheral parameters declaration
    [GAP_IDX_CHAR_SLAVE_PREF_PARAM]    =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, 0},
    // GAP_IDX_SLAVE_PREF_PARAM - Peripheral parameters definition
    [GAP_IDX_SLAVE_PREF_PARAM]         =   {ATT_CHAR_PERIPH_PREF_CON_PARAM, PERM(RD, ENABLE), PERM(RI, ENABLE), sizeof(struct gap_slv_pref)},
    // GAP_IDX_CHAR_ADDR_RESOL - Central Address Resolution declaration
    [GAP_IDX_CHAR_CNT_ADDR_RESOL]      =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, 0},
    // GAP_IDX_ADDR_RESOL_SUPP - Central Address Resolution supported
    [GAP_IDX_CNT_ADDR_RESOL]           =   {ATT_CHAR_CTL_ADDR_RESOL_SUPP, PERM(RD, ENABLE), PERM(RI, ENABLE), sizeof(uint8_t)},
    // GAP_IDX_CHAR_RSLV_PRIV_ADDR_ONLY - Resolvable Private Address Only declaration
    [GAP_IDX_CHAR_RSLV_PRIV_ADDR_ONLY] =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, 0},
    // GAP_IDX_CHAR_RSLV_PRIV_ADDR_ONLY - Resolvable Private Address Only declaration supported
    [GAP_IDX_RSLV_PRIV_ADDR_ONLY]      =   {ATT_CHAR_RSLV_PRIV_ADDR_ONLY, PERM(RD, ENABLE), PERM(RI, ENABLE), sizeof(uint8_t)},
};
#endif
#if defined(CFG_PRF_GATT)
/// GATT Attribute database description
static const struct attm_desc gattm_att_db[GATT_IDX_NUMBER] =
{
    // GATT service
    [GATT_IDX_PRIM_SVC]          = { ATT_DECL_PRIMARY_SERVICE, PERM(RD, ENABLE), 0, 0 },

    // Service Changed
    [GATT_IDX_CHAR_SVC_CHANGED]  = { ATT_DECL_CHARACTERISTIC,  PERM(RD, ENABLE), 0, 0},
    [GATT_IDX_SVC_CHANGED]       = { ATT_CHAR_SERVICE_CHANGED, PERM(IND, ENABLE), PERM(RI, ENABLE), sizeof(uint16_t) *2},
    [GATT_IDX_SVC_CHANGED_CFG]   = { ATT_DESC_CLIENT_CHAR_CFG, (PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE)), 0, sizeof(uint16_t) },

    // Client Supported Features
    [GATT_IDX_CHAR_CLI_SUP_FEAT] = { ATT_DECL_CHARACTERISTIC,  PERM(RD, ENABLE), 0, 0 },
    [GATT_IDX_CLI_SUP_FEAT]      = { ATT_CHAR_CLI_SUP_FEAT,    (PERM(RD, ENABLE)| PERM(WRITE_REQ, ENABLE)), PERM(RI, ENABLE), ATT_MAX_CLI_FEAT_LEN },

    // Database Hash
    [GATT_IDX_CHAR_DB_HASH]      = { ATT_DECL_CHARACTERISTIC,  PERM(RD, ENABLE), 0, 0 },
    [GATT_IDX_DB_HASH]           = { ATT_CHAR_DB_HASH,         PERM(RD, ENABLE), PERM(RI, ENABLE), GAP_KEY_LEN },
};
#endif
static bool gap_gatt_srv_added = false;
void app_gap_gatt_srv_add(void)
{
    if(gap_gatt_srv_added)return;
    gap_gatt_srv_added = true;
    LOG_PRINTF("app_gap_gatt_srv_add\r\n");
    uint8_t status = GAP_ERR_NO_ERROR;
    #if defined(CFG_PRF_GAP)
    /* initialize GAP Start Handle */
    gapm_env.svc_start_hdl = 0x1;
    uint32_t feat_gap = 0x001F | 0x0060 | 0x0180;
            
    /* Create GAP Attribute Database */
    status = attm_svc_create_db(&(gapm_env.svc_start_hdl), ATT_SVC_GENERIC_ACCESS, (uint8_t*) &feat_gap,
    GAP_IDX_NUMBER, NULL, TASK_GAPC, &gapm_att_db[0],
    PERM(SVC_MI, ENABLE));

    if(status != GAP_ERR_NO_ERROR)
    {
            return;
    }
    #endif // defined(CFG_PRF_GAP)

    #if defined(CFG_PRF_GATT)                        
    /* initialize GATT Start Handle */
    gattm_env.svc_start_hdl = 0x0;
    uint32_t feat_gatt = 0x00FF;
    
    /* Create GATT Attribute Database */
    status = attm_svc_create_db(&(gattm_env.svc_start_hdl), ATT_SVC_GENERIC_ATTRIBUTE, (uint8_t*) &feat_gatt, GATT_IDX_NUMBER,
            NULL, TASK_GATTC, &gattm_att_db[0], PERM(SVC_MI, ENABLE));
    
    if(status != GAP_ERR_NO_ERROR)
    {
            return;
    }
    #endif // defined(CFG_PRF_GATT)   

}
void app_gap_gatt_srv_add_clear(void)
{
    gap_gatt_srv_added = false;
}
