#ifndef __MESH_APP_H__
#define __MESH_APP_H__



#include <stdint.h>
#include <stdbool.h>

typedef struct {

    void (*set_uuid)(uint8_t *uuid);
    
    
    
    

}mesh_user_callback;



void hp_mesh_stack_init(void (*model_init)(void));
void hp_mesh_stack_enable(void);
void hp_mesh_nvds_clear(void);
void mesh_soft_reset(uint32_t address, bool baseband_reset);
void mesh_soft_reset_done(void);
void mesh_soft_reset_test(uint32_t address);
void mesh_soft_reset_baseband(void);
uint32_t check_ke_mem_used_size(void);
void mesh_app_pwr_on_record_set(void);
void mesh_app_pwr_on_record_clear(void);

#endif //__MESH_APP_H__
