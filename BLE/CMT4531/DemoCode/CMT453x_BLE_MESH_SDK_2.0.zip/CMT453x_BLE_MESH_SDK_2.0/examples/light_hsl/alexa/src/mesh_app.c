/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file mesh_app.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "cmt453x.h"
#include "gapm_task.h"
#include "rwip.h"
#include "co_bt_defines.h"
#include "gapc_task.h" 
#include "ke_task.h" 
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "rwip.h"
#include "app_task.h"
#include "rwip_int.h"
#include "mesh.h"
#include "flash_manager.h"
#include "mesh_opt.h"
#include "mesh_events.h"
#include "event.h"
#include "stdio.h"
#include "bsp_lpuart.h"
#include "app.h"
#include "Typedefine.h"



typedef void (*func_ptr_t)(void);
static volatile uint32_t was_masked;
/**
 * @brief  Reset the flash sectors.
 */
void hp_mesh_nvds_clear(void)
{    
    for(int i=1;i<MESH_OPT_FIRST_FREE_ID;i++)
    {
        Qflash_Erase_Sector(MESH_CONFIG_FLASH_START+((i)*4096));
    }
}

/**
 * @brief  Initialize the mesh stack.
 * @param  model_init function used to initialize the application models.
 */
void hp_mesh_stack_init(void (*model_init)(void))
{ 
    ke_task_delete(TASK_MESH);  
    ke_task_create(TASK_MESH, &TASK_DESC_MESH_M);          
    mesh_stack_init(model_init);    
}

int mesh_task_post_init_evt_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    LOG_PRINTF("mesh_task_post_init_evt_handler\r\n");
    const mesh_evt_t enabled =
    {
        .type = MESH_EVT_ENABLED,
    };
    event_handle(&enabled);    
    return (KE_MSG_CONSUMED);
}
/**
 * @brief  Mesh stack enables.
 */
void hp_mesh_stack_enable(void)
{
    ke_msg_send_basic(MESH_TASK_POST_INIT_EVT, TASK_MESH, TASK_NONE);
}

#define GLOBAL_INT_DISABLE()        \
uint32_t ui32IntStatus = 0;         \
do{                                 \
    ui32IntStatus = __get_PRIMASK();\
    __set_PRIMASK(1);               \
}while(0)

#define GLOBAL_INT_RESTORE()     \
do{                              \
    __set_PRIMASK(ui32IntStatus);\
}while(0)
#define IP_DEEPSLCNTL_ADDR   BASEBAND_REG_BASE +0x30
#include "reg_ipcore.h"
#include "reg_blecore.h"
#include "rwip.h"
#include "global_var.h"
#include "global_func.h"
#include "Typedefine.h"


void mesh_soft_reset(uint32_t address, bool baseband_reset)
{
    //reset baseband
    if(baseband_reset)
    {
        uint32_t timeout = 20;
        bool should_break = false; 
        scanner_radio_stop();
        rwip_schedule();
        system_delay_n_10us(10*100);
        while(true){
            
            GLOBAL_INT_DISABLE();   
            switch(rwip_sleep()){
                case RWIP_DEEP_SLEEP:{
                    LOG_PRINTF("RWIP_DEEP_SLEEP\r\n");
                    RCC->APB1PCLKEN |= RCC_APB1_PERIPH_PWR; 
                    REG32(0x40028030) |=  0x07;
                    while(PWR->CR1&0x20);
                    PWR->CR2 |= 0x100; //1<<8
                    while(!(PWR->CR1&0x20)); 
                    rwip_env.prevent_sleep = 0;
                    should_break = true;
                }break;
                case RWIP_CPU_SLEEP:{
                    LOG_PRINTF("RWIP_CPU_SLEEP\r\n");
                    EXTI_PA11_Configuration(); 
                    SCB->SCR &= 0xFB;
                    __WFI();  
                    if(timeout == 0){
                        RCC->APB1PCLKEN |= RCC_APB1_PERIPH_PWR; 
                        REG32(0x40028030) |=  0x07;
                        while(PWR->CR1&0x20);
                        PWR->CR2 |= 0x100; //1<<8
                        while(!(PWR->CR1&0x20)); 
                        should_break = true;      
                    }else{
                        timeout--;
                    }
                }break;            
                case RWIP_ACTIVE:{
                    LOG_PRINTF("RWIP_ACTIVE\r\n");
                }break;            
            }
            GLOBAL_INT_RESTORE();  
            if(should_break){
                break;
            }else{
                rwip_schedule();
            }
        }         
    }
    //reset baseband  

    do{
        _DISABLE_IRQS(was_masked);  
        NVIC_ClearPendingIRQ(BLE_SW_IRQn);
        NVIC_DisableIRQ(BLE_SW_IRQn);        
        NVIC_ClearPendingIRQ(BLE_HSLOT_IRQn);
        NVIC_DisableIRQ(BLE_HSLOT_IRQn);          
        NVIC_ClearPendingIRQ(BLE_ERROR_IRQn);
        NVIC_DisableIRQ(BLE_ERROR_IRQn);          
        NVIC_ClearPendingIRQ(BLE_TIMESTAMP_TGT1_IRQn);
        NVIC_DisableIRQ(BLE_TIMESTAMP_TGT1_IRQn);  
        NVIC_ClearPendingIRQ(BLE_TIMESTAMP_TGT2_IRQn);
        NVIC_DisableIRQ(BLE_TIMESTAMP_TGT2_IRQn);  
        NVIC_ClearPendingIRQ(BLE_SLP_IRQn);
        NVIC_DisableIRQ(BLE_SLP_IRQn);           
        attmdb_destroy();
        *(volatile uint32_t *)SOFT_RESET_FLAG = 1;     
        uint32_t JumpAddress;
        func_ptr_t JumpToApplication;
        JumpAddress = *(__IO uint32_t *)(address + 4);
        JumpToApplication = (func_ptr_t)JumpAddress;
        __set_MSP(*(__IO uint32_t *)address);
        JumpToApplication();    
    }while(0);

} 


void mesh_soft_reset_done(void)
{
    LOG_PRINTF("mesh_soft_reset_done : %d\r\n",*(volatile uint32_t *)SOFT_RESET_FLAG);
    if(*(volatile uint32_t *)SOFT_RESET_FLAG == 1)
    {     
        NVIC_EnableIRQ(BLE_SW_IRQn);        
        NVIC_EnableIRQ(BLE_HSLOT_IRQn);          
        NVIC_EnableIRQ(BLE_ERROR_IRQn);          
        NVIC_EnableIRQ(BLE_TIMESTAMP_TGT1_IRQn);  
        NVIC_EnableIRQ(BLE_TIMESTAMP_TGT2_IRQn);  
        NVIC_EnableIRQ(BLE_SLP_IRQn);             
        _ENABLE_IRQS(was_masked);
    }
    *(volatile uint32_t *)SOFT_RESET_FLAG = 0;
}





void mesh_soft_reset_test(uint32_t address)
{
    do{
        _DISABLE_IRQS(was_masked);  
        LOG_PRINTF("mesh_soft_reset : %d\r\n",*(volatile uint32_t *)SOFT_RESET_FLAG);
        *(volatile uint32_t *)SOFT_RESET_FLAG = 1;     
        LOG_PRINTF("mesh_soft_reset : %d\r\n",*(volatile uint32_t *)SOFT_RESET_FLAG);
        uint32_t JumpAddress;
        func_ptr_t JumpToApplication;
        JumpAddress = *(__IO uint32_t *)(address + 4);
        JumpToApplication = (func_ptr_t)JumpAddress;
        __set_MSP(*(__IO uint32_t *)address);
        JumpToApplication();    
    }while(0);

}

void mesh_soft_reset_baseband(void)
{
    RCC->APB1PCLKEN |= RCC_APB1_PERIPH_PWR; // PWR enable
    REG32(0x40028030) |=  0x07;
    while(PWR->CR1&0x20);
    PWR->CR2 |= 0x100; //1<<8
    while(!(PWR->CR1&0x20)); 

} 

#include "ke_env.h"
struct mblock_free
{
    uint16_t corrupt_check;
    uint16_t free_size;
    struct mblock_free* next;
    struct mblock_free* previous;
};
uint32_t check_ke_mem_used_size(void)
{
    uint16_t heap_used[KE_MEM_BLOCK_MAX];
    uint32_t max_heap_used = 0;    
    uint8_t cursor = 0;
    struct mblock_free *node = NULL;
    GLOBAL_INT_DISABLE();
    while((cursor < KE_MEM_BLOCK_MAX))
    {   
        uint8_t heap_id = CO_MOD((cursor), KE_MEM_BLOCK_MAX);
        uint32_t totalfreesize = 0;
        node = ke_env.heap[heap_id];
        while (node != NULL)
        {
            totalfreesize += node->free_size;
            node = node->next;
        }     
        heap_used[heap_id] = ke_env.heap_size[heap_id] - totalfreesize;
        cursor ++;
    }
    uint32_t totalusedsize = 0;
    for(cursor = 0 ; cursor < KE_MEM_BLOCK_MAX ; cursor ++)
    {
        totalusedsize +=  heap_used[cursor];
    }

    if(max_heap_used < totalusedsize)
    {
        max_heap_used = totalusedsize;
    }
    GLOBAL_INT_RESTORE();
    
    return max_heap_used;
    
    
}

static void memalloc_failed(void) __attribute__ ((section(".ARM.__at_0x1001000"))) __attribute__((used));                            
static void memalloc_failed(void)                                  
{
    mesh_soft_reset(0x1000000,false);    
}    


#define LIGHT_PWR_ON_RECORD_ADDRESS   0x01030000       
void mesh_app_pwr_on_record_set(void)
{
    //��flashĥ��
    uint16_t record = 0 ;
    uint16_t i = 0;
    for(i = 0; i < 4095;)
    {
        record = *(uint16_t *)(LIGHT_PWR_ON_RECORD_ADDRESS + i);
        if(record){
            break;
        }
        i += 2;
    }
    if(record < (0xFFFF - 4)){
        Qflash_Erase_Sector(LIGHT_PWR_ON_RECORD_ADDRESS);
        hp_mesh_nvds_clear();
        NVIC_SystemReset();        
        while(1);        
    }else{
        record--;
        Qflash_Write(LIGHT_PWR_ON_RECORD_ADDRESS + i, (uint8_t*)&record, 2);
    }
    
}

void mesh_app_pwr_on_record_clear(void)
{
    uint16_t record = 0 ;
    uint16_t i = 0;
    for(i = 0; i < 4095;)
    {
        record = *(uint16_t *)(LIGHT_PWR_ON_RECORD_ADDRESS + i);
        if(record){
            break;
        }
        i += 2;
    }    
    if(i >= 4094){
        Qflash_Erase_Sector(LIGHT_PWR_ON_RECORD_ADDRESS);
    }else{
        record = 0;
        Qflash_Write(LIGHT_PWR_ON_RECORD_ADDRESS + i, (uint8_t*)&record, 2);
    }
   
}









