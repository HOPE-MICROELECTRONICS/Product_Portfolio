/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file mesh_app_task.h
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */

#ifndef __MESH_APP_TASK_H__
#define __MESH_APP_TASK_H__





#include "rwip_config.h"   
#include <stdint.h>         // Standard Integer
#include "rwip_task.h"      // Task definitions
#include "ke_task.h"        // Kernel Task
#include "ke_timer.h" 
#include "mesh.h"

/* Mesh tasks id */
enum mesh_msg_id
{
    MESH_DUMMY_MSG = TASK_FIRST_MSG(TASK_ID_MESH),

    

    
    MESH_TASK_BUTTON_TIMER,
    MESH_TASK_FLASH_EVT,
    MESH_TASK_FLASH_END_EVT,
    MESH_TASK_FLASH_DEFRAG_EVT,
    MESH_TASK_BEARER_EVENT,
    MESH_TASK_START_SCAN,
    MESH_TASK_STOP_SCAN,
    MESH_TASK_GATT_RESET,
    MESH_TASK_WDT,    
    MESH_TASK_SCHEDULE_TIMER,
    MESH_TASK_AD_REPORT_MESH,  
    MESH_TASK_AD_BEACON_REPORT_MESH, 
    MESH_TASK_TIMER_SCHED_TIMEOUT,
    MESH_TASK_MODEL_TIMER_LL,
    MESH_TASK_MODEL_TIMER_CTL,
    MESH_TASK_MODEL_TIMER_HSL,
    MESH_TASK_PROVISION_COMPLETE,
    MESH_TASK_TIMEOUT_FAKE_RESET,
    MESH_TASK_TIMEOUT_PWR_ON_RECORD,
    MESH_TASK_PROVISION_ERROR_TIMER,
    
    MESH_TASK_POST_INIT_EVT,
};

struct ad_report_cmd
{
    uint32_t ad_packet_length;
    mesh_rx_metadata_t metadata;
    uint8_t p_packet[];
};

//#define SMALL_GREEN_BOARD 1

//#define SOP16_LIGHT         1

#endif //__MESH_APP_TASK_H__

