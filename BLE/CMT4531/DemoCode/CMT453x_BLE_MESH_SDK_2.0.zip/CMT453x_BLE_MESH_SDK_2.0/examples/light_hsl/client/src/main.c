#include "cmt453x.h"
#include "ble_stack_common.h"
#include "prf.h"
#include <co_bt.h>
#include "bsp_led.h"
#include "bsp_lpuart.h"
#include "bsp_button.h"
#include "bsp_wdt.h"
#include "app.h"
#include "reg_ipcore.h"
#include "mesh_app.h"
#include "mesh_app_task.h"
#include "utils.h"
#include "rwip.h"
#include "app_task.h"
#include "Typedefine.h"
#include "ke_timer.h"
#include "global_var.h"
#include "rwip_int.h"
#include "mesh_events.h"
#include "light_hsl_client.h"
#include "bsp_uart.h"
#include "light_hsl_common.h"


extern struct rwip_env_tag rwip_env;
extern otp1_stored_t otp1_stored;
extern void system_opt_read(uint8_t* p_data,uint32_t byte_length);
static void HardFault_Handler_CC(void);
static void models_init(void);
static void button_evt(uint8_t evt);

static void mesh_events_handle(const mesh_evt_t * p_evt);
static mesh_evt_handler_t m_event_handler =
{
    .evt_cb = mesh_events_handle,
};




void make_ble_mac(void)
{
        system_opt_read((uint8_t*)&otp1_stored,sizeof(otp1_stored));
        memcpy(g_co_default_bdaddr.addr,&otp1_stored.flash_uuid[5],6);   
}





int main(void)
{
    SystemInit();
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);
    //Redirect Hardfault function.
    REG32(0x200000f0) =(uint32_t) HardFault_Handler_CC;
    //Initialize ble stack.
    HP_BLE_STACK_INIT();
    PATCH_init();
    //Setting RF TX Power
    rf_tx_power_set(TX_POWER_Pos6_DBM);
    //Create a unique ble mac address.
    make_ble_mac();      
    //Initialize uart for logging.
    bsp_usart1_init();  
    bsp_lpuart_init();    
    printf("application start...\r\n");   
    LOG_HEXDUMP(g_co_default_bdaddr.addr,6);
    //Initialize watch dog timer.
    bsp_wdt_init(); 
    //Initialize evaluation board button driver. 
    bsp_button_init(button_evt);    
    //Initialize Q-spi Flash driver.
    Qflash_Init();   
    //Initalize ble app task.    
    app_init();    
    //Initialze mesh stack.
    hp_mesh_stack_init(models_init);    
    //Add a callback to post event
    mesh_evt_handler_add(&m_event_handler);     
    //Enable mesh stack
    hp_mesh_stack_enable();    
    //Start watch dog timer
//    bsp_wdt_start();  

    while(1){
        //Fork and handle events.
        rwip_schedule();
    }
}

__asm int return_sp()
{
    MOV r0, sp
    BX LR
}   
__asm uint32_t getStackedReg(uint32_t regnum, uint32_t u32SP)
{
    lsls    r0, r0, #2
    adds    r0, r0, r1
    ldr     r0, [r0]
    bx      lr
}
/**
 * @brief  Handle the exceptions.
 */
static void HardFault_Handler_CC(void) __attribute__((section("user_function_ram")));
static void HardFault_Handler_CC(void)
{
    uint32_t sp = return_sp();
	LOG_PRINTF("HardFault_Handler_CC --> 0x%08X\r\n",sp);
    LOG_PRINTF("r0 --> 0x%08X\r\n", getStackedReg(0, sp));
    LOG_PRINTF("r1 --> 0x%08X\r\n", getStackedReg(1, sp));
    LOG_PRINTF("r2 --> 0x%08X\r\n", getStackedReg(2, sp));
    LOG_PRINTF("r3 --> 0x%08X\r\n", getStackedReg(3, sp));
    LOG_PRINTF("r12 --> 0x%08X\r\n",getStackedReg(4, sp));
    LOG_PRINTF("lr --> 0x%08X\r\n", getStackedReg(5, sp));
    LOG_PRINTF("pc --> 0x%08X\r\n", getStackedReg(6, sp));
    LOG_PRINTF("psr --> 0x%08X\r\n",getStackedReg(7, sp));
    
//    NVIC_SystemReset();

	while(1);
}






static void mesh_events_handle(const mesh_evt_t * p_evt)
{
    if (p_evt->type == MESH_EVT_ENABLED)
    {
        mesh_stack_enable(1000);        
    }
}                               



static void app_light_hsl_client_publish_interval_cb(access_model_handle_t handle, void * p_self);
static void app_light_hsl_client_transaction_status_cb(access_model_handle_t model_handle, void * p_args, access_reliable_status_t status);
static void light_hsl_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_status_params_t * p_in);
static void light_hsl_hue_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_hue_status_params_t * p_in);
static void light_hsl_saturation_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_saturation_status_params_t * p_in);
static void light_hsl_default_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_default_status_params_t * p_in);
static void light_hsl_range_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_range_status_params_t * p_in);

static light_hsl_client_t m_clients[CLIENT_MODEL_INSTANCE_COUNT];                     
      

static const light_hsl_client_callbacks_t m_client_cbs =
{
    .light_hsl_state_status_cb              =   light_hsl_state_status_cb,                    
    .light_hsl_hue_state_status_cb          =   light_hsl_hue_state_status_cb,      
    .light_hsl_saturation_state_status_cb   =   light_hsl_saturation_state_status_cb, 
    .light_hsl_default_state_status_cb      =   light_hsl_default_state_status_cb,      
    .light_hsl_range_state_status_cb        =   light_hsl_range_state_status_cb,                
    .ack_transaction_status_cb              =   app_light_hsl_client_transaction_status_cb,
    .periodic_publish_cb                    =   app_light_hsl_client_publish_interval_cb,
};

static light_hsl_set_params_t m_set_params;
static light_hsl_hue_set_params_t m_hue_set_params;
static light_hsl_saturation_set_params_t m_saturation_set_params;
static light_hsl_default_set_params_t m_default_set_params;


static void models_init(void)
{
    m_set_params.lightness = 0;
    m_hue_set_params.hue = 0;
    m_saturation_set_params.saturation = 0;
    for (uint32_t i = 0; i < CLIENT_MODEL_INSTANCE_COUNT; ++i)
    {
        m_clients[i].settings.p_callbacks = &m_client_cbs;
        m_clients[i].settings.timeout = 0;
        m_clients[i].settings.force_segmented = false;
        m_clients[i].settings.transmic_size = MESH_TRANSMIC_SIZE_SMALL;
        light_hsl_client_init(&m_clients[i], i + 1);
    }       
    
}

static void app_light_hsl_client_publish_interval_cb(access_model_handle_t handle, void * p_self)
{
     printf("%s\n", __FUNCTION__);
}
static void app_light_hsl_client_transaction_status_cb(access_model_handle_t model_handle, void * p_args, access_reliable_status_t status)
{
     printf("%s\n", __FUNCTION__);
    
    
}
static void light_hsl_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_status_params_t * p_in)
{
     printf("%s\n", __FUNCTION__);       
    
}
static void light_hsl_hue_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_hue_status_params_t * p_in)
{
     printf("%s\n", __FUNCTION__);
}
static void light_hsl_saturation_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_saturation_status_params_t * p_in)
{
     printf("%s\n", __FUNCTION__);
}
static void light_hsl_default_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_default_status_params_t * p_in)
{
     printf("%s\n", __FUNCTION__);
}
static void light_hsl_range_state_status_cb(const light_hsl_client_t * p_self, const access_message_rx_meta_t * p_meta, const light_hsl_range_status_params_t * p_in)
{
     printf("%s\n", __FUNCTION__);
}


static void button_evt(uint8_t evt)
{
    switch(evt){
        case BUTTON_EVT_ONE_SHORT_RELEASE:{
            printf("BUTTON_EVT_ONE_SHORT_RELEASE\r\n");           
        }break;
        case BUTTON_EVT_TWO_SHORT_RELEASE:{
            printf("BUTTON_EVT_TWO_SHORT_RELEASE\r\n");
        }break;    
        case BUTTON_EVT_TWO_LONG_PUSH:{
            uint32_t was_masked;
            _DISABLE_IRQS(was_masked);              
            hp_mesh_nvds_clear();  
            NVIC_SystemReset();
        }break;        
        
    }
}


#define APP_LIGHTNESS_STEP_SIZE          (300L)
#define APP_TIMEOUT_FOR_TID_CHANGE       (3)
#define APP_DELAY_MS                 (1000)
#define APP_TRANSITION_TIME_MS       (1000)

#define APP_HUE_STEP_SIZE            (300L)
#define APP_HUE_MIN                  (0)
#define APP_HUE_MAX                  (0xFFFF)

int mesh_task_uart_rx_data_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    uint8_t data = *(uint8_t *)p_param;
    uint32_t num = 0xFFFFFFFF;
    if (data >= '1' && data <= '9')
    {
        num = data - '1';
    }
    if (data >= 'a' && data <= 'f')
    {
        num = data - 'a' + 0xa;
    }     
    if (num < 0xa)
    {
        num++;
    }    
    printf("num %u passed\r\n", num);
    uint32_t status = MESH_SUCCESS;
    static uint8_t client = 0;
    printf("client --> %d\r\n",client);
    model_transition_t transition_params;
    static uint32_t timestamp = 0;
    timestamp_t current_time;   
    
    switch(num)
    {
        case 1:
            m_set_params.lightness = (m_set_params.lightness + APP_LIGHTNESS_STEP_SIZE);
            m_set_params.hue = (m_set_params.hue + APP_HUE_STEP_SIZE);
            m_set_params.saturation = m_saturation_set_params.saturation;;
            m_set_params.tid++;
            break;
        case 2:
            m_set_params.lightness = (m_set_params.lightness - APP_LIGHTNESS_STEP_SIZE);
            m_set_params.hue = m_hue_set_params.hue - APP_HUE_STEP_SIZE;
            m_set_params.saturation = m_saturation_set_params.saturation;;
            m_set_params.tid++;
            break;        
        case 3:
            m_set_params.lightness = 0;
            m_set_params.hue = 0;
            m_set_params.saturation = 0;
            m_set_params.tid++;
            break;
        case 4:
            m_set_params.hue = (m_set_params.hue - APP_HUE_STEP_SIZE) <= APP_HUE_MIN ? APP_HUE_MIN : m_set_params.hue - APP_HUE_STEP_SIZE;
            m_set_params.tid++;
            break;
        case 13:
            m_default_set_params.lightness =(m_default_set_params.lightness + APP_LIGHTNESS_STEP_SIZE) >= UINT16_MAX ? UINT16_MAX : m_default_set_params.lightness + APP_LIGHTNESS_STEP_SIZE;
            break;
        
        
        default:
            break;
    }    
    current_time = bsp_time_now();
    if (timestamp + SEC_TO_US(APP_TIMEOUT_FOR_TID_CHANGE) < current_time)
    {
        m_hue_set_params.tid++;
        m_set_params.tid++;
        m_saturation_set_params.tid++;
    }
    timestamp = current_time;

    transition_params.delay_ms = APP_DELAY_MS;
    transition_params.transition_time_ms = 100;
    switch (num)
    {
        case 1:
            status = light_hsl_client_set(&m_clients[client], &m_set_params, NULL);
            break;
        case 2:
            status = light_hsl_client_set(&m_clients[client], &m_set_params, NULL);
            break;    
        case 3:
        case 4:
            status = light_hsl_client_set_unack(&m_clients[client], &m_set_params, &transition_params, 0);
            break;
        case 7:
            status = light_hsl_client_get(&m_clients[client]);
            break;
        case 8:
            status = light_hsl_client_hue_get(&m_clients[client]);
            break;
        case 9:
            status = light_hsl_client_saturation_get(&m_clients[client]);
            break;
        case 10:
            status = light_hsl_client_default_get(&m_clients[client]);
            break;        
        case 11:
            status = light_hsl_client_range_get(&m_clients[client]);
            break;        
        case 12:
            status = light_hsl_client_target_get(&m_clients[client]);
            break;        
        case 13:
            status = light_hsl_client_default_set_unack(&m_clients[client], &m_default_set_params, 0);
            break;        
        
        case 0xe:
            client++;
            client = (client < CLIENT_MODEL_INSTANCE_COUNT) ? client : 0;
            printf("Switching to client instance: %d\n", client);
            break;      
        default:
            break;
    }

    switch (status)
    {
        case MESH_SUCCESS:
            break;

        case MESH_ERROR_NO_MEM:
        case MESH_ERROR_BUSY:
        case MESH_ERROR_INVALID_STATE:
            printf("Client %u cannot send: status: %d\n", client, status);
            break;

        case MESH_ERROR_INVALID_PARAM:
            printf("Publication not configured for client %u\n", client);
            break;
        default:
            break;
    }    
    
    
    return (KE_MSG_CONSUMED);
}



