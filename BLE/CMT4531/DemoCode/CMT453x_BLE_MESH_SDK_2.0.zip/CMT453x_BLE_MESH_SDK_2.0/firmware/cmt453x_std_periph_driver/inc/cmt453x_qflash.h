/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file cmt453x_qflash.h
 * @version v1.0.1
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */
#ifndef __CMT453X_QFLASH_H__
#define __CMT453X_QFLASH_H__

#ifdef __cplusplus
extern "C" {
#endif
    
#include "cmt453x.h"
/** @addtogroup CMT453X_StdPeriph_Driver
 * @{
 */

/** @addtogroup QFLASH
 * @{
 */
    
/** @addtogroup QFLASH_Defines
 * @{
 */ 
#define Qflash_Erase_Sector_Raw     Qflash_Erase_Sector 
#define Qflash_Write_Raw            Qflash_Write
 
#define FLASH_PAGE_SIZE             0x100
#define FLASH_SECTOR_SIZE           0x1000
/**
 * @}
 */
 
/** @addtogroup QFLASH_ReturnMsg
 * @{
 */
typedef enum{
    FlashOperationSuccess,
    FlashWriteRegFailed,
    FlashTimeOut,
    FlashIsBusy,
    FlashQuadNotEnable,
    FlashAddressInvalid,
}ReturnMsg; 
/**
 * @}
 */

/** @addtogroup RCC_Exported_Functions
 * @{
 */
void Qflash_Init(void);
void Qflash_Erase_Sector(uint32_t address);
void Qflash_Write(uint32_t address, uint8_t* p_data, uint32_t len);
void Qflash_Read(uint32_t address, uint8_t* p_data, uint32_t len);
void Qflash_Erase_Sector_WX_Mask(uint32_t address);
void Qflash_Write_With_Mask(uint32_t address, uint8_t* p_data, uint32_t len);

#ifdef __cplusplus
}
#endif

#endif /* __CMT453X_QFLASH_H__ */
/**
 * @}
 */    

/**
 * @}
 */

/**
 * @}
 */
