/***************************************************************************//**
* # License
* Copyright 2022 HOPE Microelectronics CO., Ltd. 
* All rights reserved.
* 
* IMPORTANT: All rights of this software belong to HOPE Microelectronics 
* CO., Ltd. ("HOPERF"). Your use of this Software is limited to those 
* specific rights granted under the terms of the business contract, the 
* confidential agreement, the non-disclosure agreement and any other forms 
* of agreements as a customer or a partner of HOPERF. You may not use this 
* Software unless you agree to abide by the terms of these agreements. 
* You acknowledge that the Software may not be modified, copied, 
* distributed or disclosed unless embedded on a HOPERF Bluetooth Low Energy 
* (BLE) integrated circuit, either as a product or is integrated into your 
* products.  Other than for the aforementioned purposes, you may not use, 
* reproduce, copy, prepare derivative works of, modify, distribute, perform, 
* display or sell this Software and/or its documentation for any purposes.
* 
* YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE 
* PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
* INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, 
* NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL 
* CMOSTEK OR ITS SUBSIDIARIES BE LIABLE OR OBLIGATED UNDER CONTRACT, 
* NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER 
* LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING 
* BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF 
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES 
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.  
*******************************************************************************/

/**
 * @file system_cmt453x.c
 * @version v1.0.0
 *
 * @copyright Copyright 2022 HOPE Microelectronics CO., Ltd. All rights reserved.
 */
#include "cmt453x.h"
#include "string.h"
/* Uncomment the line corresponding to the desired System clock (SYSCLK)
   frequency (after reset the HSI is used as SYSCLK source)

   IMPORTANT NOTE:
   ==============
   1. After each device reset the HSI is used as System clock source.

   2. Please make sure that the selected System clock doesn't exceed your
   device's maximum frequency.

   3. If none of the define below is enabled, the HSI is used as System clock
    source.

   4. The System clock configuration functions provided within this file assume
   that:
        - HSI is configer as 64M and used to driverd the system clock.
        - External 32MHz crystal use for Bluetooth RF system only.
        - If Bluetooth stack is enable, we should select the LSI or LSE when configer
          the Bluetooth stack only.
*/

#define SYSCLK_USE_HSI     1
#define SYSCLK_USE_HSE     0

#ifndef SYSCLK_FREQ
#define SYSCLK_FREQ HSI_VALUE
#endif

/*
* SYSCLK_SRC *
** SYSCLK_USE_HSI     **
** SYSCLK_USE_HSE     **
*/
#ifndef SYSCLK_SRC
#define SYSCLK_SRC SYSCLK_USE_HSI
#endif



#define OTP1_ADDR 0x1000 
#define OTP_READ_CMD_CODE_LEN  0x140
#define OTP_READ_CMD_CODE_CRC  0x3aa0
const unsigned char  otp_read_code_array[] ={
0x40,0xba,0x70,0x47,0xc0,0xba,0x70,0x47,0x01,0x38,0xfd,0xd1,0x70,0x47,0x00,0x00,
0xf7,0xb5,0x03,0x25,0xad,0x06,0x28,0x6a,0x82,0xb0,0x16,0x46,0x0c,0x46,0x40,0x08,
0x40,0x00,0x28,0x62,0x28,0x6a,0x02,0x21,0x08,0x43,0x28,0x62,0x28,0x6a,0x80,0x07,
0xfc,0xd4,0x66,0x20,0x68,0x60,0x01,0x27,0x2f,0x61,0xa8,0x6a,0xc0,0x05,0xfc,0xd5,
0x99,0x20,0x68,0x60,0x2f,0x61,0xa8,0x6a,0xc0,0x05,0xfc,0xd5,0xff,0x20,0x91,0x30,
0xff,0xf7,0xda,0xff,0xff,0x23,0x01,0x33,0xab,0x62,0x68,0x46,0xef,0x60,0x35,0x21,
0x69,0x60,0x2f,0x61,0xa9,0x6a,0xc9,0x05,0xfc,0xd5,0xab,0x62,0xa9,0x69,0xef,0x60,
0xc9,0xb2,0x05,0x22,0x6a,0x60,0x2f,0x61,0xaa,0x6a,0xd2,0x05,0xfc,0xd5,0xab,0x62,
0xaa,0x69,0x09,0x02,0xd2,0xb2,0x11,0x43,0x01,0x80,0xc8,0x07,0x02,0xd0,0x03,0x20,
0x05,0xb0,0xf0,0xbd,0xab,0x62,0x68,0x69,0xff,0x21,0x08,0x31,0x88,0x43,0x68,0x61,
0x68,0x69,0xc9,0x1e,0x08,0x43,0x68,0x61,0x02,0x98,0x00,0x02,0x48,0x30,0x68,0x60,
0x08,0x20,0xa8,0x60,0xee,0x60,0x2f,0x61,0xa8,0x6a,0xc0,0x05,0xfc,0xd5,0xff,0x20,
0x01,0x30,0xa8,0x62,0x00,0x23,0xf6,0x1c,0xb0,0x08,0x0e,0xd0,0xb2,0x08,0x11,0x48,
0x00,0x68,0x99,0x00,0x60,0x54,0x06,0x0a,0x09,0x19,0x4e,0x70,0x06,0x0c,0x00,0x0e,
0x8e,0x70,0x5b,0x1c,0xc8,0x70,0x9a,0x42,0xf1,0xd8,0xff,0x20,0x01,0x30,0xa8,0x62,
0x68,0x69,0xff,0x21,0x08,0x31,0x88,0x43,0x68,0x61,0x68,0x69,0x38,0x43,0x68,0x61,
0x28,0x6a,0x80,0x08,0x80,0x00,0x28,0x62,0x28,0x6a,0x38,0x43,0x28,0x62,0x00,0x20,
0x05,0xb0,0xf0,0xbd,0x80,0x00,0x00,0x0c,0x03,0x20,0x80,0x06,0x41,0x69,0xff,0x22,
0x08,0x32,0x91,0x43,0x41,0x61,0x42,0x69,0x01,0x21,0x0a,0x43,0x42,0x61,0x02,0x6a,
0x92,0x08,0x92,0x00,0x02,0x62,0x02,0x6a,0x0a,0x43,0x02,0x62,0x70,0x47,0x00,0x00,
};
typedef uint32_t (*otp_read_cmd_func_t)(uint32_t,uint8_t*,uint32_t);
otp1_stored_t otp1_stored;
/*******************************************************************************
 *  Clock Definitions
 *******************************************************************************/
uint32_t SystemCoreClock = SYSCLK_FREQ; /*!< System Clock Frequency (Core Clock) */
const uint8_t AHBPrescTable[4] = {0, 0, 1, 2};

    
void system_opt_read(uint8_t* p_data,uint32_t byte_length)
{
    uint32_t ramcode[OTP_READ_CMD_CODE_LEN/4 +1 ];
    otp_read_cmd_func_t otp_read_cmd_func = (otp_read_cmd_func_t)((uint8_t*)&ramcode[0] + 0x11);
    memcpy((void*)ramcode,(const void*)otp_read_code_array,OTP_READ_CMD_CODE_LEN);
    (*otp_read_cmd_func)(OTP1_ADDR, p_data, byte_length);
}
void RCC_HsiTrimValueSet(uint8_t trim)
{
    uint32_t  tmp = RCC->CTRL & ~(0x7F << 8);   // TRIM 8-14 bit
    RCC->CTRL  =  tmp| (trim << 8);             // clear and set TRIM value 
    
    RCC->CFG |= (1<<16);                        // USE HSI(not HSI/2)
   
}
//#define NO_HSE_ON_BOARD
/**
 * @brief  Setup the microcontroller system
 *         Initialize the Embedded Flash Interface, the PLL and update the
 *         SystemCoreClock variable.
 * @note   This function should be used only after reset.
 */


void SystemInit(void)
{
    PWR->VTOR_REG = 0x81000000;
    RCC->CFG |=  0x04<<8;  
    RCC->CFG |= (1<<16);      

    
//    *(uint32_t*)0x40007014  = 0x0000080F; 
//    *(uint32_t*)0x40007020  = 0x00020018;    
    *(uint32_t*)0x40011000 &= ~0xC000;    
    

    
    
//  LDO_SYS1/2 voltage settings
//  000: LDO_SYS1: 0.9V, LDO_SYS2: 1.0V
//  001: LDO_SYS1: 1.0V, LDO_SYS2: 1.1V;(default)
//  010: LDO_SYS1: 0.7V, LDO_SYS2: 0.8V
//  011: LDO_SYS1: 0.8V, LDO_SYS2: 0.9V
//  100: LDO_SYS1: 0.75V, LDO_SYS2: 0.85V
//  101: LDO_SYS1: 0.85V, LDO_SYS2: 0.95V
//  110: LDO_SYS1: 1.0V, LDO_SYS2: 1.16V
//  111: LDO_SYS1: 1.1V, LDO_SYS2: 1.2V

//  LDO_RET trimming
//  5'b10100:0.8V(default)
//  5'b00000~01111:0.500~0.688V,step=12.5mV
//  5'b10000~11110:0.700~1.050V,step=25mV
//  5'b11111:1.1V
 
//    *(uint32_t*)0x40007014 = 0x0000080F;
//  *(uint32_t*)0x40007014 &= ~0xFF; //clr LDOSYS_VREF bit<7:5> and LDORET_TRIM bit<4:0>
//  uint8_t ldosys = 0x7;
//  uint8_t ldoret = 0xf;
//  *(uint32_t*)0x40007014 |= (ldosys << 5) | ldoret;    
    
    
    
    
    

//    system_opt_read((uint8_t*)&otp1_stored,sizeof(otp1_stored));
//    /* check otp has been write */
//    if(otp1_stored.stote_rc64m_trim_value == 0xFFFFFFFF) 
//    {
//        /* Calib from HSE */
        RCC_HsiCalib(SYSCLK_FREQ);

    
//    }
//    else
//    {
//		if(SYSCLK_FREQ == 64000000)
//		{           
//            RCC->CTRL &= ~0x8000;    
//            RCC_HsiTrimValueSet(otp1_stored.stote_rc64m_trim_value);//+5 : 66M, +7 : 68M
//		}
//        else if(SYSCLK_FREQ == 96000000)
//        {                      
//            RCC->CTRL |= 0x8000;
//            RCC_HsiTrimValueSet(otp1_stored.stote_rc96m_trim_value);
//        }        
//    }
 
}
static uint32_t m_trim_sys = 0;
void dynamic_hsi_trim(uint32_t hz)
{
    if(hz == DANAMIC_HSI_TRIM_96MHZ){
        RCC->CTRL |= 0x8000;
        RCC_HsiTrimValueSet(90);//96M
    }else if(hz == DANAMIC_HSI_TRIM_66MHZ){
        RCC->CTRL &= ~0x8000;   
        RCC_HsiTrimValueSet(m_trim_sys);        
    }else if(hz == DANAMIC_HSI_TRIM_120MHZ){
        RCC->CTRL |= 0x8000;
        RCC_HsiTrimValueSet(114);//120M        
    }else if(hz == DANAMIC_HSI_TRIM_72MHZ){
        RCC->CTRL &= ~0x8000;  
        RCC_HsiTrimValueSet(m_trim_sys);    
    }

}
    

/**
 * @brief  Update SystemCoreClock variable according to Clock Register Values.
 *         The SystemCoreClock variable contains the core clock (HCLK), it can
 *         be used by the user application to setup the SysTick timer or
 * configure other parameters.
 *
 * @note   Each time the core clock (HCLK) changes, this function must be called
 *         to update SystemCoreClock variable value. Otherwise, any
 * configuration based on this variable will be incorrect.
 *
 * @note   - The system frequency computed by this function is not the real
 *           frequency in the chip. It is calculated based on the predefined
 *           constant and the selected clock source:
 */
void SystemCoreClockUpdate(void)
{
    SystemCoreClock = HSI_VALUE;
}

/**
 * @brief dealy cycles.
 */
__ASM  void system_delay_cycles(uint32_t i)
{
    SUBS r0, #1
    BNE system_delay_cycles
    BX LR
}

/**
 * @brief  Dealy 10 us
 */
void system_delay_n_10us(uint32_t value)
{
    system_delay_cycles(110*value);
}

/**
 * @brief  Enable the HSI and calibration it.
 */
void RCC_HsiCalib(uint32_t systemfreq) 
{
    uint32_t g_hsi_accuracy = 0;
    uint32_t g_timeoutcnt = 1000;
    uint32_t g_cal_hsi_cnt_value = 1024;

    uint32_t delta =0;
    uint32_t min = 0;
    uint32_t max = 127;                                 //32M TRIM 8-14 bit
    uint32_t mid = (RCC->CTRL >> 8) & 0x7F; ; 
    uint16_t count_value = 0;
    uint32_t hsi_timeoutcnt = 0; 
    uint8_t tmp_trim;


    
    if(systemfreq == 64000000)
    {
        RCC->CTRL &= ~0x8000;
        g_cal_hsi_cnt_value = 2048;            //for 64M        
    }
    else if(systemfreq == 66000000)
    {
        RCC->CTRL &= ~0x8000;  
        g_cal_hsi_cnt_value = 2148;          
    }
    else if(systemfreq == 68000000)
    {
        RCC->CTRL &= ~0x8000;  
        g_cal_hsi_cnt_value = 2176;          
    } 
    else if(systemfreq == 72000000)
    {
        RCC->CTRL &= ~0x8000;  
        g_cal_hsi_cnt_value = 2304;          
    }       
    else if(systemfreq == 96000000)
    {
        RCC->CTRL |= 0x8000;
        g_cal_hsi_cnt_value = 3072;            //for 96M    
    }
    else if(systemfreq == 100000000)
    {
        RCC->CTRL |= 0x8000;
        g_cal_hsi_cnt_value = 3200;            //for 100M    
    }
    else if(systemfreq == 120000000)
    {
        RCC->CTRL |= 0x8000;
        g_cal_hsi_cnt_value = 3840;            //for 120M    
    }    
    do{
        uint32_t  tmp = RCC->CTRL & ~(0x7F << 8);   //32M TRIM 8-14 bit
        RCC->CTRL  =  tmp| (mid << 8);              // clear and set TRIM value  //and start to cnt
        system_delay_cycles(5);                                // delay scape          
        while(1)
        {
            system_delay_cycles(1);        
            if((RCC->OSCFCSR & 0x02))
            {
                break;
            }    
            if(hsi_timeoutcnt++ > g_timeoutcnt)
            {    
                break;
            }
        }
        count_value = RCC->OSCFCHSICNT;                 //ready cnt value       
		if(count_value > g_cal_hsi_cnt_value)
		{
			delta = count_value - g_cal_hsi_cnt_value; 
		}
		else
		{
			delta = g_cal_hsi_cnt_value - count_value; 
		}
        
        if(count_value >=  g_cal_hsi_cnt_value)
        {
            max = mid;
        }
        else
        {
            min = mid;
        }
        
        tmp_trim = (min + max)/2;  
        if(tmp_trim == mid )                //0 and 127 if not used        
        {
            break;
        }
        mid = tmp_trim;
    }while(delta > g_hsi_accuracy);  
    RCC->CFG &= ~1;
    while((RCC->CFG & (1<<2)));
    m_trim_sys = mid;
}

