

<details>
<summary><font size=5>目录</font> </summary>

- [1. 概述](#1-概述)
- [2. 开始](#2-开始)
  - [2.1. 示例代码演示](#21-示例代码演示)
- [3. 协议栈使用说明](#3-协议栈使用说明)
  - [3.1. 架构](#31-架构)
    - [3.1.1. 术语](#311-术语)
    - [3.1.2. 调度](#312-调度)
    - [3.1.3. 加密](#313-加密)
    - [3.1.4. 配网](#314-配网)
    - [3.1.5. 模型](#315-模型)
    - [3.1.6. 存储](#316-存储)
  - [3.2. 接口](#32-接口)
    - [3.2.1. 蓝牙接口](#321-蓝牙接口)
      - [3.2.1.1. 蓝牙广播](#3211-蓝牙广播)
      - [3.2.1.2. 蓝牙扫描](#3212-蓝牙扫描)
      - [3.2.1.3. 蓝牙连接事件](#3213-蓝牙连接事件)
      - [3.2.1.4. 蓝牙断开事件](#3214-蓝牙断开事件)
      - [3.2.1.5. 蓝牙服务事件](#3215-蓝牙服务事件)
    - [3.2.2. 蓝牙Mesh接口](#322-蓝牙mesh接口)
    - [3.2.3. 数据库接口](#323-数据库接口)
    - [3.2.4. 自定义接口](#324-自定义接口)
- [4. Mesh例程讲解](#4-mesh例程讲解)
  - [4.1. Generic OnOff](#41-generic-onoff)
    - [4.1.1. Generic OnOff Server](#411-generic-onoff-server)
      - [4.1.1.1. Main用户层](#4111-main用户层)
      - [4.1.1.2. App应用层](#4112-app应用层)
      - [4.1.1.3. Model模型层](#4113-model模型层)
    - [4.1.2. Generic OnOff Client](#412-generic-onoff-client)
      - [4.1.2.1. Main用户层](#4121-main用户层)
      - [4.1.2.2. Model模型层](#4122-model模型层)
  - [4.2. Generic Level](#42-generic-level)
    - [4.2.1. Generic Level Server](#421-generic-level-server)
      - [4.2.1.1. Main用户层](#4211-main用户层)
      - [4.2.1.2. App应用层](#4212-app应用层)
      - [4.2.1.3. Model模型层](#4213-model模型层)
    - [4.2.2. Generic Level Client](#422-generic-level-client)
      - [4.2.2.1. Main用户层](#4221-main用户层)
  - [4.3. Light Lightness](#43-light-lightness)
    - [4.3.1. Light Lightness Server](#431-light-lightness-server)
      - [4.3.1.1. Main用户层](#4311-main用户层)
      - [4.3.1.2. App应用层](#4312-app应用层)
      - [4.3.1.3. Model模型层](#4313-model模型层)
    - [4.3.2. Light Lightness Client](#432-light-lightness-client)
  - [4.4. Light CTL](#44-light-ctl)
    - [4.4.1. Light CTL Server](#441-light-ctl-server)
      - [4.4.1.1. CTL状态绑定，消息响应流程](#4411-ctl状态绑定消息响应流程)
    - [4.4.2. Light CTL Client](#442-light-ctl-client)
  - [4.5. Light HSL](#45-light-hsl)
    - [4.5.1. Light HSL Server](#451-light-hsl-server)
    - [4.5.2. Light HSL Client](#452-light-hsl-client)
  - [4.6. Light CTL HSL](#46-light-ctl-hsl)
    - [4.6.1. Light CTL HSL Server](#461-light-ctl-hsl-server)

</details>

*** 

# 1. 概述

CMT453x_BLE_MESH_SDK 是基于CMT453x芯片实现的SIG MESH协议栈，用户可以使用CMT453x芯片和该协议栈实现蓝牙MESH应用程序的开发。
Bluetooth SIG组织发布了 Bluetooth Mesh Profile Specification 和 Bluetooth Mesh Model Specification 。MESH Profile Specification定义了蓝牙MESH协议栈的架构和原理，以及定义了Generic Server Model等必须的模型。MESH Model Specification定义了如灯控，传感器等模型。
蓝牙MESH支持一对一，一对多，多对多通信，底层使用蓝牙协议栈进行消息传输。蓝牙通信范围内节点可以通过扫描和广播自由通信，通信范围以外节点需要中继节点将消息中继到目标节点。


# 2. 开始
## 2.1. 示例代码演示
本章节展示使用开发板通过按键发送Mesh广播，控制多个Led灯。

* 硬件需求   
一个CMT453x开发板作为clinet。
一个或多个CMT453x开发板作为server。

* 软件需求   
nRF Mesh 安卓APP作为配网设备（Google play下载）。
generic_onoff server例程（ CMT453x_BLE_MESH_SDK example目录下）。
generic_onoff client例程（ CMT453x_BLE_MESH_SDK example目录下）。

* 测试环境搭建   
编译并烧录generic_onoff client例程到开发板，作为client设备。
编译并烧录generic_onoff server例程到开发板，作为server设备。

* 配网过程   
1. 打开nRF Mesh APP，然后点击添加设备到网络按钮（APP右下脚加号）。
2. 进入扫描界面，可以看到两个开发板的广播名称。
3. 点击一个设备广播名称，再点击IDENTIFY按钮，再点击PROVISION按钮，开始自动配网流程。
4. 配网成功结束点击ok按钮，该设备被添加到Network Tab中，成为网络中的一个节点。
5. 点击设备节点选项卡，进入设备节点配置界面，点击Element下拉箭头打开Model选项。
6. 点击Generic On Off Client/Server，进入Model配置界面。
7. 如果是Client配置界面，首先点击BIND KEY按钮，选择Application Key 1，再点击SET PUBLICATION按钮，接着点击Publication Address，在弹出对话框内选择All Nodes，点击OK，最后点击APPLY，配置完成。
8. 如果是Server配置界面，点击BIND KEY按钮，选择Application Key 1，配置完成。   
多个server开发板，按照配网过程中server的配网方法配置。

* 测试效果说明   
Client开发板button1按下，控制Server开发板led2亮。
Client开发板button2按下，控制Server开发板led2灭。
如果有多个Server开发板，所有Server开发板的led2会同时被Client开发板控制。

# 3. 协议栈使用说明
Mesh Profile是BLE Profile中一个较大的Profile，其中包含了Mesh Stack和Mesh Model。CMT453x_BLE_MESH_SDK 开放全部Mesh Model层源代码，并开放部分Mesh Profile源代码。
关于Mesh Profile规范，请参考 [Mesh Profile Specification](https://www.bluetooth.com/specifications/specs/mesh-profile-1-0-1/)

## 3.1. 架构
Mesh协议栈居于蓝牙协议栈之上 ，Mesh协议栈需要蓝牙协议栈完成蓝牙连接，蓝牙广播发送和蓝牙扫描接收。
Mesh协议栈各层的定义在 Bluetooth Mesh Profile Specification 中有详细描述，下面只是对各层的一个简单概述。

<div align="center">
  <img src="_images/Architecture.png" width=400>  
</div>  
<div align="center">
  <b>Mesh协议栈框图</b>
</div>  
</br>  

* Access Layer:   
对Model数据进行打包封装，Access Layer包头数据包括，ttl、src、dst、seq num、iv index、application key index等。
* Upper Transport Layer:   
对Access Layer数据进行加密和完整性校验。
* Lower Transport Layer:   
对Upper Transport Layer数据进行Segmentation(分包)处理。
* Network Layer:   
对Lower Transport Layer数据进行加密和完整性校验，以及加入网络层包头，最后obfuscation(乱序)处理。

### 3.1.1. 术语
* TTL: Time To Live   
每条消息都包含一个生存时间 (TTL)值，该值限制了一条消息可以被中继的次数。每次转发（最多转发 126 次）后，TTL 值减 1。   
TTL在配网时被分配，该值决定了消息可以被转发次数。   

* Cache: 消息缓存机制   
网络消息缓存旨在通过将所有消息添加到缓存列表来防止设备中继以前接收到的消息。收到消息时，会根据列表检查它，如果已经存在则忽略它。如果尚未收到，则将其添加到缓存中，以便将来可以忽略。为防止此列表变得过长，缓存的消息数量受实现限制。   
缓存机制确保同条消息只会被同一个设备转发一次。

* Sequence Number: 消息序列号   
序列号是包含在网络PDU的SEQ字段中的24位值，主要用于防止重放攻击。同一节点内的元素可能会或可能不会彼此共享序列号空间。在每个消息源（由SRC字段中包含的单播地址标识）的每个新网络PDU中具有不同的序列号对于网状网络的安全性至关重要。

序列号可以防止相同或者小于当前序列号的消息被处理多次，只有大于当前序列号的消息才会被处理，确保相同消息只会被处理一次，处理过的相同消息会被抛弃。

* Relay Retransmit Count: 重复次数   
Relay Retransmit Count字段是一个3位的值，用于控制节点中继的Network PDU的消息重传次数。Relay Retransmit Count + 1是为每个中继的数据包传输数据包。   
重复次数可以弥补因为干扰导致掉包，增加成功到达远端机率。   
重发次数在配网时被分配，但是可以根据应用动态修改该值，即增大了接收概率，也减少空中消息的阻塞。   

* Unicast Address: 单播地址   
首要Element地址是每个节点的单播地址，通过单播地址可以控制网络内单个节点。   

* Group Address: 组播地址   
属于不同节点的Model可以订阅同一组播地址，同时被发布该组播地址的消息控制。   

* All Nodes Address: 群播地址   
该地址消息可以发送给网络内所有节点。   

### 3.1.2. 调度
蓝牙和Mesh接口均为异步接口，命令的执行都需要通过Kernel内核进行调度，确保蓝牙事件不会被长时间阻塞、能够及时得到执行。

<div align="center">
  <img src="_images/schedule.png" width=400>  
</div>  
</br>  

用户程序调用蓝牙协议栈接口，实现比如打开广播，打开扫描等功能，当蓝牙协议栈完成工作后将结果通过send message接口发给Kernel，Kernel通过用户注册的回调将结果返回给用户。   

用户程序调用Mesh协议栈接口，实现Mesh数据广播，Mesh协议栈将打包好的数据通过蓝牙协议栈接口发给蓝牙协议栈，蓝牙协议栈完成发送工作后将结果通过send message接口发给Kernel，Kernel再调用用户注册的回调将结果返回给用户。   

Mesh协议栈也会直接与Kernel通信，将事件进行异步处理。   

### 3.1.3. 加密
蓝牙MESH中加密与认证是必须的，非对称算法使用ECC，对称算法使用AES。   
CMT453x BLE MESH SDK中ECC使用开源uECC软件算法，AES使用硬件加密模块。   

* 密钥：
Device Key设备密钥，配网过程中生成，入网后，节点与配网设备使用Device Key加密Upper Transport层数据。   
Network Key网络密钥，配网设备生成，配网过程中由配网设备加密发给入网设备。   
Application Key应用密钥，配网设备生成，入网后，用于加密Upper Transport层数据。   

<div align="center">
  <img src="_images/Encryption_Packet.png">  
</div>  
</br>  

* 加密：加密使用AES-CCM，认证使用AES-CMAC   
Upper Transport层使用Application Key对Acces Pdu进行加密和认证。   
Network层使用Netwok Key对Lower Transport层数据进行加密和认证。   

注解:   
Application Key可以有多个，Access层提供App Key序号。 Network Key也可以有多个，Access层提供Network Key序号。App Key序号和Network Key序号和Model绑定。   

* 解密：解密使用AES-CCM，认证使用AES-CMAC   
Network层使用Network Key对接收到的数据进行解密和认证判断。   
Upper Transport层使用Application Key对Lower Transport层数据进行解密和认证判断。   

注解:
Network Key可以有多个，Network Pdu中的NID可以用来匹配使用哪个Network Key。 Application Key也可以有多个，Upper Transport层会轮询所有App Key尝试解密和认证判断，直到找到正确可以解密的Key。

### 3.1.4. 配网
配网流程是让配网设备安全的把Network Key发送给入网设备。   
<div align="center">
  <img src="_images/Provision.png" width=500>  
</div>  
</br>  

如图配网流程分为4个阶段 ：
1. 配网设备连接入网设备，读取入网设备支持的配网模式。   
2. 配网设备与入网设备交换Publice Key，并计算Share Key。   
3. 配网设备与入网设备生成Random Number，使用Share Key计算Comfirmation Value，发给对方，并进行校验。   
4. 最后配网设备与入网设备生成Device Key，配网设备将Network Key，IV Index，Unicast Address加密发给入网设备，配网设备断开蓝牙连接，入网设备将数据保存数据库。   
5. 入网设备角色切换成网络内节点，并开始广播Proxy(代理服务)。   

### 3.1.5. 模型
SIG规定所有节点必须至少要有Configuration Server Model和Health Server Model。另外，SIG还定义了灯控Model，传感器Model，时间和场景Model。

* Configuration Server Model:   
节点配置模型，配网设备通过该模型实现节点网络配置的重要工作：
1. 获取节点Element和Model信息。   
2. Element地址分配。   
3. Secondary Network Key和Application Key的添加、删除。   
4. Model与Application Key的绑定。   
5. Model的Publication Address和Subscription Address的添加等。   

* Health Server Model:   
配网设备通过这个模型，周期性查询节点的健康状态。   

* Light Lightness Server Model:   
Light Lightness控制单色灯亮度，应用中需要将Lightness值转换成单色灯的PWM占空比值。   

* Light CTL Server Model:   
Light CTL控制灯冷暖色，应用中需要将CTL Temperature值转换成冷色灯和暖色灯的PWM占空比值。

* Light HSL Server Model:
HSL是Hue、Saturation、Lightness的缩写，是RGB的另外一种容易感知的颜色表达形式。   
应用中需要将HSL值转换成RGB灯的PWM占空比值。   

* Model Transition:   
Transition实现状态的Delay和渐变效果。   
需要注意的是，Delay结束后、渐变过程中、渐变结束后，节点都需要将状态发布出去。   
<div align="center">
  <img src="_images/Model_Transition.png" width=800>  
</div>  
</br>  

* Model Inheritance：模型的继承   
模型的继承在蓝牙Mesh中非常常见，意思是一个模型可以被另外一个或几个模型继承。   

例如：Light CTL Server Model中需要Generic OnOff Server Model，Lgitht Lightness Server Model中也需要Generic OnOff Server Model，Lgiht HSL Server Model中也需要Generic OnOff Server Model，那么就可以实现一个Generic OnOff Server Model，然后让它被另外三个Model继承，或者也可以是Generic OnOff Server Model被Lgitht Lightness Server Model继承，然后Lgitht Lightness Server Model同时被被Light CTL Server Model和Lgiht HSL Server Model继承。   

<div align="center">
  <img src="_images/Model_Inheritance.png">  
</div>  
</br>  

上图中的Generic OnOff Server Model被Light Lightness Server Model继承，Light Lightness Server Model再被Lgiht HSL Server Model继承。   
软件通过分层和注册回调的方法实现模型的继承。

### 3.1.6. 存储
蓝牙Mesh数据存储在芯片Flash上，确保掉电不丢失。
芯片Flash的特点是，最小擦除单元4K，最大连续写单元256字节，擦除时间长，同一存储单元寿命有限，因此需要减少擦除次数，减少单次写数据的大小，数据更新需要做去磨损处理。
蓝牙Mesh数据的特点是，数据单元小，某些数据更新率非常低，而另外一些数据更新则非常频繁。
根据上述特点，蓝牙Mesh数据库设计如下：

<div align="center">
  <img src="_images/Storage.png" width=350>  
</div>  
</br>  

* 蓝牙Mesh数据分为5个File，每个File占4K Flash，File说明如下 :
1. Model File：保存模型状态数据，此数据特点是更新非常频繁，所以单独保存在一个File里。
2. Core File：保存协议栈核心数据，例如Mesh广播重发使能，Mesh广播重发次数，Mesh广播重发间隔。
3. Access File：保存Access层数据，例如Element数量，Element地址，Element下Model数量，Model绑定Application Key序号，Model发布地址，Model订阅地址等。
4. DSM File：保存密钥，次数据特点是更新率非常低，且数据非常重要，不要和其它类型数据保存在一起。
5. Net State File：保存网络状态数据，例如IV index和Sequence Number，此数据更新率适中，Sequence Number每增加512更新一次。

* 数据库垃圾回收机制:   
当数据写满4K时，首先将有效数据提取到垃圾回收区域，然后擦除数据区域，再将垃圾回收区域的有效数据恢复到数据区域。   

* 数据库保护机制:   
擦写数据时只允许蓝牙中断打断，其它中断暂停响应。   
数据库工作期间，如果产生异常复位，开机后数据库状态自动恢复，如果Model File数据出现问题，Model数据区数据恢复成默认状态。   

## 3.2. 接口
本章介绍 CMT453x_BLE_MESH_SDK 中常用软件接口。
### 3.2.1. 蓝牙接口
#### 3.2.1.1. 蓝牙广播
* 创建广播:
``` struct gapm_activity_create_adv_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_CREATE_CMD, TASK_GAPM, TASK_APP, gapm_activity_create_adv_cmd);
p_cmd->operation = GAPM_CREATE_ADV_ACTIVITY;
p_cmd->own_addr_type = GAPM_STATIC_ADDR;                            //静态广播地址
p_cmd->adv_param.type = GAPM_ADV_TYPE_LEGACY;
p_cmd->adv_param.prop = GAPM_ADV_PROP_UNDIR_CONN_MASK;              //非定向可连接广播
p_cmd->adv_param.filter_pol = ADV_ALLOW_SCAN_ANY_CON_ANY;           //允许扫描请求和连接请求
p_cmd->adv_param.prim_cfg.chnl_map = ADV_ALL_CHNLS_EN;              //使能37 38 39广播信道
p_cmd->adv_param.prim_cfg.phy = GAP_PHY_LE_1MBPS;                   //1M速率
p_cmd->adv_param.disc_mode = GAPM_ADV_MODE_GEN_DISC;                //一般发现模式
p_cmd->adv_param.prim_cfg.adv_intv_min = interval_units;            //广播间隙
p_cmd->adv_param.prim_cfg.adv_intv_max = interval_units;            //广播间隙
ke_msg_send(p_cmd); 
```

* 设置广播数据:
```
struct gapm_set_adv_data_cmd *p_adv_cmd = KE_MSG_ALLOC_DYN(GAPM_SET_ADV_DATA_CMD,
                                                            TASK_GAPM, TASK_APP,
                                                            gapm_set_adv_data_cmd,
                                                            ADV_DATA_LEN);
p_adv_cmd->operation = GAPM_SET_ADV_DATA;               //设置广播数据
p_adv_cmd->actv_idx = m_adv_idx;                        //广播活动序号
if(service_uuid == MESH_PB_GATT_SERVICE_UUID){
    app_build_adv_data(&p_adv_cmd->length, &p_adv_cmd->data[0],p_service_data, length);         //设置配网广播数据    
}else if(service_uuid == PROXY_UUID_SERVICE){
    app_build_adv_data_proxy(&p_adv_cmd->length, &p_adv_cmd->data[0],p_service_data, length);   //设置代理广播数据
}
ke_msg_send(p_adv_cmd);     
struct gapm_set_adv_data_cmd *p_rsp_cmd = KE_MSG_ALLOC_DYN(GAPM_SET_ADV_DATA_CMD,
                                                        TASK_GAPM, TASK_APP,
                                                        gapm_set_adv_data_cmd,
                                                        ADV_DATA_LEN);
p_rsp_cmd->operation = GAPM_SET_SCAN_RSP_DATA;          //设置广播响应数据
p_rsp_cmd->actv_idx = m_adv_idx;
p_rsp_cmd->length = 0;   
uint8_t *p_buf = p_rsp_cmd->data; 
char name[20];
memset(name,0,sizeof(name));
sprintf(name,"MESH_%02X%02X",g_co_default_bdaddr.addr[4],g_co_default_bdaddr.addr[5]);          //设备名称设置在广播响应数据中
*p_buf = strlen(name) + 1;
*(p_buf + 1) = '\x09';//full device name
memcpy(p_rsp_cmd->data + 2, name, strlen(name));
p_rsp_cmd->length += strlen(name) + 2;
ke_msg_send(p_rsp_cmd);  
```

* 开始广播:
```
struct gapm_activity_start_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_START_CMD, TASK_GAPM, TASK_APP, gapm_activity_start_cmd);
p_cmd->operation = GAPM_START_ACTIVITY;
p_cmd->actv_idx = m_adv_idx;
p_cmd->u_param.adv_add_param.duration = 0;              //广播超时时间，0表示不超时
p_cmd->u_param.adv_add_param.max_adv_evt = 0;
ke_msg_send(p_cmd);
```

* 广播事件回调:
```
static int gapm_cmp_evt_handler(ke_msg_id_t const msgid, struct gapm_cmp_evt const *p_param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    switch(p_param->operation)
    {
        case GAPM_CREATE_ADV_ACTIVITY:{
            //广播创建事件，事件结果在p_param中
        }break;
        case GAPM_SET_ADV_DATA:{
            //广播数据设置事件，事件结果在p_param中
        }break;
        case GAPM_SET_SCAN_RSP_DATA:{
            //广播响应数据设置事件，事件结果在p_param中
        }break;
        case GAPM_START_ACTIVITY:{
            if(prov_proxy_adv_adv_idx_get() == p_param->actv_idx){
                if(p_param->status == LL_ERR_MEMORY_CAPA_EXCEED){
                    prov_proxy_adv_start();
                }
            }
        }break;   
        case GAPM_STOP_ACTIVITY:{
                //广播停止事件，事件结果在p_param中
        }break;
        case GAPM_DELETE_ALL_ACTIVITIES:{
        }break;
        case GAPM_CREATE_SCAN_ACTIVITY:{
        }break;
        case GAPM_DELETE_ACTIVITY:{
        }break;
    }
    if (p_param->operation >= GAPM_CREATE_ADV_ACTIVITY)
    {
        mal_activity_cmp_evt_handler(p_param->operation, p_param->status, p_param->actv_idx);
    }
    return KE_MSG_CONSUMED;
}
```

#### 3.2.1.2. 蓝牙扫描
* 创建扫描 :
```
struct gapm_activity_create_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_CREATE_CMD, TASK_GAPM, TASK_APP, gapm_activity_create_cmd);
p_cmd->operation = GAPM_CREATE_SCAN_ACTIVITY;
p_cmd->own_addr_type = GAPM_STATIC_ADDR;
ke_msg_send(p_cmd);

//创建扫描事件回调
static int gapm_activity_created_ind_handler(ke_msg_id_t const msgid,struct gapm_activity_created_ind const *p_param, ke_task_id_t const dest_id,ke_task_id_t const src_id)
{
    if(p_param->actv_type == GAPM_ACTV_TYPE_ADV)
    {
        m_actv_idx = p_param->actv_idx;                 //获取广播活动序号
        mal_adv_created_ind_handler(p_param->actv_type, p_param->actv_idx);
    }
    else if(p_param->actv_type == GAPM_ACTV_TYPE_SCAN)
    {
        m_scan_actv_idx = p_param->actv_idx;            //获取扫描活动序号
    }
    return KE_MSG_CONSUMED;
}
```

* 开始扫描 :
```
struct gapm_activity_start_cmd *p_cmd = KE_MSG_ALLOC(GAPM_ACTIVITY_START_CMD, TASK_GAPM, TASK_APP, gapm_activity_start_cmd);
p_cmd->operation = GAPM_START_ACTIVITY;
p_cmd->actv_idx = m_scan_actv_idx;
p_cmd->u_param.scan_param.type = GAPM_SCAN_TYPE_OBSERVER;           //Observer模式允许扫描Beacon包
p_cmd->u_param.scan_param.prop = GAPM_SCAN_PROP_PHY_1M_BIT|GAPM_SCAN_PROP_FILT_TRUNC_BIT;
p_cmd->u_param.scan_param.dup_filt_pol = GAPM_DUP_FILT_DIS;         //关闭扫描数据过滤功能
p_cmd->u_param.scan_param.scan_param_1m.scan_intv = 0x40;           //扫描周期时间
p_cmd->u_param.scan_param.scan_param_1m.scan_wd  = 0x30;            //扫描窗口时间，RX打开时间
p_cmd->u_param.scan_param.duration = 0;                             //扫描超时时间，0表示不超时
p_cmd->u_param.scan_param.period = 0;
ke_msg_send(p_cmd);
```

* 扫描数据回调 :
```
static int appm_gapm_ext_adv_repoer_ind_handler(ke_msg_id_t const msgid, struct gapm_ext_adv_report_ind const *param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    g_rf_scan_adv_report_counter++;
    if (mesh_is_device_provisioned()){
        if(param->info == (GAPM_REPORT_TYPE_ADV_LEG | GAPM_REPORT_INFO_COMPLETE_BIT)){    
            mesh_rx_metadata_scanner_t metadata;
            metadata.adv_type = BLE_PACKET_TYPE_ADV_NONCONN_IND;
            metadata.rssi = param->rssi;
            metadata.adv_addr.addr[0] = param->trans_addr.addr.addr[0];
            metadata.adv_addr.addr[1] = param->trans_addr.addr.addr[1];
            metadata.adv_addr.addr[2] = param->trans_addr.addr.addr[2];
            metadata.adv_addr.addr[3] = param->trans_addr.addr.addr[3];
            metadata.adv_addr.addr[4] = param->trans_addr.addr.addr[4];
            metadata.adv_addr.addr[5] = param->trans_addr.addr.addr[5];
            scanner_handle_end_event(&metadata, (uint8_t *)param->data,param->length);
        }    
    }
    return (KE_MSG_CONSUMED);
}
```

#### 3.2.1.3. 蓝牙连接事件
* 连接事件回调
```
static int gapc_connection_req_ind_handler(ke_msg_id_t const msgid, struct gapc_connection_req_ind const *p_param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    DEBUG_PRINTF("gapc_connection_req_ind_handler\r\n");
    g_rf_scan_adv_report_counter++;
	struct gapc_connection_cfm *cfm = KE_MSG_ALLOC(GAPC_CONNECTION_CFM,KE_BUILD_ID(TASK_GAPC, KE_IDX_GET(src_id)), TASK_APP, gapc_connection_cfm);    
    cfm->pairing_lvl = GAP_AUTH_REQ_NO_MITM_NO_BOND; 
    ke_msg_send(cfm);
    m_con_idx = KE_IDX_GET(src_id);
	struct mesh_gatt_connection_req_ind *p_cmd = KE_MSG_ALLOC(MESH_GATT_CONNECT, TASK_APP, dest_id, mesh_gatt_connection_req_ind);	
	p_cmd->conhdl = p_param->conhdl;
    p_cmd->con_index = KE_IDX_GET(src_id);
	ke_msg_send(p_cmd);	    
    
    if (mesh_is_device_provisioned())
    {
        ke_timer_clear(TIMER_CONN_PARAM_MSG, TASK_APP); 
        ke_timer_set(TIMER_CONN_PARAM_MSG, TASK_APP, 5000); 
    }
    
    return KE_MSG_CONSUMED;
}
```

#### 3.2.1.4. 蓝牙断开事件
* 断开事件回调
```
static int gapc_disconnect_ind_handler(ke_msg_id_t const msgid, struct gapc_disconnect_ind const *p_param, ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    ke_timer_clear(TIMER_CONN_PARAM_MSG, TASK_APP); 
    m_con_idx = 0xff;
	struct gapc_disconnect_ind *p_cmd = KE_MSG_ALLOC(MESH_GATT_DISCONNECT, TASK_APP, dest_id, gapc_disconnect_ind);	
	p_cmd->conhdl = p_param->conhdl;
	ke_msg_send(p_cmd);	
    return KE_MSG_CONSUMED;
}
```

#### 3.2.1.5. 蓝牙服务事件
* 服务事件回调
```
static int app_msg_default_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
	ke_task_id_t src_task_id = MSG_T(msgid);
	switch (src_task_id)
	{	
		case TASK_ID_MESH_GATT:{
            app_get_handler(&mesh_gatt_app_handlers, msgid, p_param, src_id);
		} break;	
	}
  return KE_MSG_CONSUMED;
}
```

### 3.2.2. 蓝牙Mesh接口
* Mesh广播   
```
static void broadcast_start(void* p_args)
{
    LOG_PRINTF("broadcast_start\r\n");
    mp_broadcast = (broadcast_t *) p_args;
    mal_adv_bearer_param_t param = {
          .chlmap = mp_broadcast->params.chlmap,
          .interval = mp_broadcast->params.interval,
          .duration = mp_broadcast->params.duration,
          .adv_len = mp_broadcast->params.p_packet->header.length-BLE_ADV_PACKET_OVERHEAD,
          .p_data = mp_broadcast->params.p_packet->payload,       
    };
	if(MESH_SUCCESS != mal_adv_bearer_send(&param, MAL_ADV_BEARER_SRCINFO_BROADCAST, NULL)){
        mp_broadcast->params.tx_complete_cb(&mp_broadcast->params, 0);
        bearer_handler_action_end();
        mp_broadcast->active = false;   
        mp_broadcast = NULL;    
    }
}

/**
 * param :      设置广播参数
 * srcinfo :    回调回传参数，可以用于组包
 * cb :         广播完成回调函数
 * return :     0表示函数执行成功，非0值可能是入参错误，或者缓冲区内存不足
 */
uint32_t mal_adv_bearer_send(mal_adv_bearer_param_t *param, uint8_t srcinfo, mal_adv_bearer_callback cb);
```

* 获取Mesh网络参数   
1. 获取Unicast Address   
```
dsm_local_unicast_address_t address;
//获取节点所有单播地址
dsm_local_unicast_addresses_get(&address);
```

2. 获取Network Key   
```
uint8_t net_key[MESH_KEY_SIZE];
//获取Primary Network Key，0表示Primary
subnet_key_get(net_key,0);
```

3. 获取Application Key   
```
uint8_t app_key[MESH_KEY_SIZE];
//获取序号为0的Application Key
appkey_get(app_key,0);
```

4. 获取Device Key   
```
uint8_t dev_key[MESH_KEY_SIZE];
//获取Device Key
devkey_get(dev_key,0);
```

### 3.2.3. 数据库接口
* 创建File
```
MESH_CONFIG_FILE(m_custom_config_file, MESH_OPT_CUSTOMER_FILE_ID, MESH_CONFIG_STRATEGY_CONTINUOUS);
```

* 创建Entry
```
MESH_CONFIG_ENTRY(test1_data,
                  MESH_OPT_CUSTOMER_CONFIG_TEST1_BLOCK_EID,
                  1,
                  sizeof(customer_config_test1_data_t),             //自定义数据结构
                  test1_block_setter,                               //读取Flash数据到内存回调
                  test1_block_getter,                               //内存数据拷贝到Flash回调
                  test1_block_deleter,                              //删除内存数据回调，Flash数据修改为Invalid
                  NULL);
```

* 读Entry
```
mesh_config_entry_get(MESH_OPT_CUSTOMER_CONFIG_TEST1_BLOCK_EID, &m_test1_data);
/**
 * id : Entry ID    用于检索需要读取的Entry
 * p_entry :        Entry读取缓冲区
 * return :         MESH_SUCCESS表示读取成功，其它参考错误原因
 */
uint32_t mesh_config_entry_get(mesh_config_entry_id_t id, void * p_entry);
```

* 写Entry
```
mesh_config_entry_set(MESH_OPT_CUSTOMER_CONFIG_TEST1_BLOCK_EID, data);
/**
 * id :             Entry ID用于检索需要写入的Entry
 * p_entry :        Entry写入缓冲区
 * return :         MESH_SUCCESS表示读取成功，其它参考错误原因
 */
uint32_t mesh_config_entry_set(mesh_config_entry_id_t id, const void * p_entry);
```

* 擦Entry
```
mesh_config_entry_delete(MESH_OPT_CUSTOMER_CONFIG_TEST1_BLOCK_EID);
/**
 * id :             Entry ID用于检索需要擦除的Entry
 * return :         MESH_SUCCESS表示读取成功，其它参考错误原因
 */
uint32_t mesh_config_entry_delete(mesh_config_entry_id_t id);
```


### 3.2.4. 自定义接口
* 用户层动态修改Relay广播参数
```
//通过判断广播设备信号强度，动态调整重发次数
//距离近时减少Relay重发次数，增加自己广播重发次数
//距离远时增加Relay重发次数，减少自己广播重发次数
static bool mesh_relay_check_cb(const network_packet_metadata_t * p_metadata, const mesh_rx_metadata_t * p_rx_metadata)
{
    if(p_rx_metadata->params.scanner.rssi > -50){
        mesh_dynamic_param.original_tx_cnt = 13 + rand()%5;
        mesh_dynamic_param.relay_tx_cnt = 3 + rand()%3;
        mesh_dynamic_param.relay_duration = 10 + rand()%5;
        mesh_dynamic_param.original_duration = 30 + rand()%10;
    }else{
        mesh_dynamic_param.original_tx_cnt = 8 + rand()%5;
        mesh_dynamic_param.relay_tx_cnt = 8 + rand()%3;
        mesh_dynamic_param.relay_duration = 10 + rand()%10;
        mesh_dynamic_param.original_duration = 20 + rand()%10;
    }
    return true;
}
```

* 恢复出厂设置
```
uint32_t was_masked;
_DISABLE_IRQS(was_masked);
hp_mesh_nvds_clear();           //删除数据库中所有Mesh数据
NVIC_SystemReset();
```

* 记录开机次数: 灯控需求
```
//Flash保存开机次数
#define LIGHT_PWR_ON_RECORD_ADDRESS   0x01030000
void mesh_app_pwr_on_record_set(void)
{
    //降flash磨损
    uint16_t record = 0 ;
    uint16_t i = 0;
    for(i = 0; i < 4095;)
    {
        record = *(uint16_t *)(LIGHT_PWR_ON_RECORD_ADDRESS + i);
        if(record){
            break;
        }
        i += 2;
    }
    if(record < (0xFFFF - 4)){
        Qflash_Erase_Sector(LIGHT_PWR_ON_RECORD_ADDRESS);
        hp_mesh_nvds_clear();  
        NVIC_SystemReset();
        while(1);
    }else{
        record--;
        Qflash_Write(LIGHT_PWR_ON_RECORD_ADDRESS + i, (uint8_t*)&record, 2);
    }
}
//Flash开机次数擦除
void mesh_app_pwr_on_record_clear(void)
{
    uint16_t record = 0 ;
    uint16_t i = 0;
    for(i = 0; i < 4095;)
    {
        record = *(uint16_t *)(LIGHT_PWR_ON_RECORD_ADDRESS + i);
        if(record){
            break;
        }
        i += 2;
    }
    if(i >= 4094){
        Qflash_Erase_Sector(LIGHT_PWR_ON_RECORD_ADDRESS);
    }else{
        record = 0;
        Qflash_Write(LIGHT_PWR_ON_RECORD_ADDRESS + i, (uint8_t*)&record, 2);
    }
}
```

# 4. Mesh例程讲解
例程按照循序渐进的方式，从易到难，一步步完成SIG Mesh灯控模型的应用实例，最后还提供了Amazon Alexa产品的例程。
初级用户请按照导航栏的顺序先实验Generic OnOff，再实验Generic Level和Light Lightness，规范可以参考 Mesh Model Bluetooth Specification。对Bluetooth mesh相对了解的用户可以直接选择需要的例程使用。   

## 4.1. Generic OnOff
用户可以通过此例程了解Mesh网络各个设备的角色与关系。
了解配网流程与网络组成。
通过调试代码了解Element和Model的注册与回调机制。

例程中手机控制Client开发板Led灯亮灭是通过Server节点作为Proxy代理节点，将手机发送的Gatt数据转换成Mesh广播数据发送到网络。
例程中一个开发板上实现了Generic OnOff Server Model控制开发板上的灯，另外一个开发板上实现了Generic OnOff Client Model通过按键作为灯的开关控制Server板上的灯。

注解:   
Android手机不能直接发送Mesh广播，因为Andoid API只能设置蓝牙名称，厂商自定义数据，不能配置蓝牙Mesh包类型。

### 4.1.1. Generic OnOff Server
例程分为三层结构，最顶层为用户层，中层为应用层，最底层为模型层。
各层间通信方式为，上层调用下层接口，下层调用上层回调。

<div align="center">
  <img src="_images/Generic_OnOff_Server.png" height=200>  
</div>  
</br>  

#### 4.1.1.1. Main用户层
* 初始化Generic OnOff Server App模块
```
//模块初始化宏定义
APP_ONOFF_SERVER_DEF(   m_onoff_server_0,
                        false,
                        MESH_TRANSMIC_SIZE_SMALL,
                        app_onoff_server_set_cb,
                        app_onoff_server_get_cb)
app_onoff_init(&m_onoff_server_0, 0);

/**
* p_server : 模块指针
* element_index : Element序号
*/
uint32_t app_onoff_init(app_onoff_server_t * p_server, uint8_t element_index);
```

* Generic OnOff Server App模块回调函数
```
//设置灯状态
static void app_onoff_server_set_cb(const app_onoff_server_t * p_server, bool onoff)
{
    if(onoff){
        bsp_led_on(LED2_GPIO_PORT, LED_GPIO2_PIN); //开灯
    }else{
        bsp_led_off(LED2_GPIO_PORT, LED_GPIO2_PIN); //关灯
    }
}
//读取灯状态
static void app_onoff_server_get_cb(const app_onoff_server_t * p_server, bool * p_present_onoff)
{
    *p_present_onoff = bsp_led_read(LED2_GPIO_PORT, LED_GPIO2_PIN); //读取IO口状态
}
```

#### 4.1.1.2. App应用层
* 模块初始化
```
uint32_t app_onoff_init(app_onoff_server_t * p_server, uint8_t element_index)
{
    uint32_t status = MESH_ERROR_INTERNAL;
    if (p_server == NULL)
    {
        return MESH_ERROR_NULL;
    }
    p_server->server.settings.p_callbacks = &onoff_srv_cbs; //注册Model层回调
    if (p_server->onoff_set_cb == NULL || p_server->onoff_get_cb == NULL)
    {
        return MESH_ERROR_NULL;
    }
    status = generic_onoff_server_init(&p_server->server, element_index); //Model初始化
    if (status == MESH_SUCCESS)
    {

    }
    return status;
}
```

* Model回调函数
```
//Model层收到Generic OnOff Set或者Generic OnOff Set Unack命令时调用的回调函数
//该函数调用应用层注册的回调改变灯状态
//如果需要Transition，则根据Transition参数打开app_transition模块
static void generic_onoff_state_set_cb(const generic_onoff_server_t * p_self,
       const access_message_rx_meta_t * p_meta,
       const generic_onoff_set_params_t * p_in,
       const model_transition_t * p_in_transition,
       generic_onoff_status_params_t * p_out)
{
    app_onoff_server_t   * p_server = PARENT_BY_FIELD_GET(app_onoff_server_t, server, p_self);
    p_server->value_updated = false;
    p_server->state.target_onoff = p_in->on_off;
    if (p_in_transition == NULL)
    {
        p_server->state.delay_ms = 0;
        p_server->state.remaining_time_ms = 0;
    }
    else
    {
        p_server->state.delay_ms = p_in_transition->delay_ms;
        p_server->state.remaining_time_ms = p_in_transition->transition_time_ms;
    }
    onoff_state_value_update(p_server);
    onoff_state_process_timing(p_server);
    if (p_out != NULL)
    {
        p_out->present_on_off = p_server->state.present_onoff;
        p_out->target_on_off = p_server->state.target_onoff;
        p_out->remaining_time_ms = p_server->state.remaining_time_ms;
    }
}
//Model层收到Generic OnOff Get命令时调用的回调函数
//该函数调用应用层注册的回调读取灯状态
static void generic_onoff_state_get_cb(const generic_onoff_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       generic_onoff_status_params_t * p_out)
{
    app_onoff_server_t   * p_server = PARENT_BY_FIELD_GET(app_onoff_server_t, server, p_self);
    p_server->onoff_get_cb(p_server, &p_server->state.present_onoff);
    p_out->present_on_off = p_server->state.present_onoff;
    p_out->target_on_off = p_server->state.target_onoff;
}
//主动发布Model状态，在Transition过程中，和Transition结束时被调用
void app_onoff_status_publish(app_onoff_server_t * p_server)
{
    p_server->onoff_get_cb(p_server, &p_server->state.present_onoff);
    p_server->state.target_onoff = p_server->state.present_onoff;
    p_server->state.delay_ms = 0;
    p_server->state.remaining_time_ms = 0;
    generic_onoff_status_params_t status = {
                .present_on_off = p_server->state.present_onoff,
                .target_on_off = p_server->state.target_onoff,
                .remaining_time_ms = p_server->state.remaining_time_ms
            };
    (void) generic_onoff_server_status_publish(&p_server->server, &status);
}
```
注解:   
该例程没有演示app_transition模块的调用，其它例程都有演示app_transition模块。 app_onoff_status_publish会在app_transition时被调用，其它例程都有演示。

#### 4.1.1.3. Model模型层
* Model初始化
```
uint32_t generic_onoff_server_init(generic_onoff_server_t * p_server, uint8_t element_index)
{
    //顶层注册回调检查
    if (p_server == NULL ||
        p_server->settings.p_callbacks == NULL ||
        p_server->settings.p_callbacks->onoff_cbs.set_cb == NULL ||
        p_server->settings.p_callbacks->onoff_cbs.get_cb == NULL )
    {
        return MESH_ERROR_NULL;
    }
    //Access层参数初始化
    access_model_add_params_t init_params =
    {
        .model_id = ACCESS_MODEL_SIG(GENERIC_ONOFF_SERVER_MODEL_ID), //SIG Model定义ID号
        .element_index =  element_index,
        .p_opcode_handlers = &m_opcode_handlers[0], //SIG Model Message回调函数
        .opcode_count = ARRAY_SIZE(m_opcode_handlers),
        .p_args = p_server,
        .publish_timeout_cb = periodic_publish_cb
    };
    uint32_t status = access_model_add(&init_params, &p_server->model_handle);
    if (status == MESH_SUCCESS)
    {
        status = access_model_subscription_list_alloc(p_server->model_handle); //Access层订阅列表分配
    }
    return status;
}
//Model Message回调函数注册，SIG Model Message ID对应相应的处理函数
static const access_opcode_handler_t m_opcode_handlers[] =
{
    {ACCESS_OPCODE_SIG(GENERIC_ONOFF_OPCODE_SET), handle_set},
    {ACCESS_OPCODE_SIG(GENERIC_ONOFF_OPCODE_SET_UNACKNOWLEDGED), handle_set},
    {ACCESS_OPCODE_SIG(GENERIC_ONOFF_OPCODE_GET), handle_get},
};
```

* Model Message回调
```
static void handle_set(access_model_handle_t model_handle, const access_message_rx_t * p_rx_msg, void * p_args)
{
    generic_onoff_server_t * p_server = (generic_onoff_server_t *) p_args;
    generic_onoff_set_params_t in_data = {0};
    model_transition_t in_data_tr = {0};
    generic_onoff_status_params_t out_data = {0};
    generic_onoff_set_msg_pkt_t * p_msg_params_packed = (generic_onoff_set_msg_pkt_t *) p_rx_msg->p_data;
    //检查消息参数是否有效
    if (set_params_validate(p_rx_msg, p_msg_params_packed))
    {
        in_data.on_off = p_msg_params_packed->on_off;
        in_data.tid = p_msg_params_packed->tid;
        //检查消息tid是否正确，过滤掉有相同tid的消息，避免重复处理
        if (model_tid_validate(&p_server->tid_tracker, &p_rx_msg->meta_data, GENERIC_ONOFF_OPCODE_SET, in_data.tid))
        {
                //判断是否使用Transition
            if (p_rx_msg->length == GENERIC_ONOFF_SET_MAXLEN)
            {
                if (!model_transition_time_is_valid(p_msg_params_packed->transition_time))
                {
                    return;
                }
                in_data_tr.transition_time_ms = model_transition_time_decode(p_msg_params_packed->transition_time);
                in_data_tr.delay_ms = model_delay_decode(p_msg_params_packed->delay);
            }
            //调用App应用层回调
            p_server->settings.p_callbacks->onoff_cbs.set_cb(p_server,
                                                            &p_rx_msg->meta_data,
                                                            &in_data,
                                                            (p_rx_msg->length == GENERIC_ONOFF_SET_MINLEN) ? NULL : &in_data_tr,
                                                            (p_rx_msg->opcode.opcode == GENERIC_ONOFF_OPCODE_SET) ? &out_data : NULL);
            //Set消息回响应，Set Unack消息不会响应
            if (p_rx_msg->opcode.opcode == GENERIC_ONOFF_OPCODE_SET)
            {
                (void) status_send(p_server, p_rx_msg, &out_data);
            }
        }
    }
}
```

### 4.1.2. Generic OnOff Client
用户层直接调用Model层发送Mesh命令。
Model层将Opcode和Parameter打包层Access包，调用Access层publish接口发送数据。

#### 4.1.2.1. Main用户层
* 初始化Generic OnOff Client Model模块
```
//初始化Generic OnOff Client Model模块变量
const generic_onoff_client_callbacks_t client_cbs =
{
    .onoff_status_cb = app_generic_onoff_client_status_cb,
    .ack_transaction_status_cb = app_gen_onoff_client_transaction_status_cb,
    .periodic_publish_cb = app_gen_onoff_client_publish_interval_cb
};
static generic_onoff_client_t m_clients = {
    .settings.p_callbacks = &client_cbs,
    .settings.timeout = 0,
    .settings.force_segmented = false,
    .settings.transmic_size = MESH_TRANSMIC_SIZE_SMALL,
};
static void models_init(void)
{
    generic_onoff_client_init(&m_clients, 0); //Model初始化
}
```

* 注册Generic OnOff Client Model模块回调函数
```
static void app_gen_onoff_client_publish_interval_cb(access_model_handle_t handle, void * p_self)
{
     //周期发布回调函数
}
static void app_gen_onoff_client_transaction_status_cb(access_model_handle_t model_handle,
                                                       void * p_args,
                                                       access_reliable_status_t status)
{
    switch(status)
    {
        case ACCESS_RELIABLE_TRANSFER_SUCCESS:
            //发布和响应成功
            break;

        case ACCESS_RELIABLE_TRANSFER_TIMEOUT:
            //发布后没有响应错误
            break;

        case ACCESS_RELIABLE_TRANSFER_CANCELLED:
            //发布被取消
            break;
        default:
            break;
    }
}
//Generic OnOff Server返回数据回调
static void app_generic_onoff_client_status_cb(const generic_onoff_client_t * p_self,
                                               const access_message_rx_meta_t * p_meta,
                                               const generic_onoff_status_params_t * p_in)
{
    if (p_in->remaining_time_ms > 0)
    {
        //Transition还未结束
    }
    else
    {
        //Transition已经结束
    }
}
```

#### 4.1.2.2. Model模型层
* Model初始化
```   
uint32_t generic_onoff_client_init(generic_onoff_client_t * p_client, uint8_t element_index)
{
    if (p_client->settings.timeout == 0)
    {
        p_client->settings.timeout= MODEL_ACKNOWLEDGED_TRANSACTION_TIMEOUT;
    }
    //Access层参数初始化
    access_model_add_params_t add_params =
    {
        .model_id = ACCESS_MODEL_SIG(GENERIC_ONOFF_CLIENT_MODEL_ID), //SIG Model定义ID号
        .element_index = element_index,
        .p_opcode_handlers = &m_opcode_handlers[0], //SIG Model Message回调函数
        .opcode_count = ARRAY_SIZE(m_opcode_handlers),
        .p_args = p_client,
        .publish_timeout_cb = p_client->settings.p_callbacks->periodic_publish_cb
    };
    uint32_t status = access_model_add(&add_params, &p_client->model_handle);
    if (status == MESH_SUCCESS)
    {
        status = access_model_subscription_list_alloc(p_client->model_handle); //Access层订阅列表分配
    }
    return status;
}
//Model Message回调函数注册，SIG Model Message ID对应相应的处理函数
static const access_opcode_handler_t m_opcode_handlers[] =
{
    {ACCESS_OPCODE_SIG(GENERIC_ONOFF_OPCODE_STATUS), status_handle},
};
```

* Model Message回调
```
//接收Set命令响应，和接收Transition状态改变消息
static void status_handle(access_model_handle_t handle, const access_message_rx_t * p_rx_msg, void * p_args)
{
    generic_onoff_client_t * p_client = (generic_onoff_client_t *) p_args;
    generic_onoff_status_params_t in_data = {0};
    if (p_rx_msg->length == GENERIC_ONOFF_STATUS_MINLEN || p_rx_msg->length == GENERIC_ONOFF_STATUS_MAXLEN)
    {
        generic_onoff_status_msg_pkt_t * p_msg_params_packed = (generic_onoff_status_msg_pkt_t *) p_rx_msg->p_data;
        if (p_rx_msg->length == GENERIC_ONOFF_STATUS_MINLEN)
        {
            in_data.present_on_off = p_msg_params_packed->present_on_off;
            in_data.target_on_off = p_msg_params_packed->present_on_off;
            in_data.remaining_time_ms = 0;
        }
        else
        {
            in_data.present_on_off = p_msg_params_packed->present_on_off;
            in_data.target_on_off = p_msg_params_packed->target_on_off;
            in_data.remaining_time_ms = model_transition_time_decode(p_msg_params_packed->remaining_time);
        }
    }
    //调用Main层回调，上报状态
    p_client->settings.p_callbacks->onoff_status_cb(p_client, &p_rx_msg->meta_data, &in_data);
}
```

## 4.2. Generic Level
通过此例程，用户可以学习Generic Level Server/Client Model State, Message, Transition。
Generic Level 是一个控制灯亮度的基础模型（root model），上层模型例如灯控模型会继承这个模型，并拥有这个模型的所有功能。
注解:
模型的继承是SIG Mesh中的一个特点，例如一个灯控Model可以继承Generic OnOff Model拥有灯的开关功能（包括开关的记忆功能），另外一个灯控Model可以继承Generic OnOff Model和Generic Level Model，即拥有开关功能，也拥有调光功能。

* 硬件需求
一个CMT453x开发板作为clinet。
一个或多个CMT453x开发板作为server。

* 软件需求
nRF Mesh安卓APP作为配网设备（Google play下载）。
generic_level server例程（BLE MESH SDK example目录下）。
generic_level client例程（BLE MESH SDK example目录下）。

* 测试环境搭建
编译并烧录generic_level client例程到开发板，作为client设备。
编译并烧录generic_level server例程到开发板，作为server设备。

* 配网过程
1. 打开nRF Mesh APP，然后点击添加设备到网络按钮（APP右下脚加号）。
2. 进入扫描界面，可以看到两个开发板的广播名称。
3. 点击一个设备广播名称，再点击IDENTIFY按钮，再点击PROVISION按钮，开始自动配网流程。
4. 配网成功结束点击ok按钮，该设备被添加到Network Tab中，成为网络中的一个节点。
5. 点击设备节点选项卡，进入设备节点配置界面，点击Element下拉箭头打开Model选项。
6. 点击Generic Level Client/Server，进入Model配置界面。
7. 如果是Client配置界面，首先点击BIND KEY按钮，选择Application Key 1，再点击SET PUBLICATION按钮，接着点击Publication Address，在弹出对话框内选择Unicast Address，写入Server节点地址，点击OK，最后点击APPLY，配置完成。
8. 如果是Server配置界面，点击BIND KEY按钮，选择Application Key 1，再点击SET PUBLICATION按钮，接着点击Publication Address，在弹出对话框内选择Unicast Address，写入Generic Level Client所在Element的地址，配置完成。

多个server开发板，按照配网过程中server的配网方法配置。   
Server开发板PB4连接LED1(PWM输出)，开发板串口转USB芯片RX连接PB12(log输出)。   
Client开发板串口转USB芯片RX连接PB12(log输出)，串口转USB芯片TX连接PB7(串口命令输入)。   

* 测试效果说明
1. Client开发板串口输入”1”，控制Server开发板LED1亮度增加。
2. Client开发板串口输入”2”，控制Server开发板LED1亮度减少。
3. Client和Server开发板通过串口查看log。
4. 如果有多个Server开发板，所有Server开发板的LED1会同时被Client开发板控制。

### 4.2.1. Generic Level Server
此例程演示Transition功能，用户可以通过串口输出了解Transition的整个工作流程。   
开发板Button1有主动发布Generic Level值功能，使用此功能前，需要在App中配置Generic Level Server的Publication地址，例如此例程中配置成Client Model的Element地址。

<div align="center">
  <img src="_images/Generic_Level_Server.png" width=800>  
</div>  
</br>  

#### 4.2.1.1. Main用户层
* 初始化Generic Level Server App模块
```
APP_LEVEL_SERVER_DEF(m_level_server_0,
                     false,
                     MESH_TRANSMIC_SIZE_SMALL,
                     NULL,
                     app_level_server_set_cb,
                     app_level_server_get_cb,
                     app_level_server_transition_cb);
app_level_init(&m_level_server_0, 0);
```

* Generic Level Server App模块回调函数
```
//Generic Level Set Message回调
static void app_level_server_set_cb(const app_level_server_t * p_server, int16_t present_level)
{
    m_pwm0_present_level = present_level;
    pwm_utils_level_set(&m_pwm0, m_pwm0_present_level); //设置灯亮度
}
//Generic Level Get Message回调
static void app_level_server_get_cb(const app_level_server_t * p_server, int16_t * p_present_level)
{
    *p_present_level = m_pwm0_present_level;
}
//Transition回调
static void app_level_server_transition_cb(const app_level_server_t * p_server,
                                                uint32_t transition_time_ms, uint16_t target_level,
                                                app_transition_type_t transition_type)
{
        //Transition状态改变时被调用
}
```

#### 4.2.1.2. App应用层
* 模块初始化
```
uint32_t app_level_init(app_level_server_t * p_app, uint8_t element_index)
{
    uint32_t status = MESH_ERROR_INTERNAL;
    if (p_app == NULL)
    {
        return MESH_ERROR_NULL;
    }
    if ( (p_app->level_get_cb == NULL) ||
         ( (p_app->level_set_cb == NULL) &&
           (p_app->level_transition_cb == NULL) ) )
    {
        return MESH_ERROR_NULL;
    }
    p_app->server.settings.p_callbacks = &m_level_srv_cbs;
    status = generic_level_server_init(&p_app->server, element_index); //Model初始化
    if (status != MESH_SUCCESS)
    {
        return status;
    }
    p_app->state.transition.delay_start_cb = app_level_delay_start_cb;
    p_app->state.transition.transition_start_cb = app_level_transition_start_cb;
    p_app->state.transition.transition_tick_cb = app_level_transition_tick_cb;
    p_app->state.transition.transition_complete_cb = app_level_transition_complete_cb;
    p_app->state.transition.timer.msg_id = MESH_TASK_MODEL_TIMER_LL;
    p_app->state.transition.p_context = p_app;
    return app_transition_init(&p_app->state.transition); //Transition初始化
}
```

* Model回调函数
```
static void generic_level_state_set_cb(const generic_level_server_t * p_self,
                                       const access_message_rx_meta_t * p_meta,
                                       const generic_level_set_params_t * p_in,
                                       const model_transition_t * p_in_transition,
                                       generic_level_status_params_t * p_out)
{
    app_level_server_t * p_app = PARENT_BY_FIELD_GET(app_level_server_t, server, p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    p_app->state.target_snapshot = p_in->level;
    p_app->state.init_present_snapshot = p_app->state.present_level;
    transition_params_set(p_app,
                          (int32_t)p_app->state.target_snapshot - (int32_t)p_app->state.init_present_snapshot,
                          p_in_transition,
                          APP_TRANSITION_TYPE_SET);
    //开始Transition
    app_transition_trigger(&p_app->state.transition);
    if (p_out != NULL)
    {
        p_out->present_level = p_app->state.present_level;
        p_out->target_level = p_app->state.target_snapshot;
        p_out->remaining_time_ms = p_params->transition_time_ms;
    }
}
```

* Transition回调函数
```
static void app_level_delay_start_cb(const app_transition_t * p_transition)
{
    //Transition Delay结束回调函数
}
//Transition Start开始回调函数
static void app_level_transition_start_cb(const app_transition_t * p_transition)
{
    app_level_server_t * p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    p_app->state.delta = p_params->required_delta;
    p_app->state.initial_present_level = p_app->state.init_present_snapshot;
    p_app->state.target_level = p_app->state.target_snapshot;
    if (p_app->level_transition_cb != NULL)
    {
        p_app->level_transition_cb(p_app, p_params->transition_time_ms,
                                          p_app->state.target_level,
                                          p_params->transition_type);
    }
}
//Transition Step回调函数
static void app_level_transition_tick_cb(const app_transition_t * p_transition)
{
    app_level_server_t * p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    if (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET)
    {
        int32_t delta = (p_app->state.target_level - p_app->state.initial_present_level);
        p_app->state.present_level = p_app->state.initial_present_level +
                                        (delta * (int64_t)app_transition_elapsed_time_get(&p_app->state.transition) /
                                          (int64_t)p_params->transition_time_ms);
    }
    else
    {
        p_app->state.present_level = p_app->state.initial_present_level +
                                        (((int64_t)app_transition_elapsed_time_get(&p_app->state.transition) * (int64_t)p_app->state.delta) /
                                          (int64_t)p_params->transition_time_ms);
    }
    if (p_app->level_set_cb != NULL)
    {
        //main层改变LED Level值
        p_app->level_set_cb(p_app, p_app->state.present_level);
    }
}
//Transition结束回调函数
static void app_level_transition_complete_cb(const app_transition_t * p_transition)
{
    app_level_server_t * p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    p_app->state.target_level = p_app->state.target_snapshot;
    if (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET)
    {
        p_app->state.present_level = p_app->state.target_level;
    }
    generic_level_status_params_t status_params;
    status_params.present_level = p_app->state.present_level;
    status_params.target_level = p_app->state.target_level;
    status_params.remaining_time_ms = 0;
    //发布当前状态值
    generic_level_server_status_publish(&p_app->server, &status_params);
    if (p_app->level_set_cb != NULL)
    {
        //main层改变LED Level值
        p_app->level_set_cb(p_app, p_app->state.present_level);
    }

    if (p_app->level_transition_cb != NULL)
    {
        p_app->level_transition_cb(p_app, p_params->transition_time_ms,
                                          p_app->state.target_level,
                                          p_params->transition_type);
    }
}
```

#### 4.2.1.3. Model模型层

* Model初始化
```
uint32_t generic_level_server_init(generic_level_server_t * p_server, uint8_t element_index)
{
    if (p_server == NULL ||
        p_server->settings.p_callbacks == NULL ||
        p_server->settings.p_callbacks->level_cbs.set_cb == NULL ||
        p_server->settings.p_callbacks->level_cbs.delta_set_cb == NULL ||
        p_server->settings.p_callbacks->level_cbs.move_set_cb == NULL ||
        p_server->settings.p_callbacks->level_cbs.get_cb == NULL)
    {
        return MESH_ERROR_NULL;
    }
    access_model_add_params_t init_params =
    {
        .model_id = ACCESS_MODEL_SIG(GENERIC_LEVEL_SERVER_MODEL_ID),
        .element_index =  element_index,
        .p_opcode_handlers = &m_opcode_handlers[0],
        .opcode_count = ARRAY_SIZE(m_opcode_handlers),
        .p_args = p_server,
        .publish_timeout_cb = periodic_publish_cb
    };
    uint32_t status = access_model_add(&init_params, &p_server->model_handle);
    if (status == MESH_SUCCESS)
    {
        //添加订阅列表，用于保存数据库
        status = access_model_subscription_list_alloc(p_server->model_handle);
    }
    return status;
}
//Model Message回调函数注册，SIG Model Message ID对应相应的处理函数
static const access_opcode_handler_t m_opcode_handlers[] =
{
    {ACCESS_OPCODE_SIG(GENERIC_LEVEL_OPCODE_GET), handle_get},
    {ACCESS_OPCODE_SIG(GENERIC_LEVEL_OPCODE_SET), handle_set},
    {ACCESS_OPCODE_SIG(GENERIC_LEVEL_OPCODE_SET_UNACKNOWLEDGED), handle_set},
    {ACCESS_OPCODE_SIG(GENERIC_LEVEL_OPCODE_DELTA_SET), handle_delta_set},
    {ACCESS_OPCODE_SIG(GENERIC_LEVEL_OPCODE_DELTA_SET_UNACKNOWLEDGED), handle_delta_set},
    {ACCESS_OPCODE_SIG(GENERIC_LEVEL_OPCODE_MOVE_SET), handle_move_set},
    {ACCESS_OPCODE_SIG(GENERIC_LEVEL_OPCODE_MOVE_SET_UNACKNOWLEDGED), handle_move_set}
};
```

* Model Message回调
```
//Generic Level Set回调函数
static void handle_set(access_model_handle_t model_handle, const access_message_rx_t * p_rx_msg, void * p_args)
{
    generic_level_server_t * p_server = (generic_level_server_t *) p_args;
    generic_level_set_params_t in_data = {0};
    model_transition_t in_data_tr = {0};
    generic_level_status_params_t out_data = {0};
    if (p_rx_msg->length == GENERIC_LEVEL_SET_MINLEN || p_rx_msg->length == GENERIC_LEVEL_SET_MAXLEN)
    {
        generic_level_set_msg_pkt_t * p_msg_params_packed = (generic_level_set_msg_pkt_t *) p_rx_msg->p_data;
        in_data.level = p_msg_params_packed->level;
        in_data.tid = p_msg_params_packed->tid;
        if (model_tid_validate(&p_server->tid_tracker, &p_rx_msg->meta_data, GENERIC_LEVEL_OPCODE_SET, in_data.tid))
        {
                //通过message数据长度判断是否有Transition
            if (p_rx_msg->length == GENERIC_LEVEL_SET_MAXLEN)
            {
                if (!model_transition_time_is_valid(p_msg_params_packed->transition_time))
                {
                    return;
                }
                in_data_tr.transition_time_ms = model_transition_time_decode(p_msg_params_packed->transition_time);
                in_data_tr.delay_ms = model_delay_decode(p_msg_params_packed->delay);
            }
            //调用App层回调
            p_server->settings.p_callbacks->level_cbs.set_cb(p_server,
                                                            &p_rx_msg->meta_data, &in_data,
                                                            (p_rx_msg->length == GENERIC_LEVEL_SET_MINLEN) ? NULL : &in_data_tr,
                                                            (p_rx_msg->opcode.opcode == GENERIC_LEVEL_OPCODE_SET) ? &out_data : NULL);
            if (p_rx_msg->opcode.opcode == GENERIC_LEVEL_OPCODE_SET)
            {
                //如果是Set消息，立即响应
                status_send(p_server, p_rx_msg, &out_data);
            }
        }
    }
}
//Generic Level Get回调函数
static void handle_get(access_model_handle_t model_handle, const access_message_rx_t * p_rx_msg, void * p_args)
{
    generic_level_server_t * p_server = (generic_level_server_t *) p_args;
    generic_level_status_params_t out_data = {0};
    if (p_rx_msg->length == 0)
    {
        //App层回调函数，获取当前Level
        p_server->settings.p_callbacks->level_cbs.get_cb(p_server, &p_rx_msg->meta_data, &out_data);
        //响应命令，返回当前Level
        status_send(p_server, p_rx_msg, &out_data);
    }
}
```

### 4.2.2. Generic Level Client
此例程演示了Generic Level Client Model Message数据包格式，Set Message和Set Unack Message发送方法，Set Message响应Access Reliable的使用方法，接收Status Message的处理方法。

#### 4.2.2.1. Main用户层
* 初始化Generic Level Client Model模块
```
//初始化两个Element，两个Model
static void models_init(void)
{
    for (uint32_t i = 0; i < CLIENT_MODEL_INSTANCE_COUNT; ++i)
    {
        m_clients[i].settings.p_callbacks = &client_cbs;
        m_clients[i].settings.timeout = 0;
        m_clients[i].settings.force_segmented = false;
        m_clients[i].settings.transmic_size = MESH_TRANSMIC_SIZE_SMALL;
        generic_level_client_init(&m_clients[i], i + 1);
    }
}
```

* 注册Generic Level Client Model模块回调函数
```
static void app_gen_level_client_transaction_status_cb(access_model_handle_t model_handle,
                                                       void * p_args,
                                                       access_reliable_status_t status)
{
    switch(status)
    {
        case ACCESS_RELIABLE_TRANSFER_SUCCESS:
            //Ack Message响应成功
            break;

        case ACCESS_RELIABLE_TRANSFER_TIMEOUT:
            //Ack Message响应超时
            break;

        case ACCESS_RELIABLE_TRANSFER_CANCELLED:
            //Ack Message被取消
            break;
    }
}
static void app_generic_level_client_status_cb(const generic_level_client_t * p_self,
                                               const access_message_rx_meta_t * p_meta,
                                               const generic_level_status_params_t * p_in)
{
    if (p_in->remaining_time_ms > 0)
    {
        //Transition响应
    }
    else
    {
        //Transition Complete响应
    }
}
static void app_gen_level_client_publish_interval_cb(access_model_handle_t handle, void * p_self)
{
    //周期性发布响应
}
```

* 串口Rx数据处理
```
int mesh_task_uart_rx_data_handler(ke_msg_id_t const msgid,void *p_param,ke_task_id_t const dest_id,ke_task_id_t const src_id,enum ke_msg_status_tag *msg_ret)
{
    uint8_t data = *(uint8_t *)p_param;
    uint32_t status = MESH_SUCCESS;
    static uint8_t client = 0;
    static generic_level_set_params_t set_params = {0};
    static generic_level_move_set_params_t move_set_params = {0};
    static generic_level_delta_set_params_t delta_set_params = {0};
    model_transition_t transition_params;
    static uint32_t timestamp = 0;
    timestamp_t current_time;
    switch(data)
    {
        case '1':
        //Level加上Step
        set_params.level = (set_params.level + APP_LEVEL_STEP_SIZE) >= INT16_MAX ?
                            INT16_MAX : set_params.level + APP_LEVEL_STEP_SIZE;
        set_params.tid++;
        break;
        case '2':
        //Level减去Step
        set_params.level = (set_params.level - APP_LEVEL_STEP_SIZE) <= INT16_MIN ?
                               INT16_MIN : set_params.level - APP_LEVEL_STEP_SIZE;
        set_params.tid++;
        break;
    }
    current_time = bsp_time_now();
    if (timestamp + SEC_TO_US(APP_TIMEOUT_FOR_TID_CHANGE) < current_time)
    {
        delta_set_params.tid++;
    }
    timestamp = current_time;
    transition_params.delay_ms = APP_LEVEL_DELAY_MS;
    //计算Transition Time
    transition_params.transition_time_ms = APP_LEVEL_TRANSITION_TIME_MS;
    switch(data)
    {
        case '1':
        case '2':
        //发送Set Message，reliable的意思是接收Ack，通过回调通知上层
        access_model_reliable_cancel(m_clients[client].model_handle);
        status = generic_level_client_set(&m_clients[client], &set_params, &transition_params);
        break;
    }
    switch (status)
    {
        case MESH_SUCCESS:
            break;
        case MESH_ERROR_NO_MEM:
        case MESH_ERROR_BUSY:
        case MESH_ERROR_INVALID_STATE:
            break;
        case MESH_ERROR_INVALID_PARAM:
            break;
    }
    return (KE_MSG_CONSUMED);
}
```


## 4.3. Light Lightness
此例程演示Model状态改变时保存状态，开和机读取状态并恢复状态。
通过此例程，用户可以学习文件系统的使用，Model状态的存储与读取。
Server例程中演示了Model的继承。

### 4.3.1. Light Lightness Server
此例程演示Light Lightness State掉电保存功能，开机读取状态，状态改变时写入新状态。

<div align="center">
  <img src="_images/Light_Lightness_Server.png" width=800>  
</div>  
</br>  

#### 4.3.1.1. Main用户层
* 初始化Light Lightness Server App模块
```
APP_LIGHT_LIGHTNESS_SETUP_SERVER_DEF(m_light_lightness_server_0,
                                     false,
                                     MESH_TRANSMIC_SIZE_SMALL,
                                     set_lightness_cb,
                                     get_lightness_cb,
                                     transition_time_lightness_cb)
static void models_init(void)
{
    //初始化App模块
    app_light_lightness_model_init(&m_light_lightness_server_0, 0);
}
```

* light lightness app层模块回调函数
```
//Lightness Set回调函数
static void set_lightness_cb(const app_light_lightness_setup_server_t * p_app, uint16_t lightness)
{
    //设置LED亮度值
    m_pwm0_present_actual_lightness = lightness;
    pwm_utils_level_set_unsigned(&m_pwm, m_pwm0_present_actual_lightness);
}
//Lightness Get回调函数
static void get_lightness_cb(const app_light_lightness_setup_server_t * p_app, uint16_t * p_lightness)
{
    //获取LED亮度值
    *p_lightness = (m_pwm0_present_actual_lightness);
}
//Lightness Transition回调函数
static void transition_time_lightness_cb(const app_light_lightness_setup_server_t * p_server, uint32_t transition_time_ms, uint16_t target_lightness)
{
    //Transition时间和亮度
}
```

* 开机Model状态绑定
```
app_light_lightness_binding_setup(&m_light_lightness_server_0);
```

#### 4.3.1.2. App应用层
* 模块初始化
* Model回调函数
* Transition回调函数
* 开机Model状态绑定
```
//LED亮度绑定
uint32_t app_light_lightness_binding_setup(app_light_lightness_setup_server_t * p_app)
{
    light_lightness_saved_values_t state;
    light_lightness_setup_server_t * p_s_server;
    uint16_t index;
    if (p_app == NULL)
    {
        return MESH_ERROR_NULL;
    }
    p_s_server = &p_app->light_lightness_setup_server;
    index    = p_s_server->state.handle;
    //文件系统读取LED亮度range状态
    light_lightness_mc_range_status_state_get(index, &state.range.status);
    light_lightness_mc_range_min_state_get(index, &state.range.range_min);
    light_lightness_mc_range_max_state_get(index, &state.range.range_max);
    //文件系统读取LED开关状态
    light_lightness_mc_onpowerup_state_get(index, &state.onpowerup);
    light_lightness_mc_actual_state_get(index, &state.actual_lightness);
    light_lightness_mc_last_state_get(index, &state.last_lightness);
    light_lightness_mc_default_state_get(index, &state.default_lightness);
    //文件系统保存状态和Lightness Server Model绑定进行绑定
    return light_lightness_ponoff_binding_setup(p_s_server, &state);
}
```

#### 4.3.1.3. Model模型层
* Model初始化
此例程演示Model的继承，继承Model数据通过回调函数交给被继承Model处理。
Light Lightness Server model继承Generic Power OnOff Server model和Generic Level Server model。
<div align="center">
  <img src="_images/Light_Lightness_Server_Model.png">  
</div>  
</br>  
   
```
uint32_t light_lightness_setup_server_init(light_lightness_setup_server_t * p_s_server, uint8_t element_index)
{
    uint32_t status;
    if (!(p_s_server
       && p_s_server->settings.p_callbacks
       && p_s_server->settings.p_callbacks->light_lightness_cbs.set_cb
       && p_s_server->settings.p_callbacks->light_lightness_cbs.default_set_cb
       && p_s_server->settings.p_callbacks->light_lightness_cbs.range_set_cb
       && p_s_server->settings.p_callbacks->light_lightness_cbs.delta_set_cb
       && p_s_server->settings.p_callbacks->light_lightness_cbs.move_set_cb
       && p_s_server->settings.p_callbacks->light_lightness_cbs.get_cb
       && p_s_server->settings.p_callbacks->light_lightness_cbs.last_get_cb
       && p_s_server->settings.p_callbacks->light_lightness_cbs.default_get_cb
       && p_s_server->settings.p_callbacks->light_lightness_cbs.range_get_cb))
    {
        return MESH_ERROR_NULL;
    }
    if (m_total_ll_instances >= LIGHT_LIGHTNESS_SETUP_SERVER_INSTANCES_MAX)
    {
        return MESH_ERROR_RESOURCES;
    }
    p_s_server->settings.element_index = element_index;
    p_s_server->generic_ponoff_setup_srv.settings.element_index = element_index;
    //继承Generic Power OnOff Model，注册此Model的回调函数
    p_s_server->generic_ponoff_setup_srv.generic_ponoff_srv.generic_onoff_srv.settings.p_callbacks = &m_onoff_srv_cbs;
    do
    {
        if (MESH_SUCCESS != (status = generic_ponoff_setup_server_init(&p_s_server->generic_ponoff_setup_srv, element_index)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_list_dealloc(p_s_server->generic_ponoff_setup_srv.model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_list_dealloc(p_s_server->generic_ponoff_setup_srv.generic_ponoff_srv.model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_list_dealloc(p_s_server->generic_ponoff_setup_srv.generic_ponoff_srv.generic_onoff_srv.model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_list_dealloc(p_s_server->generic_ponoff_setup_srv.generic_dtt_srv.model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = light_lightness_server_init(&p_s_server->light_lightness_srv, element_index)))
        {
            break;
        }
        access_model_add_params_t init_params =
                {
                        .model_id = ACCESS_MODEL_SIG(LIGHT_LIGHTNESS_SETUP_SERVER_MODEL_ID),
                        .element_index =  element_index,
                        .p_opcode_handlers = &m_opcode_handlers_setup[0],
                        .opcode_count = ARRAY_SIZE(m_opcode_handlers_setup),
                        .p_args = p_s_server,
                };
        if (MESH_SUCCESS != (status = access_model_add(&init_params, &p_s_server->model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_list_alloc(p_s_server->model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_lists_share(p_s_server->model_handle, p_s_server->generic_ponoff_setup_srv.model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_lists_share(p_s_server->model_handle, p_s_server->generic_ponoff_setup_srv.generic_ponoff_srv.model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_lists_share( p_s_server->model_handle, p_s_server->generic_ponoff_setup_srv.generic_ponoff_srv.generic_onoff_srv.model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_lists_share( p_s_server->model_handle, p_s_server->generic_ponoff_setup_srv.generic_dtt_srv.model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_lists_share( p_s_server->model_handle, p_s_server->light_lightness_srv.model_handle)))
        {
            break;
        }
        if (MESH_SUCCESS != (status = access_model_subscription_lists_share( p_s_server->model_handle, p_s_server->light_lightness_srv.generic_level_srv.model_handle)))
        {
            break;
        }
    } while (0);
    if (MESH_SUCCESS == status)
    {
        m_total_ll_instances++;
    }
    return status;
}
static uint32_t light_lightness_server_init(light_lightness_server_t * p_server, uint8_t element_index)
{
        uint32_t status = MESH_SUCCESS;
    if (p_server == NULL)
    {
        return MESH_ERROR_NULL;
    }
    //继承Generic Level Model，注册此Model的回调函数
    p_server->generic_level_srv.settings.p_callbacks = &m_level_srv_cbs;
    status = generic_level_server_init(&p_server->generic_level_srv, element_index);
    if (status == MESH_SUCCESS)
    {
        status = access_model_subscription_list_dealloc(p_server->generic_level_srv.model_handle);
    }
    if (status == MESH_SUCCESS)
    {
        access_model_add_params_t init_params =
        {
            .model_id = ACCESS_MODEL_SIG(LIGHT_LIGHTNESS_SERVER_MODEL_ID),
            .element_index =  element_index,
            .p_opcode_handlers = &m_opcode_handlers[0],
            .opcode_count = ARRAY_SIZE(m_opcode_handlers),
            .p_args = p_server,
            .publish_timeout_cb = periodic_publish_cb
        };
        status = access_model_add(&init_params, &p_server->model_handle);
    }
    return status;
}
```

* Model Message回调
```
//Lightness Set Actual消息回调函数
static void handle_actual_set(access_model_handle_t model_handle, const access_message_rx_t * p_rx_msg, void * p_args)
{
    light_lightness_server_t * p_server;
    light_lightness_set_msg_pkt_t * p_msg_pkt;
    light_lightness_status_params_t out_data = {0};
    light_lightness_set_params_t in_data = {0};
    model_transition_t transition = {0};
    model_transition_t * p_transition;
    p_server = (light_lightness_server_t *) p_args;
    p_msg_pkt = (light_lightness_set_msg_pkt_t *) p_rx_msg->p_data;
    if (!model_tid_validate(&p_server->tid_tracker,
                            &p_rx_msg->meta_data,
                            LIGHT_LIGHTNESS_OPCODE_SET,
                            p_msg_pkt->tid))
    {
        return;
    }
    p_transition = &transition;
    if (!handle_set_message_validate(LIGHT_LIGHTNESS_SET_MINLEN,
                                        LIGHT_LIGHTNESS_SET_MAXLEN,
                                        p_rx_msg->length,
                                        p_msg_pkt->transition_time,
                                        p_msg_pkt->delay,
                                        &p_transition))
    {
        return;
    }
    in_data.lightness = p_msg_pkt->lightness;
    in_data.tid = p_msg_pkt->tid;
    handle_set(p_server,
                p_rx_msg,
                &in_data,
                (LIGHT_LIGHTNESS_OPCODE_SET == p_rx_msg->opcode.opcode) ? &out_data : NULL,
                p_transition,
                actual_set_response);
}
static void handle_set(light_lightness_server_t * p_server, const access_message_rx_t * p_rx_msg, light_lightness_set_params_t * p_in_data, light_lightness_status_params_t * p_out_data, model_transition_t * p_transition, lightness_set_response_t response)
{
    light_lightness_setup_server_t * p_s_server;
    p_s_server = PARENT_BY_FIELD_GET(light_lightness_setup_server_t,
                                        light_lightness_srv,
                                        p_server);
    p_in_data->lightness = clip_ll_actual_to_range(p_s_server,
                                                    &p_rx_msg->meta_data,
                                                    p_in_data->lightness);
    //App层回调函数，设置Lightness值，以及Transition
    p_s_server->settings.p_callbacks->light_lightness_cbs.set_cb(p_s_server,
                                                                    &p_rx_msg->meta_data,
                                                                    p_in_data,
                                                                    p_transition,
                                                                    p_out_data);
    //Reply 命令响应
    response(p_server, p_rx_msg, p_out_data);
}
```

* Model 层数据存储
```
//Entry 宏定义结构体，开机赋值默认值，如果文件系统中有有效值，则更新默认值
MESH_CONFIG_ENTRY(m_ll_actual_entry,                //Entry 名称
                    LIGHT_LIGHTNESS_ACTUAL_EID,     //Entry ID
                    STORED_WITH_SCENE_INSTANCES,    //Entry 个数
                    sizeof(uint16_t),               //Entry 数据长度
                    actual_setter,                  //Entry Setter回调函数
                    actual_getter,                  //Entry Getter回调函数
                    NULL,
                    true);                          //Entry 默认值
```

* 开机Model状态绑定
```
uint32_t light_lightness_ponoff_binding_setup(light_lightness_setup_server_t * p_s_server,light_lightness_saved_values_t * p_saved_states)
{
    if (p_s_server == NULL || p_saved_states == NULL)
    {
        return MESH_ERROR_NULL;
    }
    light_lightness_set_params_t ll_actual_set = {0};
    uint16_t led_value = 0;
    if (p_saved_states->onpowerup == GENERIC_ON_POWERUP_OFF)
    {
        led_value = 0;
    }
    else if ((p_saved_states->onpowerup == GENERIC_ON_POWERUP_DEFAULT) && (p_saved_states->default_lightness != 0))
    {
        led_value = p_saved_states->default_lightness;
    }
    else if ((p_saved_states->onpowerup == GENERIC_ON_POWERUP_DEFAULT) && (p_saved_states->default_lightness == 0))
    {
        led_value = p_saved_states->last_lightness;
    }
    else if (p_saved_states->onpowerup == GENERIC_ON_POWERUP_RESTORE)
    {
        led_value = p_saved_states->actual_lightness;
    }
    led_value = light_lightness_utils_actual_to_range_restrict(led_value, p_saved_states->range.range_min, p_saved_states->range.range_max);
    ll_actual_set.lightness = led_value;
    //调用App回调，设置LED灯状态，但是不开启Transition，也不发布状态
    p_s_server->settings.p_callbacks->light_lightness_cbs.set_cb(p_s_server,
                                                                 NULL,
                                                                 &ll_actual_set,
                                                                 NULL,
                                                                 NULL);
    p_s_server->state.initialized = true;
    return MESH_SUCCESS;
}
```

### 4.3.2. Light Lightness Client
用户通过此例程可以测试Light Lightness Message。
代码结构和Generic Level Client例程类似。 参考 [Generic Level Client](#422-generic-level-client)。


## 4.4. Light CTL
Light CTL是用来控制色温的模型，色温是将人对自然光线亮度的感觉量化的意思，通过色温值，照明厂家可以准确的设计出客户需要的光线温度效果。
色温是表示光线中包含颜色成分的一个计量单位，指黑体开始加温后所呈现的颜色。黑体在受热后，逐渐由黑变红，转黄，发白，最后发出蓝色光。当加热到一定的温度，黑体发出的光所含的光谱成分，就称为这一温度下的色温，计量单位为“K”（开尔文 英文 Kelvin）。
色温和 “黑体辐射定律” （Black Body）有直接联系。这条定律的原理也很简单：假想一个纯黑的物体，它能一点儿都不带损失的完全吸收到落在它身上的全部热量，那么随着热量的不断上升，这个黑体就一定会随着温度的不同颜色也会发生变化。而根据温度的升高过程，黑体会逐渐变为红色，然后升级到橙色，黄色，白色，直至变为蓝色。   
黑体色温按照开尔文排列如图:   
<div align="center">
  <img src="_images/Color_Temp_K_Scale.png">  
</div>  
</br>  

自然界色温按照卡尔文排列如图:
<div align="center">
  <img src="_images/Color_Temp_Nature_Scale.jpeg">  
</div>  
</br>  

房间色温按照卡尔文排列如图:
<div align="center">
  <img src="_images/Color_Temp_Room.jpg" width=800>  
</div>  
</br>  

LED色温按照卡尔文排列如图:
<div align="center">
  <img src="_images/Color_Temp_LED.jpeg">  
</div>  
</br>  

CTL例程使用开发板两个LED灯模拟冷暖灯演示Mesh色温控制，目前LED厂家通常使用两种LED实现色温效果，冷色灯偏蓝色和暖色灯偏黄色。
测试方法 : 参考 [Generic Level](#42-generic-level) 。


### 4.4.1. Light CTL Server
此例程CTL Server Model继承Lightness Server Model。   
此例程演示消息的绑定。   

Light CTL Lightness状态绑定Light Lightness Actual状态，当Lightness状态改变时，CTL Lightness状态需要重新计算，以及发布CTL状态。   
<div align="center">
  <img src="_images/CTL_Server_State_Bonding.png" width=800>  
</div>  
</br>  

#### 4.4.1.1. CTL状态绑定，消息响应流程
* OnOff Model收到消息
```
static void handle_set(access_model_handle_t model_handle, const access_message_rx_t * p_rx_msg, void * p_args)
{
    generic_onoff_server_t * p_server = (generic_onoff_server_t *) p_args;
    generic_onoff_set_params_t in_data = {0};
    model_transition_t in_data_tr = {0};
    generic_onoff_status_params_t out_data = {0};
    generic_onoff_set_msg_pkt_t * p_msg_params_packed = (generic_onoff_set_msg_pkt_t *) p_rx_msg->p_data;
    if (set_params_validate(p_rx_msg, p_msg_params_packed))
    {
        in_data.on_off = p_msg_params_packed->on_off;
        in_data.tid = p_msg_params_packed->tid;
        if (model_tid_validate(&p_server->tid_tracker, &p_rx_msg->meta_data, GENERIC_ONOFF_OPCODE_SET, in_data.tid))
        {
            if (p_rx_msg->length == GENERIC_ONOFF_SET_MAXLEN)
            {
                if (!model_transition_time_is_valid(p_msg_params_packed->transition_time))
                {
                    return;
                }
                in_data_tr.transition_time_ms = model_transition_time_decode(p_msg_params_packed->transition_time);
                in_data_tr.delay_ms = model_delay_decode(p_msg_params_packed->delay);
            }
            //App Lightness回调
            p_server->settings.p_callbacks->onoff_cbs.set_cb(p_server,
                                                            &p_rx_msg->meta_data,
                                                            &in_data,
                                                            (p_rx_msg->length == GENERIC_ONOFF_SET_MINLEN) ? NULL : &in_data_tr,
                                                            (p_rx_msg->opcode.opcode == GENERIC_ONOFF_OPCODE_SET) ? &out_data : NULL);
            if (p_rx_msg->opcode.opcode == GENERIC_ONOFF_OPCODE_SET)
            {
                //Set Msg响应
                status_send(p_server, p_rx_msg, &out_data);
            }
        }
    }
}
```

* App Lightness回调
```
static void light_lightness_state_set_cb(const light_lightness_setup_server_t * p_self,const access_message_rx_meta_t * p_meta,const light_lightness_set_params_t * p_in,const model_transition_t * p_in_transition,light_lightness_status_params_t * p_out)
{
    app_light_lightness_setup_server_t * p_app;
    uint16_t present_lightness;
    uint32_t transition_time_ms;
    p_app = PARENT_BY_FIELD_GET(app_light_lightness_setup_server_t,light_lightness_setup_server,p_self);
    app_transition_params_t * p_params = app_transition_requested_get(&p_app->state.transition);
    if (p_app->app_add_notify.app_notify_set_cb != NULL)
    {
        p_app->app_add_notify.app_notify_set_cb(p_app->app_add_notify.p_app_notify_v, p_in->lightness);
    }
    p_app->app_light_lightness_get_cb(p_app, &present_lightness);
    p_app->state.target_snapshot = target_snapshot_get(p_self->state.handle, p_in->lightness);
    p_app->state.init_present_snapshot = p_app->state.present_lightness;
    light_lightness_mc_actual_state_set(p_self->state.handle, p_app->state.target_snapshot);
    if (p_app->state.target_snapshot >= LIGHT_LIGHTNESS_LAST_MIN)
    {
        light_lightness_mc_last_state_set(p_self->state.handle, p_app->state.target_snapshot,LIGHT_LIGHTNESS_MC_WRITE_DESTINATION_FLASH_ONLY);
    }
    if (!p_self->state.initialized || (present_lightness != p_in->lightness))
    {
        transition_parameters_set(p_app,(int32_t)p_app->state.target_snapshot - (int32_t)present_lightness,p_in_transition,APP_TRANSITION_TYPE_SET);
        transition_time_ms = p_params->transition_time_ms;
        //开始Transition
        app_transition_trigger(&p_app->state.transition);
    }
    else
    {
        transition_time_ms = 0;
    }
    if (p_out != NULL)
    {
        p_out->present_lightness = p_app->state.present_lightness;
        p_out->target_lightness  = p_app->state.target_snapshot;
        p_out->remaining_time_ms = transition_time_ms;
    }
}
```

* App Lightness Transition回调
```
static void transition_complete_cb(const app_transition_t * p_transition)
{
    app_light_lightness_setup_server_t * p_app;
    p_app = transition_to_app(p_transition);
    app_transition_params_t * p_params = app_transition_ongoing_get(&p_app->state.transition);
    p_app->state.target_lightness = p_app->state.target_snapshot;
    if (p_params->transition_type != APP_TRANSITION_TYPE_MOVE_SET)
    {
        p_app->state.present_lightness = p_app->state.target_lightness;
    }
    present_lightness_set_with_range_clip(p_app);
    if (p_app->app_light_lightness_transition_cb != NULL)
    {
        p_app->app_light_lightness_transition_cb(p_app,
                    p_params->transition_time_ms,
                    p_app->state.target_lightness);
    }
    if (p_app->state.present_lightness >= LIGHT_LIGHTNESS_LAST_MIN)
    {
        light_lightness_mc_last_state_set(p_app->light_lightness_setup_server.state.handle,p_app->state.present_lightness,LIGHT_LIGHTNESS_MC_WRITE_DESTINATION_ALL);
    }
    light_lightness_mc_actual_state_set(p_app->light_lightness_setup_server.state.handle,p_app->state.present_lightness);
    //发布状态
    publish_lightness(p_app, 0);
}
static uint32_t publish_lightness(app_light_lightness_setup_server_t * p_app, uint32_t remaining_time_ms)
{
    light_lightness_status_params_t publication_data;
    light_lightness_server_t * p_light_lightness_srv;
    publication_data.present_lightness = p_app->state.present_lightness;
    publication_data.target_lightness  = p_app->state.target_lightness;
    publication_data.remaining_time_ms = remaining_time_ms;
    if (p_app->app_add_notify.app_add_publish_cb != NULL)
    {
        //通知被绑定状态进行发布，此例程被绑定状态是CTL
        p_app->app_add_notify.app_add_publish_cb(p_app->app_add_notify.p_app_publish_v, &publication_data);
    }
    p_light_lightness_srv = &p_app->light_lightness_setup_server.light_lightness_srv;
    return light_lightness_server_status_publish((const light_lightness_server_t * )p_light_lightness_srv, (const light_lightness_status_params_t *)&publication_data);
}
```

* CTL收到通知进行绑定状态发布
```
static void add_publish(const void * p_app_v, light_lightness_status_params_t * p_pub_data)
{
    app_light_ctl_temperature_duv_hw_state_t present_ctl_state;
    light_ctl_status_params_t publication_data;
    const app_light_ctl_setup_server_t * p_app = (app_light_ctl_setup_server_t *) p_app_v;
    if (p_app->light_ctl_setup_srv.state.initialized == false)
    {
        return;
    }
    if (p_app->ctl_state_set_active == false)
    {
        p_app->app_light_ctl_get_cb(p_app, &present_ctl_state);
        publication_data.present_lightness = p_pub_data->present_lightness;
        publication_data.target_lightness =  p_pub_data->target_lightness;
        publication_data.remaining_time_ms = p_pub_data->remaining_time_ms;
        publication_data.present_temperature32 = present_ctl_state.temperature32;
        publication_data.target_temperature32 = p_app->state.target_temperature32;
        //CTL状态发布
        light_ctl_server_status_publish(&p_app->light_ctl_setup_srv.ctl_srv, &publication_data);
    }
}
```

### 4.4.2. Light CTL Client
用户通过此例程可以测试Light CTL Message。   
代码结构和Generic Level Client例程类似。 参考 [Generic Level Client](#422-generic-level-client) 。


## 4.5. Light HSL
HSL是Hue Saturation Lightness的简写，是颜色的一种量化方式，也是RGB的另外一种表达形式，灯控中常常使用HSL表达颜色，因为HSL是一种自然颜色形成的表达形式。软件处理时先使用公式将HSL转换成RGB，然后再将R G B数值转换成PWM占空比控制RGB彩LED灯。
hsl(hue,saturation,lightness) 色调是色轮上从 0 到 360 的度数。0 是红色，120 是绿色，240 是蓝色。 饱和度是一个百分比值，0% 表示灰色阴影，100% 表示全色。 亮度也是一个百分比值，0% 为黑色，100% 为白色。
色调由可见光谱的主波长决定。 它是允许将颜色分类为红色、黄色、绿色、蓝色或中间色的属性。
饱和度与混合色调的白光量有关。
亮度是指强度，通过与色调混合的阴影量来区分。 当不同数量的两种原色光——红、绿和蓝原色——通过加法或减法机械组合时，可以产生任何所需的光色。
注解

<div align="center">
  <img src="_images/Color_Wheel.png">  
</div>  
</br>  

Hue就是色轮上的角度，Saturation是某个角度对中心点直线上的百分比（靠近中心点百分比越小，浓度越小），Lightness可以理解为显示器的背光。

测试方法 : 参考 [Generic Level](#42-generic-level) 。

注解:
HSL Server Model Publish地址配置成HSL Client Model所在的Element地址，HSL Client Model的Publish地址配置成HSL Server Model所在的Element地址，配置完后可以向Client板发串口命令1和2，Server板和Client板观察Log。 此实验做完后，可以配置HSL Server和HSL Client其它Model，并进行实验。

### 4.5.1. Light HSL Server
此例程实现SIG HSL模型，该模型参考 [Mesh Model Specification](https://www.bluetooth.com/specifications/specs/mesh-model-1-0-1/) 中HSL模型章节。
HSL Server模型继承Lightness Server模型，同时需要存在的模型还有HSL Hue，HSL Saturation，HSL Lightnesss和HSL Setup。
Generic Level状态绑定对应Element中，Hue状态，Saturation状态，和Lightness状态。
注解

状态绑定的意思是，当A状态改变时，被绑定的B状态也需要跟着改变，具体实现方法参考 [Light CTL Server](#light-ctl-server)。

### 4.5.2. Light HSL Client
用户通过此例程可以测试Light HSL Message。
代码结构和Generic Level Client例程类似。 参考 [Generic Level Client](#422-generic-level-client) 。

## 4.6. Light CTL HSL
此例程构建CTL+HSL简化模型，实现色温与色彩控制。
使用 nRF Mesh 配网，检查节点Model。

### 4.6.1. Light CTL HSL Server
此例程Model有，Generic OnOff Server，Light Lightness Server，Light HSL Server，Light CTL Server，Light CTL Temperature Server，Light CTL Setup Server。
