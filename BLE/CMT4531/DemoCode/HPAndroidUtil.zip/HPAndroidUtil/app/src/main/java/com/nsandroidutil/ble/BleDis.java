package com.hpandroidutil.ble;

import android.bluetooth.BluetoothDevice;
import android.content.Context;

import androidx.annotation.NonNull;

import com.hpandroidutil.event.BleMessageEvent;
import com.hpandroidutil.utility.Logger;

import org.greenrobot.eventbus.EventBus;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.locks.LockSupport;

import no.nordicsemi.android.ble.callback.SuccessCallback;

public class BleDis {




    private BleManager bleManager;

    public BleDis(@NonNull Context context, BleManager bleManager) {
        this.bleManager = bleManager;
    }

    private Thread thread;




    public void readDeviceInformation(){
        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                bleManager.readCharacteristic(bleManager.dis_manuf).done(new SuccessCallback() {
                    @Override
                    public void onRequestCompleted(@NonNull BluetoothDevice device) {
                        String str = new String(bleManager.dis_manuf.getValue(), StandardCharsets.US_ASCII);
                        EventBus.getDefault().post(new BleMessageEvent(BleMessageEvent.TYPE_DIS_INFO,bleManager.dis_manuf,str));
                        LockSupport.unpark(thread);
                    }
                }).enqueue();
                LockSupport.park(thread);
                bleManager.readCharacteristic(bleManager.dis_model).done(new SuccessCallback() {
                    @Override
                    public void onRequestCompleted(@NonNull BluetoothDevice device) {
                        String str = new String(bleManager.dis_model.getValue(), StandardCharsets.US_ASCII);
                        EventBus.getDefault().post(new BleMessageEvent(BleMessageEvent.TYPE_DIS_INFO,bleManager.dis_model,str));
                        LockSupport.unpark(thread);
                    }
                }).enqueue();
                LockSupport.park(thread);
                bleManager.readCharacteristic(bleManager.dis_serial).done(new SuccessCallback() {
                    @Override
                    public void onRequestCompleted(@NonNull BluetoothDevice device) {
                        String str = new String(bleManager.dis_serial.getValue(), StandardCharsets.US_ASCII);
                        EventBus.getDefault().post(new BleMessageEvent(BleMessageEvent.TYPE_DIS_INFO,bleManager.dis_serial,str));
                        LockSupport.unpark(thread);
                    }
                }).enqueue();
                LockSupport.park(thread);
                bleManager.readCharacteristic(bleManager.dis_hw).done(new SuccessCallback() {
                    @Override
                    public void onRequestCompleted(@NonNull BluetoothDevice device) {
                        String str = new String(bleManager.dis_hw.getValue(), StandardCharsets.US_ASCII);
                        EventBus.getDefault().post(new BleMessageEvent(BleMessageEvent.TYPE_DIS_INFO,bleManager.dis_hw,str));
                        LockSupport.unpark(thread);
                    }
                }).enqueue();
                LockSupport.park(thread);
                bleManager.readCharacteristic(bleManager.dis_fw).done(new SuccessCallback() {
                    @Override
                    public void onRequestCompleted(@NonNull BluetoothDevice device) {
                        String str = new String(bleManager.dis_fw.getValue(), StandardCharsets.US_ASCII);
                        EventBus.getDefault().post(new BleMessageEvent(BleMessageEvent.TYPE_DIS_INFO,bleManager.dis_fw,str));
                        LockSupport.unpark(thread);
                    }
                }).enqueue();
                LockSupport.park(thread);
                bleManager.readCharacteristic(bleManager.dis_sw).done(new SuccessCallback() {
                    @Override
                    public void onRequestCompleted(@NonNull BluetoothDevice device) {
                        String str = new String(bleManager.dis_sw.getValue(), StandardCharsets.US_ASCII);
                        EventBus.getDefault().post(new BleMessageEvent(BleMessageEvent.TYPE_DIS_INFO,bleManager.dis_sw,str));
                        LockSupport.unpark(thread);
                    }
                }).enqueue();
                LockSupport.park(thread);
            }
        });




        thread.start();

    }




}
