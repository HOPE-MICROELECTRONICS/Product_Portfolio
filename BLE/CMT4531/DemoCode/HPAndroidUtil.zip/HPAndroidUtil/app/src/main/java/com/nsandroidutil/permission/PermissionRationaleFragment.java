package com.hpandroidutil.permission;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.hpandroidutil.R;


public class PermissionRationaleFragment extends DialogFragment {

    private static final String ARG_PERMISSION = "ARG_PERMISSION";
    private static final String ARG_TEXT = "ARG_TEXT";

    private PermissionDialogListener mListener;
    public interface PermissionDialogListener {
        void onRequestPermissionGranted(final String permission);
        void onRequestPermissionDenied(final String permission);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof PermissionDialogListener) {
            mListener = (PermissionDialogListener) context;
        } else {
            throw new IllegalArgumentException("The parent activity must impelemnt PermissionDialogListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
    
    public static PermissionRationaleFragment getInstance(final int aboutResId, final String permission){
        final PermissionRationaleFragment fragment = new PermissionRationaleFragment();
        
        final Bundle args = new Bundle();
        args.putInt(ARG_TEXT, aboutResId);
        args.putString(ARG_PERMISSION, permission);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Bundle args = getArguments();
        final StringBuilder text = new StringBuilder(getString(args.getInt(ARG_TEXT)));

        AlertDialog alertDialog = new AlertDialog.Builder(getActivity())
                .setTitle(R.string.permission_title)
                .setMessage(text)
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mListener.onRequestPermissionDenied(args.getString(ARG_PERMISSION));
                    }
                })
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mListener.onRequestPermissionGranted(args.getString(ARG_PERMISSION));
                    }
                })
                .create();
        return alertDialog;
        
    }


}
