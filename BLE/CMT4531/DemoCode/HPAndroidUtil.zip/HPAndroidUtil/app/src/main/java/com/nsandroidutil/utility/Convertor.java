package com.hpandroidutil.utility;

public class Convertor {



    public static String byte2HexStr(byte[] b)
    {
        String stmp="";
        StringBuilder sb = new StringBuilder("");
        for (int n=0;n<b.length;n++)
        {
            stmp = Integer.toHexString(b[n] & 0xFF);
            sb.append((stmp.length()==1)? "0"+stmp : stmp);
            sb.append(" ");
        }
        return sb.toString().toUpperCase().trim();
    }

    public static int bytesToInt(byte[] bs) {

        int int1=bs[3]&0xff;
        int int2=(bs[2]&0xff)<<8;
        int int3=(bs[1]&0xff)<<16;
        int int4=(bs[0]&0xff)<<24;

        return int1|int2|int3|int4;
    }
    public static int bytesToShort(byte[] bs) {

        int int1=bs[1]&0xff;
        int int2=(bs[0]&0xff)<<8;

        return int1|int2;
    }


}
