package com.hpandroidutil.utility;

public class CRC16 {





    public static int fast(byte[] pvData){

        int crc16 = 0;
        int i = 0, j = 0;

        for (i = 0; i < pvData.length; i++)
        {
            crc16 ^= (pvData[i] << 8) & 0xFFFF;
            for (j = 0; j < 8; j++)
            {
                if ((crc16 & 0x8000) > 0)
                {
                    crc16 = ((crc16 << 1) ^ 0x8005) & 0xFFFF;
                }
                else
                {
                    crc16 <<= 1;
                }
            }
        }

        return crc16;
    }







}
