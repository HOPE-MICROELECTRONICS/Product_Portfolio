package com.hpandroidutil.utility;

import android.util.Log;

import com.hpandroidutil.BuildConfig;


public class Logger {

    public static final String FILE_TAG = "FILE";;
    public static String PERMISSION_TAG = "PERMISSION";
    public static String BLE_TAG = "BLE";
    public static String DAILY_DATA_TAG = "DAILY_DATA";

    public static void v(final String tag, final String text) {
        if (BuildConfig.DEBUG)
            Log.v(tag, text);
    }

    public static void d(final String tag, final String text) {
        if (BuildConfig.DEBUG) {
            Log.d(tag, text);
        }
    }

    public static void i(final String tag, final String text) {
        if (BuildConfig.DEBUG)
            Log.i(tag, text);
    }

    public static void w(final String tag, final String text) {
        if (BuildConfig.DEBUG) {
            Log.w(tag, text);
        }
    }

    public static void e(final String tag, final String text) {
        if (BuildConfig.DEBUG)
            Log.e(tag, text);
    }

    public static void e(final String tag, final String text, final Throwable e) {
        if (BuildConfig.DEBUG)
            Log.e(tag, text, e);
    }

    public static void wtf(final String tag, final String text) {
        if (BuildConfig.DEBUG) {
            Log.wtf(tag, text);
        }
    }

    public static void wtf(final String tag, final String text, final Throwable e) {
        if (BuildConfig.DEBUG) {
            Log.wtf(tag, text, e);
        }
    }
    private static String byte2HexStr(byte[] b)
    {
        String stmp="";
        StringBuilder sb = new StringBuilder("");
        for (int n=0;n<b.length;n++)
        {
            stmp = Integer.toHexString(b[n] & 0xFF);
            sb.append((stmp.length()==1)? "0"+stmp : stmp);
            sb.append(" ");
        }
        return sb.toString().toUpperCase().trim();
    }
    public static void i(final String tag, final byte[] b) {
        if (BuildConfig.DEBUG)
            Log.i(tag, byte2HexStr(b));
    }



}
