package com.hpandroidutil.event;

import android.bluetooth.BluetoothGattCharacteristic;

public class BleMessageEvent {


    public static final int TYPE_MTU_UPDATE = 1;
    public static final int TYPE_OTA_ERROR_MESSAGE = 2;
    public static final int TYPE_OTA_MESSAGE = 3;
    public static final int TYPE_OTA_FINISH = 4;
    public static final int TYPE_OTA_CONFIG_FILE = 5;
    public static final int TYPE_DIS_INFO = 6;
    public static final int TYPE_OTA_PROGRESS = 7;
    public static final int TYPE_OTA_ALERT_NOTIFY = 8;
    public static final int TYPE_ATM_UPDATE_GRAPH = 9;
    public static final int TYPE_OTA_CONFIG_FILE_ERROR = 10;


    public int type;
    public int number;
    public String errorMessage;
    public int errorCode;
    public String message;
    public BluetoothGattCharacteristic chara;
    public String deviceInfoVaule;
    public float fValue;
    public float fTime;

    public BleMessageEvent(int type, int number) {
        this.type = type;
        this.number = number;
    }
    public BleMessageEvent(int type, float fValue, float fTime) {
        this.type = type;
        this.fValue = fValue;
        this.fTime = fTime;
    }
    public BleMessageEvent(int type) {
        this.type = type;
    }

    public BleMessageEvent(int type, String message) {
        this.type = type;
        this.message = message;
    }
    public BleMessageEvent(int type, String errorMessage, int errorCode) {
        this.type = type;
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
    }
    public BleMessageEvent(int type, BluetoothGattCharacteristic chara, String value){
        this.type = type;
        this.chara = chara;
        this.deviceInfoVaule = value;
    }



}
